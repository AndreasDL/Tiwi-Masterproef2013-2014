package be.iminds.ilabt.jfed.lowlevel.resourceid;

/**
* ResourceId
*/
public interface ResourceId {
    public String getType();
    public String getValue();
}