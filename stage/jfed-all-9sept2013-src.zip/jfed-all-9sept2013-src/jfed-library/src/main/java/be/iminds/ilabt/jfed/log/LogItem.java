package be.iminds.ilabt.jfed.log;

/**
 * LogItem
 */
public class LogItem {
}
