package be.iminds.ilabt.jfed.highlevel.api;

/**
 * EasyContextListener
 */
@Deprecated
public interface EasyContextListener {
    public void onEasyContextChange();
}
