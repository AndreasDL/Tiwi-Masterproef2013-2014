xjc -p be.iminds.ilabt.vwall.sfa.client.rspec.manifest.geni_rspec_3 -d manifest/geni_rspec_3 manifest.xsd
