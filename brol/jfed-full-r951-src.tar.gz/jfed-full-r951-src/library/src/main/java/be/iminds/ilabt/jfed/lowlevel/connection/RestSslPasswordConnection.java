package be.iminds.ilabt.jfed.lowlevel.connection;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.authority.DebuggingAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniTrustStoreHelper;
import be.iminds.ilabt.jfed.util.SocksProxyHelper;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpParams;
import org.apache.logging.log4j.LogManager;

import java.net.MalformedURLException;
import java.net.URL;
import java.security.*;

/**
 * SfaSslConnection: SSL HTTP
 */
public class RestSslPasswordConnection extends JFedConnection {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    private DefaultHttpClient httpClient;

    /**
     * //@param allowedCertificateHostnameAliases may be null or empty
     * @throws be.iminds.ilabt.jfed.lowlevel.JFedException
     */
    public RestSslPasswordConnection(SfaAuthority geniAuthority, String serverUrlStr, ProxyInfo proxyInfo, boolean debugMode, String username, String password) throws JFedException {
        super(geniAuthority, serverUrlStr, proxyInfo, debugMode);

        LOG.debug("initialising RestSslPasswordConnection for "+username+" to "+serverUrlStr);

        error = true;
        this.debugMode = debugMode;

        this.geniAuthority = geniAuthority;

        if (geniAuthority != null && DebuggingAuthorityList.isDebuggingAuth(geniAuthority)) {
            fakeForDebugging = true;
            error = false;
            return;
        }

        if (serverUrlStr == null) throw new IllegalArgumentException("Illegal argument: serverURL == null");


        URL serverUrl;
        try {
            serverUrl = new URL(serverUrlStr);
        } catch (MalformedURLException e) {
            LOG.error("ERROR: MalformedURLException url=\""+serverUrlStr+"\"", e);
            error = true;
            return;
        }

        HttpParams params = new BasicHttpParams();
        params.setParameter(CoreConnectionPNames.SO_TIMEOUT, 120000); //read timeout in ms (default: 0 = infinite)   (long timeout, as some calls take time to finish)
        params.setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 10000); //connection timeout in ms (default: 0 = infinite)

        if (System.getProperty("proxySet") != null &&
                System.getProperty("proxySet").equals("true") &&
                System.getProperty("socksProxyHost") != null)
            httpClient = SocksProxyHelper.getHttpClientOverSocksProxy(params);
        else
            httpClient = new DefaultHttpClient(params);

        String algo = SSLSocketFactory.TLS;
        java.security.SecureRandom random = new SecureRandom();


        if (geniAuthority != null && geniAuthority.getPemSslTrustCert() != null)
            GeniTrustStoreHelper.addTrustedPemCertificateIfNotAdded(geniAuthority.getPemSslTrustCert());
        KeyStore trustStore = GeniTrustStoreHelper.getFullTrustStore();

        SSLSocketFactory socketFactory = null;
        try {
            socketFactory = new SSLSocketFactory(trustStore);
        } catch (Exception e) {
            LOG.error("error creating SSLSocketFactory", e);
            throw new RuntimeException(e);
        }
        Scheme sch1 = new Scheme("https", 443, socketFactory); //port is the default port for the given protocol
        httpClient.getConnectionManager().getSchemeRegistry().register(sch1);








        int port = serverUrl.getPort();
        if (serverUrl.getPort() <= 0) port = serverUrl.getDefaultPort();
        httpClient.getCredentialsProvider().setCredentials(
                new AuthScope(serverUrl.getHost(), port),
                new UsernamePasswordCredentials(username, password));

        LOG.debug("Constructed RestSslPasswordConnection");
        error = false;
    }


    public DefaultHttpClient getHttpClient() {
        assert !fakeForDebugging : "Error: This connection is a fake debugging connection, yet the httpClient was requested";
        return httpClient;
    }

}