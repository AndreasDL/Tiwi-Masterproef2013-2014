package be.iminds.ilabt.jfed.lowlevel.connection;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.authority.DebuggingAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniTrustStoreHelper;
import org.apache.xmlrpc.XmlRpcClient;

import java.net.URL;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.LinkedList;
import java.util.List;

/**
 * SfaSslConnection: XmlRpc over HTTPs
 */
public class SfaSslConnection extends SfaConnection {
    private CommonsHttpClientXmlRpcTransportFactory xmlRpcTransportFactory;
    private XmlRpcClient xmlRpcClient;

    /**
     * @param clientCertificateChain the X509Certificates to use for the SSL connection
     * @param privateKey PrivateKey to use for client authentication of the SSL connection
     * //@param allowedCertificateHostnameAliases may be null or empty
     * @throws be.iminds.ilabt.jfed.lowlevel.JFedException
     */
    public SfaSslConnection(SfaAuthority geniAuthority, String serverUrl, List<X509Certificate> clientCertificateChain,
                            PrivateKey privateKey,
                            ProxyInfo proxyInfo,
                            boolean debugMode, HttpsClientWithUserAuthenticationFactory.HandleUntrustedCallback handleUntrustedCallback) throws JFedException {
        super(geniAuthority, serverUrl, proxyInfo, debugMode);

        error = true;
        this.debugMode = debugMode;

        this.geniAuthority = geniAuthority;

        if (geniAuthority != null && DebuggingAuthorityList.isDebuggingAuth(geniAuthority)) {
            fakeForDebugging = true;
            error = false;
            this.serverUrl = serverUrl;
            return;
        }

        if (serverUrl == null) throw new IllegalArgumentException("Illegal argument: serverURL == null");
        if (clientCertificateChain == null) throw new IllegalArgumentException("Illegal argument: clientCertificateChain == null");
        if (clientCertificateChain.isEmpty()) throw new IllegalArgumentException("Illegal argument: clientCertificateChain is empty");
        if (privateKey == null) throw new IllegalArgumentException("Illegal argument: privateKey == null");

        this.serverUrl = serverUrl;

        if (geniAuthority != null && geniAuthority.getPemSslTrustCert() != null)
            GeniTrustStoreHelper.addTrustedPemCertificateIfNotAdded(geniAuthority.getPemSslTrustCert());
        KeyStore trustStore = GeniTrustStoreHelper.getFullTrustStore();

        xmlRpcTransportFactory = new ClientSslAuthenticationXmlRpcTransportFactory(
                proxyInfo,
                clientCertificateChain,
                privateKey,
                serverUrl,
                trustStore,
                geniAuthority == null ? new LinkedList<String>() : geniAuthority.getAllowedCertificateHostnameAliases(),
                debugMode, handleUntrustedCallback);
        try {
            xmlRpcClient = new XmlRpcClient(new URL(serverUrl), xmlRpcTransportFactory);
            error = false;
        } catch (Exception e) {
            throw new JFedException("Error creating XmlRpcClient in GeniConnection constructor: "+e.getMessage(), e);
        }
    }

    @Override
    public CommonsHttpClientXmlRpcTransportFactory getXmlRpcTransportFactory() {
        assert !fakeForDebugging : "Error: This connection is a fake debugging connection, yet the CommonsHttpClientXmlRpcTransportFactory was requested";
        return xmlRpcTransportFactory;
    }

    @Override
    public XmlRpcClient getXmlRpcClient() {
        assert !fakeForDebugging : "Error: This connection is a fake debugging connection, yet the XmlRpcClient was requested";
        return xmlRpcClient;
    }
}