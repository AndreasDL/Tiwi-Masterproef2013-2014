package be.iminds.ilabt.jfed.lowlevel.stitching;

import org.apache.logging.log4j.LogManager;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.*;

/**
 * StitchingHopData contains all available data about a stitching hop
 * This data comes from:
 *    - Rspec stitching extension
 *    - SCS call workflow
 *
 * The hop URN+linkName is the unique identifier that binds the 2 data sources.
 *
 * It also stores dependencies to other StitchingHopData. To create:
 *    - first create it, by giving workflowdata and full Rspec
 *    - then optionally process additional workflow data of this same hop,
 *    - and then call linkDeps
 */
public class StitchingHopData {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    //workflow data
    private final String linkName;
    private final String hopUrn;
    private final String aggregateUrn;
    private final String aggregateUrl;
    private final Boolean importVlans;

    //rspec data
    private Element hopElement;
    private Element scSpecificInfo_L2scEl;
    private String hopElId;
    private String vlanRangeAvailability;
    private String suggestedVLANRange;

    //dependencies in workflow(s)
    private List<Hashtable> rawDependencies = new ArrayList<Hashtable>();

    //links (initialised after linkDeps call)
    private List<StitchingHopData> dependencies = new ArrayList<StitchingHopData>();
    private List<StitchingHopData> dependingOnThis = new ArrayList<StitchingHopData>();


    public StitchingHopData(String linkName, Hashtable workflowData, Element stitchingElement) {
        this.linkName = linkName;
        hopUrn = (String) workflowData.get("hop_urn");
        assert hopUrn != null;

        aggregateUrn = (String) workflowData.get("aggregate_urn");
        aggregateUrl = (String) workflowData.get("aggregate_url");
        importVlans = (Boolean) workflowData.get("import_vlans");

        if (workflowData.get("dependencies") != null) {
            Vector dependenciesVector = (Vector) workflowData.get("dependencies");
            for (Object o : dependenciesVector)
                rawDependencies.add((Hashtable) o);
        }

        //search for matching rspec hop data
        processRspecElement(stitchingElement);
    }

    public void processExtraWorkflowData(String linkName, Hashtable workflowData) {
        assert this.linkName.equals(linkName);
        String otherHopUrn = (String) workflowData.get("hop_urn");
        assert otherHopUrn != null;
        assert otherHopUrn.equals(hopUrn);

        String otherAggregateUrn = (String) workflowData.get("aggregate_urn");
        String otherAggregateUrl = (String) workflowData.get("aggregate_url");
        Boolean otherImportVlans = (Boolean) workflowData.get("import_vlans");
        assert otherAggregateUrn.equals(aggregateUrn);
        assert otherAggregateUrl.equals(aggregateUrl);
        assert otherImportVlans.equals(importVlans);

        assert  (workflowData.get("dependencies") == null);
    }

    public void linkDeps(Collection<StitchingHopData> allData) {
        for (Hashtable workflowData : rawDependencies) {
            String depHopUrn = (String) workflowData.get("hop_urn");

            for (StitchingHopData other : allData)
                if (other.hopUrn.equals(depHopUrn) && other.linkName.equals(linkName)) {
                    if (!dependencies.contains(other)) {
                        dependencies.add(other);
                        other.dependingOnThis.add(this);
                    }
                }
        }
    }



    void overwriteWithManifestRspec(String manifestRspec) {
        this.hopElement = null;

        Element stitchingElement = StitchingData.extractStitchingElementFromRspec(manifestRspec);

        processRspecElement(stitchingElement);
    }

    void processRspecElement(Element stitchingElement) {
        assert this.hopElement == null :
                "Bug: clear this.hopElement before calling to acknowledge overwrite";

        //search for matching rspec hop data
        List<Element> pathEls = quickDomChildrenHelper(stitchingElement, "path");
        for (Element pathEl : pathEls) {
            String linkId = pathEl.getAttribute("id");
            assert linkId != null : "<stitching> has <path> element without id attribute: "+pathEl;

            if (!linkId.equals(linkName))
                continue;

            NodeList hopList = pathEl.getElementsByTagName("hop");
            for (int i = 0; i < hopList.getLength(); i++) {
                Node hopNode = hopList.item(i);
                assert hopNode != null;
                assert hopNode.getNodeType() == Node.ELEMENT_NODE;
                Element hopElement = (Element) hopNode;

                Element linkEl = quickDomChildHelper(hopElement, "link");

                String linkIdUrn = linkEl.getAttribute("id");
                if (!linkIdUrn.equals(hopUrn))
                    continue;

                assert this.hopElement == null :
                        "Found multiple <link> in rspec matching path id=\""+linkName+"\"  hop urn=\""+hopUrn+"\"";

                Element scDescriptorEl = quickDomChildHelper(linkEl, "switchingCapabilityDescriptor");
                Element scSpecificInfoEl = quickDomChildHelper(scDescriptorEl, "switchingCapabilitySpecificInfo");
                this.scSpecificInfo_L2scEl = quickDomChildHelper(scSpecificInfoEl, "switchingCapabilitySpecificInfo_L2sc");
                Element vlanRangeAvailabilityEl = quickDomChildHelper(scSpecificInfo_L2scEl, "vlanRangeAvailability");
                Element suggestedVLANRangeEl = quickDomChildHelper(scSpecificInfo_L2scEl, "suggestedVLANRange");

                this.hopElId = hopElement.getAttribute("id");
                this.vlanRangeAvailability = vlanRangeAvailabilityEl.getTextContent();
                this.suggestedVLANRange = suggestedVLANRangeEl.getTextContent();

                this.hopElement = hopElement;
            }
        }

        assert this.hopElement != null :
                "Found NO <link> in rspec matching path id=\""+linkName+"\"  hop urn=\""+hopUrn+"\"";
    }






    /**
     *  returns found new VLAN or null if none found
     *
     * if none is found, nothing is updated!
     */
    public Integer updateSuggestedVlan(Set<Integer> unavailableVlans) {
        logger.entry(this.getHopUrn(), unavailableVlans);

        VlanRangeHelper range = new VlanRangeHelper(getVlanRangeAvailability());

        Integer vlan = range.getCurrent();
        while (vlan != null) {
            if (!unavailableVlans.contains(vlan)) {
                suggestedVLANRange = vlan+"";
                logger.debug("Chose vlan "+vlan);
                return vlan;
            }

            vlan = range.getNext();
        }

        return null;
    }




    //Getters
    public List<StitchingHopData> getDependencies() {
        return dependencies;
    }
    public List<StitchingHopData> getDependingOnThis() {
        return dependingOnThis;
    }
    public String getLinkName() {
        return linkName;
    }
    public String getHopUrn() {
        return hopUrn;
    }
    public String getAggregateUrn() {
        return aggregateUrn;
    }
    public String getAggregateUrl() {
        return aggregateUrl;
    }
    public Boolean getImportVlans() {
        return importVlans;
    }


    public String getVlanRangeAvailability() {
        return vlanRangeAvailability;
    }
    public String getSuggestedVlanRange() {
        return suggestedVLANRange;
    }
    public Integer getSuggestedVlan() {
        return Integer.parseInt(suggestedVLANRange);
    }
    public String getRspecStitchingHopId() {
        return hopElId;
    }
    public Element getRspecStitchingHopElement() {
        Element vlanRangeAvailabilityEl = quickDomChildHelper(scSpecificInfo_L2scEl, "vlanRangeAvailability");
        Element suggestedVLANRangeEl = quickDomChildHelper(scSpecificInfo_L2scEl, "suggestedVLANRange");
        vlanRangeAvailabilityEl.setTextContent(vlanRangeAvailability);
        logger.debug("set rspec suggestedVLANRangeEl to "+suggestedVLANRange);
        suggestedVLANRangeEl.setTextContent(suggestedVLANRange);

        return hopElement;
    }

    //link name and hop URN uniquely identify this object
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StitchingHopData that = (StitchingHopData) o;

        if (!hopUrn.equals(that.hopUrn)) return false;
        if (!linkName.equals(that.linkName)) return false;

        return true;
    }
    @Override
    public int hashCode() {
        int result = linkName.hashCode();
        result = 31 * result + hopUrn.hashCode();
        return result;
    }





    private static Element quickDomChildHelper(Element e, String tagName) {
        NodeList resList = e.getElementsByTagName(tagName);
        assert resList.getLength() == 1;
        Node resNode = resList.item(0);
        assert resNode != null;
        assert resNode.getNodeType() == Node.ELEMENT_NODE;
        Element resElement = (Element) resNode;
        return resElement;
    }
    private static List<Element> quickDomChildrenHelper(Element e, String tagName) {
        NodeList resList = e.getElementsByTagName(tagName);
        List<Element> resElements = new ArrayList<Element>();
        for (int i = 0 ; i < resList.getLength(); i++) {
            Node resNode = resList.item(i);
            assert resNode != null;
            assert resNode.getNodeType() == Node.ELEMENT_NODE;
            Element resElement = (Element) resNode;
            resElements.add(resElement);
        }
        return resElements;
    }

    @Override
    public String toString() {
        List<String> depUrns = new ArrayList<String>();
        for (StitchingHopData stitchingHopData : dependencies)
            depUrns.add(stitchingHopData.linkName+" "+stitchingHopData.getHopUrn());

        return "StitchingHopData{" +
                "linkName='" + linkName + '\'' +
                ", hopUrn='" + hopUrn + '\'' +
                ", aggregateUrn='" + aggregateUrn + '\'' +
                ", aggregateUrl='" + aggregateUrl + '\'' +
                ", importVlans=" + importVlans +
                ", vlanRangeAvailability='" + vlanRangeAvailability + '\'' +
                ", suggestedVLANRange='" + suggestedVLANRange + '\'' +
                ", dependencies (link+urn)=" + depUrns +
                '}';
    }
}
