package be.iminds.ilabt.jfed.lowlevel;

import be.iminds.ilabt.jfed.util.GeniTrustStoreHelper;
import be.iminds.ilabt.jfed.util.X509KeySelector;
import org.w3c.dom.*;
import org.xml.sax.InputSource;

import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;

/**
 * <p>AnyCredential is a wrapper for any XML Credential.
 *
 * <p>It does not parse anything as the format is unknown <p>A name is stored alongside the actual credential, which is useful for listing the credential in GUI lists and comboboxes.
 *
 */
public class AnyCredential {
    protected String name;
    protected String credentialXml;

    //see Geni Aggregate Manager API v3: http://groups.geni.net/geni/wiki/GAPI_AM_API_V3/CommonConcepts#credentials
    protected String type;
    protected String version;

    protected AnyCredential(String name, String credentialXml, String type, String version) {
        this.name = name;
        this.credentialXml = credentialXml;
        this.type = type;
        this.version = version;

        if (credentialXml == null) throw new RuntimeException("AnyCredential credentialXml may not be null");
    }

    /** Pre Geni API v3 credentials: type=geni_sfa version=2 */
    public static AnyCredential create(String name, String credentialXml) throws CredentialException {
        return new SfaCredential(name, credentialXml, "geni_sfa", "2");
    }
    public static AnyCredential create(String name, String credentialXml, String type, String version) throws CredentialException {
        if (type.equalsIgnoreCase("sfa") && type.equalsIgnoreCase("geni_sfa"))
            return new SfaCredential(name, credentialXml, type, version);

        if (type.equalsIgnoreCase("abac") && type.equalsIgnoreCase("geni_abac"))
            return new AbacCredential(name, credentialXml, type, version);

        return new AnyCredential(name, credentialXml, type, version);
    }

    public static AnyCredential createFromV3Hashtable(String credName, Hashtable ht) throws BadReplyGeniException, CredentialException {
        Object geniTypeO = ht.get("geni_type");
        Object geniVersionO = ht.get("geni_version");
        Object genivalueO = ht.get("geni_value");

        if (geniTypeO == null || geniVersionO== null || genivalueO == null)
            throw new BadReplyGeniException("The API specified a Vector of Hashtables sepcifying credentials. These must contain the keys geni_type, geni_version and geni_value." +
                    " At least one of these is missing. Hashtable content: "+ht);

        if (!(geniTypeO instanceof String))
            throw new BadReplyGeniException("The API specified a credential, but the geni_type field of the Hashtable is of type "+geniTypeO.getClass().getName()+" instead of String. value="+geniTypeO);

        if (!(geniVersionO instanceof Integer) && !(geniVersionO instanceof String))
            throw new BadReplyGeniException("The API specified a credential, but the geni_version field of the Hashtable is of type "+geniVersionO.getClass().getName()+" instead of String with Integer. value="+geniVersionO);

        if (!(genivalueO instanceof String))
            throw new BadReplyGeniException("The API specified a credential, but the geni_value field of the Hashtable is of type "+genivalueO.getClass().getName()+" instead of String. value="+genivalueO);

        return create(credName, (String)genivalueO, (String)geniTypeO, geniVersionO.toString());
    }


    public String getCredentialXml() {
        assert credentialXml != null;
        return credentialXml;
    }

    public String getType() {
        return type;
    }

    public String getVersion() {
        return version;
    }

    public Hashtable getGeniV3Hashtable() {
        Hashtable res = new Hashtable();
        res.put("geni_type", type);
        res.put("geni_version", version);
        assert credentialXml != null;
        res.put("geni_value", credentialXml);
        return res;
    }

    public String getName() {
        return name;
    }

    public String getExpires() { return null; }
    public Date getExpiresDate() { return null; }

    @Override
    public String toString() {
        return credentialXml;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AnyCredential that = (AnyCredential) o;

        if (!credentialXml.equals(that.credentialXml)) return false;
        if (!name.equals(that.name)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = name.hashCode();
        result = 31 * result + credentialXml.hashCode();
        return result;
    }
}
