package be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.GeniUserProvider;
import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.ServerType;
import be.iminds.ilabt.jfed.lowlevel.api.AbstractGeniAggregateManager;
import be.iminds.ilabt.jfed.lowlevel.api.AggregateManager3;
import be.iminds.ilabt.jfed.lowlevel.api.UserSpec;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.AggregateManagerWrapper;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.RFC3339Util;
import org.apache.logging.log4j.LogManager;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * AMv3Wrapper
 */
public class AMv3Wrapper extends AggregateManagerWrapper {
    private final static org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    private AggregateManager3 am3;

    protected AMv3Wrapper(Logger logger, GeniUserProvider geniUserProvider, GeniConnectionProvider connectionProvider, SfaAuthority amAuthority) {
        super(logger, geniUserProvider, connectionProvider, amAuthority);

        am3 = new AggregateManager3(logger, true);
    }

    protected SfaConnection getConnection() throws JFedException {
        return (SfaConnection)getConnection(new ServerType(ServerType.GeniServerRole.AM, 3));
    }

    @Override
    public void getVersion() throws JFedException {
        AbstractGeniAggregateManager.AggregateManagerReply<AggregateManager3.VersionInfo> reply =
                am3.getVersion(getConnection());

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("GetVersion Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
        }
    }

    @Override
    public String listResources(AnyCredential userCredential, boolean available) throws JFedException {
        AbstractGeniAggregateManager.AggregateManagerReply<String> reply = am3.listResources(
                getConnection(),
                toCredentialList(userCredential),
                "geni", "3",
                available, true/*compressed*/,
                null/*extra_options*/);

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("ListResources Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
//            return null;
        }

        return reply.getValue();
    }

    @Override
    public String createSliver(GeniUrn sliceUrn, AnyCredential sliceCredential, String rspec, List<UserSpec> users, Date expirationDate) throws JFedException {
        String endTime = RFC3339Util.dateToRFC3339String(expirationDate, true, true, true); //most compatible date format

        AbstractGeniAggregateManager.AggregateManagerReply<AggregateManager3.AllocateAndProvisionInfo> replyAllocate = am3.allocate(
                getConnection(),
                toCredentialList(sliceCredential),
                sliceUrn.getValue(), rspec,
                endTime, null/*extra_options*/);
        if (!replyAllocate.getGeniResponseCode().isSuccess()) {
            throw new JFedException("Allocate Call not successful", replyAllocate.getXMLRPCCallDetailsGeni(), replyAllocate.getGeniResponseCode());
//            return null;
        }

        List<String> urns = new ArrayList<String>();
        urns.add(sliceUrn.getValue());
        AbstractGeniAggregateManager.AggregateManagerReply<AggregateManager3.AllocateAndProvisionInfo> replyProvision = am3.provision(
                getConnection(),
                urns,
                toCredentialList(sliceCredential),
                "geni", "3",
                null/*besteffort*/,
                endTime, users, null/*extra_options*/);
        if (!replyProvision.getGeniResponseCode().isSuccess()) {
            throw new JFedException("Allocate Call not successful", replyProvision.getXMLRPCCallDetailsGeni(), replyProvision.getGeniResponseCode());
//            return null;
        }

        AbstractGeniAggregateManager.AggregateManagerReply<List<AggregateManager3.SliverInfo>> replyPerfOpAction = am3.performOperationalAction(
                getConnection(),
                urns,
                toCredentialList(sliceCredential),
                "geni_start", null/*besteffort*/,
                null/*extra_options*/);
        if (!replyPerfOpAction.getGeniResponseCode().isSuccess()) {
            throw new JFedException("Allocate Call not successful", replyPerfOpAction.getXMLRPCCallDetailsGeni(), replyPerfOpAction.getGeniResponseCode());
//            return null;
        }
        return replyAllocate.getValue().getRspec();
    }

    @Override
    public void deleteSliver(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException {
        List<String> urns = new ArrayList<String>();
        urns.add(sliceUrn.getValue());

        AbstractGeniAggregateManager.AggregateManagerReply<List<AggregateManager3.SliverInfo>> reply = am3.delete(
                getConnection(),
                urns,
                toCredentialList(sliceCredential),
                null/*best effort*/,
                null/*extra_options*/);

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("Delete Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
            //            return null;
        }
    }

    @Override
    public SliverStatus status(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException {
        List<String> urns = new ArrayList<String>();
        urns.add(sliceUrn.getValue());

        AbstractGeniAggregateManager.AggregateManagerReply<AggregateManager3.StatusInfo> reply = am3.status(
                getConnection(),
                urns,
                toCredentialList(sliceCredential),
                null/*best effort*/,
                null/*extra_options*/);

        AggregateManager3.StatusInfo status = reply.getValue();
        if (status.getSliverInfo().isEmpty()) return SliverStatus.UNALLOCATED; //no slivers
        assert status.getSliverInfo().size() == 1 : "Multiple slivers are not supported in AMv3Wrapper at the moment";
        AggregateManager3.SliverInfo sliverInfo = status.getSliverInfo().get(0);

        if ((!reply.getGeniResponseCode().isSuccess()) || status == null) {
            throw new JFedException("Status Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
            //            return null;
        }

        String operationalStatus = sliverInfo.getOperationalStatus();

        //allocation states come first, only for the "geni_provisioned" state, we need to look at the operational state
        if (sliverInfo.getAllocationStatus().equalsIgnoreCase("geni_unallocated")) return SliverStatus.UNALLOCATED;
        if (sliverInfo.getAllocationStatus().equalsIgnoreCase("geni_allocated")) return SliverStatus.CHANGING; //actually, this means "unallocated" in SliverStatus terminology :-)
//        if (sliverInfo.getAllocationStatus().equalsIgnoreCase("geni_provisioned")) return SliverStatus.CHANGING;

        //AM API v3 defined operatinoal states  (AMv3Wrapper does not currently support extra operational states advertised in RSpec advertisement)
        if (operationalStatus.equalsIgnoreCase("geni_pending_allocation")) return SliverStatus.CHANGING;
        if (operationalStatus.equalsIgnoreCase("geni_notready")) return SliverStatus.CHANGING;
        if (operationalStatus.equalsIgnoreCase("geni_configuring")) return SliverStatus.CHANGING;
        if (operationalStatus.equalsIgnoreCase("geni_stopping")) return SliverStatus.CHANGING;
        if (operationalStatus.equalsIgnoreCase("geni_ready")) return SliverStatus.READY;
        if (operationalStatus.equalsIgnoreCase("geni_ready_busy")) return SliverStatus.READY;
        if (operationalStatus.equalsIgnoreCase("geni_failed")) return SliverStatus.FAIL;

        LOG.warn("Server returned unknown sliver operationalStatus: \"" + operationalStatus + "\"  (allocationStatus="+sliverInfo.getAllocationStatus()+")");
        return SliverStatus.UNKNOWN;
    }

    @Override
    public String describe(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException  {
        List<String> urns = new ArrayList<String>();
        urns.add(sliceUrn.getValue());

        AbstractGeniAggregateManager.AggregateManagerReply<AggregateManager3.ManifestInfo> reply = am3.describe(
                getConnection(),
                urns,
                toCredentialList(sliceCredential),
                "geni", "3", true/*compressed*/,
                null/*extra_options*/);

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("ListResources Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
            //            return null;
        }

        return reply.getValue().getManifestRspec();
    }

    @Override
    public void renewSliver(GeniUrn sliceUrn, AnyCredential sliceCredential, Date newExpire) throws JFedException {
        List<String> urns = new ArrayList<String>();
        urns.add(sliceUrn.getValue());

        AbstractGeniAggregateManager.AggregateManagerReply<List<AggregateManager3.SliverInfo>> reply = am3.renew(
                getConnection(),
                urns,
                toCredentialList(sliceCredential),
                newExpire,
                null/*best effort*/,
                null/*extra_options*/);

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("Renew Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
            //            return null;
        }
    }
}
