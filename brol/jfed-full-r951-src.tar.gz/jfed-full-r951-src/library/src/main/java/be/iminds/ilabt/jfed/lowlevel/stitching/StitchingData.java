package be.iminds.ilabt.jfed.lowlevel.stitching;

import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.XmlUtil;
import org.apache.logging.log4j.LogManager;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.*;

/**
 * StitchingData stores StitchingHopData and StitchingCallData
 *
 * It also knows the order in which AM's need to be called.
 *
 * It derives all data from the info returned from the SCS call:
 *   - stitching extension of returned rspec
 *   - workflow data
 */
public class StitchingData {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    private final List<StitchingHopData> stitchingHopDataList = new ArrayList<StitchingHopData>();
    //    private final List<StitchingCallData> stitchingCallDataList = new ArrayList<StitchingCallData>();
    private final Map<String, StitchingCallData> stitchingCallDataByAuthUrn = new HashMap<String, StitchingCallData>();

    private final List<StitchingCallData> orderedStitchingCallDataList = new ArrayList<StitchingCallData>();
    private final List<SfaAuthority> orderedSfaAuths = new ArrayList<SfaAuthority>();

    private final String scsReplyRspec;

    public StitchingData(String scsReplyRspec, Hashtable workflow, AuthorityListModel authList) {
        this.scsReplyRspec = scsReplyRspec;

        Element stitchingElement = extractStitchingElementFromRspec(scsReplyRspec);
        assert stitchingElement != null : "No stitching element in rspec";

        //then go over each hop in the workflow
        Hashtable<String, Hashtable> workflowData = getAsHtofStoHt(workflow);
        Map<String, StitchingHopData> aggUrnsToStitchingHopData = new HashMap<String, StitchingHopData>(); //keep track of all unique aggregates
        for (String linkName : workflowData.keySet()) {
            Vector<Hashtable> linkDeps = getValueOfTypeVofHt(workflowData.get(linkName), "dependencies");
            assert linkDeps != null;

            List<Hashtable> hops = new LinkedList<Hashtable>();
            hops.addAll(linkDeps);
            while (!hops.isEmpty()) {
                Hashtable hopHt = hops.remove(0);

                if (hopHt.containsKey("dependencies")) {
                    Vector<Hashtable> deps = getValueOfTypeVofHt(hopHt, "dependencies");
                    hops.addAll(deps);
                }

                StitchingHopData stitchingHopData = new StitchingHopData(linkName, hopHt, stitchingElement);
                if (stitchingHopDataList.contains(stitchingHopData)) {
                    int i = stitchingHopDataList.indexOf(stitchingHopData);
                    assert i >= 0;
                    assert i < stitchingHopDataList.size();
                    stitchingHopData = stitchingHopDataList.get(i); //replace created stitchingHopData with existing
                    stitchingHopData.processExtraWorkflowData(linkName, hopHt);
                } else {
                    stitchingHopDataList.add(stitchingHopData);
                }

                if (!aggUrnsToStitchingHopData.containsKey(stitchingHopData.getAggregateUrn()))
                    aggUrnsToStitchingHopData.put(stitchingHopData.getAggregateUrn(), stitchingHopData);
            }
        }
        //link dependency graph of stitchingHopDataList
        for (StitchingHopData stitchingHopData : stitchingHopDataList) {
            stitchingHopData.linkDeps(stitchingHopDataList);
        }

        //we now have a list with all StitchingHopData
        //we will create all StitchingCallData
        for (StitchingHopData stitchingHopData : aggUrnsToStitchingHopData.values()) {
            StitchingCallData stitchingCallData = new StitchingCallData(
                    stitchingHopData.getAggregateUrn(),
                    stitchingHopData.getAggregateUrl(),
                    authList);
            stitchingCallDataByAuthUrn.put(stitchingHopData.getAggregateUrn(), stitchingCallData);
        }
        for (StitchingHopData stitchingHopData : stitchingHopDataList) {
            StitchingCallData stitchingCallData = stitchingCallDataByAuthUrn.get(stitchingHopData.getAggregateUrn());
            assert stitchingCallData != null;
            stitchingCallData.addHopData(stitchingHopData);
        }
        for (StitchingCallData stitchingCallData : stitchingCallDataByAuthUrn.values()) {
            stitchingCallData.linkDeps(stitchingCallDataByAuthUrn.values());
        }


        //now find the ordering: copy depgraph and keep removing nodes without deps until noting is left. The order of removing is the order searched.
        Map<StitchingCallData, StitchingCallDataDepGrahpHelper> depGraphCopy = new HashMap<StitchingCallData, StitchingCallDataDepGrahpHelper>();
        for (StitchingCallData stitchingCallData : stitchingCallDataByAuthUrn.values())
            depGraphCopy.put(stitchingCallData, new StitchingCallDataDepGrahpHelper(stitchingCallData));
        while (orderedStitchingCallDataList.size() != stitchingCallDataByAuthUrn.size()) {
            int prevOrderedStitchingCallDataListSize = orderedStitchingCallDataList.size();

            for (StitchingCallDataDepGrahpHelper h : depGraphCopy.values()) {
                if (h.dependencies.isEmpty() && !orderedStitchingCallDataList.contains(h.s)) {
                    for (StitchingCallData dep : h.dependingOnThis) {
                        StitchingCallDataDepGrahpHelper hDep = depGraphCopy.get(dep);
                        hDep.dependencies.remove(h.s);
                    }
                    h.dependingOnThis.clear();
                    orderedStitchingCallDataList.add(h.s);
                }
            }

            if (prevOrderedStitchingCallDataListSize == orderedStitchingCallDataList.size())
                throw new RuntimeException("Loop in depgraph: "+orderedStitchingCallDataList);
        }

        //create orderedSfaAuths
        for (StitchingCallData dep : orderedStitchingCallDataList)
            orderedSfaAuths.add(dep.getAuth());
    }


    public static Element extractStitchingElementFromRspec(String rspec) {
        try {
            //first parse rspec
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = null;
            dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(new InputSource(new StringReader(rspec)));

            doc.getDocumentElement().normalize();

            NodeList rspecListNoNS = doc.getElementsByTagName("rspec");
            assert rspecListNoNS.getLength() == 1 : "not a single rspec element, but "+rspecListNoNS.getLength()+" in "+rspec;
            Node rspecNode = rspecListNoNS.item(0);
            assert rspecNode != null;
            assert rspecNode.getNodeType() == Node.ELEMENT_NODE;
            Element rspecElement = (Element) rspecNode;

            NodeList stitchingListNoNS = rspecElement.getElementsByTagName("stitching");
            assert stitchingListNoNS.getLength() == 1  : "not a single stitching element, but "+stitchingListNoNS.getLength()+" in "+rspec;
            Node stitchingNode = stitchingListNoNS.item(0);
            assert stitchingNode != null;
            assert stitchingNode.getNodeType() == Node.ELEMENT_NODE;
            Element stitchingElement = (Element) stitchingNode;

            return stitchingElement;
        } catch (ParserConfigurationException e) {
            logger.fatal("Error parsing rspec", e);
        } catch (SAXException e) {
            logger.fatal("Error parsing rspec", e);
        } catch (IOException e) {
            logger.fatal("Error parsing rspec", e);
        }
        return null;
    }


    /**
     * Get the current Rspec, including updated suggestVlan and availableVLAN data.
     *
     * This is based on the original request RSpec returned by the SCS, combined with updates for
     * availableVLAN and suggestedVLAN from "vlan unavailable" errors and CreateSliver manifests
     * */
    public String getCurrentRequestRspec() {
        logger.entry();
        //rewrite rspec, so that vlanInfo is used instead of what is in the rspec (requires DOM + transformation)

        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(new InputSource(new StringReader(scsReplyRspec)));

            doc.getDocumentElement().normalize();

            Element root = doc.getDocumentElement();

            //rspec - stitching - path - hop (MULTIPLE) - link - switchingCapabilityDescriptor - switchingCapabilitySpecificInfo - switchingCapabilitySpecificInfo_L2sc -
            //          vlanRangeAvailability
            //          suggestedVLANRange

            NodeList rspecListNoNS = doc.getElementsByTagName("rspec");
            assert rspecListNoNS.getLength() == 1 : "not a single rspec element, but "+rspecListNoNS.getLength()+" in "+scsReplyRspec;
            Node rspecNode = rspecListNoNS.item(0);
            assert rspecNode != null;
            assert rspecNode.getNodeType() == Node.ELEMENT_NODE;
            Element rspecElement = (Element) rspecNode;

            NodeList stitchingListNoNS = rspecElement.getElementsByTagName("stitching");
            assert stitchingListNoNS.getLength() == 1  : "not a single stitching element, but "+stitchingListNoNS.getLength()+" in "+scsReplyRspec;
            Node stitchingNode = stitchingListNoNS.item(0);
            assert stitchingNode != null;
            assert stitchingNode.getNodeType() == Node.ELEMENT_NODE;
            Element stitchingElement = (Element) stitchingNode;

            List<Element> pathEls = quickDomChildrenHelper(stitchingElement, "path");
            for (Element pathEl : pathEls) {
                String linkName = pathEl.getAttribute("id");
                assert linkName != null : "<stitching> has <path> element without id attribute: "+pathEl;

                List<Element> origHopElements = quickDomChildrenHelper(pathEl, "hop");

                logger.trace("getCurrentRequestRspec() rewriting path with link id="+linkName+" orig el count: "+origHopElements.size());

                //remove original hop elements
                for (Element hopElement : origHopElements) {
                    hopElement.getParentNode().removeChild(hopElement);
                }

                //keep only hops for this path
                List<StitchingHopData> filteredHopData = new ArrayList<StitchingHopData>(stitchingHopDataList);
                for (ListIterator<StitchingHopData> it = filteredHopData.listIterator(); it.hasNext(); ) {
                    StitchingHopData hop = it.next();

                    if (!hop.getLinkName().equals(linkName))
                        it.remove();
                }

                //sort according to hop id (seems to be needed!)
                List<StitchingHopData> sortedHopData = new ArrayList<StitchingHopData>(filteredHopData);
                Collections.sort(sortedHopData, new Comparator<StitchingHopData>() {
                    @Override
                    public int compare(StitchingHopData o1, StitchingHopData o2) {
                        return o1.getRspecStitchingHopId().compareTo(o2.getRspecStitchingHopId());
                    }
                });

                //add updated hop elements
                for (StitchingHopData hop : sortedHopData) {
                    Node importedNode = doc.importNode(hop.getRspecStitchingHopElement(), true/*deep*/);
//                    logger.trace("getCurrentRequestRspec() adding hop   " + hop.getRspecStitchingHopId()+"  suggestedVlan="+hop.getSuggestedVlan()+"  nodeVlan={}",
//                            XmlUtil.elementToXmlString(hop.getRspecStitchingHopElement()));

//                    Element hopElement = (Element) importedNode;
//                    Element linkEl = quickDomChildHelper(hopElement, "link");
//                    Element scDescriptorEl = quickDomChildHelper(linkEl, "switchingCapabilityDescriptor");
//                    Element scSpecificInfoEl = quickDomChildHelper(scDescriptorEl, "switchingCapabilitySpecificInfo");
//                    Element scSpecificInfo_L2scEl = quickDomChildHelper(scSpecificInfoEl, "switchingCapabilitySpecificInfo_L2sc");
//                    Element vlanRangeAvailabilityEl = quickDomChildHelper(scSpecificInfo_L2scEl, "vlanRangeAvailability");
//                    Element suggestedVLANRangeEl = quickDomChildHelper(scSpecificInfo_L2scEl, "suggestedVLANRange");
//                    logger.trace("suggestedVLANRangeEl text="+suggestedVLANRangeEl.getTextContent());

//                    logger.trace("getCurrentRequestRspec() adding hop   " + hop.getRspecStitchingHopId()+"  suggestedVlan="+hop.getSuggestedVlan());
                    pathEl.appendChild(importedNode);
                }
            }

            try {
                TransformerFactory transFactory = TransformerFactory.newInstance();
                Transformer transformer = transFactory.newTransformer();
                StringWriter buffer = new StringWriter();
                transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
                transformer.transform(new DOMSource(rspecNode), new StreamResult(buffer));
//                logger.debug("generated RSPEC: {}", buffer.toString());
                return buffer.toString();
            } catch (TransformerConfigurationException e) {
                logger.error("TransformerConfigurationException in getCurrentRequestRspec()", e);
            } catch (TransformerException e) {
                logger.error("TransformerException in getCurrentRequestRspec()", e);
            }
        } catch (Exception e) {
            logger.error("Exception in getCurrentRequestRspec()", e);
        }

        return null;
    }


    private static Element quickDomChildHelper(Element e, String tagName) {
        NodeList resList = e.getElementsByTagName(tagName);
        assert resList.getLength() == 1;
        Node resNode = resList.item(0);
        assert resNode != null;
        assert resNode.getNodeType() == Node.ELEMENT_NODE;
        Element resElement = (Element) resNode;
        return resElement;
    }
    private static List<Element> quickDomChildrenHelper(Element e, String tagName) {
        NodeList resList = e.getElementsByTagName(tagName);
        List<Element> resElements = new ArrayList<Element>();
        for (int i = 0 ; i < resList.getLength(); i++) {
            Node resNode = resList.item(i);
            assert resNode != null;
            assert resNode.getNodeType() == Node.ELEMENT_NODE;
            Element resElement = (Element) resNode;
            resElements.add(resElement);
        }
        return resElements;
    }







    public List<StitchingCallData> getOrderedStitchingCallDataList() {
        return orderedStitchingCallDataList;
    }
    public StitchingCallData getStitchingCallData(String authUrn) {
        return stitchingCallDataByAuthUrn.get(authUrn);
    }
    public List<StitchingHopData> getStitchingHopDataList() {
        return stitchingHopDataList;
    }
    public List<SfaAuthority> getOrderedSfaAuths() {
        return orderedSfaAuths;
    }


    @Override
    public String toString() {
        String orderedStitchingCallDataListString = "{";
        for (StitchingCallData stitchingCallData : orderedStitchingCallDataList)
            orderedStitchingCallDataListString += "\n    "+stitchingCallData;
        orderedStitchingCallDataListString += "}";

        return "StitchingData{" +
                "orderedStitchingCallDataList=" + orderedStitchingCallDataListString +
                '}';
    }

    private static class StitchingCallDataDepGrahpHelper {
        List<StitchingCallData> dependencies = new ArrayList<StitchingCallData>();
        List<StitchingCallData> dependingOnThis = new ArrayList<StitchingCallData>();
        StitchingCallData s;

        public StitchingCallDataDepGrahpHelper(StitchingCallData s) {
            this.s = s;
            this.dependencies.addAll(s.getDependencies());
            this.dependingOnThis.addAll(s.getDependingOnThis());
        }
    }

    public Hashtable<String, Hashtable> getAsHtofStoHt(Hashtable ht) {
        for (Object eo : ht.entrySet()) {
            Map.Entry e = (Map.Entry) eo;
            assert e != null;
            assert e.getKey() instanceof String : "value in hashtable is not of type String, but of type "+e.getKey().getClass().getName();
            assert e.getValue() instanceof Hashtable : "key in hashtable is not of type Hashtable, but of type "+e.getValue().getClass().getName();
        }

        return (Hashtable<String, Hashtable>) ht;
    }
    public Hashtable<String, Hashtable> getValueOfTypeHtofStoHt(Hashtable h, String key) {
        Object o = h.get(key);
        assert o != null : "Hashtable does not contain key \""+key+"\". content: "+h;
        assert o instanceof Hashtable : "key in hashtable is not of type Hashtable, but of type "+o.getClass().getName();
        Hashtable ht = (Hashtable) o;
        return getAsHtofStoHt(ht);
    }
    public Vector<Hashtable> getValueOfTypeVofHt(Hashtable h, String key) {
        Object o = h.get(key);
        assert o != null : "Hashtable does not contain key \""+key+"\". content: "+h;
        assert o instanceof Vector : "key in hashtable is not of type Vector, but of type "+o.getClass().getName();
        Vector v = (Vector) o;
        for (Object vo : v)
            assert vo instanceof Hashtable : "key in hashtable is not of type Hashtable, but of type "+vo.getClass().getName();

        return (Vector<Hashtable>) v;
    }
}
