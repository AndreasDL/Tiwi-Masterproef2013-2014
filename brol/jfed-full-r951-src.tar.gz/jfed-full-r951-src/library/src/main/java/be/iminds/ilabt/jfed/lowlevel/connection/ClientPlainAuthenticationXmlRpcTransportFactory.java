package be.iminds.ilabt.jfed.lowlevel.connection;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpParams;
import org.apache.logging.log4j.LogManager;

import java.net.MalformedURLException;
import java.net.URL;


/**
 * Non encrypted HTTP connection
 */
public class ClientPlainAuthenticationXmlRpcTransportFactory extends CommonsHttpClientXmlRpcTransportFactory {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    /**
     * @param serverUrl URL of server to connect to
     */
    public ClientPlainAuthenticationXmlRpcTransportFactory(String serverUrl, boolean debugMode) throws JFedException {
        super(serverUrl, getHttpClient(serverUrl, debugMode), debugMode);
    }


    private static DefaultHttpClient getHttpClient(String serverUrlStr, boolean debugMode) throws JFedException {
        if (serverUrlStr == null) throw new RuntimeException("serverUrlStr == null");

        final URL serverUrl;
        try {
            serverUrl = new URL(serverUrlStr);
        } catch (MalformedURLException e) {
            logger.error("ERROR: MalformedURLException url=\""+serverUrlStr+"\"", e);
            return null;
        }

        HttpParams params = new BasicHttpParams();
        params.setParameter(CoreConnectionPNames.SO_TIMEOUT, 120000); //read timeout in ms (default: 0 = infinite)   (long timeout, as some calls take time to finish)
        params.setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 10000); //connection timeout in ms (default: 0 = infinite)

        return new DefaultHttpClient(params);
    }
}
