package be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api.AbstractFederationApi1;
import be.iminds.ilabt.jfed.lowlevel.api.FederationMemberAuthorityApi1;
import be.iminds.ilabt.jfed.lowlevel.api.FederationSliceAuthorityApi1;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.UserAndSliceApiWrapper;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.ExtraInfoCallback;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.RFC3339Util;
import be.iminds.ilabt.jfed.util.TextUtil;
import org.apache.logging.log4j.LogManager;

import java.util.*;

/**
 * ProtoGeniSAUserAndSliceApiWrapper
 */
public class UniformFederationApiUserAndSliceApiWrapper extends UserAndSliceApiWrapper {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();
    private final FederationMemberAuthorityApi1 ma;
    private final FederationSliceAuthorityApi1 sa;

    public UniformFederationApiUserAndSliceApiWrapper(Logger logger, GeniUserProvider geniUserProvider, GeniConnectionProvider connectionProvider) {
        super(logger, geniUserProvider, connectionProvider);
        ma = new FederationMemberAuthorityApi1(logger, true);
        sa = new FederationSliceAuthorityApi1(logger, true);
    }

    public FederationSliceAuthorityApi1.GetVersionSAResult getGetVersionSAResult() throws JFedException {
        //TODO: buffer

        AbstractFederationApi1.FederationApiReply<FederationSliceAuthorityApi1.GetVersionSAResult> reply =
                sa.getVersion((SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 1)));

        if (!reply.getGeniResponseCode().isSuccess())
            throw new JFedException("GetVersion call to SA not successful: code="+
                    reply.getGeniResponseCode()+" output="+reply.getOutput(),
                    reply.getXmlRpcCallDetailsGeni(), reply.getGeniResponseCode());

        return reply.getValue();
    }

    public List<AnyCredential> makeCredentialList(AnyCredential c) {
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        if (c != null)
            res.add(c);
        return res;
    }

    @Override
    public AnyCredential getUserCredentials(GeniUrn user) throws JFedException {
        AbstractFederationApi1.FederationApiReply<List<AnyCredential>> reply =
                ma.getCredentials(
                        (SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.GENI_CH_MA, 1)),
                        new ArrayList<AnyCredential>(),
                        user,
                        null);

        assert reply != null;

        if (!reply.getGeniResponseCode().isSuccess())
            throw new JFedException("Could not retrieve user credential from server: code="+
                    reply.getGeniResponseCode()+" output="+reply.getOutput(),
                    reply.getXmlRpcCallDetailsGeni(), reply.getGeniResponseCode());

        assert reply.getValue() != null;
        assert !reply.getValue().isEmpty();

        //TODO support multiple credentials
        return reply.getValue().get(0);
    }

    @Override
    public AnyCredential getSliceCredentials(AnyCredential userCredential, GeniUrn sliceUrn) throws JFedException {
        AbstractFederationApi1.FederationApiReply<List<AnyCredential>> reply =
                sa.getSliceCredentials((SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 1)), makeCredentialList(userCredential), sliceUrn, null);

        if (!reply.getGeniResponseCode().isSuccess())
            throw new JFedException("Could not retrieve slice credential from server: code="+
                    reply.getGeniResponseCode()+" output="+reply.getOutput(),
                    reply.getXmlRpcCallDetailsGeni(), reply.getGeniResponseCode());

        //TODO support multiple credentials
        return reply.getValue().get(0);
    }

    @Override
    public List<GeniUrn> getSlicesForUser(AnyCredential userCredential, GeniUrn user) throws JFedException {
        List<GeniUrn> res = new ArrayList<GeniUrn>();
        AbstractFederationApi1.FederationApiReply<List<FederationSliceAuthorityApi1.UrnRoleTuple>> reply =
                sa.lookupSlicesForMember((SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 1)), user, makeCredentialList(userCredential), null);
        if (reply == null || reply.getGeniResponseCode() == null || !reply.getGeniResponseCode().isSuccess() || reply.getValue() == null)
            return res;
        List<FederationSliceAuthorityApi1.UrnRoleTuple> urnRoleTuples = reply.getValue();
        for (FederationSliceAuthorityApi1.UrnRoleTuple urnRoleTuple : urnRoleTuples)
            res.add(urnRoleTuple.getUrn());

        return res;
        //get other info:
//        Map<String, String> match = new HashMap<String, String>();
//        match.put("MEMBER_URN", user.toString());
//        ma.lookupPublicMemberInfo(con, match, null, null);
//        ma.lookupPrivateMemberInfo(con, makeCredentialList(userCredential), match, null, null);
    }

    public List<GeniUrn> getUserProjects(AnyCredential userCredential, GeniUrn user) throws JFedException {
        List<GeniUrn> res = new ArrayList<GeniUrn>();

        AbstractFederationApi1.FederationApiReply<List<FederationSliceAuthorityApi1.UrnRoleTuple>> reply =
                sa.lookupProjectsForMember((SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 1)),
                        user,
                        makeCredentialList(userCredential),
                        null);
        if (reply == null || reply.getGeniResponseCode() == null || !reply.getGeniResponseCode().isSuccess() || reply.getValue() == null)
            return res;
        List<FederationSliceAuthorityApi1.UrnRoleTuple> urnRoleTuples = reply.getValue();
        LOG.debug("UniformFederationApiUserAndSliceApiWrapper#getUserProjects urnRoleTuples.size()="+urnRoleTuples.size());
        boolean hasExpired = false;
        for (FederationSliceAuthorityApi1.UrnRoleTuple urnRoleTuple : urnRoleTuples) {

            //first a special exception: server might include EXPIRED field in tuple. We can use that info
            if (urnRoleTuple.dictRaw != null && urnRoleTuple.dictRaw.containsKey("EXPIRED")) {
                hasExpired = true;
                if (TextUtil.objectToBoolean(urnRoleTuple.dictRaw.get("EXPIRED"))) {
                    LOG.debug("skipping expired project: "+urnRoleTuple.getUrn());
                    continue;
                }
            }

            res.add(urnRoleTuple.getUrn());
        }

        if (!hasExpired) {
            LOG.debug("doing second call to check for expired projects");

            Map<String, Object> match = new HashMap<String, Object>();
            match.put("EXPIRED", Boolean.FALSE);
            List<String> filter = new ArrayList<String>();
            filter.add("PROJECT_URN");
            AbstractFederationApi1.FederationApiReply<AbstractFederationApi1.LookupResult> nonExpiredProj = null;
            try {
                nonExpiredProj =
                    sa.lookupProjects((SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 1)),
                    makeCredentialList(userCredential),
                    match,
                    filter,
                    null);
            } catch (Throwable e) {
                LOG.warn("lookup_projects call failed. Could not check for expired projects. This error will be ignored (possibly leaving expired projects in the list).", e);
                nonExpiredProj = null;
                return res;
            }
            if (nonExpiredProj == null || nonExpiredProj.getGeniResponseCode() == null || !nonExpiredProj.getGeniResponseCode().isSuccess() || nonExpiredProj.getValue() == null) {
                LOG.warn("lookup_projects call failed. Could not check for expired projects. This error will be ignored (possibly leaving expired projects in the list).");
            } else {
                LOG.debug("Found "+nonExpiredProj.getValue().size()+" non expired projects on server.");
                List<GeniUrn> expiredUserProjects = new ArrayList<GeniUrn>();
                for (GeniUrn resUrn : res) {
                    if (nonExpiredProj.getValue().get(resUrn) == null)
                        expiredUserProjects.add(resUrn);
                }
                LOG.debug("found "+expiredUserProjects.size()+" expired projects in "+res.size()+" user projects: will remove them");
                res.removeAll(expiredUserProjects);
            }
        } else {
            LOG.debug("no second call needed to check for expired projects");
        }

        LOG.debug("UniformFederationApiUserAndSliceApiWrapper#getUserProjects res.size()="+res.size());
        return res;
    }

    public AbstractFederationApi1.LookupResult getUserIdentifyingInfo(AnyCredential userCredential, GeniUrn user) throws JFedException {
        Hashtable<String, String> match = new Hashtable<String, String>();
        match.put("MEMBER_URN", getUser().getUserUrnString());

//        Vector<String> filter = new Vector<String>();

        AbstractFederationApi1.FederationApiReply<AbstractFederationApi1.LookupResult> reply =
                ma.lookupIdentifyingMemberInfo((SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.GENI_CH_MA, 1)),
                        makeCredentialList(userCredential),
                        match,
                        null/*filter*/,
                        null);


        if (reply == null)
            throw new JFedException("Problem looking up user info for "+getUser().getUserUrnString());

        if (reply.getGeniResponseCode() == null || !reply.getGeniResponseCode().isSuccess() || reply.getValue() == null)
            throw new JFedException("Problem looking up user info for "+getUser().getUserUrnString(), reply.getXmlRpcCallDetailsGeni(), reply.getGeniResponseCode());

        return reply.getValue();
    }

    @Override
    public void getAggregatesForSlice(AnyCredential userCredential, AnyCredential sliceCredential, GeniUrn sliceUrn) throws JFedException {
        sa.lookupSliverInfo((SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 1)), makeCredentialList(sliceCredential), sliceUrn, null, null, null);
    }

    @Override
    public SliceInfo createSlice(AnyCredential userCredential, String sliceName, Date expirationDate) throws JFedException {
        //2 steps: create slice, and then get its credential(s)

        SfaConnection con = (SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 1));

        FederationSliceAuthorityApi1.GetVersionSAResult gv = getGetVersionSAResult();
        assert gv != null;

        Map<String, String> fields = new HashMap<String, String>();
        fields.put("SLICE_DESCRIPTION", "jFed Experimenter GUI slice '"+sliceName+"' for user "+getUser().getUserUrnString());

        if (gv.getServices().contains("PROJECT")) {
            List<GeniUrn> userProjects = getUserProjects(userCredential, getUser().getUserUrn());
            if (userProjects.isEmpty())
                throw new JFedException("Slice creation requires a project, but user is not a member of any project.");

            if (userProjects.size() <= 0) {
                LOG.error("User " + getUser().getUserUrnString() + " is member of no projects! Will try to create slice without project, but that will most likely fail.");
                return null;
            } else {
                GeniUrn chosenProject = null;
                if (userProjects.size() > 1) {
                    if (ExtraInfoCallback.getFederationApiProjectSelectionCallback() != null) {
                        LOG.debug("User is member of "+userProjects.size()+" projects. Using callback to let user choose one.");
                        chosenProject = ExtraInfoCallback.getFederationApiProjectSelection(userProjects);
                    } else {
                        LOG.warn("User "+getUser().getUserUrnString()+" is member of multiple projects: "+userProjects+". " +
                                "No callback available to let user choose project: Choosing first project as project for this slice.");
                        chosenProject = userProjects.get(0);
                    }
                } else
                    chosenProject = userProjects.get(0);
                fields.put("SLICE_PROJECT_URN", chosenProject.getValue());
            }
        }

        if (gv.getFieldsForObject("PROJECT").containsKey("_GENI_SLICE_EMAIL")) {
            AbstractFederationApi1.LookupResult userIdentifyingInfo = getUserIdentifyingInfo(userCredential, getUser().getUserUrn());

            if (userIdentifyingInfo != null && userIdentifyingInfo.get(getUser().getUserUrn()).containsKey("MEMBER_EMAIL")) {
                String userEmail = (String) userIdentifyingInfo.get(getUser().getUserUrn()).get("MEMBER_EMAIL");
                fields.put("_GENI_SLICE_EMAIL", userEmail);
            }
            else {
                throw new JFedException("Slice creation requires a user email, but the user email is not known.");
            }
        }

//      TODO  addRequiredSupplementaryFieldsToCreate(fields, "SLICE");

         if(expirationDate != null){
             //note: SLICE_EXPIRATION is allowed on Creation, so this will always work
             fields.put("SLICE_EXPIRATION", RFC3339Util.dateToRFC3339String(expirationDate, true, true, true));
         }

        AbstractFederationApi1.FederationApiReply<Hashtable<String, Object>> reply =
                sa.createSlice(
                        con,
                        makeCredentialList(userCredential),
                        sliceName/* automatically added to "SLICE_NAME" field*/,
                        fields,
                        null/*extraOptions*/);


        if (reply != null && reply.getGeniResponseCode() != null && reply.getGeniResponseCode().isSuccess() && reply.getValue() != null) {
            Hashtable<String, Object> sliceInfo = reply.getValue();

//            if (sliceInfo.containsKey("SLICE_CREDENTIAL"?)) {
            //        //TODO slice credential is normally in returned fields? Otherwise, we can retrieve it with a call.
//            }

            if (sliceInfo.containsKey("SLICE_URN")) {
                String sliceUrnStr = sliceInfo.get("SLICE_URN").toString();
                GeniUrn sliceUrn = GeniUrn.parse(sliceUrnStr);
                if (sliceUrn != null) {
                    AbstractFederationApi1.FederationApiReply<List<AnyCredential>> credReply =
                            sa.getSliceCredentials(con, makeCredentialList(userCredential), sliceUrn, null);

                    //TODO support multiple credentials
                    return new SliceInfo(sliceName, sliceUrn, credReply.getValue().get(0));
                }
            }
            throw new JFedException("Error creating slice");
        } else
            throw new JFedException("Error creating slice");
    }

    @Override
    public AnyCredential renewSlice(AnyCredential sliceCredential, Date newExpirationDate) throws JFedException {
        throw new UnsupportedOperationException("Currently not supported");
    }

    @Override
    public void getSshKeysForUser(AnyCredential userCredential, GeniUrn userUrn) throws JFedException {
        Map<String, String> match = new HashMap<String, String>();
        match.put("KEY_MEMBER", userUrn.toString());
        ma.lookupKeys((SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.GENI_CH_MA, 1)), makeCredentialList(userCredential), match, null/*filter*/, null);
    }
}
