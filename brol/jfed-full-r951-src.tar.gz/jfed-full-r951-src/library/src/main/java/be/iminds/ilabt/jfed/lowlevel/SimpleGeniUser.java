package be.iminds.ilabt.jfed.lowlevel;

import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.KeyUtil;

import java.io.File;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.List;

/**
 * SimpleGeniUser
 */
public class SimpleGeniUser implements GeniUser {
    private List<X509Certificate> certificateChain;
    private PrivateKey privateKey;

    private SfaAuthority authority;
    private GeniUrn userUrn;

    private File certificateKeyFile;
    private File privateKeyFile;

//    public SimpleGeniUser(SfaAuthority userAuthority, String username, String keyCertContent, char[] keyPass) {
//        this(userAuthority, "urn:publicid:IDN+"+userAuthority.getNameForUrn()+"+user+"+username, keyCertContent, keyPass);
//    }
    public SimpleGeniUser(SfaAuthority userAuthority, GeniUrn userUrn, String keyCertContent, char[] keyPass, File certificateKeyFile, File privateKeyFile) {
        this.authority = userAuthority;
        this.userUrn = userUrn;
        this.certificateKeyFile = certificateKeyFile;
        this.privateKeyFile = privateKeyFile;

        try {
            privateKey = KeyUtil.pemToAnyPrivateKey(keyCertContent, keyPass);
        } catch (KeyUtil.PEMDecodingException e) {
            privateKey = null;
            throw new RuntimeException("ERROR reading PEM key:"+keyCertContent+" -> "+e.getMessage(), e);
        }
        if (privateKey == null)
            throw new RuntimeException("ERROR: PEM key and certificate does not contain a key:"+keyCertContent);

        certificateChain = KeyUtil.pemToX509CertificateChain(keyCertContent);
        if (certificateChain == null || certificateChain.isEmpty())
            throw new RuntimeException("ERROR: PEM key and certificate does not contain a X509 certificate:"+keyCertContent);
    }
    public SimpleGeniUser(SfaAuthority userAuthority, GeniUrn userUrn, List<X509Certificate> certificateChain, PrivateKey privateKey, File certificateKeyFile, File privateKeyFile) {
        this.authority = userAuthority;
        this.userUrn = userUrn;
        this.privateKey = privateKey;
        this.certificateChain = certificateChain;
        this.certificateKeyFile = certificateKeyFile;
        this.privateKeyFile = privateKeyFile;
    }

    /**
     * make a copy of a GeniUser
     * */
    public SimpleGeniUser(GeniUser geniUser) {
        this.certificateChain = geniUser.getClientCertificateChain();
        this.privateKey = geniUser.getPrivateKey();
        this.authority = geniUser.getUserAuthority();
//        this.userName = geniUser.getUserName();
        this.userUrn = GeniUrn.parse(geniUser.getUserUrnString());

        this.certificateKeyFile = geniUser.getCertificateFile();
        this.privateKeyFile = geniUser.getPrivateKeyFile();
    }
    /**
     * make a copy of a GeniUser
     * */
    public SimpleGeniUser(SimpleGeniUser geniUser) {
        this.certificateChain = geniUser.certificateChain;
        this.privateKey = geniUser.privateKey;
        this.authority = geniUser.authority;
        this.userUrn = geniUser.userUrn;

        this.certificateKeyFile = geniUser.certificateKeyFile;
        this.privateKeyFile = geniUser.privateKeyFile;
    }


    @Override
    public List<X509Certificate> getClientCertificateChain() {
        return certificateChain;
    }

    @Override
    public PrivateKey getPrivateKey() {
        return privateKey;
    }

    @Override
    public PublicKey getPublicKey() {
        List<X509Certificate> certificateChain = getClientCertificateChain();
        if (certificateChain == null || certificateChain.isEmpty())
            return null;
        return certificateChain.get(0).getPublicKey();
    }

    @Override
    public SfaAuthority getUserAuthority() {
        return authority;
    }

//    @Override
//    public String getUserName() {
//        return userName;
//    }

    @Override
    public GeniUrn getUserUrn() {
        return userUrn;
    }

    @Override
    public File getPrivateKeyFile() {
        return privateKeyFile;
    }

    @Override
    public File getCertificateFile() {
        return certificateKeyFile;
    }

    @Override
    public String getUserUrnString() {
        return userUrn.toString();
    }
}
