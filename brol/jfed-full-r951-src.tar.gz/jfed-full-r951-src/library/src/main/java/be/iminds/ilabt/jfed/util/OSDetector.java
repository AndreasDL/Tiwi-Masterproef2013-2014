package be.iminds.ilabt.jfed.util;

import org.apache.logging.log4j.LogManager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * OSDetector
 */
public class OSDetector {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    public static enum OS { WIN, UNIX, MAC };

    public static OS findOS() {
        final String osname = System.getProperty("os.name").toLowerCase();
        if (osname.contains("win")) {
            return OSDetector.OS.WIN;
        }

        if (osname.contains("mac")) {
            return OSDetector.OS.MAC;
        }

        if (osname.contains("nix") || osname.contains("nux") || osname.contains("aix") || osname.contains("bsd")) {
            return OSDetector.OS.UNIX;
        }

        LOG.warn("OSDetector could not detect os from os.name=\""+osname+"\"");

        return null;
    }

    public static final OS os = findOS();




    // filters for OSes

    public static interface OSFilter {
        public boolean includedOs(OS os);
    }

    public static class OneOsFilter implements OSFilter {
        private final OS os;
        private final boolean invert;
        public OneOsFilter(OS os) { this.os = os; this.invert = false; }
        public OneOsFilter(OS os, boolean invert) { this.os = os; this.invert = invert; }
        public boolean includedOs(OS o) {
            if (invert)
                return !os.equals(o);
            else
                return os.equals(o);
        }
    }
    public static class MultiOsFilter implements OSFilter {
        private Collection<OS> os;
        private final boolean invert;
        public MultiOsFilter(Collection<OS> o) { this.os = o; this.invert = false; }
        public MultiOsFilter(Collection<OS> o, boolean invert) { this.os = os; this.invert = invert; }
        public boolean includedOs(OS o) {
            if (invert)
                return !os.contains(o);
            else
                return os.contains(o);
        }
    }
    public static OSFilter getUnixLikeOsFilter() {
        List<OS> oses = new ArrayList<OS>();
        oses.add(OS.UNIX);
        oses.add(OS.MAC);
        return new MultiOsFilter(oses);
    }
}
