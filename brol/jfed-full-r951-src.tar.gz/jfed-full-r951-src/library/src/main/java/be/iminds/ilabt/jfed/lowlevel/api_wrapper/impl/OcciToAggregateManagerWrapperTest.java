package be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl;

import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.JFedAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * OcciToAggregateManagerWrapperTest
 */
public class OcciToAggregateManagerWrapperTest {
    @Test
    public void testParseExperimentComputes() {
        List<OcciToAggregateManagerWrapper.ComputeInfo> computeInfos = OcciToAggregateManagerWrapper.parseExperimentComputes("expId", "\n" +
                "<collection xmlns=\"http://api.bonfire-project.eu/doc/schemas/occi\" href=\"/experiments/336/computes\">\n" +
                "  <items offset=\"0\" total=\"1\">\n" +
                "<compute href=\"/locations/fr-inria/computes/426\" name=\"BonFIRE-monitor-experiment336\"/>\n" +
                "<compute href=\"/locations/test/computes/1024\" name=\"Test\"/>\n" +
                "  </items>\n" +
                "  <link href=\"/experiments/336\" rel=\"parent\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</collection>");
        Assert.assertEquals(computeInfos.size(), 2);
        Assert.assertEquals(computeInfos.get(0).computeId, "426");
        Assert.assertEquals(computeInfos.get(0).computeName, "BonFIRE-monitor-experiment336");
        Assert.assertEquals(computeInfos.get(0).locationName, "fr-inria");
        Assert.assertEquals(computeInfos.get(0).experimentId, "expId");
        Assert.assertEquals(computeInfos.get(1).computeId, "1024");
        Assert.assertEquals(computeInfos.get(1).computeName, "Test");
        Assert.assertEquals(computeInfos.get(1).locationName, "test");
        Assert.assertEquals(computeInfos.get(1).experimentId, "expId");
    }

    @Test
    public void testParseExperiment() {
        SfaAuthority bonfireAuth = JFedAuthorityList.getAuthorityListModel().getByUrn(OcciToAggregateManagerWrapper.bonfireUrn);
        GeniUrn sliceUrn = new GeniUrn("example.com", "slice", "Scenario1");
        OcciToAggregateManagerWrapper.ExperimentInfo experimentInfo = OcciToAggregateManagerWrapper.parseExperiment(bonfireAuth, sliceUrn, "<experiment href=\"/experiments/336\" xmlns=\"http://api.bonfire-project.eu/doc/schemas/occi\">\n" +
                "  <id>336</id>\n" +
                "  <description>Demo of scenario1 using Restfully</description>\n" +
                "  <name>Scenario1</name>\n" +
                "  <walltime>1800</walltime>\n" +
                "  <user_id>crohr</user_id>\n" +
                "  <status>canceling</status>\n" +
                "  <networks>\n" +
                "  </networks>\n" +
                "  <computes>\n" +
                "    <compute href=\"/locations/fr-inria/computes/426\" name=\"BonFIRE-monitor-experiment336\"/>\n" +
                "    <compute href=\"/locations/fr-inria/computes/427\" name=\"server-experiment#336\"/>\n" +
                "    <compute href=\"/locations/uk-epcc/computes/289\" name=\"client-experiment#336\"/>\n" +
                "  </computes>\n" +
                "  <storages>\n" +
                "  </storages>\n" +
                "  <link rel=\"parent\" href=\"/\"/>\n" +
                "  <link rel=\"storages\" href=\"/experiments/336/storages\"/>\n" +
                "  <link rel=\"networks\" href=\"/experiments/336/networks\"/>\n" +
                "  <link rel=\"computes\" href=\"/experiments/336/computes\"/>\n" +
                "</experiment>");
        Assert.assertEquals(experimentInfo.experimentId, "336");
        Assert.assertEquals(experimentInfo.experimentName, "Scenario1");
        Assert.assertEquals(experimentInfo.sliceUrn, sliceUrn);
        Assert.assertEquals(experimentInfo.sliverUrn, new GeniUrn(OcciToAggregateManagerWrapper.bonfireUrnPart, "sliver", "Scenario1"));
    }

    @Test
    public void testParseCompute() {
        OcciToAggregateManagerWrapper.ComputeInfo computeInfo = OcciToAggregateManagerWrapper.parseCompute("\n" +
                "<compute xmlns=\"http://api.bonfire-project.eu/doc/schemas/occi\" href=\"/locations/fr-inria/computes/427\">\n" +
                "  <id>427</id>\n" +
                "  <cpu>1</cpu>\n" +
                "  <memory>1024</memory>\n" +
                "  <name>server-experiment#336</name>\n" +
                "  <instance_type>small</instance_type>\n" +
                "  <state>ACTIVE</state>\n" +
                "  <disk id=\"0\">\n" +
                "    <storage href=\"/locations/fr-inria/storages/64\" name=\"squeeze 2G 2\" />\n" +
                "    <type>DISK</type>\n" +
                "    <target>xvda</target>\n" +
                "  </disk>\n" +
                "  <nic>\n" +
                "    <network href=\"/locations/fr-inria/networks/20\" name=\"Public Network\" />\n" +
                "    <ips>131.254.204.145</ips>\n" +
                "    <mac>02:00:83:fe:cc:91</mac>\n" +
                "  </nic>\n" +
                "</compute>");
        Assert.assertEquals(computeInfo.state, "ACTIVE");
        Assert.assertEquals(computeInfo.computeId, "427");
        Assert.assertEquals(computeInfo.computeName, "server-experiment#336");
        Assert.assertEquals(computeInfo.locationName, "fr-inria");
    }
    @Test
    public void testParseLocations() {
        List<String> parsedLocations = OcciToAggregateManagerWrapper.parseLocationsXml("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<collection xmlns=\"http://api.bonfire-project.eu/doc/schemas/occi\" href=\"/locations\">\n" +
                "  <items offset=\"0\" total=\"10\">\n" +
                "<location href=\"/locations/autobahn\">\n" +
                "  <name>autobahn</name>\n" +
                "  <url>http://172.18.9.5:8080/autobahn/uap</url>\n" +
                "  <link rel=\"parent\" href=\"/\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"computes\" href=\"/locations/autobahn/computes\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"networks\" href=\"/locations/autobahn/networks\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"storages\" href=\"/locations/autobahn/storages\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"routers\" href=\"/locations/autobahn/routers\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"site_links\" href=\"/locations/autobahn/site_links\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"configurations\" href=\"/locations/autobahn/configurations\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"services\" href=\"/locations/autobahn/services\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"account\" href=\"/locations/autobahn/account\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</location>\n" +
                "<location href=\"/locations/be-ibbt\">\n" +
                "  <name>be-ibbt</name>\n" +
                "  <url>https://bonfire2.test.atlantis.ugent.be</url>\n" +
                "  <link rel=\"parent\" href=\"/\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"computes\" href=\"/locations/be-ibbt/computes\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"networks\" href=\"/locations/be-ibbt/networks\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"storages\" href=\"/locations/be-ibbt/storages\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"routers\" href=\"/locations/be-ibbt/routers\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"site_links\" href=\"/locations/be-ibbt/site_links\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"configurations\" href=\"/locations/be-ibbt/configurations\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"services\" href=\"/locations/be-ibbt/services\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"account\" href=\"/locations/be-ibbt/account\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</location>\n" +
                "<location href=\"/locations/de-hlrs\">\n" +
                "  <name>de-hlrs</name>\n" +
                "  <url>https://nebulosus.rus.uni-stuttgart.de:8443</url>\n" +
                "  <link rel=\"parent\" href=\"/\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"computes\" href=\"/locations/de-hlrs/computes\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"networks\" href=\"/locations/de-hlrs/networks\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"storages\" href=\"/locations/de-hlrs/storages\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"routers\" href=\"/locations/de-hlrs/routers\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"site_links\" href=\"/locations/de-hlrs/site_links\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"configurations\" href=\"/locations/de-hlrs/configurations\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"services\" href=\"/locations/de-hlrs/services\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"account\" href=\"/locations/de-hlrs/account\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</location>\n" +
                "<location href=\"/locations/es-wellness\">\n" +
                "  <name>es-wellness</name>\n" +
                "  <url>https://occi-bonfire.wtelecom.es</url>\n" +
                "  <link rel=\"parent\" href=\"/\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"computes\" href=\"/locations/es-wellness/computes\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"networks\" href=\"/locations/es-wellness/networks\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"storages\" href=\"/locations/es-wellness/storages\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"routers\" href=\"/locations/es-wellness/routers\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"site_links\" href=\"/locations/es-wellness/site_links\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"configurations\" href=\"/locations/es-wellness/configurations\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"services\" href=\"/locations/es-wellness/services\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"account\" href=\"/locations/es-wellness/account\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</location>\n" +
                "<location href=\"/locations/federica\">\n" +
                "  <name>federica</name>\n" +
                "  <url>https://sfa-registry.ict-openlab.eu:12345;https://sfa-federica.ict-openlab.eu:12346</url>\n" +
                "  <link rel=\"parent\" href=\"/\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"computes\" href=\"/locations/federica/computes\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"networks\" href=\"/locations/federica/networks\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"storages\" href=\"/locations/federica/storages\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"routers\" href=\"/locations/federica/routers\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"site_links\" href=\"/locations/federica/site_links\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"configurations\" href=\"/locations/federica/configurations\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"services\" href=\"/locations/federica/services\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"account\" href=\"/locations/federica/account\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</location>\n" +
                "<location href=\"/locations/fr-inria\">\n" +
                "  <name>fr-inria</name>\n" +
                "  <url>https://frontend.bonfire.grid5000.fr:443</url>\n" +
                "  <link rel=\"parent\" href=\"/\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"computes\" href=\"/locations/fr-inria/computes\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"networks\" href=\"/locations/fr-inria/networks\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"storages\" href=\"/locations/fr-inria/storages\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"routers\" href=\"/locations/fr-inria/routers\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"site_links\" href=\"/locations/fr-inria/site_links\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"configurations\" href=\"/locations/fr-inria/configurations\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"services\" href=\"/locations/fr-inria/services\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"account\" href=\"/locations/fr-inria/account\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</location>\n" +
                "<location href=\"/locations/pl-psnc\">\n" +
                "  <name>pl-psnc</name>\n" +
                "  <url>https://bonfire.psnc.pl:8443</url>\n" +
                "  <link rel=\"parent\" href=\"/\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"computes\" href=\"/locations/pl-psnc/computes\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"networks\" href=\"/locations/pl-psnc/networks\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"storages\" href=\"/locations/pl-psnc/storages\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"routers\" href=\"/locations/pl-psnc/routers\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"site_links\" href=\"/locations/pl-psnc/site_links\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"configurations\" href=\"/locations/pl-psnc/configurations\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"services\" href=\"/locations/pl-psnc/services\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"account\" href=\"/locations/pl-psnc/account\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</location>\n" +
                "<location href=\"/locations/uk-epcc\">\n" +
                "  <name>uk-epcc</name>\n" +
                "  <url>https://bonfire.epcc.ed.ac.uk:8443</url>\n" +
                "  <link rel=\"parent\" href=\"/\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"computes\" href=\"/locations/uk-epcc/computes\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"networks\" href=\"/locations/uk-epcc/networks\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"storages\" href=\"/locations/uk-epcc/storages\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"routers\" href=\"/locations/uk-epcc/routers\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"site_links\" href=\"/locations/uk-epcc/site_links\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"configurations\" href=\"/locations/uk-epcc/configurations\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"services\" href=\"/locations/uk-epcc/services\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"account\" href=\"/locations/uk-epcc/account\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</location>\n" +
                "<location href=\"/locations/uk-hplabs\">\n" +
                "  <name>uk-hplabs</name>\n" +
                "  <url>https://occisvr.bonfire3.ext25.bonfire.hpl.hp.com</url>\n" +
                "  <link rel=\"parent\" href=\"/\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"computes\" href=\"/locations/uk-hplabs/computes\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"networks\" href=\"/locations/uk-hplabs/networks\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"storages\" href=\"/locations/uk-hplabs/storages\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"routers\" href=\"/locations/uk-hplabs/routers\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"site_links\" href=\"/locations/uk-hplabs/site_links\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"configurations\" href=\"/locations/uk-hplabs/configurations\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"services\" href=\"/locations/uk-hplabs/services\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"account\" href=\"/locations/uk-hplabs/account\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</location>\n" +
                "<location href=\"/locations/useast-aws\">\n" +
                "  <name>useast-aws</name>\n" +
                "  <url>https://ec2.amazonaws.com</url>\n" +
                "  <link rel=\"parent\" href=\"/\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"computes\" href=\"/locations/useast-aws/computes\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"networks\" href=\"/locations/useast-aws/networks\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"storages\" href=\"/locations/useast-aws/storages\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"routers\" href=\"/locations/useast-aws/routers\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"site_links\" href=\"/locations/useast-aws/site_links\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"configurations\" href=\"/locations/useast-aws/configurations\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"services\" href=\"/locations/useast-aws/services\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "  <link rel=\"account\" href=\"/locations/useast-aws/account\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</location>\n" +
                "  </items>\n" +
                "  <link href=\"/\" rel=\"parent\" type=\"application/vnd.bonfire+xml\"/>\n" +
                "</collection>\n" +
                "\n");

        List<String> correctLocations = new ArrayList<String>();
        correctLocations.add("autobahn");
        correctLocations.add("be-ibbt");
        correctLocations.add("de-hlrs");
        correctLocations.add("es-wellness");
        correctLocations.add("federica");
        correctLocations.add("fr-inria");
        correctLocations.add("pl-psnc");
        correctLocations.add("uk-epcc");
        correctLocations.add("uk-hplabs");
        correctLocations.add("useast-aws");

        Assert.assertEquals(correctLocations.size(), parsedLocations.size());
        Assert.assertEquals(correctLocations, parsedLocations);
    }
}
