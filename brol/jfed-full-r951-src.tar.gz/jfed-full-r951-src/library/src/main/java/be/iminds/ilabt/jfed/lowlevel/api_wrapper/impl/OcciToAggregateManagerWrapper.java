package be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl;

import be.iminds.ilabt.jfed.log.ApiCallDetails;
import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.GeniUserProvider;
import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.ServerType;
import be.iminds.ilabt.jfed.lowlevel.api.OCCI;
import be.iminds.ilabt.jfed.lowlevel.api.UserSpec;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.AggregateManagerWrapper;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.JFedConnection;
import be.iminds.ilabt.jfed.lowlevel.connection.RestSslPasswordConnection;
import be.iminds.ilabt.jfed.util.ExtraInfoCallback;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.StringReader;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * OcciToAggregateManagerWrapper
 *
 * OCCI doesn't provide a real AM, but we can wrap it (with limited functionality)...
 *
 */
public class OcciToAggregateManagerWrapper extends AggregateManagerWrapper {
    public static final String bonfireUrnPart = "bonfire-project.eu";
    public static final GeniUrn bonfireUrn = new GeniUrn(bonfireUrnPart, "authority", "cm");
    private final static org.apache.logging.log4j.Logger LOG = LogManager.getLogger();


    //    public static GeniUrn mapExperimentInfoToSliceUrn(String experimentName) {
//        return new GeniUrn(bonfireUrnPart, "slice", experimentName);
//    }
    public static GeniUrn mapExperimentInfoToSliverUrn(String experimentName) {
        return new GeniUrn(bonfireUrnPart, "sliver", experimentName);
    }
    public static GeniUrn mapSliceUrnToSliverUrn(GeniUrn sliceUrn) {
        return new GeniUrn(bonfireUrnPart, "sliver", sliceUrn.getResourceName());
    }
    public String mapSliceUrnToExperimentName(GeniUrn sliceUrn) {
        return sliceUrn.getResourceName();
    }
    public String mapSliverUrnToExperimentName(GeniUrn sliceUrn) {
        return sliceUrn.getResourceName();
    }

    private static Map<String, GeniUrn> experimentIdToSliceUrn = new HashMap<String, GeniUrn>();
    /**
     * HACK this is a shortcut, because EasyModelICCIListener has no way to know the slice URN, but it needs it...
     * */
    public static synchronized GeniUrn mapExperimentIdToSliceUrn(String experimentId) {
        GeniUrn sliceUrn = experimentIdToSliceUrn.get(experimentId);
        assert sliceUrn != null : "No slice URN known for bonfire experiment ID: \""+experimentId+"\"";
        return sliceUrn;
    }

    private OCCI occi;


    public static class ExperimentInfo {
        public ExperimentInfo(GeniUrn sliceUrn, GeniUrn sliverUrn, String experimentName) {
            this.sliceUrn = sliceUrn;
            this.sliverUrn = sliverUrn;
            this.experimentName = experimentName;
        }
        public GeniUrn sliceUrn;
        public GeniUrn sliverUrn;
        public String experimentName;
        public String experimentId;
        public List<ComputeInfo> computes;

        public String manifestRspec;

        @Override
        public String toString() {
            return "ExperimentInfo{" +
                    "sliceUrn=" + sliceUrn +
                    ", experimentId='" + experimentId + '\'' +
                    '}';
        }
    }

    public static class ComputeInfo {
        public String experimentId;
        public final List<String> storageIds = new ArrayList<String>();
        public final List<String> networkIds = new ArrayList<String>();
        public String computeName;
        public String computeId;
        public String locationName;
        public String state;
        public final Map<String, String> ipsByNetworkId = new HashMap<String,String>();
        public boolean ready() {
            if (state == null) return false;
            return state.equalsIgnoreCase("ACTIVE") || state.equalsIgnoreCase("RUNNING") || state.equalsIgnoreCase("READY");
        };

        @Override
        public String toString() {
            return "ComputeInfo{" +
                    "computeId='" + computeId + '\'' +
                    ", locationName='" + locationName + '\'' +
                    ", experimentId='" + experimentId + '\'' +
                    '}';
        }
    }

    static private Map<GeniUrn, ExperimentInfo> sliceUrnToExperimentInfo = new HashMap<GeniUrn, ExperimentInfo>();

    protected OcciToAggregateManagerWrapper(Logger logger, GeniUserProvider geniUserProvider, GeniConnectionProvider connectionProvider, SfaAuthority amAuthority) {
        super(logger, geniUserProvider, connectionProvider, amAuthority);

        occi = new OCCI(logger);
    }

    protected RestSslPasswordConnection getConnection() throws JFedException {
        JFedConnection res = getConnection(new ServerType(ServerType.GeniServerRole.OCCI, 1));
        if (res == null) throw new RuntimeException("No connection can be created.");
        return (RestSslPasswordConnection) res;
    }

    public static List<String> parseLocationsXml(String xml) {

/* example
<?xml version="1.0" encoding="UTF-8"?>
<collection xmlns="http://api.bonfire-project.eu/doc/schemas/occi" href="/locations">
  <items offset="0" total="10">
<location href="/locations/autobahn">
  <name>autobahn</name>
  <url>http://172.18.9.5:8080/autobahn/uap</url>
</location>
<location href="/locations/be-ibbt">
  <name>be-ibbt</name>
  <url>https://bonfire2.test.atlantis.ugent.be</url>
</location>
* */
        try {
            List<String> locations = new ArrayList<String>();

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(xml));
            Document doc = db.parse(is);

            Element rootEl = doc.getDocumentElement();

            String rootElName = rootEl.getTagName();
            if (!rootElName.equalsIgnoreCase("collection")) {
                throw new RuntimeException("Not a collection (root element tag name="+rootElName+"): "+xml);
            }

            NodeList itemsList = rootEl.getElementsByTagName("items");
            assert itemsList.getLength() > 0;
            Node itemsN = itemsList.item(0);
            assert itemsN instanceof Element;
            Element itemsEl = (Element) itemsN;

            NodeList locationList = itemsEl.getElementsByTagName("location");
            for (int i = 0; i < locationList.getLength(); i++) {
                Node locNode = locationList.item(i);
                assert locNode instanceof Element;
                Element locEl = (Element) locNode;

                NodeList nameList = locEl.getElementsByTagName("name");
                assert nameList.getLength() == 1;
                Node nameN = nameList.item(0);
                assert nameN instanceof Element;
                Element nameEl = (Element) nameN;

                locations.add(nameEl.getTextContent());
            }

            return locations;
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("ParserConfigurationException: "+e.getMessage(), e);
        } catch (SAXException e) {
            throw new RuntimeException("SAXException: "+e.getMessage(), e);
        } catch (IOException e) {
            throw new RuntimeException("IOException: "+e.getMessage(), e);
        }
    }

    public static String fakeAdvertisementRspec(List<String> sites) {
        assert sites != null;

        StringBuilder adRspecBuilder = new StringBuilder();
        adRspecBuilder.append("<rspec type=\"advertisement\" xmlns=\"http://www.geni.net/resources/rspec/3\"" +
                "    xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/ad.xsd \">\n");
        for (String site : sites) {
            String siteUrnPart = site.replaceAll("[^a-zA-Z0-9-]", "");
            adRspecBuilder.append("    <node\n" +
                    "        component_id=\"urn:publicid:IDN+"+bonfireUrnPart+"+node+"+siteUrnPart+"\"\n" +
                    "        component_manager_id=\""+bonfireUrn.toString()+"\"\n" +
                    "        component_name=\""+site+"\" exclusive=\"false\">\n" +
                    "        <sliver_type name=\"lite\"/>\n" +
                    "        <sliver_type name=\"small\"/>\n" +
                    "    </node>\n");
        }
        adRspecBuilder.append("</rspec>");
        final String adRspec = adRspecBuilder.toString();
        return adRspec;
    }

    @Override
    public void getVersion() throws JFedException {
        //does nothing
    }

    @Override
    public String listResources(AnyCredential userCredential, boolean available) throws JFedException {
        OCCI.OCCIReply<String> reply = occi.getLocations(getConnection());

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("OCCI getExperiments Call not successful");
        }

        List<String> locations = parseLocationsXml(reply.getValue());
        LOG.debug("OcciToAggregateManagerWrapper.listResources: Received "+locations.size()+" locations from server: "+locations);
        String fakeAdvertisementRspec = fakeAdvertisementRspec(locations);
        LOG.debug("OcciToAggregateManagerWrapper.listResources: Created fake advertisement Rspec: "+fakeAdvertisementRspec);
        return fakeAdvertisementRspec;
    }

    /**
     * @return ExperimentInfo with experimentId and experimentName filled in
     * */
    public static ExperimentInfo parseExperiment(SfaAuthority auth, GeniUrn sliceUrn, String xml) {
        /*
        <experiment href="/experiments/336" xmlns="http://api.bonfire-project.eu/doc/schemas/occi">
          <id>336</id>
          ...
        * */
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(xml));
            Document doc = db.parse(is);

            Element rootEl = doc.getDocumentElement();

            String rootElName = rootEl.getTagName();
            if (!rootElName.equalsIgnoreCase("experiment")) {
                throw new RuntimeException("Not an experiment (root element tag name="+rootElName+"): "+xml);
            }

            NodeList idList = rootEl.getElementsByTagName("id");
            assert idList.getLength() > 0;
            Node idN = idList.item(0);
            assert idN instanceof Element;
            Element idEl = (Element) idN;
            String id = idEl.getTextContent();

            NodeList nameList = rootEl.getElementsByTagName("name");
            assert nameList.getLength() > 0;
            Node nameN = nameList.item(0);
            assert nameN instanceof Element;
            Element nameEl = (Element) nameN;
            String name = nameEl.getTextContent();

            GeniUrn sliverUrn = mapExperimentInfoToSliverUrn(name);
            assert sliceUrn == null || sliverUrn.equals(mapSliceUrnToSliverUrn(sliceUrn));

            ExperimentInfo res = new ExperimentInfo(sliceUrn, sliverUrn, name);
            res.experimentId = idEl.getTextContent();
            return res;
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("ParserConfigurationException: "+e.getMessage(), e);
        } catch (SAXException e) {
            throw new RuntimeException("SAXException: "+e.getMessage(), e);
        } catch (IOException e) {
            throw new RuntimeException("IOException: "+e.getMessage(), e);
        }
    }

    private static String fixedPublicNetworkIdForLocation(String locationName) {
        //TODO get list using OCCI and let user choose using RSpec somehow
        if (locationName.equals("uk-epcc")) return "517";
        if (locationName.equals("be-ibbt")) return null;
        if (locationName.equals("de-hlrs")) return null;
        if (locationName.equals("es-wellness")) return null;
        if (locationName.equals("fr-inria")) return "27";
        if (locationName.equals("pl-psnc")) return null;
        if (locationName.equals("uk-hplabs")) return "subnet-2-2";
        return null;
    }
    private static String fixedWanNetworkIdForLocation(String locationName) {
        //TODO get list using OCCI and let user choose using RSpec somehow
        if (locationName.equals("uk-epcc")) return "105";
        if (locationName.equals("be-ibbt")) return "1"; //also 2561 2563
        if (locationName.equals("de-hlrs")) return "90";
        if (locationName.equals("es-wellness")) return "8d6b0daa-858b-41e7-b72e-310ac8619b50";
        if (locationName.equals("fr-inria")) return "53";
        if (locationName.equals("pl-psnc")) return "0";
        if (locationName.equals("uk-hplabs")) return "subnet-2-3";
        return null;
    }

    private static String fixedStorageIdForLocation(String locationName) {
        //TODO get list using OCCI and let user choose using RSpec somehow
        if (locationName.equals("be-ibbt")) return "14";
        if (locationName.equals("de-hlrs")) return "3516";
        if (locationName.equals("es-wellness")) return "vappTemplate-394cf26e-85a9-4180-80fd-88e8f6e47dc1";
        if (locationName.equals("fr-inria")) return "3904";
        if (locationName.equals("pl-psnc")) return "1067";
        if (locationName.equals("uk-epcc")) return "4527";
        if (locationName.equals("uk-hplabs")) return "vol-32108796";
        return null;
    }

    @Override
    public String createSliver(GeniUrn sliceUrn, AnyCredential sliceCredential, String rspec, List<UserSpec> users, Date expirationDate) throws JFedException {
        //create bonfire experiment and generate sliver URN. link (static) sliver URN with slice URN and with bonfire experiment in this class.

        LOG.debug("OcciToAggregateManagerWrapper.createSliver sliceUrn="+sliceUrn+" rspec="+rspec);

        String groups = ExtraInfoCallback.getBonfireGroups();

        ExperimentInfo exInf = sliceUrnToExperimentInfo.get(sliceUrn);
        if (exInf != null && exInf.experimentId != null) {
            //check if experiment has compute nodes. If it has fail.
            OCCI.OCCIReply<String> reply = occi.getExperimentComputes(getConnection(), exInf.experimentId);

            //TODO check if there are computes...
            LOG.warn("TO IMPLEMENT: check if there are computes active already, fail if so");
        } else {
            exInf = new ExperimentInfo(sliceUrn, mapExperimentInfoToSliverUrn(sliceUrn.getResourceName()), sliceUrn.getResourceName());
            LOG.debug("Linking generated experiment Urn ("+sliceUrn+") with bonfire experiment info");
            sliceUrnToExperimentInfo.put(sliceUrn, exInf);
            exInf.experimentName = sliceUrn.getResourceName();

            //walltime = time in seconds that the sliver should live
            int walltime_s = (int) ((expirationDate.getTime() - new Date().getTime())/1000);

            String description = "experiment generated by jFed";

            OCCI.OCCIReply<String> reply = occi.postExperimentWizard(getConnection(), groups, exInf.experimentName, walltime_s, description);

            if (!reply.getGeniResponseCode().isSuccess() || reply.getValue() == null)
                throw new JFedException("Failed to create experiment \""+exInf.experimentName+"\"");

            //parse experiment ID
            exInf.experimentId = parseExperiment(amAuthority, sliceUrn, reply.getValue()).experimentId;
            experimentIdToSliceUrn.put(exInf.experimentId,  sliceUrn); //register link between experiment ID and slice
            LOG.debug("mapped experiment id "+exInf.experimentId+" to slice urn "+sliceUrn);
        }

        assert exInf.experimentName != null;
        assert exInf.experimentId != null;

        StringBuilder fakeManifestRspecBuilder = new StringBuilder(200);
        fakeManifestRspecBuilder.append("<rspec " +
                "xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" " +
                "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
                "xmlns=\"http://www.geni.net/resources/rspec/3\" type=\"manifest\" " +
                "xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/manifest.xsd \" >\n");

        //create computes
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(rspec));
            Document doc = db.parse(is);

            Element rootEl = doc.getDocumentElement();

            String rootElName = rootEl.getTagName();
            if (!rootElName.equalsIgnoreCase("rspec")) {
                throw new RuntimeException("Not an rspec (root element tag name="+rootElName+"): "+rspec);
            }

            NodeList childNodeList = rootEl.getChildNodes();
            for (int i = 0; i < childNodeList.getLength(); i++) {
                Node n = childNodeList.item(i);

                if (n instanceof Element) {
                    Element e = (Element) n;
                    String childName = e.getTagName();
                    if (childName.equalsIgnoreCase("node")) {
                        String componentId = e.getAttribute("component_id");
                        String componentManagerId = e.getAttribute("component_manager_id");
                        String clientId = e.getAttribute("client_id");

                        boolean usableRspecNode=true;
                        if (componentId == null || componentId.trim().isEmpty()) usableRspecNode = false;
                        if (componentManagerId == null || componentManagerId.trim().isEmpty()) usableRspecNode = false;
                        if (clientId == null || clientId.trim().isEmpty()) usableRspecNode = false;
                        if (!usableRspecNode)
                            LOG.warn("RSpec node is not usable for bonfire emualtion: componentId="+componentId+
                                    " clientId="+clientId+" componentManagerId="+componentManagerId);

                        if (usableRspecNode && componentManagerId.equals(bonfireUrn.toString())) {
                            ComputeInfo computeInfo = new ComputeInfo();
                            computeInfo.computeName = clientId;
                            GeniUrn locationUrn = new GeniUrn(componentId);
                            computeInfo.locationName = locationUrn.getResourceName();

                            String publicNetId = fixedPublicNetworkIdForLocation(computeInfo.locationName);
                            String wanNetId = fixedWanNetworkIdForLocation(computeInfo.locationName);
                            if (publicNetId != null) computeInfo.networkIds.add(publicNetId);
                            if (wanNetId != null) computeInfo.networkIds.add(wanNetId);
                            computeInfo.storageIds.add(fixedStorageIdForLocation(computeInfo.locationName));

                            //TODO parse sliver_type and use as instanceType
                            String instanceType = "lite";

                            OCCI.OCCIReply<String> reply = occi.postExperimentComputeWizard(getConnection(), exInf.experimentId,
                                    computeInfo.computeName,
                                    groups,
                                    computeInfo.locationName,
                                    instanceType,
                                    computeInfo.networkIds,
                                    computeInfo.storageIds);

                            if (!reply.getGeniResponseCode().isSuccess())
                                throw new JFedException("Could not post experiment compute", null, reply.getGeniResponseCode());

                            ComputeInfo computeInfoRecv = parseCompute(reply.getValue());

                            fakeManifestRspecBuilder.append(
                                    " <node client_id=\""+computeInfo.computeName+"\" " +
                                            "       component_manager_id=\""+componentManagerId+"\" " +
                                            "       exclusive=\"false\" " +
                                            "       component_id=\""+componentId+"\"" +
                                            "       sliver_id=\""+exInf.sliverUrn.toString()+"\"> " +
                                            "   <sliver_type name=\""+instanceType+"\"/> ");
                            if (computeInfoRecv.ipsByNetworkId.containsKey(publicNetId) || computeInfoRecv.ipsByNetworkId.containsKey(wanNetId)) {
                                String nodename;
                                if (computeInfoRecv.ipsByNetworkId.containsKey(publicNetId))
                                    nodename = computeInfoRecv.ipsByNetworkId.get(publicNetId);
                                else
                                    nodename = computeInfoRecv.ipsByNetworkId.get(wanNetId);

                                LOG.debug("Using IP in bonfire compute info for SSH: "+nodename);

                                assert nodename != null;
                                String port = "22";
                                String username = "root";
                                fakeManifestRspecBuilder.append(
                                        "   <services>" +
                                                "       <login authentication=\"ssh-keys\" " +
                                                "hostname=\""+nodename+"\" " +
                                                "port=\""+port+"\" " +
                                                "username=\""+username+"\"/>" +
                                                "   </services>");
                            } else {
                                LOG.debug("No IP in bonfire compute info");
                            }
                            fakeManifestRspecBuilder.append("</node> ");
                        }
                    }
                }
            }
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("ParserConfigurationException: "+e.getMessage(), e);
        } catch (SAXException e) {
            throw new RuntimeException("SAXException: "+e.getMessage(), e);
        } catch (IOException e) {
            throw new RuntimeException("IOException: "+e.getMessage(), e);
        } catch (GeniUrn.GeniUrnParseException e) {
            throw new RuntimeException("GeniUrnParseException: "+e.getMessage(), e);
        }

        fakeManifestRspecBuilder.append("</rspec>");

        exInf.manifestRspec = fakeManifestRspecBuilder.toString();


        //HACK to send manifest to easymodel if any
        Map<String, Object> methodParameters = new HashMap<String, Object>();
        methodParameters.put("sliceUrn", exInf.sliceUrn);
        methodParameters.put("sliverUrn", exInf.sliverUrn);
        methodParameters.put("fakeManifest", exInf.manifestRspec);
        ApiCallDetails fakeManifestCall = new ApiCallDetails(
                amAuthority,  null, null,
                OCCI.getApiName(), "fakeManifest", "fakeManifest",
                null, null, null, null, null, null, null, null, null,
                methodParameters,
                null, null, null
        );
        occi.getLogger().fireResult(fakeManifestCall);
        //end HACK




        return exInf.manifestRspec;
    }

    @Override
    public void deleteSliver(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException {
        //delete bonfire experiment related to this sliver
        ExperimentInfo exInf = sliceUrnToExperimentInfo.get(sliceUrn);

        LOG.debug("OcciToAggregateManagerWrapper.deleteSliver("+sliceUrn+") -> exInf="+exInf);

        if (exInf != null && exInf.experimentId != null) {
            LOG.debug("OcciToAggregateManagerWrapper.deleteSliver("+sliceUrn+") is deleting -> exInf.experimentId="+exInf.experimentId);
            OCCI.OCCIReply<String> reply = occi.deleteExperiment(getConnection(), exInf.experimentId);

            if (reply.getGeniResponseCode().isSuccess())
                sliceUrnToExperimentInfo.remove(sliceUrn);
        } else {
            LOG.debug("Could not find experiment to delete! ");
        }
    }

    public static List<ComputeInfo> parseExperimentComputes(String experimentId, String xml) {
        /*example:
<collection xmlns="http://api.bonfire-project.eu/doc/schemas/occi" href="/experiments/336/computes">
  <items offset="0" total="1">
<compute href="/locations/fr-inria/computes/426" name="BonFIRE-monitor-experiment336"/>
  </items>
  <link href="/experiments/336" rel="parent" type="application/vnd.bonfire+xml"/>
</collection>
        * */

        List<ComputeInfo> res = new ArrayList<ComputeInfo>();
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(xml));
            Document doc = db.parse(is);

            Element rootEl = doc.getDocumentElement();

            String rootElName = rootEl.getTagName();
            if (!rootElName.equalsIgnoreCase("collection")) {
                throw new RuntimeException("Not an collection (root element tag name="+rootElName+"): "+xml);
            }

            NodeList itemsList = rootEl.getElementsByTagName("items");
            assert itemsList.getLength() > 0;
            Node itemN = itemsList.item(0);
            assert itemN instanceof Element;
            Element itemEl = (Element) itemN;

            NodeList computesList = itemEl.getChildNodes();
            for (int i = 0; i < computesList.getLength(); i++) {
                Node n = computesList.item(i);

                if (n instanceof Element) {
                    Element e = (Element) n;
                    String childName = e.getTagName();
                    ComputeInfo computeInfo = new ComputeInfo();
                    if (childName.equalsIgnoreCase("compute")) {
                        computeInfo.computeName = e.getAttribute("name");
                        String href = e.getAttribute("href");
                        Pattern pattern = Pattern.compile("/locations/([a-zA-Z0-9-_]*)/computes/([0-9]*)");
                        Matcher matcher = pattern.matcher(href);
                        if (matcher.find()) {
                            computeInfo.locationName = matcher.group(1);
                            computeInfo.computeId = matcher.group(2);
                        }
                        else
                            LOG.warn("found no location in compute href=\""+href+"\"");
                        computeInfo.experimentId = experimentId;
                        res.add(computeInfo);
                    }
                }
            }
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("ParserConfigurationException: "+e.getMessage(), e);
        } catch (SAXException e) {
            throw new RuntimeException("SAXException: "+e.getMessage(), e);
        } catch (IOException e) {
            throw new RuntimeException("IOException: "+e.getMessage(), e);
        }
        return res;
    }

    /**
     * @return state
     * */
    public static ComputeInfo parseCompute(String xml) {
        /*example
        * <compute xmlns="http://api.bonfire-project.eu/doc/schemas/occi" href="/locations/fr-inria/computes/427">
          <id>427</id>
          <cpu>1</cpu>
          <memory>1024</memory>
          <name>server-experiment#336</name>
          <instance_type>small</instance_type>
          <state>PENDING</state>
          <disk id="0">
            <storage href="/locations/fr-inria/storages/64" name="squeeze 2G 2" />
            <type>DISK</type>
            <target>xvda</target>
          </disk>
          <nic>
            <network href="/locations/fr-inria/networks/20" name="Public Network" />
            <ips>131.254.204.145</ips>
            <mac>02:00:83:fe:cc:91</mac>
          </nic>
          <context>
        <eth0_ip>129.215.175.149</eth0_ip>
          </context>
        </compute>*/
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(xml));
            Document doc = db.parse(is);

            Element rootEl = doc.getDocumentElement();

            String rootElName = rootEl.getTagName();
            if (!rootElName.equalsIgnoreCase("compute")) {
                throw new RuntimeException("Not a compute (root element tag name="+rootElName+"): "+xml);
            }

            ComputeInfo computeInfo = new ComputeInfo();
            String href = rootEl.getAttribute("href");
            Pattern pattern = Pattern.compile("/locations/([a-zA-Z0-9-_]*)/computes/([0-9]*)");
            Matcher matcher = pattern.matcher(href);
            if (matcher.find()) {
                computeInfo.locationName = matcher.group(1);
                computeInfo.computeId = matcher.group(2);
            }
            else
                LOG.warn("found no location in compute href=\""+href+"\"");

            NodeList computesList = rootEl.getChildNodes();
            for (int i = 0; i < computesList.getLength(); i++) {
                Node n = computesList.item(i);

                if (n instanceof Element) {
                    Element e = (Element) n;
                    String childName = e.getTagName();
                    if (childName.equalsIgnoreCase("state")) {
                        computeInfo.state = e.getTextContent();
                    }
                    if (childName.equalsIgnoreCase("id")) {
                        assert computeInfo.computeId == null || computeInfo.computeId.equals(e.getTextContent()) : "compute id mismatch";
                        computeInfo.computeId = e.getTextContent();
                    }
                    if (childName.equalsIgnoreCase("name"))
                        computeInfo.computeName = e.getTextContent();

//                    if (childName.equalsIgnoreCase("context")) {
//                        NodeList contextNodesList = e.getChildNodes();
//                        for (int j = 0; j < contextNodesList.getLength(); j++) {
//                            Node subn = contextNodesList.item(j);
//                            if (subn instanceof Element) {
//                                Element sube = (Element) subn;
//                                String subChildName = sube.getTagName();
//                                if (subChildName.startsWith("eth") &&
//                                    subChildName.endsWith("_ip"))
//                                    computeInfo.ipsByNetworkId.put(?, sube.getTextContent());
//                            }
//                        }
//                    }
                    if (childName.equalsIgnoreCase("nic")) {
                        NodeList nicNodesList = e.getChildNodes();
                        String nicIp = null, networkId = null;
                        for (int j = 0; j < nicNodesList.getLength(); j++) {
                            Node subn = nicNodesList.item(j);
                            if (subn instanceof Element) {
                                Element sube = (Element) subn;
                                String subChildName = sube.getTagName();
                                if (subChildName.equals("network")) {
                                    String networkHref = sube.getAttribute("href");
                                    int lastSlash = networkHref.lastIndexOf('/');
                                    if (lastSlash > 0) {
                                        networkId = networkHref.substring(lastSlash+1);
                                    }
                                }
                                if (subChildName.equals("ip")) {
                                    nicIp = sube.getTextContent();
                                }
                            }
                        }
                        if (nicIp != null && networkId != null) {
                            computeInfo.ipsByNetworkId.put(networkId, nicIp);
                            LOG.debug("Parsed IP in bonfire compute info: "+networkId+" -> "+nicIp);
                        }
                    }
                }
            }

            return computeInfo;
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("ParserConfigurationException: "+e.getMessage(), e);
        } catch (SAXException e) {
            throw new RuntimeException("SAXException: "+e.getMessage(), e);
        } catch (IOException e) {
            throw new RuntimeException("IOException: "+e.getMessage(), e);
        }
    }

    @Override
    public SliverStatus status(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException {
        //check status of experiment computes
        ExperimentInfo exInf = sliceUrnToExperimentInfo.get(sliceUrn);

        if (exInf != null && exInf.experimentId != null) {
            OCCI.OCCIReply<String> replyComputes = occi.getExperimentComputes(getConnection(), exInf.experimentId);

            if (replyComputes.getGeniResponseCode().isSuccess()) {
                List<ComputeInfo> computeInfos = parseExperimentComputes(exInf.experimentId, replyComputes.getValue());

                LOG.debug("OcciToAggregateManagerWrapper.status checking "+computeInfos.size()+" computes");

                boolean allReady = true;
                for (ComputeInfo computeInfo : computeInfos) {
                    OCCI.OCCIReply<String> replyLocCompute = occi.getLocationCompute(getConnection(), computeInfo.locationName, computeInfo.computeId);
                    //Note that EasyModelOCCIListener independently handles replies to this call

                    if (!replyLocCompute.getGeniResponseCode().isSuccess()) {
                        LOG.debug("OcciToAggregateManagerWrapper.status   failed to get status for compute "+computeInfo+". status unknown. "+replyLocCompute.getGeniResponseCode());
                        return SliverStatus.UNKNOWN; //fail or unallocated but we don't know...
                    }
                    else {
                        OcciToAggregateManagerWrapper.ComputeInfo infoRecv = OcciToAggregateManagerWrapper.parseCompute(replyLocCompute.getValue());
                        LOG.debug("OcciToAggregateManagerWrapper.status got status "+infoRecv.state+" (ready="+infoRecv.ready()+") for compute "+computeInfo);
                        if (!infoRecv.ready())
                            allReady = false;
                    }
                }
                LOG.debug("OcciToAggregateManagerWrapper.status   allready="+allReady);

                if (allReady)
                    return SliverStatus.READY;
                else
                    return SliverStatus.CHANGING;
            }
        }

        return SliverStatus.UNKNOWN; //fail or unallocated but we don't know...
    }

    @Override
    public String describe(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException  {
        //generate RSpec based on experiment  This is actually done on createSliver, and stored version is returned here.
        ExperimentInfo exInf = sliceUrnToExperimentInfo.get(sliceUrn);

        if (exInf != null) {
            //totally fake
            return exInf.manifestRspec;
        }

        return null;
    }

    @Override
    public void renewSliver(GeniUrn sliceUrn, AnyCredential sliceCredential, Date newExpire) throws JFedException {
        //modify bonfire experiment wall time
        ExperimentInfo exInf = sliceUrnToExperimentInfo.get(sliceUrn);

        throw new RuntimeException("Not yet implemented");
    }
}
