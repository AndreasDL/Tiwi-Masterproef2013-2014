//package be.iminds.ilabt.jfed.util;
//
///*
// * Licensed to the Apache Software Foundation (ASF) under one
// * or more contributor license agreements.  See the NOTICE file
// * distributed with this work for additional information
// * regarding copyright ownership.  The ASF licenses this file
// * to you under the Apache License, Version 2.0 (the
// * "License"); you may not use this file except in compliance
// * with the License.  You may obtain a copy of the License at
// *
// *     http://www.apache.org/licenses/LICENSE-2.0
// *
// * Unless required by applicable law or agreed to in writing, software
// * distributed under the License is distributed on an "AS IS" BASIS,
// * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// * See the License for the specific language governing permissions and
// * limitations under the License.
// */
//
//import java.io.*;
//import java.net.ConnectException;
//import java.net.InetAddress;
//import java.net.InetSocketAddress;
//import java.net.Socket;
//import java.net.SocketAddress;
//import java.net.SocketException;
//import java.net.SocketImpl;
//import java.net.SocketImplFactory;
//import java.net.UnknownHostException;
//import java.nio.ByteBuffer;
//import java.nio.channels.SocketChannel;
//import java.util.Properties;
//
//import com.jcraft.jsch.*;
//
///**
// * This class replaces the standard SocketImplFactory with a factory
// * that will use an SSH proxy. Only connect operations are supported. There
// * are no server operations and nio.channels are not supported.
// * <p>
// * This class uses the following system properties:
// * <ul>
// * <li>user.home - used to calculate the default .ssh directory
// * <li>user.name - used for the default ssh user id
// * <li>ssh.user - will override user.name as the user name to send over ssh
// * <li>ssh.gateway - sets the ssh host that will proxy connections
// * <li>ssh.knownhosts - the known hosts file. (We will not add to it)
// * <li>ssh.identity - the location of the identity file. The default name
// *       is openid in the ssh directory. THIS FILE MUST NOT BE PASSWORD
// *       PROTECTED.
// * </ul>
// * @author breed
// *
// */
//public class JschSshSocketImplFactory implements SocketImplFactory, Logger {
//    Session session;
//
//    public synchronized static JschSshSocketImplFactory getFactory(InetSocketAddress proxyAddress,
//                                                               String sshUsername,
//                                                               File identityFile, File knownHostsFile) throws JSchException, IOException {
//        return new JschSshSocketImplFactory(proxyAddress, sshUsername, identityFile, knownHostsFile);
//    }
//
//    private JschSshSocketImplFactory(InetSocketAddress proxyAddress, String sshUsername, File identityFile, File knownHostsFile) throws JSchException, IOException {
//        JSch jsch = new JSch();
//        jsch.setLogger(this);
//        String knownHosts = knownHostsFile.getAbsolutePath();
//        jsch.setKnownHosts(knownHosts);
////        HostKeyRepository hostKeyRepo = ...;
////        jsch.setHostKeyRepository(hostKeyRepo);
//        jsch.addIdentity(identityFile.getAbsolutePath());
//        session = jsch.getSession(sshUsername, proxyAddress.getHostName());
//        Properties props = new Properties();
//        props.put("compression.s2c", "none");
//        props.put("compression.c2s", "none");
//        props.put("cipher.s2c", "blowfish-cbc,3des-cbc");
//        props.put("cipher.c2s", "blowfish-cbc,3des-cbc");
//        if (jsch.getHostKeyRepository().getHostKey(proxyAddress.getHostName(), null) == null) {
//            // We don't have a way to prompt, so if it isn't there we want
//            // it automatically added.
//            props.put("StrictHostKeyChecking", "no"); //TODO insecure!!!
//        }
//        session.setConfig(props);
//        session.setDaemonThread(true);
//
//        // We have to make sure that SSH uses it's own socket factory so
//        // that we don't get recursion
//        SocketFactory sfactory = new SSHSocketFactory();
//        session.setSocketFactory(sfactory);
//        UserInfo userinfo = null;
//        session.setUserInfo(userinfo);
//        session.connect();
//        if (!session.isConnected()) {
//            throw new IOException("Session not connected");
//        }
//    }
//
//    public SocketImpl createSocketImpl() {
//        return new SSHSocketImpl(session);
//
//    }
//
//    public boolean isEnabled(int arg0) {
//        // Default to not logging anything
//        return false;
//    }
//
//    public void log(int arg0, String arg1) {
//        System.err.println(arg0 + ": " + arg1);
//    }
//
//
//
//    /**
//     * This socket factory is only used by SSH. We implement it using nio.channels
//     * since those classes do not use the SocketImplFactory.
//     *
//     * @author breed
//     *
//     */
//    class SSHSocketFactory implements SocketFactory {
//
//        public Socket createSocket(String host, int port) throws IOException,
//                UnknownHostException {
////		String socksHost = System.getProperty("socksProxyHost");
//            Socket s;
//            InetSocketAddress addr = new InetSocketAddress(host, port);
////		if (socksHost != null) {
////			Proxy proxy = new Proxy(Type.SOCKS, new InetSocketAddress(
////					socksHost, 1080));
////			s = new Socket(proxy);
////			s.connect(addr);
////		} else {
////			System.err.println(addr);
//            SocketChannel sc = SocketChannel.open(addr);
//            s = sc.socket();
////		}
//            s.setTcpNoDelay(true);
//            return s;
//        }
//
//        public InputStream getInputStream(Socket socket) throws IOException {
//            return new ChannelInputStream(socket.getChannel());
//        }
//
//        public OutputStream getOutputStream(Socket socket) throws IOException {
//            return new ChannelOutputStream(socket.getChannel());
//        }
//    }
//
//
//
//    private static class ChannelOutputStream extends OutputStream {
//        SocketChannel sc;
//
//        public ChannelOutputStream(SocketChannel sc) {
//            this.sc = sc;
//        }
//
//        @Override
//        public void write(int b) throws IOException {
//            byte bs[] = new byte[1];
//            bs[0] = (byte) b;
//            write(bs);
//        }
//
//        @Override
//        public void write(byte b[], int off, int len) throws IOException {
//            sc.write(ByteBuffer.wrap(b, off, len));
//        }
//
//    }
//
//    private static class ChannelInputStream extends InputStream {
//        SocketChannel sc;
//
//        public ChannelInputStream(SocketChannel sc) {
//            this.sc = sc;
//        }
//
//        @Override
//        public int read() throws IOException {
//            byte b[] = new byte[1];
//            if (read(b) != 1) {
//                return -1;
//            }
//            return b[0] & 0xff;
//        }
//
//        @Override
//        public int read(byte b[], int off, int len) throws IOException {
//            return sc.read(ByteBuffer.wrap(b, off, len));
//        }
//    }
//
//    /**
//     * We aren't going to actually create any new connection, we will forward
//     * things to SSH.
//     */
//    private static class SSHSocketImpl extends SocketImpl {
//        Session session;
//
//        ChannelDirectTCPIP channel;
//
//        InputStream is;
//
//        OutputStream os;
//
//        SSHSocketImpl(Session session) {
//            this.session = session;
//        }
//
//        @Override
//        protected void accept(SocketImpl s) throws IOException {
//            throw new IOException("SSHSocketImpl does not implement accept");
//        }
//
//        @Override
//        protected int available() throws IOException {
//            if (is == null) {
//                throw new ConnectException("Not connected");
//            }
//            return is.available();
//        }
//
//        @Override
//        protected void bind(InetAddress host, int port) throws IOException {
//            if ((host != null && !host.isAnyLocalAddress()) || port != 0) {
//                throw new IOException("SSHSocketImpl does not implement bind");
//            }
//        }
//
//        @Override
//        protected void close() throws IOException {
//            if (channel != null) {
//                //	    channel.disconnect();
//                is = null;
//                os = null;
//            }
//        }
//
//        @Override
//        protected void connect(String host, int port) throws IOException {
//            InetAddress addr = InetAddress.getByName(host);
//            connect(addr, port);
//        }
//
//        @Override
//        protected void connect(InetAddress address, int port) throws IOException {
//            connect(new InetSocketAddress(address, port), 300000);
//        }
//
//        @Override
//        protected void connect(SocketAddress address, int timeout)
//                throws IOException {
//            try {
//                if (!session.isConnected()) {
//                    session.connect();
//                }
//                channel = (ChannelDirectTCPIP) session.openChannel("direct-tcpip");
//                //is = channel.getInputStream();
//                //os = channel.getOutputStream();
//                channel.setHost(((InetSocketAddress) address).getHostName());
//                channel.setPort(((InetSocketAddress) address).getPort());
//                channel.setOrgPort(22);
//                is = new PipedInputStream();
//                os = new PipedOutputStream();
//                channel
//                        .setInputStream(new PipedInputStream((PipedOutputStream) os));
//                channel
//                        .setOutputStream(new PipedOutputStream(
//                                (PipedInputStream) is));
//                channel.connect();
//                if (!channel.isConnected()) {
//                    System.err.println("Not connected");
//                }
//                if (channel.isEOF()) {
//                    System.err.println("EOF");
//                }
//            } catch (JSchException e) {
//                e.printStackTrace();
//                IOException newE = new IOException(e.getMessage());
//                newE.setStackTrace(e.getStackTrace());
//                throw newE;
//            }
//        }
//
//        @Override
//        protected void create(boolean stream) throws IOException {
//            if (stream == false) {
//                throw new IOException("Cannot handle UDP streams");
//            }
//        }
//
//        @Override
//        protected InputStream getInputStream() throws IOException {
//            return is;
//        }
//
//        @Override
//        protected OutputStream getOutputStream() throws IOException {
//            return os;
//        }
//
//        @Override
//        protected void listen(int backlog) throws IOException {
//            throw new IOException("SSHSocketImpl does not implement listen");
//        }
//
//        @Override
//        protected void sendUrgentData(int data) throws IOException {
//            throw new IOException("SSHSocketImpl does not implement sendUrgentData");
//        }
//
//        public Object getOption(int optID) throws SocketException {
//            throw new SocketException("SSHSocketImpl does not implement getOption");
//        }
//
//        /**
//         * We silently ignore setOptions because they do happen, but there is
//         * nothing that we can do about it.
//         */
//        public void setOption(int optID, Object value) throws SocketException {
//        }
//
//    }
//
//}
