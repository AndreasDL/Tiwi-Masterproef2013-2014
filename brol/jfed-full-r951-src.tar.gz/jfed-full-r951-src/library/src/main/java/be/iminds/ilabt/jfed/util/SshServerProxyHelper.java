package be.iminds.ilabt.jfed.util;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.params.HttpParams;
import org.apache.logging.log4j.LogManager;

import java.io.*;
import java.net.*;
import java.security.*;

/**
 * SshProxyHelper:
 *   uses some deprecated classes -> SSH proxy support is not an important feature, so not important if it breaks.
 */
public class SshServerProxyHelper {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    private static class SshProxySocket extends Socket {
        public SshProxySocket(SocketImplFactory sshHSocketImplFactory) throws IOException {
            super(sshHSocketImplFactory.createSocketImpl());
        }
    }

//    public static class SshPlainSocketFactory extends PlainSocketFactory {
//        public static final String SSH_PROXY_HOST = "sshProxy.proxyHost";
//        public static final String SSH_PROXY_PORT = "sshProxy.proxyPort";
//
//        @Override
//        public Socket createSocket(final HttpParams params) {
//            String proxyHost = (String) params.getParameter(SSH_PROXY_HOST);
//            int proxyPort = (Integer) params.getParameter(SSH_PROXY_PORT);
//
//            InetSocketAddress sshAddr = new InetSocketAddress(proxyHost, proxyPort);
//
//            Socket socket = null;
//            try {
//                socket = new SshProxySocket(sshAddr, new File("/home/wim/.ssh/id_dsa"), new File("/home/wim/.ssh/known_hosts"));
//            } catch (IOException e) {
//                e.printStackTrace();
//            } catch (JSchException e) {
//                e.printStackTrace();
//            }
//
//            return socket;
//        }
//    }

    public static class SshProxyInfo {
        private InetSocketAddress sshProxyAddr;
        private String sshUsername;
        private String sshKnownHostsFileLine;
        private String sshKnownHostsAlgo;
        private byte[] sshKnownHostsHostKey;

        private String pemPrivateKeyString;

        /**
         * @param sshKnownHostsFileLine The host key, as the single line it would appear in, in  a known_hosts file. The hostname is ignored but must be present (so it may be a dummy). The format of this line is: <hostname or hash of hostname> <key type (typically "ssh-rsa")> <host key in base64 encoding>
         *                           * */
        public SshProxyInfo(InetSocketAddress sshProxyAddr, String sshUsername, String sshKnownHostsFileLine, String pemPrivateKeyString) {
            this.sshProxyAddr = sshProxyAddr;
            this.sshUsername = sshUsername;
            this.pemPrivateKeyString = pemPrivateKeyString;

            this.sshKnownHostsFileLine = sshKnownHostsFileLine;
            if (this.sshKnownHostsFileLine != null) {
                String[] parts = sshKnownHostsFileLine.split(" ");
                if (parts.length >= 3) {
                    sshKnownHostsAlgo = parts[1];
                    sshKnownHostsHostKey = Base64.decodeBase64(org.apache.commons.codec.binary.StringUtils.getBytesUtf8(parts[2]));
                }
            }
        }

        public InetSocketAddress getSshProxyAddr() {
            return sshProxyAddr;
        }

        public String getHostName() {
            return sshProxyAddr.getHostName();
        }

        public int getPort() {
            return sshProxyAddr.getPort();
        }

        public String getSshUsername() {
            return sshUsername;
        }

        public String getServerHostKeyAlgo() {
            return sshKnownHostsAlgo;
        }
        public byte[] getServerHostKey() {
            return sshKnownHostsHostKey;
        }

        public String getPemPrivateKeyString() {
            return pemPrivateKeyString;
        }

        public char[] getPemPrivateKeyChars() {
            return getPemPrivateKeyString().toCharArray();
        }
    }


    public static class SslOverSshProxySocketFactory extends SSLSocketFactory {
        private SshProxyInfo sshProxyInfo;

        public SslOverSshProxySocketFactory(SshProxyInfo sshProxyInfo,
                                            String algorithm,
                                            KeyStore keystore,
                                            String keystorePassword,
                                            KeyStore truststore,
                                            SecureRandom random,
                                            X509HostnameVerifier hostnameVerifier)
                throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException, UnrecoverableKeyException {
            super(algorithm, keystore, keystorePassword, truststore, random, hostnameVerifier);
            this.sshProxyInfo = sshProxyInfo;
        }

        @Override
        public Socket createSocket(final HttpParams params) {
            Socket socket = null;
            try {
//                JschSshSocketImplFactory sshHSocketImplFactory =
//                        JschSshSocketImplFactory.getFactory(
//                                sshProxyAddr,
//                                sshUsername,
//                                new File(sshIdentityFilename),
//                                new File(sshKnownHosts));
                GanymedSshSocketImplFactory sshHSocketImplFactory =
                        GanymedSshSocketImplFactory.getFactory(sshProxyInfo);

                socket = new SshProxySocket(sshHSocketImplFactory);
            } catch (IOException e) {
                e.printStackTrace();
            }

            return socket;
        }
    }

}