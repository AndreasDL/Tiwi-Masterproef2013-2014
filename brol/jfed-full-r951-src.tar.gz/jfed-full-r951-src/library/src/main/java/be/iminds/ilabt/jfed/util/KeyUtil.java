package be.iminds.ilabt.jfed.util;

import ch.ethz.ssh2.crypto.cipher.DESede;
import org.apache.commons.codec.binary.*;
import org.apache.logging.log4j.LogManager;
import sun.security.x509.*;
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//import org.bouncycastle.openssl.PEMReader;
//import org.bouncycastle.openssl.PasswordFinder;

import java.io.*;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.*;
import java.security.cert.*;
//import java.security.interfaces.RSAPrivateKey;
import java.security.cert.Certificate;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.*;
import java.util.*;

/**
 * KeyUtil contains various methods to convert java keys and certificates to and from PEM format
 */
public class KeyUtil {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    public static class PEMDecodingException extends Exception {
        public PEMDecodingException() { }
        public PEMDecodingException(String message) { super(message); }
        public PEMDecodingException(String message, Throwable cause) { super(message, cause); }
        public PEMDecodingException(Throwable cause) { super(cause); }
        public PEMDecodingException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) { super(message, cause, enableSuppression, writableStackTrace); }
    }

    private KeyUtil() {}

//    private static boolean bcLoaded = false;
//    private static void assureBCloaded() {
//        if (bcLoaded) return;
//        Security.addProvider(new BouncyCastleProvider());
//        bcLoaded = true;
//    }

    /**
     * This reads an X509Certificate from a string containing the certificate in PEM format.
     * PEM format uses markers -----BEGIN CERTIFICATE----- and -----END CERTIFICATE----- to mark the certificate data.
     * the certificate data bytes are encoded in Base64. java.security.cert.CertificateFactory can read the decoded bytes
     * into a certificate.
     *
     * @param pem is a String containing a PEM certificate.
     *        It may contain the -----BEGIN CERTIFICATE----- and -----END CERTIFICATE----- markers, or it may contain only the data.
     *        If it contains the markers, everything outside these markers is ignored, including any other type of markers.
     *        If there are multiple CERTIFICATE markers, only the certificate between the first is read.
     * @return the certificate as a java.security.cert.X509Certificate object
     * */
    public static X509Certificate pemToX509Certificate(String pem) /*throws PEMDecodingError*/ {
        String pemCert = pem.trim();
        String start = "-----BEGIN CERTIFICATE-----";
        String end = "-----END CERTIFICATE-----";
        int startPos = pemCert.indexOf(start);
        if (startPos != -1) {
            pemCert = pemCert.substring(startPos + start.length());
            int endPos = pemCert.indexOf(end);
            if (endPos < 0) return null; //throw new PEMDecodingError("Did not find end: '"+end+"' in: "+pem);
            pemCert = pemCert.substring(0, endPos);
        }
        byte[] decodedContent = Base64.decodeBase64(org.apache.commons.codec.binary.StringUtils.getBytesUtf8(pemCert));
        InputStream inStream = new ByteArrayInputStream(decodedContent);
        try {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate certificate = (X509Certificate)cf.generateCertificate(inStream);
            try { inStream.close(); } catch (IOException e) { }
            return certificate;
        } catch (CertificateException e) {
            LOG.warn("Note: failed to parse certificate: " + e.getMessage(), e);
            return null;
        }
    }

    /** Convert a String containing PEM certificates to a list of X509 certificates.
     * Non Certificate PEM blocks (keys etc) are skipped
     * Invallid certificate PEM blocks are skipped.
     *
     * @return a list of found PEM certificates. if no certificates are in the PEM block null is returned. (so an empty list is never returned.)
     */
    public static List<X509Certificate> pemToX509CertificateChain(String origPem) /*throws PEMDecodingError*/ {
        String pem = origPem;
        List<X509Certificate> res = new ArrayList<X509Certificate>();

        String start = "-----BEGIN CERTIFICATE-----";
        String end = "-----END CERTIFICATE-----";

        String pemCert;

        while (!pem.isEmpty()) {
            pemCert = pem.trim();
            int startPos = pemCert.indexOf(start);
            if (startPos != -1) {
                pemCert = pemCert.substring(startPos + start.length());
                int endPos = pemCert.indexOf(end);
//                System.out.println("DEBUG: pemToX509CertificateChain startPos="+startPos+" endPos="+endPos);
                if (endPos < 0) { pem = ""; break; }
                pem = pemCert.substring(endPos + end.length());
                pemCert = pemCert.substring(0, endPos);
//                System.out.println("DEBUG: pemToX509CertificateChain newPem="+pem);
            } else {
//                System.out.println("DEBUG: pemToX509CertificateChain startPos=-1");
                pem = ""; break;
            }
            byte[] decodedContent = Base64.decodeBase64(org.apache.commons.codec.binary.StringUtils.getBytesUtf8(pemCert));
            InputStream inStream = new ByteArrayInputStream(decodedContent);
            try {
                CertificateFactory cf = CertificateFactory.getInstance("X.509");
                X509Certificate certificate = (X509Certificate)cf.generateCertificate(inStream);
                try { inStream.close(); } catch (IOException e) { }
                res.add(certificate);
            } catch (CertificateException e) {
                //ignore invalid certificates
                LOG.warn("Note: failed to parse certificate (in cert chain). Will ignore this certificate.", e);
//                    return null;
            }
        }

//        System.out.println("DEBUG: pemToX509CertificateChain res.size()="+res.size()+"\n       Pem="+origPem);

        if (res.isEmpty())
            return null;
        return res;
    }


    public static String x509certificateChainToPem(List<X509Certificate> certs) {
        String pem = "";
        for (X509Certificate c : certs)
            pem += x509certificateToPem(c);
        return pem;
    }

    public static String x509certificateToPem(X509Certificate cert) {
//        throw new RuntimeException("Error in x509certificateToPem implementation");
        if (cert == null)
            return null;

        try {
            String s = Base64.encodeBase64String(cert.getEncoded());
            String begin = "-----BEGIN CERTIFICATE-----\n";
            String end = "-----END CERTIFICATE-----\n";
            s = TextUtil.wrap(s+"\n", 64);
            String res = begin + s + end;
            //assert pemToX509Certificate(res) != null;
            return res;
        } catch (CertificateEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    /** same as x509certificateToPem but without -----BEGIN CERTIFICATE----- and -----END CERTIFICATE-----*/
    public static String x509certificateToCredentialXmlGid(X509Certificate cert) {
//        throw new RuntimeException("Error in x509certificateToPem implementation");
        if (cert == null)
            return null;

        try {
            String s = Base64.encodeBase64String(cert.getEncoded());
            s = TextUtil.wrap(s+"\n", 64);
            String res = s;
            return res;
        } catch (CertificateEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * This code comes from sun.security.tools.KeyTool
     * choose signature algorithm that is compatible with the private key algorithm argument (keyAlgName)
     */
    public static String getCompatibleSigAlgName(String keyAlgName) {
        if ("DSA".equalsIgnoreCase(keyAlgName)) {
            return "SHA1WithDSA";
        } else if ("RSA".equalsIgnoreCase(keyAlgName)) {
            return "SHA256WithRSA";
        } else if ("EC".equalsIgnoreCase(keyAlgName)) {
            return "SHA256withECDSA";
        } else {
            throw new RuntimeException("Cannot Derive Signature Algorithm");
        }
    }
    /*
     * This code comes from sun.security.tools.KeyTool and  sun.security.x509.CertAndKeyGen
     *
     * Note: since it uses a lot of sun.* classes, it is not stable
     * */
    public static X509Certificate makeSelfSigned(KeyPair keyPair, String dn, int validityDays) {
        assert keyPair != null;
        Calendar expiry = Calendar.getInstance();
        expiry.add(Calendar.DAY_OF_YEAR, validityDays);

        try {
            PrivateKey privKey = keyPair.getPrivate();
            PublicKey pubKey = keyPair.getPublic();
            assert privKey != null;
            assert pubKey != null;

            // Determine the signature algorithm
            String sigAlgName = getCompatibleSigAlgName(privKey.getAlgorithm());




            Date firstDate = new Date(System.currentTimeMillis() - (24L*60*60*1000));
            Date lastDate = new Date(System.currentTimeMillis() + (validityDays*24L*60*60*1000));
            CertificateValidity interval = new CertificateValidity(firstDate, lastDate);
            X500Name owner = new X500Name("CN="+dn);


            X509CertInfo info = new X509CertInfo();
            // Add all mandatory attributes
            info.set(X509CertInfo.VERSION,
                    new CertificateVersion(CertificateVersion.V3));
            info.set(X509CertInfo.SERIAL_NUMBER, new CertificateSerialNumber(
                    new java.util.Random().nextInt() & 0x7fffffff));
            AlgorithmId algID = AlgorithmId.getAlgorithmId(sigAlgName);
            info.set(X509CertInfo.ALGORITHM_ID,
                    new CertificateAlgorithmId(algID));
            info.set(X509CertInfo.SUBJECT, new CertificateSubjectName(owner));
            info.set(X509CertInfo.KEY, new CertificateX509Key(pubKey));
            info.set(X509CertInfo.VALIDITY, interval);
            info.set(X509CertInfo.ISSUER, new CertificateIssuerName(owner));

            X509CertImpl cert = new X509CertImpl(info);
            cert.sign(privKey, sigAlgName);

            return cert;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        } catch (CertificateException e) {
            e.printStackTrace();
            return null;
        } catch (NoSuchProviderException e) {
            e.printStackTrace();
            return null;
        } catch (InvalidKeyException e) {
            e.printStackTrace();
            return null;
        } catch (SignatureException e) {
            e.printStackTrace();
            return null;
        }
    }


//    /**
//     * Searches and returns the first private key found in the pem string provided. Uses bouncycastle.
//    * */
//    public static PrivateKey getPrivateKey(String pem, final char[] password) throws GeniException {
//        assureBCloaded();
//
//        PasswordFinder passwordFinder = new PasswordFinder() { public char[] getPassword() { return password; } };
//        PEMReader pemkeycertReader = new PEMReader(new StringReader(pem), passwordFinder);
//        Object o = null;
//        do {
//            try {
//                o = pemkeycertReader.readObject();
//            } catch (IOException e) {
//                throw new GeniException("Error reading Private key ("+e.getMessage()+") pem:"+pem, e);
//            }
//            if (o instanceof PrivateKey)
//                return (PrivateKey) o;
//            if (o instanceof KeyPair) {
//                KeyPair keyPair = (KeyPair) o;
//                return keyPair.getPrivate();
//            }
//        } while (o != null);
//        return null;
//    }

    //getPrivateKey doesn't work :-/


    /**
     * This uses PKCS8EncodedKeySpec (java.security.spec) to read a PKCS#8 encoded private key from a -----BEGIN PRIVATE KEY----- PEM block
     *
     * Only the first -----BEGIN PRIVATE KEY----- to -----END PRIVATE KEY----- PEM block is used, all other pem blocks are ignored.
     * */

    public static boolean isPemPrivateKeyEncrypted(String pem) {
        if (pem.contains("Proc-Type")) return true;
        if (pem.contains("DEK-Info")) return true;
        return false;
    }

    /**
     * This reads a PrivateKey from a string containing the private key in PEM format.
     * PEM format uses markers -----BEGIN PRIVATE KEY----- and -----END PRIVATE KEY----- to mark the private key.
     * the key data bytes are encoded in Base64. The bytes are in PKCS#8 format. java.security.spec.PKCS8EncodedKeySpec
     * can read the decoded bytes into a PrivateKey.
     *
     * Note: pemToRsaPrivateKey reads data between -----BEGIN/END RSA PRIVATE KEY----- markers. This data is not so different.
     *       Between these markers, PKCS#1 is used to encode the RSA key.
     *       PKCS#8 has header info, where PKCS#1 does not. This header contains info about the key, and if it specifies
     *       that the key is RSA, it also includes the RSA key in PKCS#1.
     *
     * @param pem is a String containing a PEM private key.
     *        It must contain the -----BEGIN PRIVATE KEY----- and -----END PRIVATE KEY----- markers.
     *        Everything outside these markers is ignored, including any other type of markers.
     *        If there are multiple PRIVATE KEY markers, only the private key between the first is read.
     * @return the private key as a PrivateKey object
     * */
    public static PrivateKey pemToPrivateKey(String pem, final char[] password) throws PEMDecodingException {
        //see http://www.bitpapers.com/2012/04/using-asn1-in-java-some-real-examples.html on how to support encrypted keys them
        //but you are probably looking for "pemToRsaPrivateKey" which parses -----BEGIN RSA PRIVATE KEY----- and DOES support encrypted keys.
        assert !isPemPrivateKeyEncrypted(pem) : "This method does not support encrypted keys";
        assert password == null : "This method does not support encrypted keys";

        String pemKey = pem.trim();
        String start = "-----BEGIN PRIVATE KEY-----";
        String end = "-----END PRIVATE KEY-----";
        int startPos = pemKey.indexOf(start);
        if (startPos != -1) {
            pemKey = pemKey.substring(startPos + start.length());
            int endPos = pemKey.indexOf(end);
            if (endPos < 0) throw new PEMDecodingException("Did not find end: '"+end+"' in: "+pem);
            pemKey = pemKey.substring(0, endPos).trim();
            String fullPemKey = start+"\n"+pemKey+"\n"+end;

//            System.out.println("Found PEM key: "+pemKey);
//            System.out.println("Full PEM key: "+fullPemKey);

            try {
                //this uses PKCS8EncodedKeySpec (java.security.spec) to read a PKCS#8 encoded private key from a -----BEGIN PRIVATE KEY----- pem block
                byte [] pkcs8KeyBytes = Base64.decodeBase64(pemKey.replaceAll("\n", ""));
                PKCS8EncodedKeySpec pkcs8Spec = new PKCS8EncodedKeySpec(pkcs8KeyBytes);
                KeyFactory keyFact = KeyFactory.getInstance("RSA");
                PrivateKey key = keyFact.generatePrivate(pkcs8Spec);
                return key;
            } catch (Exception e) {
                throw new PEMDecodingException("Error reading PEM private key: "+e.getMessage(), e);
            }
        }
        return null;
    }

    /**
     * RSAPrivateCrtKey contains the public key, this method extracts it
     * */
    public static RSAPublicKey rsaPrivateKeyToRsaPublicKey(RSAPrivateKey privateKey) {
        if (privateKey instanceof RSAPrivateCrtKey)
            return rsaPrivateCrtKeyToPublicKey((RSAPrivateCrtKey) privateKey);
        else {
//            LOG.warn("RSAPrivateKey is not of type RSAPrivateCrtKey bu of class="+privateKey.getClass().getName()+". Will guess public exponent is 65537");
//            BigInteger publicExponent = BigInteger.valueOf(65537); //common public exponent
//            RSAPublicKeySpec publicKeySpec = new java.security.spec.RSAPublicKeySpec(publicExponent, privateKey.getModulus());
//            try {
//                KeyFactory keyFactory = KeyFactory.getInstance("RSA");
//
//                PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);
//                return (RSAPublicKey) publicKey;
//            } catch (Exception e) {
//                LOG.error("Error constructing public key from private key: "+e.getMessage(), e);
//                return null;
//            }
            LOG.error("Cannot reconstruct public key from private key. privateKey class=" + privateKey.getClass().getName());
            return null;
        }
    }
    /**
     * RSAPrivateCrtKey contains the public key, this method extracts it
     * */
    public static RSAPublicKey rsaPrivateCrtKeyToPublicKey(RSAPrivateCrtKey rsaPrivateKey) {
        RSAPublicKeySpec publicKeySpec = new java.security.spec.RSAPublicKeySpec(rsaPrivateKey.getModulus(), rsaPrivateKey.getPublicExponent());
        KeyFactory keyFactory = null;
        try {
            keyFactory = KeyFactory.getInstance("RSA");
            PublicKey myPublicKey = keyFactory.generatePublic(publicKeySpec);
            return (RSAPublicKey) myPublicKey;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
            return null;
        }
    }



    private static byte DER_ANS_SEQUENCE = 0x30;
    private static byte DER_ANS_INTEGER = 0x02;

    /** read a length stored in DER */
    private static BigInteger readDerLength(LinkedList<Byte> bytes) throws PEMDecodingException {
        LOG.trace("readDerLength bytes.size=" + bytes.size() + (bytes.isEmpty() ? "" : " first=" + bytes.getFirst()));
        byte first = bytes.removeFirst();

        boolean shortform = (first & 0x80) == 0;
        int len = first & 0x7F;

        LOG.trace("readDerLength shortform=" + shortform + " len=" + len);

        if (shortform) {
            assert len > 0;
            BigInteger r = BigInteger.valueOf(len);
            LOG.trace("readDerLength return shortform " + r);
            assert r.signum() >= 0;
            return r; //len is actual length
        }
        else {
            //len is number of octests needed to express length
            int resBytesLen = len;
            int resBytesStart = 0;
            if (bytes.getFirst() < 0) {
                //this is in base 256, so cannot be negative!
                LOG.trace("readDerLength longform starts with 1, padding with 0 to avoid negative");
                resBytesLen += 1;
                resBytesStart = 1;
            }
            byte[] res = new byte[resBytesLen];
            res[0] = 0;
            for (int i = resBytesStart; i < resBytesLen; i++) {
                res[i] = bytes.removeFirst();
                LOG.trace("readDerLength longform read " + res[i]);
            }
            BigInteger r = new BigInteger(res);
            LOG.trace("readDerLength return longform " + r);
            assert r.signum() > 0;
            return r;
        }
    }
    /** read a length stored in DER */
    private static BigInteger readDerInt(LinkedList<Byte> bytes) throws PEMDecodingException {
        LOG.trace("readDerInt bytes.size=" + bytes.size() + (bytes.isEmpty() ? "" : " first=" + bytes.getFirst()) + " needfirst=" + DER_ANS_INTEGER);

        byte first = bytes.removeFirst();
        if (first != DER_ANS_INTEGER)
            throw new PEMDecodingException("Expected INTEGER in PEM bytes, but got "+first);
        BigInteger len = readDerLength(bytes);
        int l = len.intValue();
        LOG.trace("readDerInt Read DER length of " + l + " bytes.size=" + bytes.size());
        assert l <= bytes.size();

        byte[] intBytes = new byte[l];
        for (int i = 0; i < l; i++)
            intBytes[i] = bytes.removeFirst();

        return new BigInteger(intBytes);
    }

    /*
     * Read a der sequence containing integers. Store these integers.
     * Any non integer is ignored, and the rest of the sequence is ignored (including integers)! (however, bytes is still left in an usable state)
     */
    private static List<BigInteger> readDerBigIntSequence(LinkedList<Byte> bytes) throws PEMDecodingException {
        LOG.trace("readDerBigIntSequence bytes.size=" + bytes.size() + (bytes.isEmpty() ? "" : " first=" + bytes.getFirst()) + " needfirst=" + DER_ANS_SEQUENCE);
        List<BigInteger> res = new ArrayList<BigInteger>();

        byte first = bytes.removeFirst();
        if (first != DER_ANS_SEQUENCE)
            throw new PEMDecodingException("Expected SEQUENCE in PEM bytes, but got "+first);
        BigInteger octetLen = readDerLength(bytes);
        int l = octetLen.intValue();
        int targetLen = bytes.size() - l;

        LOG.trace("readDerBigIntSequence Read DER length of " + l + "  bytes.size=" + bytes.size() + " targetLen=" + targetLen);

        while (bytes.size() > targetLen) {
            byte nextStart = bytes.getFirst();
            if (nextStart != DER_ANS_INTEGER)
                return res;
            LOG.trace("readDerBigIntSequence Read DER INTEGER bytes.size=" + bytes.size());
            BigInteger nextInt = readDerInt(bytes);
            res.add(nextInt);
        }

        LOG.trace("readDerBigIntSequence stopped reading bytes bytes.size=" + bytes.size() + " targetLen=" + targetLen + " res.size=" + res.size());

        if (bytes.size() > targetLen)
            throw new PEMDecodingException("Expected reading to end at targetLen="+targetLen+" but read more: bytes.size="+bytes.size());

        //skip last part if encountered any non DER_ANS_INTEGER
        while (bytes.size() < targetLen)
            bytes.removeFirst();

        return res;
    }




    /**
     * This reads an RsaPrivateKey from a string containing the private key in PEM format.
     * PEM format uses markers -----BEGIN RSA PRIVATE KEY----- and -----END RSA PRIVATE KEY----- to mark the private key.
     * the key data bytes are encoded in Base64. The bytes are in PKCS#1 format. This uses Ganymed SSH2 RSAPrivateKey to
     * read a PKCS#1 encoded RSAPrivateKey. That library supports encoded keys.
     *
     * Note: see pemToPrivateKey for info about the difference between PKCS#1 and PKCS#8
     *
     * @param pem is a String containing a PEM private key.
     *        It must contain the -----BEGIN RSA PRIVATE KEY----- and -----END RSA PRIVATE KEY----- markers.
     *        Everything outside these markers is ignored, including any other type of markers.
     *        If there are multiple RSA PRIVATE KEY markers, only the private key between the first is read.
     * @return the RSA private key as a java.security.interfaces.RSAPrivateKey object
     *
     *
     * */
    /**
     * This uses Ganymed SSH2 RSAPrivateKey to read a PKCS#1 encoded RSAPrivateKey from a -----BEGIN RSA PRIVATE KEY----- PEM block
     *
     * Only the first -----BEGIN RSA PRIVATE KEY----- to -----END RSA PRIVATE KEY----- PEM block is used, all other pem blocks are ignored.
     * */
    public static KeyPair pemToRsaKeyPair(String pem, final char[] password) throws PEMDecodingException {
        if (pem == null) return null;
        String pemKey = pem.trim();
        String start = "-----BEGIN RSA PRIVATE KEY-----";
        String end = "-----END RSA PRIVATE KEY-----";
        int startPos = pemKey.indexOf(start);
        if (startPos != -1) {
            pemKey = pemKey.substring(startPos + start.length());
            int endPos = pemKey.indexOf(end);
            if (endPos < 0) throw new PEMDecodingException("Did not find end: '"+end+"' in: "+pem);
            pemKey = pemKey.substring(0, endPos).trim();
            String fullPemKey = start+"\n"+pemKey+"\n"+end;

//            System.out.println("Found PEM key: "+pemKey);
//            System.out.println("Full PEM key: "+fullPemKey);

            //example of encryption header:
            //-----BEGIN RSA PRIVATE KEY-----
            //Proc-Type: 4,ENCRYPTED
            //DEK-Info: DES-EDE3-CBC,B9A4EBF539D5D355
            //
            //<data>

            try {
                String passString = null;
                if (password != null)
                    passString = new String(password);

                String pemEncodedData = pemKey;
                byte[] data;
                if (pemKey.trim().startsWith("Proc-Type: 4,ENCRYPTED")) {
                    int dekInfoIndex = pemKey.indexOf("DEK-Info: ");
                    if (dekInfoIndex < 0)
                        throw new PEMDecodingException("Found Proc-Type: 4,ENCRYPTED in RSA PRIVATE KEY, but no DEK-Info");
                    int dekInfoEndIndex = pemKey.indexOf("\n", dekInfoIndex);
                    assert dekInfoEndIndex != -1;
                    String dekInfoLine = pemKey.substring(dekInfoIndex, dekInfoEndIndex);
                    LOG.trace("read dekInfoLine=\"" + dekInfoLine + "\"");
                    assert dekInfoLine.startsWith("DEK-Info: ");
                    String dekInfoContent = dekInfoLine.substring("DEK-Info: ".length());
                    String[] dekInfoContentParts = dekInfoContent.split(",");
                    LOG.trace("dekInfoContent=\"" + dekInfoContent + "\" dekInfoContentParts=" + dekInfoContentParts);
                    if (dekInfoContentParts.length != 2)
                        throw new PEMDecodingException("Did not find 2 parts of info in DEK-Info: \""+dekInfoContent+"\"");
                    String algo = dekInfoContentParts[0];
//                    byte[] salt = new BigInteger(dekInfoContentParts[1], 16).toByteArray(); //convert salt hexadecimal number String to byte array
                    byte[] salt = hexToByteArray(dekInfoContentParts[1]); //convert salt hexadecimal number String to byte array
                    LOG.trace("read dekInfoLine algo=\"" + algo + "\" salt=\"" + dekInfoContentParts[1] + "\"");

                    int emptyLineIndex = pemKey.indexOf("\n\n");
                    if (emptyLineIndex < 0)
                        throw new PEMDecodingException("Did not find empty line in encoded PEM block");
                    pemEncodedData = pemKey.substring(emptyLineIndex+1);
                    data = Base64.decodeBase64(pemEncodedData.replaceAll("\n", ""));

                    byte[] passBytes = passString.getBytes("US-ASCII"); //TODO check which charset is supported for PEM passwords (ISO-8859-1? UTF-8? (note: ISO-8859-1 and UTF-8 are supported in all java implementations))
                    data = decryptPEM(algo, salt, data, passBytes);
                } else {
                    data = Base64.decodeBase64(pemEncodedData.replaceAll("\n", ""));
                }

                LinkedList<Byte> dataList = new LinkedList<Byte>();
                for (int i = 0; i < data.length; i++)
                    dataList.add(data[i]);
                List<BigInteger> ints = readDerBigIntSequence(dataList); //skips any otherPrimeInfos SEQUENCE at the end!

                if (ints.size() < 9)
                    throw new RuntimeException("Not enough Integers in DER sequence: "+ints.size());

                BigInteger version = ints.get(0);
                BigInteger modulus = ints.get(1);         //n
                BigInteger publicExponent = ints.get(2);  //e
                BigInteger privateExponent = ints.get(3); //d
                BigInteger primeP = ints.get(4);          //p
                BigInteger primeQ = ints.get(5);          //q
                BigInteger primeExponentP = ints.get(6);  //dmp1
                BigInteger primeExponentQ = ints.get(7);  //dmq1
                BigInteger crtCoefficient = ints.get(8);  //iqmp

                RSAPrivateCrtKeySpec rSAPrivateCrtKeySpec = new RSAPrivateCrtKeySpec(modulus, publicExponent,
                        privateExponent, primeP, primeQ, primeExponentP, primeExponentQ, crtCoefficient);
                KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                RSAPrivateCrtKey key = (RSAPrivateCrtKey) keyFactory.generatePrivate(rSAPrivateCrtKeySpec);

                KeySpec pubKeySpec = new RSAPublicKeySpec(modulus, publicExponent);
                RSAPublicKey pubkey = (RSAPublicKey) keyFactory.generatePublic(pubKeySpec);

//                //This uses Ganymed SSH2 RSAPrivateKey to read a PKCS#1 encoded RSAPrivateKey from a -----BEGIN RSA PRIVATE KEY----- pem block
//                Object res = PEMDecoder.decode(fullPemKey.toCharArray(), passString);
//                if (!(res instanceof ch.ethz.ssh2.signature.RSAPrivateKey))
//                    throw new PEMDecodingException("PEMDecoder did not return RSAPrivateKey but "+res.getClass().getName());
//                ch.ethz.ssh2.signature.RSAPrivateKey rsaPrivateKey = (ch.ethz.ssh2.signature.RSAPrivateKey) res;
//                ch.ethz.ssh2.signature.RSAPublicKey rsaPublicKey = rsaPrivateKey.getPublicKey();
//
//                //convert from Ganymed SSH2 RSAPrivateKey to java.security.interfaces.RSAPrivateKey
//                KeyFactory keyFactory = KeyFactory.getInstance("RSA");
//                KeySpec ks = new RSAPrivateKeySpec(rsaPrivateKey.getN()/*the modulus n*/, rsaPrivateKey.getD()/*the private exponent d*/);
//                java.security.interfaces.RSAPrivateKey key = (java.security.interfaces.RSAPrivateKey) keyFactory.generatePrivate(ks);
//
//                //convert from Ganymed SSH2 RSAPrivateKey to java.security.interfaces.RSAPublicKey
//                KeySpec ks2 = new RSAPublicKeySpec(rsaPublicKey.getN()/*the modulus n*/, rsaPublicKey.getE()/*the public exponent e*/);
//                java.security.interfaces.RSAPublicKey pubkey = (java.security.interfaces.RSAPublicKey) keyFactory.generatePublic(ks2);


                return new KeyPair(pubkey, key);
            } catch (Exception e) {
                throw new PEMDecodingException("Error reading PEM private key: "+e.getMessage(), e);
            }
        }
        return null;
    }
    /**
     * This uses Ganymed SSH2 RSAPrivateKey to read a PKCS#1 encoded RSAPrivateKey from a -----BEGIN RSA PRIVATE KEY----- PEM block
     *
     * Only the first -----BEGIN RSA PRIVATE KEY----- to -----END RSA PRIVATE KEY----- PEM block is used, all other pem blocks are ignored.
     * */
    public static java.security.interfaces.RSAPrivateKey pemToRsaPrivateKey(String pem, final char[] password) throws PEMDecodingException {
        if (pem == null) return null;
        KeyPair res = pemToRsaKeyPair(pem, password);
        if (res == null) return null;
        return (RSAPrivateKey) res.getPrivate();
    }

    /**
     * This find either a PRIVATE KEY or a RSA PRIVATE KEY in a PEM file.
     * The RSA PRIVATE KEY will be searched first, and returned if it exists.
     * If there is no RSA PRIVATE KEY, a PRIVATE KEY will be searched and returned if it exists.
     * null will be returned if neither can be found.
     *
     * @see KeyUtil#pemToRsaPrivateKey
     * @see KeyUtil#pemToPrivateKey
     * */
    public static PrivateKey pemToAnyPrivateKey(String pem, final char[] password)  throws PEMDecodingException {
        PrivateKey pk1 = pemToRsaPrivateKey(pem, password);
        if (pk1 != null) return pk1;
        PrivateKey pk2 = pemToPrivateKey(pem, password);
        if (pk2 != null) return pk2;
        return null;
    }


    /**
     * Parses all the PEM certificates that can be found in the String and returns them.
     *
     * Certificates are be found between:
     * -----BEGIN CERTIFICATE-----
     * and
     * -----END CERTIFICATE-----
     *
     * @see KeyUtil#pemToX509Certificate
     *
     * @param pemCerts String containing PEM certificates
     * @return a list with all certificates found
     */
    public static List<Certificate> parseAllPEMCertificates(String pemCerts) {
        List<Certificate> res = new ArrayList<Certificate>();

        String begin = "-----BEGIN CERTIFICATE-----";
        String end = "-----END CERTIFICATE-----";

        int startIndex = pemCerts.indexOf(begin);
        while (startIndex != -1) {
            int endIndex = pemCerts.indexOf(end, startIndex+1);
            if (endIndex == -1) break;
            String certString = pemCerts.substring(startIndex + begin.length(), endIndex).trim();
//            System.out.println("Found cert: "+certString+"\n\n");
            Certificate cert = pemToX509Certificate(certString);
            res.add(cert);
            startIndex = pemCerts.indexOf(begin, endIndex + end.length());
        }

        return res;
    }




    /** helper for DER encoding. DER Length octets for a certain length */
    static private List<Byte> derLength(int len) {
        assert len >= 0;
        //dirty and quick implementation!
        List<Byte> res = new ArrayList<Byte>();
        if (len >= 0 && len <= 127) {
            res.add((byte)len);
//            System.out.println("DER len " + len + " in 1 octet");
            return res;
        }
        BigInteger helper = BigInteger.valueOf(len);
        byte[] helperBytes = helper.toByteArray();
        assert helper.toByteArray()[0] >= 0;

        int octets_needed = helperBytes.length;//helper.bitLength()+2 / 8;
        if (octets_needed < 2) octets_needed = 2;

//        System.out.println("DER len "+len+" fits in 1 + "+octets_needed+" octets");

        assert octets_needed < 128 && octets_needed >= 0;
        byte first = (byte)(0x80 | octets_needed);
        int firstInt = 0x80 | octets_needed; //for printing only
        res.add(first);

        assert octets_needed == helperBytes.length;

        for (byte b : helperBytes)
            res.add(b);

//        System.out.println("DER len "+len+" encoded in total "+res.size()+" octets. first="+firstInt);

        return res;
    }

    /** helper for DER encoding. Encodes a java BigInt as list of DER bytes. */
    static private List<Byte> derBigInt(BigInteger bigint) {
        List<Byte> res = new ArrayList<Byte>();

        if (bigint.signum() == 0) {
            res.add((byte)0);
            return res;
        }

        byte[] bytes = bigint.toByteArray();
        assert bytes.length > 0;
        boolean skipFirstZeroes = true;
        for (byte b : bytes) {
            if (b != 0 && skipFirstZeroes && (b > 127 || b < 0) && bigint.signum() > 0) {
                //Note: Bigint probably does this, but we make sure here
                //first is negative but number is positive, so add 00 padding to prevent negative integer
                res.add((byte) 0x00);
//                System.out.println("DER Bigint 00 padded");
            }
            if (b != 0 || !skipFirstZeroes) {
                skipFirstZeroes = false;
                res.add(b);
            }
//            else
//                System.out.println("DER Bigint skipped a zero");
        }

//        System.out.println("DER Bigint to "+res.size()+" bytes");

        return res;
    }

    /** helper for DER encoding. Encodes a list of java BigInt as list of DER bytes. */
    static public List<Byte> derSequenceBigInt(List<BigInteger> bigints) {
        List<Byte> integers = new ArrayList<Byte>();
        for (BigInteger bigint : bigints) {
            integers.add((byte) 0x02); //ANS Integer (public exponent)
            List<Byte> e = derBigInt(bigint);
            integers.addAll(derLength(e.size())); //ANS Integer Size
            integers.addAll(e); //Integer itself
        }

        List<Byte> der = new ArrayList<Byte>();
        der.add((byte) 0x30); //ANS Sequence
        der.addAll(derLength(integers.size())); //ANS Sequence size
        der.addAll(integers);

        return der;
    }

    /**
     * encodes a java RSAPrivateKey object using PKCS#1 standard
     * @param sshPrivateKey the RSAPrivateKey to encode
     * @return an array of bytes containing the PKCS#1 encoded key
     */
    public static byte[] getPrivateKeyPKCS1(RSAPrivateCrtKey sshPrivateKey) {
        /*
                In the case of an RSA private key, PKCS #1 defines a structure called RSAPrivateKey, which looks as follows:

                RSAPrivateKey ::= SEQUENCE {
                                    version Version,
                                    modulus INTEGER,
                                    publicExponent INTEGER,
                                    privateExponent INTEGER,
                                    prime1 INTEGER,
                                    prime2 INTEGER,
                                    exponent1 INTEGER,
                                    exponent2 INTEGER,
                                    coefficient INTEGER,
                                    otherPrimeInfos OtherPrimeInfos OPTIONAL }
                Version ::= INTEGER { two-prime(0), multi(1) }
                (CONSTRAINED BY {-- version must be multi if otherPrimeInfos present --})

                OtherPrimeInfos ::= SEQUENCE SIZE(1..MAX) OF OtherPrimeInfo

                OtherPrimeInfo ::= SEQUENCE {
                                    prime INTEGER,
                                    exponent INTEGER,
                                    coefficient INTEGER }
       * */

        List<BigInteger> bigints = new ArrayList<BigInteger>();
        RSAPrivateCrtKey crtKey = (RSAPrivateCrtKey) sshPrivateKey;
        bigints.add(BigInteger.valueOf(0));
        bigints.add(sshPrivateKey.getModulus());
        bigints.add(crtKey.getPublicExponent());
        bigints.add(sshPrivateKey.getPrivateExponent());
        bigints.add(crtKey.getPrimeP());
        bigints.add(crtKey.getPrimeQ());
        bigints.add(crtKey.getPrimeExponentP());
        bigints.add(crtKey.getPrimeExponentQ());
        bigints.add(crtKey.getCrtCoefficient());


        List<Byte> der = derSequenceBigInt(bigints);

        byte derBytes[] = new byte[der.size()];
        int i = 0;
//        String s = "";
        for (byte b : der) {
//            s += String.format("%02X ", b);
            derBytes[i++] = b;
        }
//        System.out.println(StringUtils.wrap(s, 70));

        return derBytes;
    }

    /**
     * encodes a java RSAPrivateKey object using PKCS#1 standard
     * @param sshPublicKey the RSAPrivateKey to encode
     * @return an array of bytes containing the PKCS#1 encoded key
     */
    public static byte[] getPublicKeyPKCS1(RSAPublicKey sshPublicKey) {
        /*
      An RSA public key should be represented with the ASN.1 type
         RSAPublicKey:

            RSAPublicKey ::= SEQUENCE {
                modulus           INTEGER,  -- n
                publicExponent    INTEGER   -- e
            }

         The fields of type RSAPublicKey have the following meanings:

          * modulus is the RSA modulus n.

          * publicExponent is the RSA public exponent e.
       * */

        List<BigInteger> bigints = new ArrayList<BigInteger>();
        bigints.add(sshPublicKey.getModulus());
        bigints.add(sshPublicKey.getPublicExponent());
        List<Byte> der = derSequenceBigInt(bigints);

        byte derBytes[] = new byte[der.size()];
        int i = 0;
        for (byte b : der) {
            derBytes[i++] = b;
        }

        return derBytes;
    }

    /**
     * encodes a java RSAPrivateKey object using PKCS#1 standard. Then encodes the bytes using Base64.
     * @param sshPrivateKey the RSAPrivateKey to encode
     * @return an array of bytes containing the PKCS#1 encoded key, encoded using Base64
     */
    public static char[] getPrivateKeyCharsPKCS1Base64(RSAPrivateCrtKey sshPrivateKey) {
        String s = Base64.encodeBase64String(getPrivateKeyPKCS1(sshPrivateKey));
        return s.toCharArray();
    }
    /**
     * encodes a java RSAPublicKey object using PKCS#1 standard. Then encodes the bytes using Base64.
     * @param sshPublicKey the RSAPrivateKey to encode
     * @return an array of bytes containing the PKCS#1 encoded key, encoded using Base64
     */
    public static char[] getPublicKeyCharsPKCS1Base64(RSAPublicKey sshPublicKey) {
        String s = Base64.encodeBase64String(getPublicKeyPKCS1(sshPublicKey));
        return s.toCharArray();
    }

    /**
     * encodes a java PrivateKey object using PKCS#8 standard.
     * The java PrivateKey class normally actually supports this conversion. This checks that and does the conversion.
     *
     * @param privateKey the PrivateKey to encode
     * @return an array of bytes containing the PKCS#8 encoded key
     */
    public static byte[] getPrivateKeyCharsPKCS8(PrivateKey privateKey) {
        if (!privateKey.getFormat().equals("PKCS#8"))
            throw new RuntimeException(privateKey.getClass().getName()+" does not support PKCS#8");
        assert privateKey.getFormat().equals("PKCS#8");
        return privateKey.getEncoded();
    }


    /**
     * encodes a java PrivateKey object using PKCS#8 standard. Then encodes the bytes using Base64.
     *
     * @param privateKey the PrivateKey to encode
     * @return an array of bytes containing the PKCS#8 encoded key, encoded using Base64
     */
    public static char[] getPrivateKeyCharsPKCS8Base64(PrivateKey privateKey) {
        String s = Base64.encodeBase64String(getPrivateKeyCharsPKCS8(privateKey));
        return s.toCharArray();
    }
    /**
     * Convert an PrivateKey into a PEM "PRIVATE KEY". (PKCS#8)
     *
     * @param privateKey PrivateKey to encode into PEM format
     * @return an array of chars containing the private key in PEM format
     * */
    public static char[] privateKeyToPem(PrivateKey privateKey) {
        String pem = TextUtil.wrap(new String(getPrivateKeyCharsPKCS8Base64(privateKey)), 65); //PKCS#8 encoded
        String res = "-----BEGIN PRIVATE KEY-----\n" + pem + "\n-----END PRIVATE KEY-----\n"; //RSA does not need to be mentioned, since "RSA" algo is in PKCS#8 header (which also contains PKCS#1 key)
        return res.toCharArray();
    }
    public static char[] privateKeyToAnyPem(PrivateKey privateKey) {
        if (privateKey instanceof RSAPrivateCrtKey)
            return rsaPrivateKeyToPem((RSAPrivateCrtKey)privateKey);
        else
            return privateKeyToPem(privateKey);
    }

    //does this make sense?
//    /**
//     * Convert an PublicKey into a PEM "PUBLIC KEY".
//     *
//     * @param publicKey PublicKey to encode into PEM format
//     * @return an array of chars containing the private key in PEM format
//     * */
//    public static String publicKeyToPem(PublicKey publicKey) {
//        byte[] bytes = publicKey.getEncoded();
//        String encodedBytes = Base64.encodeBase64String(bytes);
//        String pem = TextUtil.wrap(encodedBytes, 65);
//        String res = "-----BEGIN PUBLIC KEY-----\n" + pem + "\n-----END PUBLIC KEY-----\n";
//        return res;
//    }

    /**
     * Convert an RsaPrivateKey into a PEM "RSA PRIVATE KEY". (PKCS#1)
     *
     * @param rsaPrivateKey RsaPrivateKey to encode into PEM format
     * @return an array of chars containing the RSA private key in PEM format
     * */
    public static char[] rsaPrivateKeyToPem(RSAPrivateKey rsaPrivateKey) {
        if (!(rsaPrivateKey instanceof RSAPrivateCrtKey)) {
            throw new RuntimeException("rsaPrivateKey is not of class RSAPrivateCrtKey but of class="+
                    rsaPrivateKey.getClass().getName()+
                    " -> does not contain enough data to transform it to the PKCS1 format needed for PEM \"RSA PRIVATE KEY\"");
        }

        RSAPrivateCrtKey rsaPrivateCrtKey = (RSAPrivateCrtKey) rsaPrivateKey;

        String pem = TextUtil.wrap(new String(getPrivateKeyCharsPKCS1Base64(rsaPrivateCrtKey)), 65); //PKCS#1 encoded
        String res = "-----BEGIN RSA PRIVATE KEY-----\n" + pem + "\n-----END RSA PRIVATE KEY-----\n"; //this only works if the key is in PKCS#1 format
        return res.toCharArray();
    }



    public static boolean hasAnyPrivateKey(String keyCertContent) {
        return hasPrivateKey(keyCertContent) || hasRsaPrivateKey(keyCertContent);
    }
    public static boolean hasPrivateKey(String pemContent) {
        return pemContent.contains("-----BEGIN PRIVATE KEY-----");
    }
    public static boolean hasRsaPrivateKey(String pemContent) {
        return pemContent.contains("-----BEGIN RSA PRIVATE KEY-----");
    }
    public static boolean hasX509Certificate(String pemContent) {
        return pemContent.contains("-----BEGIN CERTIFICATE-----");
    }
    public static boolean isOpenSshRsaKey(File file) throws IOException {
        return isOpenSshRsaKey(IOUtils.fileToString(file));
    }
    public static boolean isOpenSshRsaKey(String content) {
        return content != null && content.startsWith("ssh-rsa ");
    }
    public static boolean hasEncryptedRsaPrivateKey(String pemContent) {
//        return keyCertContent.contains("-----BEGIN RSA PRIVATE KEY-----") && keyCertContent.contains("Proc-Type: 4,ENCRYPTED");
        return pemContent.contains("-----BEGIN RSA PRIVATE KEY-----") && (
                pemContent.contains("Proc-Type:") || pemContent.contains("DEK-Info: ") || pemContent.contains("ENCRYPTED")
        );
    }





    public static String publicKeyToOpenSshAuthorizedKeysFormat(PublicKey publicKey) {
        if (publicKey == null) return null;
        if (publicKey instanceof RSAPublicKey)
            return rsaPublicKeyToOpenSshAuthorizedKeysFormat((RSAPublicKey) publicKey);
        throw new UnsupportedOperationException("Cannot convert non RSAPublicKey to OpenSshAuthorizedKeysFormat: "+publicKey.getClass().getName());
    }

    public static String rsaPublicKeyToOpenSshAuthorizedKeysFormatData(RSAPublicKey rsaPublicKey) {
          /*
           * See: http://blog.oddbit.com/post/converting-openssh-public-keys
           * For an ssh-rsa key, the PEM-encoded data is a series of (length, data) pairs. The length is encoded as four octets (in big-endian order). The values encoded are:
           *      - algorithm name (one of (ssh-rsa, ssh-dsa)). This duplicates the key type in the first field of the public key.
           *      - RSA exponent
           *      - RSA modulus
           */
          byte[] keytype = StringUtils.getBytesUtf8("ssh-rsa");
          byte[] exp = rsaPublicKey.getPublicExponent().toByteArray();
          assert new BigInteger(exp).equals(rsaPublicKey.getPublicExponent());
          byte[] mod = rsaPublicKey.getModulus().toByteArray();
          byte[] all = ByteBuffer.allocate(exp.length + mod.length + keytype.length + 12).order(ByteOrder.BIG_ENDIAN).
                  putInt(keytype.length).put(keytype).
                  putInt(exp.length).put(exp).
                  putInt(mod.length).put(mod).
                  array();
          String encoded_all =  Base64.encodeBase64String(all);

         return encoded_all;
      }
    /**
     * Converts an RsaPublicKey to the format of the OpenSSH "authorized_keys" file.
     *
     * Note: This format is not a standard (not PEM, PKCS#1, ...)
     *
     * Example public key in this format (... used to shorten example):
     *   ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAAB...3DxZtLq2nuf4n name@example.com
     *
     *   @see KeyUtil#openSshAuthorizedKeysFormatRsaPublicKey(String) for the reverse
     * */
    public static String rsaPublicKeyToOpenSshAuthorizedKeysFormat(RSAPublicKey rsaPublicKey) {
        String encoded_all =  rsaPublicKeyToOpenSshAuthorizedKeysFormatData(rsaPublicKey);

        String res = "ssh-rsa " + encoded_all;

        //self check
        assert openSshAuthorizedKeysFormatRsaPublicKey(res).getModulus().equals(rsaPublicKey.getModulus());
        assert openSshAuthorizedKeysFormatRsaPublicKey(res).getPublicExponent().equals(rsaPublicKey.getPublicExponent());

        return res;
    }

    /**
     * Converts a string containing an RSA public key in the format of the OpenSSH "authorized_keys" file to a
     * RsaPublicKey object
     *
     * Note: This format is not a standard (not PEM, PKCS#1, ...)
     *
     * Example public key in this format (... used to shorten example):
     *   ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAAB...3DxZtLq2nuf4n name@example.com
     *
     *   @see KeyUtil#rsaPublicKeyToOpenSshAuthorizedKeysFormat(RSAPublicKey) for the reverse
     * */
    public static RSAPublicKey openSshAuthorizedKeysFormatRsaPublicKey(String ssh_rsa) {
        //full format (space seperated fields, check also "man sshd" under "authorized_keys"): options, keytype, base64-encoded key, comment
        //with keytype one of ssh-rsa and ssh-dsa
        String[] parts = ssh_rsa.trim().split(" ");
        String encodedKey = null;
        for (int i = 0; i < parts.length - 1; i++) {
            if (parts[i].equals("ssh-rsa")) {
                encodedKey = parts[i+1];
                break;
            }
            if (parts[i].equals("ssh-dsa") || parts[i].equals("ssh-dss"))
                throw new RuntimeException("DSA key found in OpenSSH authorized_keys format. DSA keys are not supported by this method, only RSA is supported. input=\""+ssh_rsa+"\"");
        }
        if (encodedKey == null) {
            throw new RuntimeException("No key found in OpenSSH authorized_keys format. format syntax: <options> <keytype> <base64-encoded key> <comment>. input=\""+ssh_rsa+"\"");
        }

        byte[] all_restored = Base64.decodeBase64(encodedKey);
        ByteBuffer bb = ByteBuffer.wrap(all_restored).order(ByteOrder.BIG_ENDIAN);

        int kts = bb.getInt();
        byte[] kt = new byte[kts];
        bb.get(kt);
        String keyType = StringUtils.newStringUtf8(kt);
        assert keyType.equals("ssh-rsa");

        int es = bb.getInt();
        byte[] exp = new byte[es];
        bb.get(exp);

        int ms = bb.getInt();
        byte[] mod = new byte[ms];
        bb.get(mod);

        BigInteger exponent = new BigInteger(exp);
        BigInteger modulus = new BigInteger(mod);

        RSAPublicKeySpec spec = new RSAPublicKeySpec(modulus, exponent);
        RSAPublicKey res = null;
        try {
            KeyFactory keyFact = KeyFactory.getInstance("RSA");
            PublicKey key = keyFact.generatePublic(spec);
            res = (RSAPublicKey) key;
        } catch (Exception e) {
            throw new RuntimeException("Error creating RSAPublicKey: "+e.getMessage(), e);
        }
        return res;
    }










//code below is based on  ch.ethz.ssh2.crypto.PEMDecoder
//the library is included in this project, see it's license
//    (binary and source distribution, with or without modification is allowed, with some restrictions.)

    private static byte[] generateKeyFromPasswordSaltWithMD5(byte[] password, byte[] salt, int keyLen)
            throws PEMDecodingException
    {
        if (salt.length < 8)
            throw new PEMDecodingException("Salt needs to be at least 8 bytes for key generation. It is only "+salt.length+" bytes");

        ch.ethz.ssh2.crypto.digest.MD5 md5 = new ch.ethz.ssh2.crypto.digest.MD5();

        byte[] key = new byte[keyLen];
        byte[] tmp = new byte[md5.getDigestLength()];

        while (true)
        {
            md5.update(password, 0, password.length);
            md5.update(salt, 0, 8);

            int copy = (keyLen < tmp.length) ? keyLen : tmp.length;

            md5.digest(tmp, 0);

            System.arraycopy(tmp, 0, key, key.length - keyLen, copy);

            keyLen -= copy;

            if (keyLen == 0)
                return key;

            md5.update(tmp, 0, tmp.length);
        }
    }
    private static byte[] decryptPEM(String algo, byte[] salt, byte[] data, byte[] pw) throws PEMDecodingException
    {
        ch.ethz.ssh2.crypto.cipher.BlockCipher bc = null;

        if (algo.equals("DES-EDE3-CBC"))
        {
            DESede des3 = new DESede();
            des3.init(false, generateKeyFromPasswordSaltWithMD5(pw, salt, 24));
            bc = new ch.ethz.ssh2.crypto.cipher.CBCMode(des3, salt, false);
        }
        else if (algo.equals("DES-CBC"))
        {
            ch.ethz.ssh2.crypto.cipher.DES des = new ch.ethz.ssh2.crypto.cipher.DES();
            des.init(false, generateKeyFromPasswordSaltWithMD5(pw, salt, 8));
            bc = new ch.ethz.ssh2.crypto.cipher.CBCMode(des, salt, false);
        }
        else if (algo.equals("AES-128-CBC"))
        {
            ch.ethz.ssh2.crypto.cipher.AES aes = new ch.ethz.ssh2.crypto.cipher.AES();
            aes.init(false, generateKeyFromPasswordSaltWithMD5(pw, salt, 16));
            bc = new ch.ethz.ssh2.crypto.cipher.CBCMode(aes, salt, false);
        }
        else if (algo.equals("AES-192-CBC"))
        {
            ch.ethz.ssh2.crypto.cipher.AES aes = new ch.ethz.ssh2.crypto.cipher.AES();
            aes.init(false, generateKeyFromPasswordSaltWithMD5(pw, salt, 24));
            bc = new ch.ethz.ssh2.crypto.cipher.CBCMode(aes, salt, false);
        }
        else if (algo.equals("AES-256-CBC"))
        {
            ch.ethz.ssh2.crypto.cipher.AES aes = new ch.ethz.ssh2.crypto.cipher.AES();
            aes.init(false, generateKeyFromPasswordSaltWithMD5(pw, salt, 32));
            bc = new ch.ethz.ssh2.crypto.cipher.CBCMode(aes, salt, false);
        }
        else
        {
            throw new PEMDecodingException("Cannot decrypt PEM structure, unknown cipher " + algo);
        }

        if ((data.length % bc.getBlockSize()) != 0)
            throw new PEMDecodingException("Invalid PEM structure, size of encrypted block is not a multiple of "
                    + bc.getBlockSize());

        /* Now decrypt the content */

        byte[] dz = new byte[data.length];

        for (int i = 0; i < data.length / bc.getBlockSize(); i++)
            bc.transformBlock(data, i * bc.getBlockSize(), dz, i * bc.getBlockSize());

        /* Now check and remove RFC 1423/PKCS #7 padding */
        dz = removePadding(dz, bc.getBlockSize());

        return dz;
    }
    private static byte[] removePadding(byte[] buff, int blockSize) throws PEMDecodingException
    {
        /* Removes RFC 1423/PKCS #7 padding */

        int rfc_1423_padding = buff[buff.length - 1] & 0xff;

        if ((rfc_1423_padding < 1) || (rfc_1423_padding > blockSize))
            throw new PEMDecodingException("Decrypted PEM has wrong padding, did you specify the correct password?");

        for (int i = 2; i <= rfc_1423_padding; i++)
        {
            if (buff[buff.length - i] != rfc_1423_padding)
                throw new PEMDecodingException("Decrypted PEM has wrong padding, did you specify the correct password?");
        }

        byte[] tmp = new byte[buff.length - rfc_1423_padding];
        System.arraycopy(buff, 0, tmp, 0, buff.length - rfc_1423_padding);
        return tmp;
    }


    public static final int hexToInt(char c)
    {
        if ((c >= 'a') && (c <= 'f'))
        {
            return (c - 'a') + 10;
        }

        if ((c >= 'A') && (c <= 'F'))
        {
            return (c - 'A') + 10;
        }

        if ((c >= '0') && (c <= '9'))
        {
            return (c - '0');
        }

        throw new IllegalArgumentException("Need hex char");
    }

    public static byte[] hexToByteArray(String hex)
    {
        //this should do the same, but it doesn't it pads with 0 sometimes: return new BigInteger(hex, 16).toByteArray();

        if ((hex.length() % 2) != 0)
            throw new IllegalArgumentException("Uneven string length in hex encoding.");

        byte decoded[] = new byte[hex.length() / 2];

        for (int i = 0; i < decoded.length; i++)
        {
            int hi = hexToInt(hex.charAt(i * 2));
            int lo = hexToInt(hex.charAt((i * 2) + 1));

            decoded[i] = (byte) (hi * 16 + lo);
        }

        return decoded;
    }

}
