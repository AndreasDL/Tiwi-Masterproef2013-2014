package be.iminds.ilabt.jfed.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;

/**
 * User: twalcari
 * Date: 12/11/13
 * Time: 2:32 PM
 */
public class JFedUtils {

    private static final Logger LOG = LogManager.getLogger();

    /**
     * Returns the directory in which all data related to jFed-tools should be stored.
     * If this directory doesn't exist, it is created first.
     * <p/>
     * When the filesystem is inaccessible, null is returned
     *
     * @return
     */
    public static String getUserDataDirectory() {
        String userDataDir;

        if (System.getProperty("os.name").toLowerCase().contains("win"))
            userDataDir = System.getenv("APPDATA") + File.separator + "jFed" + File.separator;
        else
            userDataDir = System.getProperty("user.home") + File.separator + ".jFed" + File.separator;


        try {
            File userDataDirFile = new File(userDataDir);
            if (!userDataDirFile.exists()) {
                LOG.info("User data dir " + userDataDir + " does not exist. Creating it.");
                if (userDataDirFile.mkdir())
                    return userDataDir;
                else {
                    LOG.error("Failed to create the user data directory.");
                    return null;
                }
            } else if (userDataDirFile.list() != null)  //check if we can read the file system
                return userDataDir;
            else {
                LOG.error("Unable to list the files in the user data directory");
                return null;
            }


        } catch (SecurityException ex) {
            LOG.error("Unable to create User Data Directory", ex);
            return null;
        }
    }

    public static File getUserDataDirectoryFile() {
        String userDataDir = getUserDataDirectory();

        if (userDataDir != null)
            return new File(userDataDir);
        else
            return null;
    }

    /**
     * returns the user data dir under windows, but instead of a full path, the windows envirement variables are used if possible.
     * <p/>
     * obviosuly only makes sense to call this on windows.
     * <p/>
     * On windows, this points to the same dir as getUserDataDirectory()
     */
    public static String getWindowsUserDataDirectoryString() {
        String ignoreButCreate = getUserDataDirectory();

        return "%APPDATA%" + File.separator + "jFed" + File.separator;
    }

//see alternative: JFedCommonDialogs.requestEraseJFedConfiguration()
//    /**
//     * WARNING: this method will cause data loss
//     */
//    public static boolean clearUserDataDirectory() {
//        return clearFolder(getUserDataDirectoryFile());
//
//    }
//    private static boolean clearFolder(File folder) {
//        //dangerous: does not support symbolic links
//        for (File file : folder.listFiles()) {
//            if (file.isDirectory()) {
//                if (!clearFolder(file))
//                    return false;
//            }
//            if (!file.delete())
//                return false;
//        }
//        return true;
//    }
}
