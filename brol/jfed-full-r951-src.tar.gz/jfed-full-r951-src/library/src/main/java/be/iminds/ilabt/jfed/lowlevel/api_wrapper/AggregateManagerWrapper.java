package be.iminds.ilabt.jfed.lowlevel.api_wrapper;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api.UserSpec;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.JFedConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * AggregateManagerWrapper
 *
 * Supports only geni_sfa v3 rspec!
 */
public abstract class AggregateManagerWrapper {
    protected final GeniUserProvider geniUserProvider;
    protected final GeniConnectionProvider connectionProvider;
    protected final Logger logger;
    protected final SfaAuthority amAuthority;

    protected AggregateManagerWrapper(Logger logger, GeniUserProvider geniUserProvider, GeniConnectionProvider connectionProvider, SfaAuthority amAuthority) {
        this.logger = logger;
        this.geniUserProvider = geniUserProvider;
        this.connectionProvider = connectionProvider;
        this.amAuthority = amAuthority;
    }

    protected JFedConnection getConnection(ServerType serverType) throws JFedException {
        GeniUser user = geniUserProvider.getLoggedInGeniUser();
//        SfaAuthority userAuth = user.getUserAuthority();
        return connectionProvider.getConnectionByAuthority(user, amAuthority, serverType);
    }

    protected GeniUser getUser() {
        return geniUserProvider.getLoggedInGeniUser();
    }

    protected SfaAuthority getUserAuthority() {
        GeniUser user = geniUserProvider.getLoggedInGeniUser();
        SfaAuthority userAuth = user.getUserAuthority();
        return userAuth;
    }

    protected static List<AnyCredential> toCredentialList(AnyCredential cred) {
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(cred);
        return res;
    }

    protected SfaAuthority getAmAuthority() {
        return amAuthority;
    }


    public abstract void getVersion() throws JFedException;

    public abstract String listResources(AnyCredential userCredential, boolean available) throws JFedException;

    public abstract String createSliver(GeniUrn sliceUrn, AnyCredential sliceCredential, String rspec, List<UserSpec> userSpecs, Date expirationDate) throws JFedException;

    public abstract void deleteSliver(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException;

    public abstract SliverStatus status(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException;

    public abstract String describe(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException;

    public abstract void renewSliver(GeniUrn sliceUrn, AnyCredential sliceCredential, Date newExpire) throws JFedException;
}
