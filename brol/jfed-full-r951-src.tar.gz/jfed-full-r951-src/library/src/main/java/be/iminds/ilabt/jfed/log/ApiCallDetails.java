package be.iminds.ilabt.jfed.log;

import be.iminds.ilabt.jfed.lowlevel.ApiCallReply;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.JFedConnection;
import be.iminds.ilabt.jfed.util.XmlRpcPrintUtil;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.*;

/**
 * ApiCallDetails contains everything about an API call.
 * This includes HTTP and XmlRpc sent and received data,
 * the interpreted APICallReply object, info about hte method that did the call,
 * including it's parameters, etc...
 */
@XmlRootElement(name = "api_call_details")
@XmlAccessorType(XmlAccessType.NONE)
public class ApiCallDetails {
    //Fields with JAXB annotions for XML-ized fields
                                                private final SfaAuthority authority;
    @XmlElement(name = "server_url")            private final String serverUrl;

    /** proxy used for the connection. May be null. */
    @XmlElement(name = "proxy_info")            private final JFedConnection.ProxyInfo proxyInfo;

    @XmlElement(name = "http_request_line")     private final String httpRequestLine;
    @XmlElement(name = "http_request_headers")  private final String httpRequestHeaders;
    @XmlElement(name = "http_request")          private final String httpRequest;
    @XmlElement(name = "http_status_line")      private final String httpStatusLine;
    @XmlElement(name = "http_response_headers") private final String httpResponseHeaders;
    @XmlElement(name = "http_reply")            private final String httpReply;

                                                private final Vector xmlRpcRequest;
                                                private final Object xmlRpcReply;

    @XmlElement(name = "api_name")              private final String apiName;
    @XmlElement(name = "java_method_name")      private final String javaMethodName;
    @XmlElement(name = "geni_method_name")      private final String geniMethodName;
                                                private final Map<String,Object> methodParameters;

                                                private final ApiCallReply reply;

    @XmlElement(name = "start_time")            private final Date startTime;
    @XmlElement(name = "stop_time")             private final Date stopTime;

                                                private final Throwable exception;



    /**
     * @param authority (if applicable, otherwise null)
     * @param serverUrl
     * @param apiName
     * @param javaMethodName may be null
     * @param geniMethodName
     * @param reply may be null
     * @param httpRequest
     * @param httpReply
     */
    public ApiCallDetails(SfaAuthority authority, String serverUrl, JFedConnection.ProxyInfo proxyInfo,
                          String apiName, String javaMethodName, String geniMethodName,
                          ApiCallReply reply,

                          String httpRequestLine, String httpRequestHeaders, String httpRequest,
                          String httpStatusLine, String httpResponseHeaders, String httpReply,

                          Vector xmlRpcRequest, Object xmlRpcReply,
                          Map<String, Object> methodParameters, Date startTime, Date stopTime, Throwable exception) {
//        assert authority != null; //not guaranteed anymore

        this.authority = authority;
        this.serverUrl = serverUrl;
        this.proxyInfo = proxyInfo;
        this.apiName = apiName;
        this.javaMethodName = javaMethodName;
        this.geniMethodName = geniMethodName;
        this.reply = reply;

        this.httpRequestLine = httpRequestLine;
        this.httpRequestHeaders = httpRequestHeaders;
        this.httpRequest = httpRequest;

        this.httpStatusLine = httpStatusLine;
        this.httpResponseHeaders = httpResponseHeaders;
        this.httpReply = httpReply;

        this.xmlRpcRequest = xmlRpcRequest;
        this.xmlRpcReply = xmlRpcReply;
        if (methodParameters == null)
            this.methodParameters = new HashMap<String, Object>();
        else
            this.methodParameters = new HashMap<String, Object>(methodParameters);
        this.startTime = startTime;
        this.stopTime = stopTime;
        this.exception = exception;
    }

    /**
     * should only be called for JAXB! (we support JAXB goinf to XML, but not the other way around! But JAXB still wants a constructor)
     * Luckily, the constructor may be private
     * */
    @SuppressWarnings("unused")
    private ApiCallDetails() {
        this.authority = null;
        this.serverUrl = null;
        this.proxyInfo = null;
        this.apiName = null;
        this.javaMethodName = null;
        this.geniMethodName = null;
        this.reply = null;
        this.httpRequestLine = null;
        this.httpRequestHeaders = null;
        this.httpResponseHeaders = null;
        this.httpRequest = null;
        this.httpStatusLine = null;
        this.httpReply = null;
        this.xmlRpcRequest = null;
        this.xmlRpcReply = null;
        this.methodParameters = null;
        this.startTime = null;
        this.stopTime = null;
        this.exception = null;
    }

    /**
     * @return GeniAuthority corresponding to the server this call was made to. Can be null
     */
    public SfaAuthority getAuthority() {
        return authority;
    }

    public String getServerUrl() {
        return serverUrl;
    }

    public String getApiName() {
        return apiName;
    }


    public JFedConnection.ProxyInfo getProxyInfo() {
        return proxyInfo;
    }

    public Object getXmlRpcRequest() {
        return xmlRpcRequest;
    }

    public Object getXmlRpcReply() {
        return xmlRpcReply;
    }


    /*these 3 do not really belong here, but they are convenient for xml generation */
    @XmlElement(name = "geni_value", nillable = true)
    public String getXmlRpcReplyGeniValue() {
        if (!(xmlRpcReply instanceof Hashtable)) return null;
        Hashtable ht = (Hashtable) xmlRpcReply;
        Object valueVal = ht.get("value");
        if (valueVal == null) return null;
        return XmlRpcPrintUtil.printXmlRpcResultObject(valueVal);
    }
    @XmlElement(name = "geni_output", nillable = true)
    public String getXmlRpcReplyGeniOutput() {
        if (!(xmlRpcReply instanceof Hashtable)) return null;
        Hashtable ht = (Hashtable) xmlRpcReply;
        Object outputVal = ht.get("output");
        if (outputVal == null) return null;
        return XmlRpcPrintUtil.printXmlRpcResultObject(outputVal);
    }
    @XmlElement(name = "geni_code", nillable = true)
    public String getXmlRpcReplyGeniCode() {
        if (!(xmlRpcReply instanceof Hashtable)) return null;
        Hashtable ht = (Hashtable) xmlRpcReply;
        Object codeVal = ht.get("code");
        if (codeVal == null) return null;
        return XmlRpcPrintUtil.printXmlRpcResultObject(codeVal);
    }

    public Map<String, Object> getMethodParameters() {
        return Collections.unmodifiableMap(methodParameters);
    }

    /**
     * @return may return null
     */

    public String getJavaMethodName() {
        return javaMethodName;
    }


    public String getGeniMethodName() {
        return geniMethodName;
    }

    /**
     * @return may return null
     */
    public ApiCallReply getReply() {
        return reply;
    }


    public String getHttpRequestLine() {
        return httpRequestLine;
    }


    public String getHttpRequestHeaders() {
        return httpRequestHeaders;
    }


    public String getHttpRequest() {
        return httpRequest;
    }


    public String getHttpStatusLine() {
        return httpStatusLine;
    }


    public String getHttpResponseHeaders() {
        return httpResponseHeaders;
    }


    public String getHttpReply() {
        return httpReply;
    }

    @Override
    public String toString() {
        String responseCode = "no reply";
        if (reply != null && reply.getGeniResponseCode() != null)
            responseCode = reply.getGeniResponseCode().toString();
        return "Result{" + '\n' +
                "serverUrl='" + serverUrl + '\'' + '\n' +
                ", apiName='" + apiName + '\'' + '\n' +
                ", javaMethodName='" + javaMethodName + '\'' + '\n' +
                ", geniMethodName='" + geniMethodName + '\'' + '\n' +
                ", reply.getGeniResponseCode()=" + responseCode + '\n' +
                ", httpRequest='" + httpRequest + '\'' + '\n' +
                ", httpStatusLine='" + httpStatusLine + '\'' + '\n' +
                ", httpReply='" + httpReply + '\'' + '\n' +
                '}';
    }


//    public void setStartTime(Date startTime) {
//        this.startTime = startTime;
//    }
//
//    public void setStopTime(Date stopTime) {
//        this.stopTime = stopTime;
//    }



    public Date getStartTime() {
        return startTime;
    }


    public Date getStopTime() {
        return stopTime;
    }

    public Throwable getException() {
        return exception;
    }
}
