package be.iminds.ilabt.jfed.log;

/**
 * ResultListener
 */
public interface ResultListener {
    public void onResult(ApiCallDetails result);
}
