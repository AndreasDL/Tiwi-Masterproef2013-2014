package be.iminds.ilabt.jfed.lowlevel.authority;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.ServerType;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/*
*
* Hint: to fetch server SSL certificates in PEM format, you can use openssl like this:
*    openssl s_client -showcerts -connect <hostname>:<port> -prexit
*
* */

public class BuiltinAuthorityList {
    private BuiltinAuthorityList() {    }

    private static SfaAuthority emulabAuthority(String baseUrl, String urnName, String hrn, boolean am, boolean am2, boolean am3) throws JFedException {
        try {
            URL base = new URL(baseUrl);
            String url_sa = baseUrl+"/protogeni/xmlrpc/sa";
            String url_am = baseUrl+"/protogeni/xmlrpc/am";
            String url_am2 = baseUrl+"/protogeni/xmlrpc/am/2.0";
            String url_am3 = baseUrl+"/protogeni/xmlrpc/am/3.0";

            String urn = "urn:publicid:IDN+"+urnName+"+authority+cm";

            String name = base.getHost();

            Map<ServerType, URL> urls = new HashMap<ServerType, URL>();
            urls.put(new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1), new URL(url_sa));
            if (am)
                urls.put(new ServerType(ServerType.GeniServerRole.AM, 1), new URL(url_am));
            if (am2)
                urls.put(new ServerType(ServerType.GeniServerRole.AM, 2), new URL(url_am2));
            if (am3)
                urls.put(new ServerType(ServerType.GeniServerRole.AM, 3), new URL(url_am3));
            SfaAuthority emulabauth = new SfaAuthority(urn, hrn, urls, null/*proxies*/, null/*gid*/, "emulab");
            emulabauth.setSource(SfaAuthority.InfoSource.BUILTIN);

            return emulabauth;
        } catch (MalformedURLException e) {
            throw new RuntimeException("URL malformed: "+baseUrl, e);
        }
    }

    private static SfaAuthority planetLabEurope() throws JFedException {
        try {
            String planetLabPemcert = "-----BEGIN CERTIFICATE-----\n" +
                    "MIICAjCCAWugAwIBAgIBAzANBgkqhkiG9w0BAQQFADAOMQwwCgYDVQQDEwNwbGUw\n" +
                    "HhcNMTEwOTA2MTM1NDQ3WhcNMTYwOTA0MTM1NDQ3WjAOMQwwCgYDVQQDEwNwbGUw\n" +
                    "gZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBALkBw6LbOd11cCG16hnh/HN/r6hu\n" +
                    "pmqTHhhOI9RO5fc8ypbcMvvEzOf1+QbQlv9itVIL7jjoAKiCyVcC1PmAlQyV8U8a\n" +
                    "fsRuTOAy+gXQUGQxKeR8G4k9iv3VoXj2TuSpFUUN9EfjS/2BJl7enkdaoPTWrs9z\n" +
                    "sEdCjKGEeYlQPqRhAgMBAAGjcDBuMA8GA1UdEwEB/wQFMAMBAf8wWwYDVR0RBFQw\n" +
                    "UoYhdXJuOnB1YmxpY2lkOklETitwbGUrYXV0aG9yaXR5K3Nhhi11cm46dXVpZDo2\n" +
                    "MTMyNThjMi0wMmJlLTRkZDgtOThlMS02NjAxZmNhNTNhZjIwDQYJKoZIhvcNAQEE\n" +
                    "BQADgYEARhqfrAhxX4caWnfYVSx1fF3/adA7KkUZonSUgEd38NmAlt9xLqOJAAcZ\n" +
                    "0GLfOrxm7Url31GqwDFsND9/VLaDt7WEx5NbsbaFhMu9TNlhc/2UQOuoQK0glyaw\n" +
                    "dAyg/PfHVy1XACG/kqIKIwKvx17mpXTF+bZLzcVwhMwgb3Ipcak=\n" +
                    "-----END CERTIFICATE-----";

            String url_registry =  "https://sfa.planet-lab.eu:12345";
            String url_am2 = "https://sfa.planet-lab.eu:12346";
            String url_slicemgr = "https://sfa.planet-lab.eu:12347";

            String urn = "urn:publicid:IDN+ple:ibbtple+authority+cm";

            String name = "PlanetLab Europe";

            Map<ServerType, URL> urls = new HashMap<ServerType, URL>();
            urls.put(new ServerType(ServerType.GeniServerRole.PlanetLabSliceRegistry, 1), new URL(url_registry));
            urls.put(new ServerType(ServerType.GeniServerRole.AM, 2), new URL(url_am2));
            SfaAuthority pleAuth = new SfaAuthority(urn, name, urls, null/*proxies*/, null/*gid*/, "planetlab");
            pleAuth.setSource(SfaAuthority.InfoSource.BUILTIN);
            pleAuth.setReconnectEachTime(true);

            pleAuth.setPemSslTrustCert(planetLabPemcert);

            pleAuth.addAllowedCertificateHostnameAlias("ple");

            return pleAuth;
        } catch (MalformedURLException e) {
            throw new RuntimeException("URL malformed: "+e.getMessage(), e);
        }
    }
    private static SfaAuthority planetLabCentral() throws JFedException {
        try {
            String planetLabPemcert = "-----BEGIN CERTIFICATE-----\n" +
                    "MIICAjCCAWugAwIBAgIBAzANBgkqhkiG9w0BAQQFADAOMQwwCgYDVQQDEwNwbGMw\n" +
                    "HhcNMTEwOTA2MTkxNzE3WhcNMTYwOTA0MTkxNzE3WjAOMQwwCgYDVQQDEwNwbGMw\n" +
                    "gZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBALwfK0p5JtRfQp+kQTZfokt1mcqb\n" +
                    "IYvfnTH2SxhdDZsFmelVWISi70VWQBLWsZu/xqZrale0it9tOVNLNwQLIbSqZFqL\n" +
                    "mK7EemuPQVs5q83ezGvmJsUT4EXIAMg8JScaCTht3JMWoFQMJCOMOga50hnitfCF\n" +
                    "vm9ih44/7ehwvQf7AgMBAAGjcDBuMA8GA1UdEwEB/wQFMAMBAf8wWwYDVR0RBFQw\n" +
                    "UoYhdXJuOnB1YmxpY2lkOklETitwbGMrYXV0aG9yaXR5K3Nhhi11cm46dXVpZDpi\n" +
                    "YzVkNmFkMy0zYTA4LTRmNGItOGViOC1iZDhjNWNiMGU0NGUwDQYJKoZIhvcNAQEE\n" +
                    "BQADgYEAUqNjtwhyQWu87nklNuGa2/7DIThdSvObbs1S/7XhKUox9vwCJPQc0mmr\n" +
                    "4tzJOpsm/8Mg80UFOK9e5dSLmCiu8JANI4B/i3xozYc1GO1H/DToq2FMQjbbibUq\n" +
                    "T6KxeHlwYPrlonM1TXx9w+6YUQ4tzUX/bqT5ck1TpMDkftV9pjM="+
                    "-----END CERTIFICATE-----";

            String url_sa =  "https://";
            String url_am3 = "http://sfav3.planet-lab.org:12346";

            String urn = "urn:publicid:IDN+plc+authority+cm";

            String name = "PlanetLab Central";

            Map<ServerType, URL> urls = new HashMap<ServerType, URL>();
//            urls.put(new ServerType(ServerType.GeniServerRole.SA, 1), new URL(url_sa));
            urls.put(new ServerType(ServerType.GeniServerRole.AM, 3), new URL(url_am3));
            SfaAuthority plcAuth = new SfaAuthority(urn, name, urls, null/*proxies*/, null/*gid*/, "planetlab");
            plcAuth.setSource(SfaAuthority.InfoSource.BUILTIN);
            plcAuth.setReconnectEachTime(true);

            plcAuth.setPemSslTrustCert(planetLabPemcert);

            plcAuth.addAllowedCertificateHostnameAlias("plc");

            return plcAuth;
        } catch (MalformedURLException e) {
            throw new RuntimeException("URL malformed: "+e.getMessage(), e);
        }
    }

    private static SfaAuthority fiTeagle() throws JFedException {
        try {
            String fiTeaglePemcert = "-----BEGIN CERTIFICATE-----\n" +
                    "MIIDRjCCAq+gAwIBAgIBCTANBgkqhkiG9w0BAQUFADBqMQswCQYDVQQGEwJERTEP\n" +
                    "MA0GA1UECAwGQmVybGluMQ8wDQYDVQQHDAZCZXJsaW4xEjAQBgNVBAoMCVRVIEJl\n" +
                    "cmxpbjELMAkGA1UECwwCQVYxGDAWBgNVBAMMD2F2LnR1LWJlcmxpbi5kZTAeFw0x\n" +
                    "MzA1MzExMzI4NDNaFw0xNDA1MzExMzI4NDNaMHYxCzAJBgNVBAYTAkRFMQ8wDQYD\n" +
                    "VQQIDAZCZXJsaW4xGTAXBgNVBAoMEEZyYXVuaG9mZXIgRk9LVVMxDTALBgNVBAsM\n" +
                    "BE5HTkkxLDAqBgNVBAMMI2ZpdGVhZ2xlLWZ1c2Vjby5mb2t1cy5mcmF1bmhvZmVy\n" +
                    "LmRlMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC/52gb28jfxz/EopFy1j1r\n" +
                    "5tcGtMPqyREaHaMY4GXAmNlnfJzxILFtLUOSPa4R4hChrl8qXqCa09iLnRQfS9fC\n" +
                    "i706MdMsppwFeAaWwyYPmN9AUOR3IDearz4AHPoncd6tbcDHODxfwmikyrqW5Oen\n" +
                    "5pFz7M0xz4X1qATNteGEbwIDAQABo4HvMIHsMAkGA1UdEwQCMAAwLAYJYIZIAYb4\n" +
                    "QgENBB8WHU9wZW5TU0wgR2VuZXJhdGVkIENlcnRpZmljYXRlMB0GA1UdDgQWBBTK\n" +
                    "Wq0AvCeFYdtb+bg8Ogj0SeeJbTCBhAYDVR0jBH0we6FupGwwajELMAkGA1UEBhMC\n" +
                    "REUxDzANBgNVBAgMBkJlcmxpbjEPMA0GA1UEBwwGQmVybGluMRIwEAYDVQQKDAlU\n" +
                    "VSBCZXJsaW4xCzAJBgNVBAsMAkFWMRgwFgYDVQQDDA9hdi50dS1iZXJsaW4uZGWC\n" +
                    "CQDJgKT16VcNozALBgNVHQ8EBAMCBeAwDQYJKoZIhvcNAQEFBQADgYEAYSZ7BRTl\n" +
                    "9+wVr9+pbRaMeg9BMqJCep2Xu7LEWK7tn3oH1O9uI7/Bo6axwrmcGsHw0vtgmd2N\n" +
                    "hfgeVqRGHgeFDpgtWFWwXu/rDS8pslOV9Y2pvKC3CIoCSWEIPu2VVWfMRVbN5G1l\n" +
                    "sABRUfL5sr6S0T8QSxXpg2P7qel1oa4hoYY=\n" +
                    "-----END CERTIFICATE-----\n";

//            String url_am3 = "https://fiteagle-fuseco.fokus.fraunhofer.de/api/sfa/am/v3";
            String url_am3 = "https://193.175.132.29/api/sfa/am/v3";

            String urn = "urn:publicid:IDN+fiteagle+authority+am";

            String name = "FITeagle";


            Map<ServerType, URL> urls = new HashMap<ServerType, URL>();
            urls.put(new ServerType(ServerType.GeniServerRole.AM, 3), new URL(url_am3));
            SfaAuthority fiteagleAuth = new SfaAuthority(urn, name, urls, null/*proxies*/, null/*gid*/, "teagle");
            fiteagleAuth.setSource(SfaAuthority.InfoSource.BUILTIN);
            fiteagleAuth.setReconnectEachTime(false);

            fiteagleAuth.setPemSslTrustCert(fiTeaglePemcert);

            fiteagleAuth.addAllowedCertificateHostnameAlias("fiteagle-fuseco.fokus.fraunhofer.de");

            return fiteagleAuth;
        } catch (MalformedURLException e) {
            throw new RuntimeException("URL malformed: "+e.getMessage(), e);
        }
    }


    public static void load(AuthorityListModel authorityListModel) {
        try {
            String pem_wall2_CA_cert = "-----BEGIN CERTIFICATE-----\n" +
                    "MIIEgjCCA2qgAwIBAgIRAJtSpUYIQTrQTVeuvAt8bXQwDQYJKoZIhvcNAQEFBQAw\n" +
                    "NjELMAkGA1UEBhMCTkwxDzANBgNVBAoTBlRFUkVOQTEWMBQGA1UEAxMNVEVSRU5B\n" +
                    "IFNTTCBDQTAeFw0xMzA1MDYwMDAwMDBaFw0xNjA1MDUyMzU5NTlaMEgxITAfBgNV\n" +
                    "BAsTGERvbWFpbiBDb250cm9sIFZhbGlkYXRlZDEjMCEGA1UEAxMad3d3LndpbGFi\n" +
                    "Mi5pbGFidC5pbWluZHMuYmUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB\n" +
                    "AQDH3Tel+sJ6ikRLtZ43YaTQq8YOSaHnguy/3RDHeRoQAiNoyopQvXNwzeRgpHMR\n" +
                    "3bRwG6jjmwfIsVfMwL+f1gX/bmWrZxCoovU2Fz1NiR3p1zI1AHnW+MBWoF9/Q+5Y\n" +
                    "1eWAz61VKu/kL6X55fD8GYWs1vRrFeMyvqGhkBWDwQza0Ct5TH/x016pUM4jaF+b\n" +
                    "s5xD6cP37bCMUO5S7rlYa7v4BGLvJgMxax7x3RoMOaAddOM/4lofdZmFlKvYa0nM\n" +
                    "a/ta+dDecBz35/minYUwuq5gW25XR7KFfNeyVAkv69nNiErFGVCt2Mv5kjwm3NgV\n" +
                    "ec+mkJwU9PSAN37x+qbJHXOjAgMBAAGjggF3MIIBczAfBgNVHSMEGDAWgBQMvZNo\n" +
                    "DPPeq6NJays3V0fqkOO57TAdBgNVHQ4EFgQUqlvn1Jr9Ns1v7KUSTtweAxrieaUw\n" +
                    "DgYDVR0PAQH/BAQDAgWgMAwGA1UdEwEB/wQCMAAwHQYDVR0lBBYwFAYIKwYBBQUH\n" +
                    "AwEGCCsGAQUFBwMCMCIGA1UdIAQbMBkwDQYLKwYBBAGyMQECAh0wCAYGZ4EMAQIB\n" +
                    "MDoGA1UdHwQzMDEwL6AtoCuGKWh0dHA6Ly9jcmwudGNzLnRlcmVuYS5vcmcvVEVS\n" +
                    "RU5BU1NMQ0EuY3JsMG0GCCsGAQUFBwEBBGEwXzA1BggrBgEFBQcwAoYpaHR0cDov\n" +
                    "L2NydC50Y3MudGVyZW5hLm9yZy9URVJFTkFTU0xDQS5jcnQwJgYIKwYBBQUHMAGG\n" +
                    "Gmh0dHA6Ly9vY3NwLnRjcy50ZXJlbmEub3JnMCUGA1UdEQQeMByCGnd3dy53aWxh\n" +
                    "YjIuaWxhYnQuaW1pbmRzLmJlMA0GCSqGSIb3DQEBBQUAA4IBAQAna948n23y6gJV\n" +
                    "rR976Hxi2oW+Py7w7ycW5eHD/YF3qdhLsvWBCffh26zeWE8IXbNyLU9fP96vRHAh\n" +
                    "D99gOcD7wiUYnjmvOwRoK/1bStzxB8PYRuZVyUKp+5ksmERxSJMlFgb7HHtgF3m6\n" +
                    "e1835ONyDfxmyMH1z+G/gpw8Sl5+4tFxGnvVbyN9WnLH1ZW3mdhEIMKCRp26/wnL\n" +
                    "VU19QQHbqWnouYmeZ6ZUE3yvYobihl1Cqc207AoxmLUvQjleyC6Dr9twj775joPF\n" +
                    "rfV4VxQlZE6hhhVwgBdn/Of12KPkn4KNzxQ1G2XaGq+cBZS37F3wOKTBbp+HZjB+\n" +
                    "mqGrS2Lp" +
                    "-----END CERTIFICATE-----";
            String wilab2_cert = "-----BEGIN CERTIFICATE-----\n" +
                    "MIIEgjCCA2qgAwIBAgIRAJtSpUYIQTrQTVeuvAt8bXQwDQYJKoZIhvcNAQEFBQAw\n" +
                    "NjELMAkGA1UEBhMCTkwxDzANBgNVBAoTBlRFUkVOQTEWMBQGA1UEAxMNVEVSRU5B\n" +
                    "IFNTTCBDQTAeFw0xMzA1MDYwMDAwMDBaFw0xNjA1MDUyMzU5NTlaMEgxITAfBgNV\n" +
                    "BAsTGERvbWFpbiBDb250cm9sIFZhbGlkYXRlZDEjMCEGA1UEAxMad3d3LndpbGFi\n" +
                    "Mi5pbGFidC5pbWluZHMuYmUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB\n" +
                    "AQDH3Tel+sJ6ikRLtZ43YaTQq8YOSaHnguy/3RDHeRoQAiNoyopQvXNwzeRgpHMR\n" +
                    "3bRwG6jjmwfIsVfMwL+f1gX/bmWrZxCoovU2Fz1NiR3p1zI1AHnW+MBWoF9/Q+5Y\n" +
                    "1eWAz61VKu/kL6X55fD8GYWs1vRrFeMyvqGhkBWDwQza0Ct5TH/x016pUM4jaF+b\n" +
                    "s5xD6cP37bCMUO5S7rlYa7v4BGLvJgMxax7x3RoMOaAddOM/4lofdZmFlKvYa0nM\n" +
                    "a/ta+dDecBz35/minYUwuq5gW25XR7KFfNeyVAkv69nNiErFGVCt2Mv5kjwm3NgV\n" +
                    "ec+mkJwU9PSAN37x+qbJHXOjAgMBAAGjggF3MIIBczAfBgNVHSMEGDAWgBQMvZNo\n" +
                    "DPPeq6NJays3V0fqkOO57TAdBgNVHQ4EFgQUqlvn1Jr9Ns1v7KUSTtweAxrieaUw\n" +
                    "DgYDVR0PAQH/BAQDAgWgMAwGA1UdEwEB/wQCMAAwHQYDVR0lBBYwFAYIKwYBBQUH\n" +
                    "AwEGCCsGAQUFBwMCMCIGA1UdIAQbMBkwDQYLKwYBBAGyMQECAh0wCAYGZ4EMAQIB\n" +
                    "MDoGA1UdHwQzMDEwL6AtoCuGKWh0dHA6Ly9jcmwudGNzLnRlcmVuYS5vcmcvVEVS\n" +
                    "RU5BU1NMQ0EuY3JsMG0GCCsGAQUFBwEBBGEwXzA1BggrBgEFBQcwAoYpaHR0cDov\n" +
                    "L2NydC50Y3MudGVyZW5hLm9yZy9URVJFTkFTU0xDQS5jcnQwJgYIKwYBBQUHMAGG\n" +
                    "Gmh0dHA6Ly9vY3NwLnRjcy50ZXJlbmEub3JnMCUGA1UdEQQeMByCGnd3dy53aWxh\n" +
                    "YjIuaWxhYnQuaW1pbmRzLmJlMA0GCSqGSIb3DQEBBQUAA4IBAQAna948n23y6gJV\n" +
                    "rR976Hxi2oW+Py7w7ycW5eHD/YF3qdhLsvWBCffh26zeWE8IXbNyLU9fP96vRHAh\n" +
                    "D99gOcD7wiUYnjmvOwRoK/1bStzxB8PYRuZVyUKp+5ksmERxSJMlFgb7HHtgF3m6\n" +
                    "e1835ONyDfxmyMH1z+G/gpw8Sl5+4tFxGnvVbyN9WnLH1ZW3mdhEIMKCRp26/wnL\n" +
                    "VU19QQHbqWnouYmeZ6ZUE3yvYobihl1Cqc207AoxmLUvQjleyC6Dr9twj775joPF\n" +
                    "rfV4VxQlZE6hhhVwgBdn/Of12KPkn4KNzxQ1G2XaGq+cBZS37F3wOKTBbp+HZjB+\n" +
                    "mqGrS2Lp\n" +
                    "-----END CERTIFICATE-----\n";


            SfaAuthority wilab2 = emulabAuthority("https://www.wilab2.ilabt.iminds.be:12369", "wilab2.ilabt.iminds.be", "iMinds WiLab 2", true, true, true);
            wilab2.setPemSslTrustCert(wilab2_cert);

            SfaAuthority wall1 = emulabAuthority("https://www.wall2.ilabt.iminds.be", "wall2.ilabt.iminds.be", "iMinds Virtual Wall 2", false, false, false);
            wall1.setPemSslTrustCert(pem_wall2_CA_cert);

            authorityListModel.mergeOrAdd(wall1);
            authorityListModel.mergeOrAdd(wilab2);
            authorityListModel.mergeOrAdd(emulabAuthority("https://www.emulab.net:12369", "emulab.net", "Utah Emulab", true, true, true));
            authorityListModel.mergeOrAdd(planetLabCentral());
            authorityListModel.mergeOrAdd(planetLabEurope());
            authorityListModel.mergeOrAdd(fiTeagle());
        } catch (JFedException e) {
            throw new RuntimeException("Bug: BuiltinAuthorityList should never generate GeniException while creating GeniAuthorities: "+e.getMessage(), e);
        }

        authorityListModel.fireChange();
    }
}
