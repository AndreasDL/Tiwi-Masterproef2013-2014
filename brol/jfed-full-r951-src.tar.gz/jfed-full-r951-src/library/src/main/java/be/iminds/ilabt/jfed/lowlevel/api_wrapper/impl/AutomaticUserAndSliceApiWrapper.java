package be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.UserAndSliceApiWrapper;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.util.GeniUrn;

import java.util.Date;
import java.util.List;

/**
 * AutomaticUserAndSliceApiWrapper automatically chooses the best UserAndSliceApiWrapper implementation
 * for the situation and uses it
 */
public class AutomaticUserAndSliceApiWrapper extends UserAndSliceApiWrapper {

    protected ServerType serverType;
    protected UserAndSliceApiWrapper impl;
    public AutomaticUserAndSliceApiWrapper(Logger logger, GeniUserProvider geniUserProvider, GeniConnectionProvider connectionProvider) {
        super(logger, geniUserProvider, connectionProvider);

        choose();
    }
    public AutomaticUserAndSliceApiWrapper(Logger logger, final GeniUser geniUser, GeniConnectionProvider connectionProvider) {
        this(logger, new GeniUserProvider() {
            public GeniUser getLoggedInGeniUser() {
                return geniUser;
            }
            public boolean isUserLoggedIn() { return true; }
        }, connectionProvider);
    }

    protected void choose() {
        if (!geniUserProvider.isUserLoggedIn()) {
            serverType = null;
            impl = null;
            return;
        }

        GeniUser user = getUser();
        SfaAuthority userAuth = getUserAuthority();

        if (userAuth.getUrls().containsKey(new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1))) {
            serverType = new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1);
            impl = new ProtoGeniSAUserAndSliceApiWrapper(logger, geniUserProvider, connectionProvider);
            return;
        }
        if (userAuth.getUrls().containsKey(new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 1)) &&
                userAuth.getUrls().containsKey(new ServerType(ServerType.GeniServerRole.GENI_CH_MA, 1))) {
            serverType = null;
            impl = new UniformFederationApiUserAndSliceApiWrapper(logger, geniUserProvider, connectionProvider);

            return;
        }
        if (userAuth.getUrls().containsKey(new ServerType(ServerType.GeniServerRole.PlanetLabSliceRegistry, 1))) {
            impl = new PlanetlabRegistryUserAndSliceApiWrapper(logger, geniUserProvider, connectionProvider);
            return;
        }

        throw new RuntimeException("There is no server known at the users authority that can be used to" +
                " retrieve user and slice credentials and create slices. user authority: "+userAuth.getUrn()+
                "  types of known servers: "+userAuth.getUrls().keySet());
    }

    protected UserAndSliceApiWrapper getImpl() {
        if (impl == null)
            choose();
        return impl;
    }

    @Override
    public AnyCredential getUserCredentials(GeniUrn userUrn) throws JFedException {
        return getImpl().getUserCredentials(userUrn);
    }

    @Override
    public AnyCredential getSliceCredentials(AnyCredential userCredential, GeniUrn sliceUrn) throws JFedException {
        return getImpl().getSliceCredentials(userCredential, sliceUrn);
    }

    @Override
    public List<GeniUrn> getSlicesForUser(AnyCredential userCredential, GeniUrn userUrn) throws JFedException {
        return getImpl().getSlicesForUser(userCredential, userUrn);
    }

    @Override
    public void getAggregatesForSlice(AnyCredential userCredential, AnyCredential sliceCredential, GeniUrn sliceUrn) throws JFedException {
        getImpl().getAggregatesForSlice(userCredential, sliceCredential, sliceUrn);
    }

    @Override
    public SliceInfo createSlice(AnyCredential userCredential, String sliceName, Date expirationDate) throws JFedException {
        return getImpl().createSlice(userCredential, sliceName, expirationDate);
    }

    @Override
    public AnyCredential renewSlice(AnyCredential sliceCredential, Date newExpirationDate) throws JFedException {
        return getImpl().renewSlice(sliceCredential, newExpirationDate);
    }

    @Override
    public void getSshKeysForUser(AnyCredential userCredential, GeniUrn userUrn) throws JFedException {
        getImpl().getSshKeysForUser(userCredential, userUrn);
    }
}
