package be.iminds.ilabt.jfed.lowlevel.connection;

import be.iminds.ilabt.jfed.lowlevel.GeniUser;
import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.ServerType;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;

import java.net.URL;

/**
 * GeniConnectionProvider
 */
public interface GeniConnectionProvider {
    /** debug mode will print out a info during the call */
    public boolean isDebugMode();
    /** debug mode will print out a info during the call */
    public void setDebugMode(boolean debugMode);

    //GeniUser user is only required for HTTPS connections

    public JFedConnection getConnectionByAuthority(GeniUser user, SfaAuthority authority, Class targetClass) throws JFedException;
    public JFedConnection getConnectionByAuthority(GeniUser user, SfaAuthority authority, ServerType serverType) throws JFedException;

    public JFedConnection getConnectionByUserAuthority(GeniUser user, ServerType serverType) throws JFedException;

    public JFedConnection getConnectionByUrl(GeniUser user, URL url, HttpsClientWithUserAuthenticationFactory.HandleUntrustedCallback handleUntrustedCallback, ServerType serverType) throws JFedException;
//    public SfaConnection getSfaConnectionByUrl(GeniUser user, URL url, HttpsClientWithUserAuthenticationFactory.HandleUntrustedCallback handleUntrustedCallback) throws JFedException;
}
