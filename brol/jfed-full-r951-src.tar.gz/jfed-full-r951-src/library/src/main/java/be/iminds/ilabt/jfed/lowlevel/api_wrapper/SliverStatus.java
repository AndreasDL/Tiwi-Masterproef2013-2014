package be.iminds.ilabt.jfed.lowlevel.api_wrapper;

/**
 * Status of a sliver of a slice
 *
 * This is a generic status, independent of any AM API. The real status might be more fine-grained.
 */
public enum SliverStatus {
    UNINITIALISED, /* nothing known about status*/
    READY,
    UNALLOCATED,   /* known not to exist */
    UNKNOWN,       /* known to exist, but no status known. probably it is changing. */
    CHANGING,
    FAIL;
}
