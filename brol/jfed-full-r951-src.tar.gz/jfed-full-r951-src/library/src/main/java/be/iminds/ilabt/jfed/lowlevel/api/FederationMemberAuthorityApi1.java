package be.iminds.ilabt.jfed.lowlevel.api;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;

import java.lang.reflect.Method;
import java.util.*;

/**
 * FederationMemberAuthorityApi1
 */
public class FederationMemberAuthorityApi1 extends AbstractFederationApi1 {
    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Member Authority API v1";
     */
    static public String getApiName() {
        return "Uniform Federation Member Authority API v1";
    }
    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Member Authority API v1";
     */
    @Override
    public String getName() {
        return getApiName();
    }

    public FederationMemberAuthorityApi1(Logger logger, boolean autoRetryBusy) {
        super(logger, autoRetryBusy, new ServerType(ServerType.GeniServerRole.GENI_CH_MA, 1));
    }

    public FederationMemberAuthorityApi1(Logger logger) {
        this(logger, true);
    }

    public String getMethodObject(Method method) {
        if (method.getName().equals("createKey") ||
                method.getName().equals("lookupKeys") ||
                method.getName().equals("deleteKey") ||
                method.getName().equals("updateKey"))
            return "KEY";

        if (method.getName().equals("lookupPublicMemberInfo") ||
                method.getName().equals("lookupPrivateMemberInfo") ||
                method.getName().equals("lookupIdentifyingMemberInfo") ||
                method.getName().equals("updateMemberInfo"))
            return "MEMBER";

        return null;
    }

    @Override
    public List<GetVersionResult.FieldInfo> getMinimumFields(String objectName) {
        List<GetVersionResult.FieldInfo> res = new ArrayList<GetVersionResult.FieldInfo>();
        if (objectName.equalsIgnoreCase("MEMBER")) {
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_URN", GetVersionResult.FieldInfo.FieldType.URN, true, GetVersionResult.FieldInfo.Protect.PUBLIC));
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_UID", GetVersionResult.FieldInfo.FieldType.UID, true, GetVersionResult.FieldInfo.Protect.PUBLIC));
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_FIRSTNAME", GetVersionResult.FieldInfo.FieldType.STRING, true, GetVersionResult.FieldInfo.Protect.IDENTIFYING));
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_LASTNAME", GetVersionResult.FieldInfo.FieldType.STRING, true, GetVersionResult.FieldInfo.Protect.IDENTIFYING));
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_USERNAME", GetVersionResult.FieldInfo.FieldType.STRING, true, GetVersionResult.FieldInfo.Protect.PUBLIC));
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_EMAIL", GetVersionResult.FieldInfo.FieldType.STRING, false, GetVersionResult.FieldInfo.Protect.IDENTIFYING));
        }
        if (objectName.equalsIgnoreCase("KEY")) {
            res.add(new GetVersionResult.FieldInfo("KEY", "KEY_MEMBER", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, true, false));
            res.add(new GetVersionResult.FieldInfo("KEY", "KEY_ID", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("KEY", "KEY_PUBLIC", GetVersionResult.FieldInfo.FieldType.KEY, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, true, false));
            res.add(new GetVersionResult.FieldInfo("KEY", "KEY_PRIVATE", GetVersionResult.FieldInfo.FieldType.KEY, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("KEY", "KEY_DESCRIPTION", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, true, true));
        }
        return res;
    }

    @Override
    public List<String> getApiObjects() {
        List<String> res = new ArrayList<String>();
        res.add("MEMBER");
        res.add("KEY");
        return res;
    }

    @Override
    public List<String> getRequiredApiServices() {
        List<String> res = new ArrayList<String>();
        res.add("MEMBER");
        return res;
    }

    @Override
    public List<String> getOptionalApiServices() {
        List<String> res = new ArrayList<String>();
        res.add("KEY");
        return res;
    }


    @ApiMethod(order=1, hint="get_version call: Provide a structure detailing the version information as well as details of accepted options s for CH API calls.", unprotected=true)
    public FederationApiReply<GetVersionResult> getVersion(SfaConnection con)  throws JFedException {
        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "get_version", new Vector(), null);
        FederationApiReply<GetVersionResult> r = null;
        try {
            r = new FederationApiReply<GetVersionResult>(res, new GetVersionResult(apiSpecifiesHashtableStringToObject(res.getResultValueObject())));
        } catch (Throwable e) {
//            System.err.println("Error parsing get_version reply: "+e);
//            e.printStackTrace();
            handleErrorProcessingArguments(res, "getVersion", "get_version", con, e);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<GetVersionResult>(res, null);
        log(res, r, "getVersion", "get_version", con, null);
        return r;
    }


    @ApiMethod(order=2, hint="lookup_public_member_info call: Lookup public information about members matching given criteria", unprotected=true)
    public FederationApiReply<LookupResult> lookupPublicMemberInfo(SfaConnection con,
                                                                   @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                   List<AnyCredential> credentialList,
                                                                   @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API1_MATCH)
                                                                   Map<String, ? extends Object> match,
                                                                   @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API1_FILTER)
                                                                   List<String> filter,
                                                                   @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                   Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "match", match, "filter", filter, "extraOptions", extraOptions);
        return genericLookupCall(methodParams, con, "lookupPublicMemberInfo", "lookup_public_member_info", credentialList, match, filter, extraOptions, null);
    }

    @ApiMethod(order=3, hint="lookup_private_member_info call: Lookup private (SSL/SSH key) information about members matching given criteria")
    public FederationApiReply<LookupResult> lookupPrivateMemberInfo(SfaConnection con,
                                                                    @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                    List<AnyCredential> credentialList,
                                                                    @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API1_MATCH)
                                                                    Map<String, ? extends Object> match,
                                                                    @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API1_FILTER)
                                                                    List<String> filter,
                                                                    @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                    Map<String, Object> extraOptions)  throws JFedException {
        assert credentialList != null;
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "match", match, "filter", filter, "extraOptions", extraOptions);
        return genericLookupCall(methodParams, con, "lookupPrivateMemberInfo", "lookup_private_member_info", credentialList, match, filter, extraOptions, null);
    }

    @ApiMethod(order=4, hint="lookup_identifying_member_info call: Lookup identifying (e.g. name, email) info about matching members")
    public FederationApiReply<LookupResult> lookupIdentifyingMemberInfo(SfaConnection con,
                                                                        @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                        List<AnyCredential> credentialList,
                                                                        @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API1_MATCH)
                                                                        Map<String, ? extends Object> match,
                                                                        @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API1_FILTER)
                                                                        List<String> filter,
                                                                        @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                        Map<String, Object> extraOptions)  throws JFedException {
        assert credentialList != null;
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "match", match, "filter", filter, "extraOptions", extraOptions);
        return genericLookupCall(methodParams, con, "lookupIdentifyingMemberInfo", "lookup_identifying_member_info", credentialList, match, filter, extraOptions, null);
    }


    @ApiMethod(order=5, hint="update_member_info call: Update information about given member public, private or identifying information")
    public FederationApiReply<String> updateMemberInfo(SfaConnection con,
                                                       @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                       List<AnyCredential> credentialList,
                                                       @ApiMethodParameter(name = "urn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                       String urn,
                                                       @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API1_FIELDS)
                                                       Map<String, String> fields,
                                                       @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                       Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "urn", urn, "fields", fields, "extraOptions", extraOptions);
        return genericUpdateCall(methodParams, con, "updateMemberInfo", "update_member_info", credentialList, urn, "member", fields, extraOptions);
    }


    /**  */
    @ApiMethod(order=6, hint="get_credentials call: Provide list of credentials (signed statements) for given member\n" +
            "This is member-specific information suitable for passing as credentials in an AM API call for aggregate authorization.")
    public FederationApiReply<List<AnyCredential>> getCredentials(SfaConnection con,
                                                                  @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                  List<AnyCredential> credentialList,
                                                                  @ApiMethodParameter(name = "memberUrn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                                  GeniUrn memberUrn,
                                                                  @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                  Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "credentialList", credentialList, "extraOptions", extraOptions);
        assert credentialList != null;
        assert memberUrn != null;

        if (memberUrn == null || !memberUrn.getResourceType().equals("user"))
            System.err.println("WARNING: member URN argument to getCredentials is not a valid member urn: \""+memberUrn+"\" (will be used anyway)");

        Vector args = new Vector(3);
        args.add(memberUrn.toString());

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        if (extraOptions == null)
            args.add(new Hashtable<String, Object>());
        else
            args.add(new Hashtable<String, Object>(extraOptions));

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "get_credentials", args, methodParams);
        FederationApiReply<List<AnyCredential>> r = null;
        try {
            Object resultValueObject = res.getResultValueObject();
            List<AnyCredential> credList = apiSpecifiesVectorOfCredentials("FederationMemberAuthorityApi1 getCredentials", resultValueObject);
            r = new FederationApiReply<List<AnyCredential>>(res, credList);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "getCredentials", "get_credentials", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<List<AnyCredential>>(res, null);
        log(res, r, "getCredentials", "get_credentials", con, methodParams);
        return r;
    }





    @ApiMethod(order=7, hint="lookup_keys call:")
    public FederationApiReply<Map<GeniUrn, List<Map<String, Object>>>> lookupKeys(SfaConnection con,
                                                       @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                       List<AnyCredential> credentialList,
                                                       @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API1_MATCH)
                                                       Map<String, ? extends Object> match,
                                                       @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API1_FILTER)
                                                       List<String> filter,
                                                       @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                       Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "match", match, "filter", filter, "extraOptions", extraOptions);
        assert credentialList != null;
        /*
         * This is not a generic lookup call: it returns:
         *
         *     I think that this call should return a list of dictionaries (one for each key) for each person indexed by member_urn.
         *     Put another way, a dictionary (indexed by member_urn) of lists of dictionaries (key fields).

         That is, for example,
         {
         member_urn_1 : [
         {'KEY_MEMBER' : member_urn_1, 'KEY_ID' : key_id_1_A, 'KEY_PUBLIC' : key_public_1_A, 'KEY_PRIVATE' : key_private_1_A, 'KEY_DESCRIPTION' : key_description_1_A},
         {'KEY_MEMBER' : member_urn_1, 'KEY_ID' : key_id_1_B, 'KEY_PUBLIC' : key_public_1_B, 'KEY_PRIVATE' : key_private_1_B, 'KEY_DESCRIPTION' : key_description_1_B}
         ],
         member_urn_2 : [
         {'KEY_MEMBER' : member_urn_2, 'KEY_ID' : key_id_2_A, 'KEY_PUBLIC' : key_public_2_A, 'KEY_PRIVATE' : key_private_2_A, 'KEY_DESCRIPTION' : key_description_2_A},
         {'KEY_MEMBER' : member_urn_2, 'KEY_ID' : key_id_2_B, 'KEY_PUBLIC' : key_public_2_B, 'KEY_PRIVATE' : key_private_2_B, 'KEY_DESCRIPTION' : key_description_2_B}
         ],
         ...
         }
         *
             so not   return genericLookupCall(con, "lookupKeys", "lookup_keys", credentialList, match, filter, extraOptions, null);
         **/
        Vector args = new Vector();

        if (credentialList != null) {
            Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
            args.add(credentials);
        }

        Hashtable options = new Hashtable();
        if (match != null)
            options.put("match", new Hashtable<String, Object>(match));
        if (filter != null/* && !filter.isEmpty()*/)
            options.put("filter", new Vector<String>(filter));
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "lookup_keys", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<Map<GeniUrn, List<Map<String, Object>>>> r = null;
        try {
            Map<GeniUrn, List<Map<String, Object>>> resLookupResult = new HashMap<GeniUrn, List<Map<String, Object>>>();

            Hashtable<String, Object> res2 = apiSpecifiesHashtableStringToObject(resultValueObject);
            for (Map.Entry<String, Object> o : res2.entrySet()) {
                GeniUrn urn = new GeniUrn(o.getKey());

                List<Hashtable> o2 = apiSpecifiesVectorOfT(Hashtable.class, o.getValue());
                List<Map<String, Object>> covertedO2 = new ArrayList<Map<String, Object>>();
                for (Hashtable keyInfo : o2) {
                    covertedO2.add(apiSpecifiesHashtableStringToObject(keyInfo));
                }

                resLookupResult.put(urn, covertedO2);
            }

            r = new FederationApiReply<Map<GeniUrn, List<Map<String, Object>>>>(res, resLookupResult);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "lookupKeys", "lookup_keys", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<Map<GeniUrn, List<Map<String, Object>>>>(res, null);
        log(res, r, "lookupKeys", "lookup_keys", con, methodParams);
        return r;
    }

    @ApiMethod(order=8, hint="create_key call:")
    public FederationApiReply<Hashtable<String, Object>> createKey(SfaConnection con,
                                                                   @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                   List<AnyCredential> credentialList,
                                                                   @ApiMethodParameter(name = "memberUrn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                                   GeniUrn memberUrn,
                                                                   @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API1_FIELDS)
                                                                   Map<String, String> fields,
                                                                   @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                   Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "memberUrn", memberUrn, "fields", fields, "extraOptions", extraOptions);
        assert credentialList != null;

        Vector args = new Vector(2);

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable options = new Hashtable();
        if (fields != null || memberUrn != null) {
            Hashtable allFields = new Hashtable<String, String>();
            if (fields != null)
                allFields.putAll(fields);
            if (memberUrn != null) {
                if (fields.containsKey("KEY_MEMBER")) {
                    String fieldsKeyMember = fields.get("KEY_MEMBER")+"";
                    if (fieldsKeyMember.equals(memberUrn.getValue()))
                        System.err.println("Note: you specified both memberUrn and added KEY_MEMBER in fields, for createKey call."+
                                "They are equal, so no problem. Note that the createKey call only requires one of them.");
                    else
                        System.err.println("WARNING: you specified both memberUrn and added KEY_MEMBER in fields for createKey call."+
                                "They are NOT equal! memberUrn='"+memberUrn+"' "+
                                "KEY_MEMBER field value='"+fieldsKeyMember+"' "+
                                "Will give preference to memberUrn! THIS IS MOST LIKELY A BUG!");
                }
                allFields.put("KEY_MEMBER", memberUrn.getValue());
            }
            options.put("fields", allFields);
        }
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "create_key", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<Hashtable<String, Object>> r = null;
        try {
            Hashtable<String, Object> resHashtable = apiSpecifiesHashtableStringToObject(resultValueObject);
            r = new FederationApiReply<Hashtable<String, Object>>(res, resHashtable);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "createKey", "create_key", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<Hashtable<String, Object>>(res, null);
        log(res, r, "createKey", "create_key", con, methodParams);
        return r;
    }

    @ApiMethod(order=9, hint="delete_key call:")
    public FederationApiReply<Boolean> deleteKey(SfaConnection con,
                                                 @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                 List<AnyCredential> credentialList,
                                                 @ApiMethodParameter(name = "memberUrn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                 GeniUrn memberUrn,
                                                 @ApiMethodParameter(name = "keyId", hint="", parameterType=ApiMethodParameterType.STRING)
                                                 String keyId,
                                                 @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                 Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "memberUrn", memberUrn, "keyId", keyId, "extraOptions", extraOptions);
        assert credentialList != null;
        assert memberUrn != null;
        assert keyId != null;

        Vector args = new Vector(3);

        args.add(memberUrn.toString());
        args.add(keyId);

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable options = new Hashtable();
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "delete_key", args, methodParams);
        FederationApiReply<Boolean> r = null;
        try {
            r = new FederationApiReply<Boolean>(res);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "deleteKey", "delete_key", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<Boolean>(res, false);
        log(res, r, "deleteKey", "delete_key", con, methodParams);
        return r;
    }

    @ApiMethod(order=10, hint="update_key call: Update the details of a key pair for given member ")
    public FederationApiReply<String> updateKey(SfaConnection con,
                                                @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                List<AnyCredential> credentialList,
                                                @ApiMethodParameter(name = "memberUrn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                GeniUrn memberUrn,
                                                @ApiMethodParameter(name = "keyId", hint="", parameterType=ApiMethodParameterType.STRING)
                                                String keyId,
                                                @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API1_FIELDS)
                                                Map<String, String> fields,
                                                @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList,
                "memberUrn", memberUrn, "keyId", keyId, "fields", fields, "extraOptions", extraOptions);
        Vector memberExtraArgument = new Vector();
        memberExtraArgument.add(memberUrn.getValue());
        return genericUpdateCall(methodParams, con, "updateKey", "update_key", credentialList, keyId, null, fields, extraOptions, memberExtraArgument);
    }
}
