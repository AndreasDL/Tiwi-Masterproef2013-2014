package be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api.UserSpec;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.AggregateManagerWrapper;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.util.GeniUrn;

import java.util.Date;
import java.util.List;

/**
 * AutomaticAggregateManagerWrapper
 */
public class AutomaticAggregateManagerWrapper extends AggregateManagerWrapper {
    protected ServerType serverType;
    protected AggregateManagerWrapper impl;

    public AutomaticAggregateManagerWrapper(Logger logger, GeniUserProvider geniUserProvider, GeniConnectionProvider connectionProvider, SfaAuthority amAuthority) {
        super(logger, geniUserProvider, connectionProvider, amAuthority);

        choose();
    }

    public AutomaticAggregateManagerWrapper(Logger logger, final GeniUser geniUser, GeniConnectionProvider connectionProvider, SfaAuthority amAuthority) {
        this(logger, new GeniUserProvider() {
            public GeniUser getLoggedInGeniUser() {
                return geniUser;
            }

            public boolean isUserLoggedIn() {
                return true;
            }
        }, connectionProvider, amAuthority);
    }

    public static boolean preferAMv3 = false; //TODO put this in a preferences system somehow
    protected void choose() {
        //We currently prefer AMv3 over AMv2
        if (preferAMv3)
            if (amAuthority.getUrls().containsKey(new ServerType(ServerType.GeniServerRole.AM, 3))) {
                serverType = new ServerType(ServerType.GeniServerRole.AM, 3);
                impl = new AMv3Wrapper(logger, geniUserProvider, connectionProvider, amAuthority);
                return;
            }
        if (amAuthority.getUrls().containsKey(new ServerType(ServerType.GeniServerRole.AM, 2))) {
            serverType = new ServerType(ServerType.GeniServerRole.AM, 2);
            impl = new AMv2Wrapper(logger, geniUserProvider, connectionProvider, amAuthority);
            return;
        }
        if (amAuthority.getUrls().containsKey(new ServerType(ServerType.GeniServerRole.AM, 3))) {
            serverType = new ServerType(ServerType.GeniServerRole.AM, 3);
            impl = new AMv3Wrapper(logger, geniUserProvider, connectionProvider, amAuthority);
            return;
        }

        //OCCI doesn't provide a real AM, but we can wrap it (with limited functionality)...
        if (amAuthority.getUrls().containsKey(new ServerType(ServerType.GeniServerRole.OCCI, 1))) {
            serverType = new ServerType(ServerType.GeniServerRole.OCCI, 1);
            impl = new OcciToAggregateManagerWrapper(logger, geniUserProvider, connectionProvider, amAuthority);
            return;
        }

        throw new RuntimeException("There is no (supported) Aggregate Manager known for \"" + amAuthority.getName() + "\". amAuthority urn: " + amAuthority.getUrn() +
                "  types of known servers: " + amAuthority.getUrls().keySet());
    }

    protected AggregateManagerWrapper getImpl() {
        if (impl == null)
            choose();
        return impl;
    }

    @Override
    public void getVersion() throws JFedException {
        impl.getVersion();
    }

    @Override
    public String listResources(AnyCredential userCredential, boolean available) throws JFedException {
        return impl.listResources(userCredential, available);
    }

    @Override
    public String createSliver(GeniUrn sliceUrn, AnyCredential sliceCredential, String rspec, List<UserSpec> userUrns, Date expirationDate) throws JFedException {
        return impl.createSliver(sliceUrn, sliceCredential, rspec, userUrns, expirationDate);
    }

    @Override
    public void deleteSliver(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException {
        impl.deleteSliver(sliceUrn, sliceCredential);
    }

    @Override
    public SliverStatus status(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException {
        return impl.status(sliceUrn, sliceCredential);
    }

    @Override
    public String describe(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException {
        return impl.describe(sliceUrn, sliceCredential);
    }

    @Override
    public void renewSliver(GeniUrn sliceUrn, AnyCredential sliceCredential, Date newExpire) throws JFedException {
        impl.renewSliver(sliceUrn, sliceCredential, newExpire);
    }
}
