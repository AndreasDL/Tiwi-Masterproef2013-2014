package be.iminds.ilabt.jfed.lowlevel.api;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.connection.RestSslPasswordConnection;
import be.iminds.ilabt.jfed.util.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.logging.log4j.LogManager;

import javax.net.ssl.SSLException;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * OCCI A limited OCCI client implementation, for use with Bonfire
 *
 * (can always be extended later for full OCCI support)
 */
public class OCCI extends AbstractApi {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    /**
     * A human readable name for the implemented API
     *
     * @return "OCCI (limited)";
     */
    static public String getApiName() {
        return "OCCI (limited)";
    }
    /**
     * A human readable name for the implemented API
     *
     * @return "OCCI (limited)";
     */
    @Override
    public String getName() {
        return getApiName();
    }

    /**
     * @param logger the logger to use. May be null if no logger is used.
     */
    public OCCI(Logger logger) {
        super(logger, new ServerType(ServerType.GeniServerRole.OCCI, 1));
    }

    @Override
    protected boolean isBusyReply(XMLRPCCallDetails res) {
        return false;
    }

    public static class OCCIReply<T> implements ApiCallReply<T> {
        private T value;
        private HttpCallDetails httpCallDetails;
        private int httpCode;
        private String httpCodeDescription;

        public OCCIReply(HttpCallDetails httpCallDetails, T value) {
            this.httpCallDetails = httpCallDetails;
            this.httpCode = httpCallDetails.getResultHttpStatusCode();
            this.httpCodeDescription = httpCallDetails.getResultHttpStatusLine();
            this.value = value;
        }

        @Override
        public GeniResponseCode getGeniResponseCode() {
            return new GeniResponseCode() {
                @Override public boolean isSuccess() { return httpCode >= 200 && httpCode < 300; }
                @Override public boolean isBusy() { return httpCode == 500 && httpCode == 503; } //NOTE: These codes CAN be busy, but are not always!
                @Override public int getCode() { return httpCode; }
                @Override public String getDescription() { return httpCodeDescription; }
            };
        }

        @Override
        public T getValue() {
            return value;
        }

        @Override
        public String getOutput() {
            return null;
        }

        @Override
        public Object getRawResult() {
            return null;
        }

        private boolean busy;
    }





    public OCCIReply<String> internalGet(RestSslPasswordConnection con, String javaName, String relUrl, Map<String, Object> methodParams) throws JFedException {
        LOG.trace("OCCI."+javaName +" params: "+ methodParams);
        assert con != null;

        String url = con.getServerUrl()+relUrl;

        HttpCallDetails reply = executeHttpCall(con, relUrl, HttpVerb.GET, url,
                null/*requestContentType*/, null/*requestContent*/,
                javaName, methodParams);

        OCCIReply<String> res = new OCCIReply<String>(reply, reply.getResultHttpContent());
        logNonSfa(reply, res, javaName, relUrl, con, methodParams, null);
        return res;
    }




    public OCCIReply<String> internalPost(RestSslPasswordConnection con, String javaName, String relUrl,
                                          Map<String, Object> methodParams, ContentType contentType, String content) throws JFedException {
        LOG.trace("OCCI."+javaName +" params: "+ methodParams);
        assert con != null;

        String url = con.getServerUrl()+relUrl;

        HttpCallDetails reply = executeHttpCall(con, relUrl, HttpVerb.POST, url,
                contentType,content,
                javaName, methodParams);

        OCCIReply<String> res = new OCCIReply<String>(reply, reply.getResultHttpContent());
        logNonSfa(reply, res, javaName, relUrl, con, methodParams, null);
        return res;
    }

    public OCCIReply<String> internalPut(RestSslPasswordConnection con, String javaName, String relUrl,
                                         Map<String, Object> methodParams, ContentType contentType, String content) throws JFedException {
        LOG.trace("OCCI."+javaName +" params: "+ methodParams);
        assert con != null;

        String url = con.getServerUrl()+relUrl;

        HttpCallDetails reply = executeHttpCall(con, relUrl, HttpVerb.PUT, url,
                contentType,content,
                javaName, methodParams);

        OCCIReply<String> res = new OCCIReply<String>(reply, reply.getResultHttpContent());
        logNonSfa(reply, res, javaName, relUrl, con, methodParams, null);
        return res;
    }


    public OCCIReply<String> internalDelete(RestSslPasswordConnection con, String javaName, String relUrl,
                                            Map<String, Object> methodParams) throws JFedException {
        LOG.trace("OCCI."+javaName +" params: "+ methodParams);
        assert con != null;

        String url = con.getServerUrl()+relUrl;

        HttpCallDetails reply = executeHttpCall(con, relUrl, HttpVerb.DELETE, url,
                null/*requestContentType*/, null/*requestContent*/,
                javaName, methodParams);

        OCCIReply<String> res = new OCCIReply<String>(reply, reply.getResultHttpContent());
        logNonSfa(reply, res, javaName, relUrl, con, methodParams, null);
        return res;
    }




    @ApiMethod(order=1, hint="GET /experiments")
    public OCCIReply<String> getExperiments(RestSslPasswordConnection con) throws JFedException {
        String javaName = "getExperiments";
        String relUrl = "/experiments";
        Map<String, Object> methodParams = makeMethodParameters();

        return internalGet(con, javaName, relUrl, methodParams);
    }

    @ApiMethod(order=2, hint="GET /experiments/<ID>")
    public OCCIReply<String> getExperiment(RestSslPasswordConnection con,
                                           @ApiMethodParameter(name="experimentId", parameterType=ApiMethodParameterType.STRING, hint="")
                                           String experimentId) throws JFedException {
        String javaName = "getExperiment";
        String relUrl = "/experiments/"+experimentId;
        Map<String, Object> methodParams = makeMethodParameters("experimentId", experimentId);

        return internalGet(con, javaName, relUrl, methodParams);
    }

    @ApiMethod(order=3, hint="POST /experiments")
    public OCCIReply<String> postExperiment(RestSslPasswordConnection con,
                                            @ApiMethodParameter(name="xml", parameterType=ApiMethodParameterType.STRING_MULTILINE, hint="",
                                                    guiDefault = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                                                            "<experiment xmlns=\"http://api.bonfire-project.eu/doc/schemas/occi\">\n" +
                                                            "<name>NAME</name>\n" +
                                                            "<groups>GROUPS</groups>\n" +
                                                            "<description>DESCRIPTION</description>\n" +
                                                            "<walltime>WALLTIME</walltime>\n" +
                                                            "</experiment>")
                                            String xml) throws JFedException {
        String javaName = "postExperiment";
        String relUrl = "/experiments";
        Map<String, Object> methodParams = makeMethodParameters("xml", xml);

        return internalPost(con, javaName, relUrl, methodParams, ContentType.create("application/vnd.bonfire+xml", "UTF-8"), xml);
    }

    @ApiMethod(order=4, hint="POST /experiments")
    public OCCIReply<String> postExperimentWizard(RestSslPasswordConnection con,
                                                  @ApiMethodParameter(name="groups", parameterType=ApiMethodParameterType.STRING, hint="", required=false)
                                                  String groups,
                                                  @ApiMethodParameter(name="name", parameterType=ApiMethodParameterType.STRING, hint="")
                                                  String name,
                                                  @ApiMethodParameter(name="wallTime", parameterType=ApiMethodParameterType.INTEGER, hint="")
                                                  int wallTime,
                                                  @ApiMethodParameter(name="description", parameterType=ApiMethodParameterType.STRING, hint="", required=false)
                                                  String description) throws JFedException {
        String javaName = "postExperiment";
        String relUrl = "/experiments";
        Map<String, Object> methodParams = makeMethodParameters("groups", groups, "name", name, "wallTime", wallTime, "description", description);

        String experimentXmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<experiment xmlns=\"http://api.bonfire-project.eu/doc/schemas/occi\">\n" +
                (groups == null ? "" : "<groups>"+groups+"</groups>")+
                "  <name>"+name+"</name>\n" +
                "  <walltime>"+wallTime+"</walltime>\n" +
                (description == null ? "" : "  <description>"+description+"</description>\n") +
                "</experiment>";

        return internalPost(con, javaName, relUrl, methodParams, ContentType.create("application/vnd.bonfire+xml", "UTF-8"), experimentXmlString);
    }

//    @ApiMethod(order=5, hint="DELETE /experiments/<ID>")
//    public OCCIReply<String> updateExperimentWallTime(RestSslPasswordConnection con,
//                                                      @ApiMethodParameter(name="experimentId", parameterType=ApiMethodParameterType.STRING, hint="")
//                                                      String experimentId,
//                                                      @ApiMethodParameter(name="wallTime", parameterType=ApiMethodParameterType.INTEGER, hint="")
//                                                      int wallTime) throws JFedException {
//        String javaName = "updateExperimentWallTime";
//        String relUrl = "/experiments/"+experimentId;
//        Map<String, Object> methodParams = makeMethodParameters("experimentId", experimentId, "wallTime", wallTime);
//
//        String experimentXmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
//                "<experiment xmlns=\"http://api.bonfire-project.eu/doc/schemas/occi\">\n" +
//                "  <walltime>"+wallTime+"</walltime>\n" +
//                "</experiment>";
//
    //TODO: check how to update wall time

//        return internalPut(con, javaName, relUrl, methodParams, ContentType.create("application/vnd.bonfire+xml", "UTF-8"), experimentXmlString);
//    }


    @ApiMethod(order=5, hint="DELETE /experiments/<ID>")
    public OCCIReply<String> deleteExperiment(RestSslPasswordConnection con,
                                              @ApiMethodParameter(name="experimentId", parameterType=ApiMethodParameterType.STRING, hint="")
                                              String experimentId) throws JFedException {
        String javaName = "deleteExperiment";
        String relUrl = "/experiments/"+experimentId;
        Map<String, Object> methodParams = makeMethodParameters("experimentId", experimentId);

        return internalDelete(con, javaName, relUrl, methodParams);
    }


    @ApiMethod(order=10, hint="GET /experiments/<ID>/computes")
    public OCCIReply<String> getExperimentComputes(RestSslPasswordConnection con,
                                                   @ApiMethodParameter(name="experimentId", parameterType=ApiMethodParameterType.STRING, hint="")
                                                   String experimentId) throws JFedException {
        String javaName = "getExperimentComputes";
        String relUrl = "/experiments/"+experimentId+"/computes";
        Map<String, Object> methodParams = makeMethodParameters("experimentId", experimentId);

        return internalGet(con, javaName, relUrl, methodParams);
    }

    @ApiMethod(order=12, hint="POST /experiments/<ID>/computes")
    public OCCIReply<String> postExperimentCompute(RestSslPasswordConnection con,
                                                   @ApiMethodParameter(name="experimentId", parameterType=ApiMethodParameterType.STRING, hint="")
                                                   String experimentId,
                                                   @ApiMethodParameter(name="xml", parameterType=ApiMethodParameterType.STRING_MULTILINE,
                                                           guiDefault = "<compute xmlns=\"http://api.bonfire-project.eu/doc/schemas/occi\">\n" +
                                                                   "<name>NAME</name>\n" +
                                                                   "<groups>GROUPS</groups>\n" +
                                                                   "<instance_type>lite</instance_type>\n" +
                                                                   "<disk>\n" +
                                                                   "<storage href=\"/locations/LOCATION/storages/STORAGEID\"/>\n" +
                                                                   "<type>OS</type>\n" +
                                                                   "<target>hda</target>\n" +
                                                                   "</disk>\n" +
                                                                   "<nic>\n" +
                                                                   "<network href=\"/locations/LOCATION/networks/NETWORKID\"/>\n" +
                                                                   "</nic>\n" +
                                                                   "<link href=\"/locations/LOCATION\" rel=\"location\"/>\n" +
                                                                   "</compute>", hint="")
                                                   String xml) throws JFedException {
        String javaName = "postExperimentCompute";
        String relUrl = "/experiments/"+experimentId+"/computes";
        Map<String, Object> methodParams = makeMethodParameters("experimentId", experimentId,"xml", xml);

        return internalPost(con, javaName, relUrl, methodParams, ContentType.create("application/vnd.bonfire+xml", "UTF-8"), xml);
    }

    @ApiMethod(order=13, hint="POST /experiments/<ID>/computes")
    public OCCIReply<String> postExperimentComputeWizard(RestSslPasswordConnection con,
                                                         @ApiMethodParameter(name="experimentId", parameterType=ApiMethodParameterType.STRING, hint="")
                                                         String experimentId,
                                                         @ApiMethodParameter(name="computeName", parameterType=ApiMethodParameterType.STRING, hint="")
                                                         String computeName,
                                                         @ApiMethodParameter(name="groups", required=false, parameterType=ApiMethodParameterType.STRING, hint="")
                                                         String groups,
                                                         @ApiMethodParameter(name="locationName", parameterType=ApiMethodParameterType.STRING, hint="")
                                                         String locationName,
                                                         @ApiMethodParameter(name="instanceType", parameterType=ApiMethodParameterType.STRING, guiDefault = "lite", hint="")
                                                         String instanceType,
                                                         @ApiMethodParameter(name="networkId", parameterType=ApiMethodParameterType.STRING, hint="")
                                                         String networkId,
                                                         @ApiMethodParameter(name="storageId", parameterType=ApiMethodParameterType.STRING, hint="")
                                                         String storageId) throws JFedException {
        List<String> networkIds = new ArrayList<String>();
        if (networkId != null) networkIds.add(networkId);

        List<String> storageIds = new ArrayList<String>();
        if (storageId != null) storageIds.add(storageId);

        return postExperimentComputeWizard(con, experimentId, computeName, groups, locationName, instanceType, networkIds, storageIds);
    }
    @ApiMethod(order=14, hint="POST /experiments/<ID>/computes")
    public OCCIReply<String> postExperimentComputeWizard(RestSslPasswordConnection con,
                                                         @ApiMethodParameter(name="experimentId", parameterType=ApiMethodParameterType.STRING, hint="")
                                                         String experimentId,
                                                         @ApiMethodParameter(name="computeName", parameterType=ApiMethodParameterType.STRING, hint="")
                                                         String computeName,
                                                         @ApiMethodParameter(name="groups", required=false, parameterType=ApiMethodParameterType.STRING, hint="")
                                                         String groups,
                                                         @ApiMethodParameter(name="locationName", parameterType=ApiMethodParameterType.STRING, hint="")
                                                         String locationName,
                                                         @ApiMethodParameter(name="instanceType", parameterType=ApiMethodParameterType.STRING, guiDefault = "lite", hint="")
                                                         String instanceType,
                                                         @ApiMethodParameter(name="networkIds", parameterType=ApiMethodParameterType.LIST_OF_STRING, hint="")
                                                         List<String> networkIds,
                                                         @ApiMethodParameter(name="storageIds", parameterType=ApiMethodParameterType.LIST_OF_STRING, hint="")
                                                         List<String> storageIds) throws JFedException {
        String javaName = "postExperimentComputeWizard";
        String relUrl = "/experiments/"+experimentId+"/computes";
        Map<String, Object> methodParams = makeMethodParameters("experimentId", experimentId,
                "computeName", computeName,
                "groups", groups,
                "locationName", locationName,
                "instanceType", instanceType,
                "networkIds", networkIds,
                "storageIds", storageIds);

        String networkIdsString = "";
        String storageIdsString = "";
        int nicId = 0;
        for (String networkId : networkIds) {
            networkIdsString += "  <nic id=\""+(nicId++)+"\">\n" +
                    "    <network href=\"https://api.bonfire-project.eu/locations/"+locationName+"/networks/"+networkId+"\"/>\n" +
                    "  </nic>\n";
        }
        int diskId = 0;
        for (String storageId : storageIds) {
            storageIdsString += "  <disk id=\""+(diskId++)+"\">\n" +
                    "    <type>OS</type>\n" +
                    "    <storage href=\"https://api.bonfire-project.eu/locations/"+locationName+"/storages/"+storageId+"\"/>\n" +
                    "  </disk>\n";
        }

        String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<compute xmlns=\"http://api.bonfire-project.eu/doc/schemas/occi\">\n" +
                "  <name>"+computeName+"</name>\n" +
                (groups == null ? "" : "  <groups>"+groups+"</groups>\n") +
                "  <location href=\"https://api.bonfire-project.eu/locations/"+locationName+"\"/>\n" +
                "  <instance_type>"+instanceType+"</instance_type>\n" +
                networkIdsString+
                storageIdsString+
                "</compute>\n";

        return internalPost(con, javaName, relUrl, methodParams, ContentType.create("application/vnd.bonfire+xml", "UTF-8"), xmlString);
    }

    @ApiMethod(order=20, hint="GET /locations")
    public OCCIReply<String> getLocations(RestSslPasswordConnection con) throws JFedException {
        String javaName = "getLocations";
        String relUrl = "/locations";
        Map<String, Object> methodParams = makeMethodParameters();

        return internalGet(con, javaName, relUrl, methodParams);
    }

    @ApiMethod(order=21, hint="GET /locations/<ID>")
    public OCCIReply<String> getLocation(RestSslPasswordConnection con,
                                         @ApiMethodParameter(name="locationId", parameterType=ApiMethodParameterType.STRING, hint="")
                                         String locationName) throws JFedException {
        String javaName = "getLocation";
        String relUrl = "/locations/"+locationName;
        Map<String, Object> methodParams = makeMethodParameters("locationName", locationName);

        return internalGet(con, javaName, relUrl, methodParams);
    }

    @ApiMethod(order=30, hint="GET /locations/<ID>/storages")
    public OCCIReply<String> getLocationStorages(RestSslPasswordConnection con,
                                                 @ApiMethodParameter(name="locationName", parameterType=ApiMethodParameterType.STRING, hint="")
                                                 String locationName) throws JFedException {
        String javaName = "getLocationStorages";
        String relUrl = "/locations/"+locationName+"/storages";
        Map<String, Object> methodParams = makeMethodParameters("locationName", locationName);

        return internalGet(con, javaName, relUrl, methodParams);
    }

    @ApiMethod(order=31, hint="GET /locations/<ID>/storages/<ID>")
    public OCCIReply<String> getLocationStorage(RestSslPasswordConnection con,
                                                @ApiMethodParameter(name="locationName", parameterType=ApiMethodParameterType.STRING, hint="")
                                                String locationName,
                                                @ApiMethodParameter(name="storageId", parameterType=ApiMethodParameterType.STRING, hint="")
                                                String storageId) throws JFedException {
        String javaName = "getLocationStorage";
        String relUrl = "/locations/"+locationName+"/storages/"+storageId;
        Map<String, Object> methodParams = makeMethodParameters("locationName", locationName, "storageId", storageId);

        return internalGet(con, javaName, relUrl, methodParams);
    }

    @ApiMethod(order=40, hint="GET /locations/<ID>/networks")
    public OCCIReply<String> getLocationNetworks(RestSslPasswordConnection con,
                                                 @ApiMethodParameter(name="locationName", parameterType=ApiMethodParameterType.STRING, hint="")
                                                 String locationName) throws JFedException {
        String javaName = "getLocationNetworks";
        String relUrl = "/locations/"+locationName+"/networks";
        Map<String, Object> methodParams = makeMethodParameters("locationName", locationName);

        return internalGet(con, javaName, relUrl, methodParams);
    }

    @ApiMethod(order=41, hint="GET /locations/<ID>/networks/<ID>")
    public OCCIReply<String> getLocationNetwork(RestSslPasswordConnection con,
                                                @ApiMethodParameter(name="locationName", parameterType=ApiMethodParameterType.STRING, hint="")
                                                String locationName,
                                                @ApiMethodParameter(name="networkId", parameterType=ApiMethodParameterType.STRING, hint="")
                                                String networkId) throws JFedException {
        String javaName = "getLocationNetworks";
        String relUrl = "/locations/"+locationName+"/networks/"+networkId;
        Map<String, Object> methodParams = makeMethodParameters("locationName", locationName, "networkId", networkId);

        return internalGet(con, javaName, relUrl, methodParams);
    }

    @ApiMethod(order=50, hint="GET /locations/<ID>/computes/<ID>")
    public OCCIReply<String> getLocationCompute(RestSslPasswordConnection con,
                                                @ApiMethodParameter(name="locationName", parameterType=ApiMethodParameterType.STRING, hint="")
                                                String locationName,
                                                @ApiMethodParameter(name="computeId", parameterType=ApiMethodParameterType.STRING, hint="")
                                                String computeId) throws JFedException {
        String javaName = "getLocationCompute";
        String relUrl = "/locations/"+locationName+"/computes/"+computeId;
        Map<String, Object> methodParams = makeMethodParameters("locationName", locationName, "computeId", computeId);

        return internalGet(con, javaName, relUrl, methodParams);
    }

    @ApiMethod(order=51, hint="DELETE /locations/<ID>/computes/<ID>")
    public OCCIReply<String> deleteLocationCompute(RestSslPasswordConnection con,
                                                   @ApiMethodParameter(name="locationName", parameterType=ApiMethodParameterType.STRING, hint="")
                                                   String locationName,
                                                   @ApiMethodParameter(name="computeId", parameterType=ApiMethodParameterType.STRING, hint="")
                                                   String computeId) throws JFedException {
        String javaName = "deleteLocationCompute";
        String relUrl = "/locations/"+locationName+"/computes/"+computeId;
        Map<String, Object> methodParams = makeMethodParameters("locationName", locationName, "computeId", computeId);

        return internalDelete(con, javaName, relUrl, methodParams);
    }
}
