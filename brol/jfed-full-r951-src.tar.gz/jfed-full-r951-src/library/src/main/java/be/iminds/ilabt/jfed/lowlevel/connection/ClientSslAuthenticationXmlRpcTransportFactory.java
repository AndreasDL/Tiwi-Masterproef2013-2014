package be.iminds.ilabt.jfed.lowlevel.connection;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import org.apache.logging.log4j.LogManager;

import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;


/**
 * This XmlRpcTransportFactory will read a PEM certificate with a client key and certificate,
 * add the needed trust certificates, and setup an SSL connection. This SSL connection will be used to for the XmlRpc
 * calls.
 */
public class ClientSslAuthenticationXmlRpcTransportFactory extends CommonsHttpClientXmlRpcTransportFactory {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    /**
     * @param proxyInfo
     * @param clientCertificateChain chain of X509Certificates to use for the SSL connection
     * @param privateKey PrivateKey to use for client authentication of the SSL connection
     * @param serverUrl URL of server to connect to
     * @param trustStore The trustStore with trusted roots and trusted self signed certificates, that will be used for the SSL connection
     */
    public ClientSslAuthenticationXmlRpcTransportFactory(JFedConnection.ProxyInfo proxyInfo,
                                                         List<X509Certificate> clientCertificateChain,
                                                         PrivateKey privateKey,
                                                         String serverUrl,
                                                         KeyStore trustStore,
                                                         List<String> allowedCertificateHostnameAliases,
                                                         boolean debugMode, HttpsClientWithUserAuthenticationFactory.HandleUntrustedCallback handleUntrustedCallback) throws JFedException {
        super(serverUrl, HttpsClientWithUserAuthenticationFactory.getHttpClient(proxyInfo, clientCertificateChain, privateKey, serverUrl,
                trustStore, allowedCertificateHostnameAliases, debugMode, handleUntrustedCallback), debugMode);
    }
}
