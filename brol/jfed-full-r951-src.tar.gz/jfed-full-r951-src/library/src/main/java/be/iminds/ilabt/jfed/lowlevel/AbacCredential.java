package be.iminds.ilabt.jfed.lowlevel;

import java.util.Date;
import java.util.Hashtable;

public class AbacCredential extends AnyCredential {
    protected String name;
    protected String credentialXml;

    protected String type;
    protected String version;

    protected AbacCredential(String name, String credentialXml, String type, String version) {
        super(name, credentialXml, type, version);

        this.name = name;
        this.credentialXml = credentialXml;
        this.type = type;
        this.version = version;

        assert type.equalsIgnoreCase("abac") || type.equalsIgnoreCase("geni_abac") : "Created SfaCredential not of type sfa, but of type=\""+type+"\" version=\""+version+"\"";

        if (credentialXml == null) throw new RuntimeException("AbacCredential credentialXml may not be null");
    }

    //TODO
    @Override
    public String getExpires() { return null; }
    @Override
    public Date getExpiresDate() { return null; }

    public String getCredentialXml() {
        assert credentialXml != null;
        return credentialXml;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AbacCredential that = (AbacCredential) o;

        if (!credentialXml.equals(that.credentialXml)) return false;
        if (!name.equals(that.name)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = name.hashCode();
        result = 31 * result + credentialXml.hashCode();
        return result;
    }
}
