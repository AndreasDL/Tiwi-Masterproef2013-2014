package be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api.ProtogeniSliceAuthority;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.UserAndSliceApiWrapper;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.RFC3339Util;
import org.apache.logging.log4j.LogManager;

import java.util.*;

/**
 * ProtoGeniSAUserAndSliceApiWrapper
 */
public class ProtoGeniSAUserAndSliceApiWrapper extends UserAndSliceApiWrapper {
    private final static org.apache.logging.log4j.Logger LOG = LogManager.getLogger();
    private final ProtogeniSliceAuthority sa;

    public ProtoGeniSAUserAndSliceApiWrapper(Logger logger, GeniUserProvider geniUserProvider, GeniConnectionProvider connectionProvider) {
        super(logger, geniUserProvider, connectionProvider);
        this.sa = new ProtogeniSliceAuthority(logger, true);
    }

    @Override
    public AnyCredential getUserCredentials(GeniUrn userUrn) throws JFedException {
        ProtogeniSliceAuthority.SliceAuthorityReply<AnyCredential> reply =
                sa.getCredential((SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1)));

        if (!reply.getGeniResponseCode().isSuccess())
            throw new JFedException("Could not retrieve user credential from server: code="+
                    reply.getGeniResponseCode()+" output="+reply.getOutput(),
                    reply.getXmlRpcCallDetailsGeni(), reply.getGeniResponseCode());

        return reply.getValue();
    }

    @Override
    public AnyCredential getSliceCredentials(AnyCredential userCredential, GeniUrn sliceUrn) throws JFedException {
        ProtogeniSliceAuthority.SliceAuthorityReply<AnyCredential> reply =
                sa.getSliceCredential((SfaConnection)
                        getConnection(new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1)),
                        userCredential,
                        sliceUrn);

        if (!reply.getGeniResponseCode().isSuccess())
            throw new JFedException("Could not retrieve slice credential from server: code="+
                    reply.getGeniResponseCode()+" output="+reply.getOutput(),
                    reply.getXmlRpcCallDetailsGeni(), reply.getGeniResponseCode());

        return reply.getValue();
    }

    @Override
    public List<GeniUrn> getSlicesForUser(AnyCredential userCredential, GeniUrn user) throws JFedException {
        List<GeniUrn> res = new ArrayList<GeniUrn>();
        ProtogeniSliceAuthority.SliceAuthorityReply<Hashtable> reply =
                sa.resolveUser(
                        (SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1)),
                        userCredential,
                        user);

        if (reply == null || reply.getGeniResponseCode() == null || !reply.getGeniResponseCode().isSuccess() || reply.getValue() == null)
            return res;
        Hashtable userInfo = reply.getValue();
        Vector slicesVect = (Vector) userInfo.get("slices");
        for (int i = 0; i < slicesVect.size(); i++) {
            String s = slicesVect.get(i).toString();
            try {
                res.add(new GeniUrn(s));
            } catch (GeniUrn.GeniUrnParseException e) {
                System.err.println("error in reply: Not a slice urn: \"" + s + "\"   (see ProtoGeniSAUserAndSliceApiWrapper getSlicesForUser)");
                //ignore
            }
        }

        return res;
    }

    @Override
    public void getAggregatesForSlice(AnyCredential userCredential, AnyCredential sliceCredential, GeniUrn sliceUrn) throws JFedException {
        sa.resolveSlice((SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1)), userCredential, sliceUrn);
    }

    @Override
    public SliceInfo createSlice(AnyCredential userCredential, String sliceName, Date expirationDate) throws JFedException {
        assert userCredential != null;
        assert sliceName != null;

        GeniUrn sliceUrn = new GeniUrn(getUserAuthority().getNameForUrn(), "slice", sliceName);

        ProtogeniSliceAuthority.SliceAuthorityReply<AnyCredential> reply =
                sa.register(
                        (SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1)),
                        userCredential,
                        sliceUrn);

        if (!reply.getGeniResponseCode().isSuccess())
            throw new JFedException("Could not create slice on server: code="+
                    reply.getGeniResponseCode()+" output="+reply.getOutput(),
                    reply.getXmlRpcCallDetailsGeni(), reply.getGeniResponseCode());

        AnyCredential sliceCredential = reply.getValue();
        boolean mustRenew = expirationDate != null;
        if (expirationDate != null && sliceCredential instanceof SfaCredential) {
            SfaCredential sfaSfaCredential = (SfaCredential) sliceCredential;
            if (sfaSfaCredential.getExpiresDate() != null && sfaSfaCredential.getExpiresDate().before(expirationDate))
                mustRenew = true;
            else
                mustRenew = false;
        }

        if (mustRenew) {
            try {
                ProtogeniSliceAuthority.SliceAuthorityReply<AnyCredential> replyRenew =
                        sa.renewSlice(
                                (SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1)),
                                sliceCredential,
                                RFC3339Util.dateToRFC3339String(expirationDate, true, true, true));

                if (replyRenew.getGeniResponseCode().isSuccess()) {
                    sliceCredential = replyRenew.getValue(); //credential for new expire time
                } else {
                    LOG.warn("Renew call to set expiration of new Slice date failed. Ignoring. Output: "+replyRenew.getOutput());
                }
            } catch (JFedException e) {
                LOG.error("Ignoring exception when renewing: "+e.getMessage(), e);
            }
        }

        return new SliceInfo(sliceName, sliceUrn, sliceCredential);
    }

    @Override
    public AnyCredential renewSlice(AnyCredential sliceCredential, Date newExpirationDate) throws JFedException {
        ProtogeniSliceAuthority.SliceAuthorityReply<AnyCredential> reply =
                sa.renewSlice((SfaConnection)getConnection(new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1)),
                        sliceCredential,
                        RFC3339Util.dateToRFC3339String(newExpirationDate, true, true, true));
        if(!reply.getGeniResponseCode().isSuccess())
            throw new JFedException("Could not renew slice on server: code="+
                    reply.getGeniResponseCode() + " output=" + reply.getOutput(),
                    reply.getXmlRpcCallDetailsGeni(), reply.getGeniResponseCode());

        return reply.getValue();
    }

    @Override
    public void getSshKeysForUser(AnyCredential userCredential, GeniUrn userUrn) throws JFedException {
        sa.getKeys((SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1)), userCredential);
    }
}
