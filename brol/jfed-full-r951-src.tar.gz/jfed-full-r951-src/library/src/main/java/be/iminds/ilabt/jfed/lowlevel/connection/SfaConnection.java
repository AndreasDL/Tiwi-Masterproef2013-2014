package be.iminds.ilabt.jfed.lowlevel.connection;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.CommonsHttpClientXmlRpcTransportFactory;
import org.apache.xmlrpc.XmlRpcClient;

/**
 * SfaConnection: and XmlRpc connection over Https with user authentication, or over http
 */
public abstract class SfaConnection extends JFedConnection {
    public SfaConnection(SfaAuthority geniAuthority, String serverUrl, ProxyInfo proxyInfo, boolean debugMode) throws JFedException {
        super(geniAuthority, serverUrl, proxyInfo, debugMode);
    }

    public abstract CommonsHttpClientXmlRpcTransportFactory getXmlRpcTransportFactory();
    public abstract XmlRpcClient getXmlRpcClient();
}
