package be.iminds.ilabt.jfed.util;

import ch.ethz.ssh2.*;
import ch.ethz.ssh2.Connection;
import org.apache.logging.log4j.LogManager;

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Properties;

public class GanymedSshSocketImplFactory implements SocketImplFactory {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    Connection sshConnection;

    public synchronized static GanymedSshSocketImplFactory getFactory(SshServerProxyHelper.SshProxyInfo sshProxyInfo) throws IOException {
        return new GanymedSshSocketImplFactory(sshProxyInfo);
    }

    private GanymedSshSocketImplFactory(final SshServerProxyHelper.SshProxyInfo sshProxyInfo) throws IOException {
        sshConnection = new Connection(sshProxyInfo.getHostName(), sshProxyInfo.getPort());

        ServerHostKeyVerifier serverHostKeyVerifier = sshProxyInfo.getServerHostKey() == null ? null : new ServerHostKeyVerifier() {
            @Override
            public boolean verifyServerHostKey(String hostName, int port, String hostKeyAlgo, byte[] hostKey) throws Exception {
                //we will ignore hostname, as we don't know if an IP or full name is used. (we could check but it's not that important)
//                if (!sshProxyInfo.getHostName().equals(hostName))
//                    return false;
                LOG.debug("Checking key for host "+hostName);
                if (sshProxyInfo.getPort() != port)
                    return false;
                if (!sshProxyInfo.getServerHostKeyAlgo().equals(hostKeyAlgo))
                    return false;
                if (sshProxyInfo.getServerHostKey().length != hostKey.length)
                    return false;
                for (int i = 0; i < hostKey.length; i++) {
                    if (sshProxyInfo.getServerHostKey()[i] != hostKey[i])
                        return false;
                }
                LOG.debug("   Key known");
                return true;
            }
        };

        //timeouts in milliseconds. Zero means no timeout.
        int connectTimeout_ms = 1000; //TCP connection setup
        int kexTimeout_ms = 5000;     //full SSH connection setup

        sshConnection.connect(serverHostKeyVerifier/*ServerHostKeyVerifier = null means don't check host keys*/,  connectTimeout_ms, kexTimeout_ms);

        boolean isAuthenticated = sshConnection.authenticateWithPublicKey(sshProxyInfo.getSshUsername(), sshProxyInfo.getPemPrivateKeyChars(), null/*pass*/);

        if (!isAuthenticated) {
            throw new IOException("Could not authenticate");
        }
    }

    public SocketImpl createSocketImpl() {
        return new SSHSocketImpl(sshConnection);

    }


    /**
     * We aren't going to actually create any new connection, we will forward
     * things to SSH.
     */
    private static class SSHSocketImpl extends SocketImpl {
        Connection sshConnection;

        LocalStreamForwarder localStreamForwarder;

        InputStream is;

        OutputStream os;

        SSHSocketImpl(Connection sshConnection) {
            this.sshConnection = sshConnection;
        }

        @Override
        protected void accept(SocketImpl s) throws IOException {
            throw new IOException("SSHSocketImpl does not implement accept");
        }

        @Override
        protected int available() throws IOException {
            if (is == null) {
                throw new ConnectException("Not connected");
            }
            return is.available();
        }

        @Override
        protected void bind(InetAddress host, int port) throws IOException {
            if ((host != null && !host.isAnyLocalAddress()) || port != 0) {
                throw new IOException("SSHSocketImpl does not implement bind");
            }
        }

        @Override
        protected void close() throws IOException {
            if (localStreamForwarder != null) {
                localStreamForwarder.close();
                is = null;
                os = null;
            }
        }

        @Override
        protected void connect(String host, int port) throws IOException {
            InetAddress addr = InetAddress.getByName(host);
            connect(addr, port);
        }

        @Override
        protected void connect(InetAddress address, int port) throws IOException {
            connect(new InetSocketAddress(address, port), 300000);
        }

        @Override
        protected void connect(SocketAddress address, int timeout)
                throws IOException {
            localStreamForwarder = sshConnection.createLocalStreamForwarder((
                    (InetSocketAddress) address).getHostName(),
                    ((InetSocketAddress) address).getPort()
            );

            is = localStreamForwarder.getInputStream();
            os = localStreamForwarder.getOutputStream();
        }

        @Override
        protected void create(boolean stream) throws IOException {
            if (stream == false) {
                throw new IOException("Cannot handle UDP streams");
            }
        }

        @Override
        protected InputStream getInputStream() throws IOException {
            return is;
        }

        @Override
        protected OutputStream getOutputStream() throws IOException {
            return os;
        }

        @Override
        protected void listen(int backlog) throws IOException {
            throw new IOException("SSHSocketImpl does not implement listen");
        }

        @Override
        protected void sendUrgentData(int data) throws IOException {
            throw new IOException("SSHSocketImpl does not implement sendUrgentData");
        }

        public Object getOption(int optID) throws SocketException {
            //fake answer to some common option requests if possible.
            if (optID == SocketOptions.TCP_NODELAY) return new Boolean(false);
            if (optID == SocketOptions.SO_BINDADDR) throw new SocketException("SSHSocketImpl does not implement getOption for SO_BINDADDR");
            if (optID == SocketOptions.SO_REUSEADDR) return new Boolean(false);
            if (optID == SocketOptions.SO_BROADCAST) return new Boolean(false);
            if (optID == SocketOptions.IP_MULTICAST_IF) throw new SocketException("SSHSocketImpl does not implement getOption for IP_MULTICAST_IF");
            if (optID == SocketOptions.IP_MULTICAST_IF2) throw new SocketException("SSHSocketImpl does not implement getOption for IP_MULTICAST_IF2");
            if (optID == SocketOptions.IP_MULTICAST_LOOP) throw new SocketException("SSHSocketImpl does not implement getOption for IP_MULTICAST_LOOP");
            if (optID == SocketOptions.IP_TOS)  throw new SocketException("SSHSocketImpl does not implement getOption for IP_TOS");
            if (optID == SocketOptions.SO_LINGER) return new Integer(0); //no linger
            if (optID == SocketOptions.SO_TIMEOUT) return new Integer(0); //?
            if (optID == SocketOptions.SO_SNDBUF) throw new SocketException("SSHSocketImpl does not implement getOption for SO_SNDBUF"); //actual send buffer size
            if (optID == SocketOptions.SO_RCVBUF) throw new SocketException("SSHSocketImpl does not implement getOption for SO_RCVBUF");; //actual recv buffer size
            if (optID == SocketOptions.SO_KEEPALIVE) return new Boolean(false);
            if (optID == SocketOptions.SO_OOBINLINE) return new Boolean(false);

            throw new SocketException("SSHSocketImpl does not implement getOption for "+optID);
        }

        /**
         * We silently ignore setOptions because they do happen, but there is
         * nothing that we can do about it.
         */
        public void setOption(int optID, Object value) throws SocketException {
        }

    }

}
