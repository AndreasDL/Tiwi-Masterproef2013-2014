package be.iminds.ilabt.jfed.util;

import java.util.List;

/**
 * ExtraInfoCallback: This class is used whenever some function needs extra info.
 * It is a bit aof a HACK, which keeps separation between experimenter GUI (and other GUIS) and core library,
 * but does enable user feedback
 *
 * Supported feedback hacks:
 *   - bonfire username and password
 *   - federation API SA project to use
 */
public class ExtraInfoCallback {
    public static class Login {
        private String username;
        private String password;

        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }

        public Login(String username, String password) {
            this.username = username;
            this.password = password;
        }
    }
    public static interface BonfireLoginCallback {
        /** return null if user has no bonfire account. */
        public Login getBonfireLogin();
        public String getBonfireGroups();
    }
    public static interface FederationApiProjectSelectionCallback {
        public GeniUrn selectProject(List<GeniUrn> projectUrns);
    }

    private static BonfireLoginCallback bonfireLoginCallback;
    private static FederationApiProjectSelectionCallback federationApiProjectSelectionCallback;

    public static Login getBonfireLogin() {
        return bonfireLoginCallback.getBonfireLogin();
    }
    public static String getBonfireGroups() {
        return bonfireLoginCallback.getBonfireGroups();
    }
    public static GeniUrn getFederationApiProjectSelection(List<GeniUrn> projectUrns) {
        return federationApiProjectSelectionCallback.selectProject(projectUrns);
    }

    public static BonfireLoginCallback getBonfireLoginCallback() {
        return bonfireLoginCallback;
    }
    public static FederationApiProjectSelectionCallback getFederationApiProjectSelectionCallback() {
        return federationApiProjectSelectionCallback;
    }

    public static void setBonfireLoginCallback(BonfireLoginCallback bonfireLoginCallback) {
        ExtraInfoCallback.bonfireLoginCallback = bonfireLoginCallback;
    }
    public static void setFederationApiProjectSelectionCallback(FederationApiProjectSelectionCallback federationApiProjectSelectionCallback) {
        ExtraInfoCallback.federationApiProjectSelectionCallback = federationApiProjectSelectionCallback;
    }
}
