package be.iminds.ilabt.jfed.lowlevel.api;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;

import java.lang.reflect.Method;
import java.util.*;

/**
 * AbstractGeniClearingHouseApi
 */
public abstract class AbstractFederationApi1 extends AbstractFederationApi {
    private static org.apache.logging.log4j.Logger l4jLogger = LogManager.getLogger();

    public AbstractFederationApi1(Logger logger, boolean autoRetryBusy, ServerType serverType) {
        super(logger, autoRetryBusy, serverType);
    }

    public abstract String getMethodObject(Method method);

    public FederationApiReply<LookupResult> genericLookupCall(Map<String, Object> methodParams,
                                                              SfaConnection con,
                                                              String methodJavaName,
                                                              String methodGeniName,
                                                              List<AnyCredential> credentialList,
                                                              Map<String, ? extends Object> match,
                                                              List<String> filter,
                                                              Map<String, Object> extraOptions,
                                                              Vector extraArguments /* extraArguments are added in front of call*/)  throws JFedException {
        assert methodJavaName != null;
        assert methodGeniName != null;

        Vector args = new Vector();
        if (extraArguments != null)
            for (Object extraArgument : extraArguments)
                args.add(extraArgument);

        if (credentialList != null) {
            Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
            args.add(credentials);
        }

        Hashtable options = new Hashtable();
        if (match != null)
            options.put("match", new Hashtable<String, Object>(match));
        if (filter != null/* && !filter.isEmpty()*/)
            options.put("filter", new Vector<String>(filter));
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, methodGeniName, args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<LookupResult> r = null;
        try {
            LookupResult resLookupResult = new LookupResult(resultValueObject, null);
            r = new FederationApiReply<LookupResult>(res, resLookupResult);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, methodJavaName, methodGeniName, con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<LookupResult>(res, null);
        log(res, r, methodJavaName, methodGeniName, con, methodParams);
        return r;
    }


    /** normally returns nothing at all. Anything that might be returned anyway is converted to string, but normally a null Object will be returned. */
    public FederationApiReply<String> genericUpdateCall(Map<String, Object> methodParams,
                                                        SfaConnection con,
                                                        String methodJavaName,
                                                        String methodGeniName,
                                                        List<AnyCredential> credentialList,
                                                        String urn,
                                                        String urnType,
                                                        Map<String, String> fields,
                                                        Map<String, Object> extraOptions)  throws JFedException {
        return genericUpdateCall(methodParams, con, methodJavaName, methodGeniName, credentialList, urn, urnType, fields, extraOptions, null);
    }
    public FederationApiReply<String> genericUpdateCall(Map<String, Object> methodParams,
                                                        SfaConnection con,
                                                        String methodJavaName,
                                                        String methodGeniName,
                                                        List<AnyCredential> credentialList,
                                                        String urn,
                                                        String urnType,
                                                        Map<String, String> fields,
                                                        Map<String, Object> extraOptions,
                                                        Vector extraArguments /* extraArguments are added in front of call*/)  throws JFedException {
        assert methodJavaName != null;
        assert methodGeniName != null;
        assert credentialList != null;
        assert urn != null;
        assert fields != null;
        assert !fields.isEmpty();

        GeniUrn geniUrn = GeniUrn.parse(urn);
        if (geniUrn == null || (urnType != null && !geniUrn.getResourceType().equals(urnType)))
            System.err.println("WARNING: URN argument to "+methodJavaName+" is not a valid "+(urnType == null ? "" : urnType)+" urn: \""+urn+"\" (will be used anyway)");

        Vector args = new Vector();
        if (extraArguments != null)
            for (Object extraArgument : extraArguments)
                args.add(extraArgument);

        args.add(urn);

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable options = new Hashtable();
        options.put("fields", new Hashtable<String, String>(fields));
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, methodGeniName, args, methodParams);
        FederationApiReply<String> r = null;
        try {
            //normally returns nothing at all. Anything that might be returned anyway is converted to string
            Object resultValueObject = res.getResultValueObject();
            String nothing = resultValueObject == null ? null : resultValueObject.toString();
            if (nothing != null && nothing.isEmpty())
                nothing = null;
            r = new FederationApiReply<String>(res, nothing);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, methodJavaName, methodGeniName, con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<String>(res, null);
        log(res, r, methodJavaName, methodGeniName, con, methodParams);
        return r;
    }
}
