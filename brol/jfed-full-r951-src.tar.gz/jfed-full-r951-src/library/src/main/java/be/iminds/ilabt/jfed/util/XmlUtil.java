package be.iminds.ilabt.jfed.util;

import org.apache.logging.log4j.LogManager;
import org.apache.xml.security.Init;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.ElementProxy;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.KeyValue;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.security.InvalidAlgorithmParameterException;
import java.security.Key;
import java.security.KeyException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * XmlUtils
 */
public class XmlUtil {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    /* This new version uses only JDK classes, no apache xerces. Depends on java 1.6. */
    public static String formatXmlFromString(String unformattedXmlString) {
        try {
            final Document document = parseXmlFromString(unformattedXmlString);

            DOMImplementationRegistry registry = DOMImplementationRegistry.newInstance();
            DOMImplementationLS impl = (DOMImplementationLS)registry.getDOMImplementation("LS");
            LSSerializer writer = impl.createLSSerializer();
            writer.getDomConfig().setParameter("format-pretty-print", Boolean.TRUE);
            writer.getDomConfig().setParameter("xml-declaration", false); // true -> the xml declaration is added

            return writer.writeToString(document);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
    /* throws no errors, returns original string if something goes wrong */
    public static String formatXmlFromString_alwaysSafe(String unformattedXmlString) {
        try {
            final Document document = parseXmlFromString(unformattedXmlString);

            DOMImplementationRegistry registry = DOMImplementationRegistry.newInstance();
            DOMImplementationLS impl = (DOMImplementationLS)registry.getDOMImplementation("LS");
            LSSerializer writer = impl.createLSSerializer();
            writer.getDomConfig().setParameter("format-pretty-print", Boolean.TRUE);
            writer.getDomConfig().setParameter("xml-declaration", false); // true -> the xml declaration is added

            return writer.writeToString(document);
        } catch (Exception e) {
            return unformattedXmlString;
        }
    }
    /* throws no errors, returns original string if something goes wrong */
    public static String elementToXmlString(Element el) {
        try {
            TransformerFactory transFactory = TransformerFactory.newInstance();
            Transformer transformer = transFactory.newTransformer();
            StringWriter buffer = new StringWriter();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.transform(new DOMSource(el), new StreamResult(buffer));
            return buffer.toString();
        }  catch (TransformerConfigurationException e) {
            logger.error("TransformerConfigurationException in getCurrentRequestRspec()", e);
        } catch (TransformerException e) {
            logger.error("TransformerException in getCurrentRequestRspec()", e);
        }
        return "error converting DOM element to Xml";
    }

    public static Document parseXmlFromString(String in) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(in));
            return db.parse(is);
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }



    public static String signXml(Document doc, String elementToSignId,
                                 String elementToAddSignatureToName, X509Certificate cert, Key privateKey)
            throws TransformerException, XMLSecurityException {

           doc.normalizeDocument();

           if (cert.getPublicKey() instanceof RSAPublicKey && privateKey instanceof RSAPrivateKey) {
               assert ((RSAPublicKey)cert.getPublicKey()).getModulus().equals(((RSAPrivateKey)privateKey).getModulus());
               if (logger.isDebugEnabled()) {
                   boolean same = ((RSAPublicKey)cert.getPublicKey()).getModulus().equals(((RSAPrivateKey)privateKey).getModulus());
                   logger.debug("signXml input cert and privateKey have same modulus");
               }
           }
           else
               logger.debug("not Rsa private and/or public key: no check done");


   //        return signXmlWithoutSanturio(doc, elementToSignId, elementToAddSignatureToName, cert, privateKey);
           return signXmlWithSanturio(doc, elementToSignId, elementToAddSignatureToName, cert, privateKey);
       }
       public static String signXmlWithoutSanturio(Document doc, String elementToSignId,
                                                   String elementToAddSignatureToName, X509Certificate cert, Key privateKey)
               throws NoSuchAlgorithmException, InvalidAlgorithmParameterException, KeyException,
                      MarshalException, XMLSignatureException, TransformerException {
           Element elementToAddSignatureTo = (Element) doc.getElementsByTagName(elementToAddSignatureToName).item(0);
   //        Element elementToSign = doc.getElementById(elementToSignId);
           assert elementToAddSignatureTo != null;
   //        assert elementToSign != null;

           XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

           Reference ref = fac.newReference
                   ("#" + elementToSignId, fac.newDigestMethod(DigestMethod.SHA1, null),
                           Collections.singletonList
                                   (fac.newTransform
                                           (Transform.ENVELOPED, (TransformParameterSpec) null)),
                           null, null);

           // Create the SignedInfo
           SignedInfo si = fac.newSignedInfo
                   (fac.newCanonicalizationMethod
                           (CanonicalizationMethod.INCLUSIVE,
                                   (C14NMethodParameterSpec) null),
                           fac.newSignatureMethod(SignatureMethod.RSA_SHA1, null),
                           Collections.singletonList(ref));



           // Create a KeyValue
           KeyInfoFactory kif = fac.getKeyInfoFactory();
           KeyValue kv = kif.newKeyValue(cert.getPublicKey());
           List x509DataList = new ArrayList();
           x509DataList.add(cert); //adds X509Certificate element
   //        x509DataList.add(""); //adds X509SubjectName element
           //can also use X509IssuerSerial, see newX509Data javadoc
           X509Data x509Data = kif.newX509Data(x509DataList);

           // Create a KeyInfo and add the KeyValue to it
           List kiList = new ArrayList();
           kiList.add(kv);
           kiList.add(x509Data);
           KeyInfo ki = kif.newKeyInfo(/*Collections.singletonList(kv)*/kiList);


           // Create a DOMSignContext and specify the PrivateKey and
           // location of the resulting XMLSignature's parent element
           DOMSignContext dsc = new DOMSignContext(privateKey, elementToAddSignatureTo);

           // Create the XMLSignature (but don't sign it yet)
           javax.xml.crypto.dsig.XMLSignature signature = fac.newXMLSignature(si, ki);

           // Marshal, generate (and sign) the enveloped signature
           signature.sign(dsc);


           TransformerFactory tf = TransformerFactory.newInstance();
           Transformer trans = tf.newTransformer();
           trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
           trans.setOutputProperty(OutputKeys.ENCODING, "utf-8");
           trans.setOutputProperty(OutputKeys.INDENT, "no");
           final StringWriter stringWriter = new StringWriter();
           trans.transform(new DOMSource(doc), new StreamResult(stringWriter));
           return stringWriter.getBuffer().toString();

       }
       public static String signXmlWithSanturio(Document doc, String elementToSignId,
                                                String elementToAddSignatureToName, X509Certificate cert, Key privateKey)
               throws XMLSecurityException, TransformerException {
           Init.init();
           ElementProxy.setDefaultPrefix(Constants.SignatureSpecNS, "");
           final org.apache.xml.security.signature.XMLSignature sig =
                   new org.apache.xml.security.signature.XMLSignature(doc, null, org.apache.xml.security.signature.XMLSignature.ALGO_ID_SIGNATURE_RSA);
   //        final XMLSignature sig = new XMLSignature(elementToSign, null);
           Element elementToAddSignatureTo = (Element) doc.getElementsByTagName(elementToAddSignatureToName).item(0);
           elementToAddSignatureTo.appendChild(sig.getElement());
           final Transforms transforms = new Transforms(doc);
           transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);
   //        transforms.addTransform(Transforms.TRANSFORM_C14N_OMIT_COMMENTS);
           sig.addDocument("#" + elementToSignId, transforms, Constants.ALGO_ID_DIGEST_SHA1);
           sig.addKeyInfo(cert);
           sig.addKeyInfo(cert.getPublicKey());
           sig.sign(privateKey);


           final StringWriter stringWriter = new StringWriter();
           TransformerFactory transFactory = TransformerFactory.newInstance();
           Transformer transformer = transFactory.newTransformer();
           transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
           transformer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
           transformer.setOutputProperty(OutputKeys.INDENT, "no");
           transformer.transform(new DOMSource(doc), new StreamResult(stringWriter));
           return stringWriter.getBuffer().toString();


           //meses up xsi:xmlns
   //        ByteArrayOutputStream os = new ByteArrayOutputStream();
   //        os.write(Canonicalizer.getInstance(Canonicalizer.ALGO_ID_C14N_WITH_COMMENTS).canonicalizeSubtree(doc));
   //        return os.toString("UTF-8");
       }
}
