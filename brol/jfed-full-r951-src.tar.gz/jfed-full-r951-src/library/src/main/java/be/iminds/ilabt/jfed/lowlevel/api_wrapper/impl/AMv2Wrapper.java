package be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.GeniUserProvider;
import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.ServerType;
import be.iminds.ilabt.jfed.lowlevel.api.AbstractGeniAggregateManager;
import be.iminds.ilabt.jfed.lowlevel.api.AggregateManager2;
import be.iminds.ilabt.jfed.lowlevel.api.UserSpec;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.AggregateManagerWrapper;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;

import java.util.Date;
import java.util.List;

/**
 * AMv2Wrapper
 */
public class AMv2Wrapper extends AggregateManagerWrapper {
    private final static org.apache.logging.log4j.Logger LOG = LogManager.getLogger();
    private AggregateManager2 am2;

    protected AMv2Wrapper(Logger logger, GeniUserProvider geniUserProvider, GeniConnectionProvider connectionProvider, SfaAuthority amAuthority) {
        super(logger, geniUserProvider, connectionProvider, amAuthority);

        am2 = new AggregateManager2(logger, true);
    }

    protected SfaConnection getConnection() throws JFedException {
        return (SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.AM, 2));
    }

    @Override
    public void getVersion() throws JFedException {
        AbstractGeniAggregateManager.AggregateManagerReply<AggregateManager2.VersionInfo> reply =
                am2.getVersion(getConnection());

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("GetVersion Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
        }
    }

    @Override
    public String listResources(AnyCredential userCredential, boolean available) throws JFedException {
        AbstractGeniAggregateManager.AggregateManagerReply<String> reply = am2.listResources(
                getConnection(),
                toCredentialList(userCredential),
                "geni", "3",
                available, true/*compressed*/,
                null/*sliceUrn*/, null/*extra_options*/);

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("ListResources Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
//            return null;
        }

        return reply.getValue();
    }

    @Override
    public String createSliver(GeniUrn sliceUrn, AnyCredential sliceCredential, String rspec, List<UserSpec> users, Date expirationDate) throws JFedException {
        AbstractGeniAggregateManager.AggregateManagerReply<String> reply = am2.createSliver(
                getConnection(),
                toCredentialList(sliceCredential),
                sliceUrn.getValue(), rspec,
                users, null/*extra_options*/);

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("CreateSliver Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
//            return null;
        }


        if (expirationDate != null) {
            //AMv2 doesn't support setting the expirationDate on creation, so we now forcefully execute an renewSliver
            try {
                renewSliver(sliceUrn, sliceCredential, expirationDate);
            } catch (JFedException ex) {
                LOG.error("Error when trying to define expiration date for newly created sliver", ex);
            }
        }

        return reply.getValue();
    }

    @Override
    public void deleteSliver(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException {
        AbstractGeniAggregateManager.AggregateManagerReply<Boolean> reply = am2.deleteSliver(
                getConnection(),
                toCredentialList(sliceCredential),
                sliceUrn.getValue(), null/*extra_options*/);

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("Delete Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
            //            return null;
        }
    }

    @Override
    public SliverStatus status(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException {
        AbstractGeniAggregateManager.AggregateManagerReply<AggregateManager2.SliverStatus> reply = am2.sliverStatus(
                getConnection(),
                toCredentialList(sliceCredential),
                sliceUrn.getValue(), null/*extra_options*/);

        AggregateManager2.SliverStatus status = reply.getValue();

        if ((!reply.getGeniResponseCode().isSuccess()) || status == null) {
            throw new JFedException("SliverStatus Call not successful or no return value", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
//            return null;
        }

        //API v2 defined states
        if (status.getStatus().equalsIgnoreCase("configuring")) return SliverStatus.CHANGING;
        if (status.getStatus().equalsIgnoreCase("unknown")) return SliverStatus.UNKNOWN;
        if (status.getStatus().equalsIgnoreCase("ready")) return SliverStatus.READY;
        if (status.getStatus().equalsIgnoreCase("failed")) return SliverStatus.FAIL;

        //not valid! but it does occur a lot on real servers, so we support them as well
        if (status.getStatus().equalsIgnoreCase("changing")) return SliverStatus.CHANGING;
        if (status.getStatus().equalsIgnoreCase("notready")) return SliverStatus.CHANGING;

        //support some possible alternatives as well (not seen these yet on server)
        if (status.getStatus().equalsIgnoreCase("fail")) return SliverStatus.FAIL;
        if (status.getStatus().equalsIgnoreCase("failure")) return SliverStatus.FAIL;
        if (status.getStatus().equalsIgnoreCase("error")) return SliverStatus.FAIL;
        if (status.getStatus().equalsIgnoreCase("unallocated")) return SliverStatus.UNALLOCATED;

        LOG.warn("Server returned unknown sliver status: \"" + status.getStatus() + "\"");
        return SliverStatus.UNKNOWN;
    }

    @Override
    public String describe(GeniUrn sliceUrn, AnyCredential sliceCredential) throws JFedException {
        AbstractGeniAggregateManager.AggregateManagerReply<String> reply = am2.listResources(
                getConnection(),
                toCredentialList(sliceCredential),
                "geni", "3",
                null /*available*/, true/*compressed*/,
                sliceUrn.getValue(), null/*extra_options*/);

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("ListResources Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
            //            return null;
        }

        return reply.getValue();
    }

    @Override
    public void renewSliver(GeniUrn sliceUrn, AnyCredential sliceCredential, Date newExpire) throws JFedException {
        AbstractGeniAggregateManager.AggregateManagerReply<Boolean> reply = am2.renewSliver(
                getConnection(),
                toCredentialList(sliceCredential),
                sliceUrn.getValue(), newExpire, null/*extra_options*/);

        if (!reply.getGeniResponseCode().isSuccess()) {
            throw new JFedException("SliverStatus Call not successful", reply.getXMLRPCCallDetailsGeni(), reply.getGeniResponseCode());
//            return null;
        }
    }
}
