package be.iminds.ilabt.jfed.lowlevel;

import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;

/**
 * XMLRPCCallDetails
 */
public interface XMLRPCCallDetails extends HttpCallDetails{
    public String getResultXmlRpcString();
    public String getRequestXmlRpcString();
    public String getResultValueString();
    public Object getResultValueObject();

    public Vector getRequest();
    public Object getResult();
}
