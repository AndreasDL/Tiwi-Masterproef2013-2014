package be.iminds.ilabt.jfed.util;

import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.authority.*;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnectionPool;
import org.apache.logging.log4j.LogManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * CommandExecutionContext: all info and helper classes needed to execute SA and AM commands
 */
public class CommandExecutionContext {
    private static org.apache.logging.log4j.Logger l4jLogger = LogManager.getLogger();

    private GeniUser geniUser;
    private SfaAuthority userAuthority;
    private SfaAuthority testedAuthority;
    private GeniConnectionProvider connectionProvider;
    private Logger logger;

    public CommandExecutionContext(GeniUser geniUser, SfaAuthority userAuthority, SfaAuthority testedAuthority, Logger logger) {
        this.geniUser = geniUser;
        this.userAuthority = userAuthority;
        this.testedAuthority = testedAuthority;
        this.logger = logger;
        connectionProvider = new SfaConnectionPool();
    }
    public CommandExecutionContext(String passwordFilename, String pemKeyAndCertFilename, String userAuthorityUrn, GeniUrn userUrn,
                                   String testedAggregateManagerUrn, boolean requireUser, boolean requireTestAuth) {

        this.logger = new Logger();
//        logger.addResultListener(new PrintlnResultLogger());

        //First try builtin info
//        AuthorityListModel authorityListModel = new AuthorityListModel();
//        BuiltinAuthorityList.load(authorityListModel);
        AuthorityListModel authorityListModel = JFedAuthorityList.getAuthorityListModel();

        boolean foundUserAuth = userAuthorityUrn == null ? true : authorityListModel.getByUrn(userAuthorityUrn) != null;
        boolean foundtestedAuth = testedAggregateManagerUrn == null ? true : authorityListModel.getByUrn(testedAggregateManagerUrn) != null;

        if (!foundUserAuth || !foundtestedAuth) {
            System.out.println("Authorities in context file:");
            System.out.println("                test user authority (found="+foundUserAuth+"): "+userAuthorityUrn);
            System.out.println("                  to test authority (found="+foundtestedAuth+"): "+testedAggregateManagerUrn);
            System.out.println("Could not find all authorities from context file, will retrieve list from Utah Emulab Clearinghouse...");

            //If that is not enough, get info from clearinghouse
            UtahClearingHouseAuthorityList.load(authorityListModel);
            UtahClearingHouseAuthorityList.retrieveCertificates();
        }

        this.userAuthority = authorityListModel.getByUrn(userAuthorityUrn);
        this.testedAuthority = authorityListModel.getByUrn(testedAggregateManagerUrn);
        if ((userAuthority == null && requireUser) || (testedAuthority == null && requireTestAuth)) {
            l4jLogger.error("FATAL ERROR in CommandExecutionContext:");
            if (requireUser && userAuthority == null) l4jLogger.error("   Could not find user authority: urn=\""+userAuthorityUrn+"\"");
            if (requireTestAuth && testedAuthority == null) l4jLogger.error("   Could not find tested authority: urn=\""+testedAggregateManagerUrn+"\"");
            l4jLogger.error("All known authorities:");
            for (SfaAuthority auth : authorityListModel.getAuthorities())
                l4jLogger.error("  urn=" + auth.getUrnString() + "   name=" + auth.getName());
            System.exit(-1);
        }
        assert !requireTestAuth || testedAuthority != null;
        assert !requireUser || userAuthority != null;

        if (requireUser) {
            String pemKeyAndCert = null;
            try {
                pemKeyAndCert = IOUtils.fileToString(pemKeyAndCertFilename);
            } catch (IOException e) {
                pemKeyAndCert = null;
                throw new RuntimeException("IOException reading PEM key and certificate file: "+e.getMessage(), e);
            }

//        String pemKeyAndCert = UserLoginModelManager.loadPemFile(new File(pemKeyAndCertFilename));
            assert pemKeyAndCert != null;
            String password = null;
            if (passwordFilename != null && !passwordFilename.isEmpty())
                try {
                    password = IOUtils.fileToString(passwordFilename).replaceAll("\n", "");
                    assert password != null;
                } catch (IOException e) {
                    throw new RuntimeException("Error reading password from file \""+passwordFilename+"\"", e);
                }
            geniUser = new SimpleGeniUser(userAuthority, userUrn, pemKeyAndCert, password == null ? null : password.toCharArray(),
                    new File(pemKeyAndCertFilename), new File(pemKeyAndCertFilename));
        }

        if (userAuthority != null && userAuthority.getPemSslTrustCert() != null)
            GeniTrustStoreHelper.addTrustedPemCertificateIfNotAdded(userAuthority.getPemSslTrustCert());
        if (testedAuthority != null && testedAuthority.getPemSslTrustCert() != null)
            GeniTrustStoreHelper.addTrustedPemCertificateIfNotAdded(testedAuthority.getPemSslTrustCert());

        connectionProvider = new SfaConnectionPool();
    }

    public Logger getLogger() {
        return logger;
    }

    public GeniUser getGeniUser() {
        return geniUser;
    }

    public SfaAuthority getUserAuthority() {
        return userAuthority;
    }

    public SfaAuthority getTestedAuthority() {
        return testedAuthority;
    }

    public GeniConnectionProvider getConnectionProvider() {
        return connectionProvider;
    }



    public static CommandExecutionContext loadFromFile(File file) throws IOException {
        return loadFromFile(file, true, true);
    }
    public static CommandExecutionContext loadFromFile(File file, boolean requireUser, boolean requireTestAuth) throws IOException {
        return loadFromFile(file, requireUser, requireTestAuth, "");
    }
    /**
     * @param userSuffix optionally, expects a suffix for all user arguments.
     *                   this is useful to get info for other users. (ex: "2" for pemKeyAndCertFilename2 etc.)
     * */
    public static CommandExecutionContext loadFromFile(File file, boolean requireUser, boolean requireTestAuth, String userSuffix) throws IOException {
        Properties prop = new Properties();

        prop.load(new FileInputStream(file));

        return loadFromProperties(prop, requireUser, requireTestAuth, userSuffix, " in Test Context properties file \""+file.getName()+"\"");
    }
    public static CommandExecutionContext loadFromProperties(Properties prop, boolean requireUser, boolean requireTestAuth, String userSuffix, String sourceName) {
        String passwordFilename = prop.getProperty("passwordFilename"+userSuffix);
        String userUrn = prop.getProperty("userUrn"+userSuffix);
        String pemKeyAndCertFilename = prop.getProperty("pemKeyAndCertFilename"+userSuffix);
        String userAuthorityUrn = prop.getProperty("userAuthorityUrn"+userSuffix);

        String testedAggregateManagerUrn = prop.getProperty("testedAggregateManagerUrn");

        if (requireUser && userAuthorityUrn == null) throw new RuntimeException("property \"userAuthorityUrn"+userSuffix+"\" is missing"+sourceName);
        if (requireUser && pemKeyAndCertFilename == null) throw new RuntimeException("property \"pemKeyAndCertFilename"+userSuffix+"\" is missing"+sourceName);
        if (requireTestAuth && testedAggregateManagerUrn == null) throw new RuntimeException("property \"testedAggregateManagerUrn\" is missing"+sourceName);

        if (userUrn == null) {
            //TODO get from optional (and previously mandatory) "username" property
            String username = prop.getProperty("username"+userSuffix);
            if (requireUser && username == null) throw new RuntimeException("property \"userUrn"+userSuffix+"\" (and alternative \"username"+userSuffix+"\") is missing"+sourceName);
            else {
                if (username != null) {
                    if (userAuthorityUrn == null)
                        throw new RuntimeException("property \"userUrn"+userSuffix+"\" is missing. Alternative " +
                                "\"username"+userSuffix+"\" is present but userAuthorityUrn"+userSuffix+" is missing. "+sourceName);
                    GeniUrn authUrn = GeniUrn.parse(userAuthorityUrn);
                    if (authUrn == null)
                        throw new RuntimeException("property \"userAuthorityUrn"+userSuffix+"\" is an invalid urn: \""+userAuthorityUrn+"\"");
                    assert authUrn != null;
                    userUrn = new GeniUrn(authUrn.getTopLevelAuthority(), "user", username).toString();
                }
            }
        }

        if (requireUser && userUrn == null) throw new RuntimeException("property \"userUrn"+userSuffix+"\" is missing"+sourceName);

        GeniUrn geniUserUrn;
        try {
            geniUserUrn = new GeniUrn(userUrn);
        } catch (GeniUrn.GeniUrnParseException e) {
            throw new RuntimeException("property \"userUrn"+userSuffix+"\" is not an urn \""+userUrn+"\"", e);
        }

        CommandExecutionContext res = new CommandExecutionContext(passwordFilename, pemKeyAndCertFilename, userAuthorityUrn, geniUserUrn, testedAggregateManagerUrn, requireUser, requireTestAuth);
        return res;
    }
}
