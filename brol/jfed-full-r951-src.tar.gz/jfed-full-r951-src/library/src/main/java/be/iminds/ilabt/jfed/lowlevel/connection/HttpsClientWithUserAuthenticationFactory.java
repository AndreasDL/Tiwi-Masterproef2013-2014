package be.iminds.ilabt.jfed.lowlevel.connection;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.stitching.VlanRangeHelper;
import be.iminds.ilabt.jfed.util.*;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.BrowserCompatHostnameVerifier;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpParams;
import org.apache.logging.log4j.LogManager;

import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.util.ArrayList;
import java.util.List;

/**
 * HttpsClientWithUserAuthenticationFactory
 */
public class HttpsClientWithUserAuthenticationFactory {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    public static interface HandleUntrustedCallback {
        public boolean trust(SSLCertificateDownloader.SSLCertificateJFedInfo sSLCertificateJFedInfo);
    }
    public static class INSECURE_TRUSTALL_HandleUntrustedCallback implements HandleUntrustedCallback {
        public INSECURE_TRUSTALL_HandleUntrustedCallback() {
            LOG.warn("SECURITY WARNING: constructing INSECURE_TRUSTALL_HandleUntrustedCallback");
        }
        @Override
        public boolean trust(SSLCertificateDownloader.SSLCertificateJFedInfo sSLCertificateJFedInfo) {
            return true;
        }
    }

    public static DefaultHttpClient getHttpClient(JFedConnection.ProxyInfo proxyInfo,
                                                  List<X509Certificate> clientCertificateChain,
                                                  PrivateKey privateKey,
                                                  String serverUrlStr,
                                                  KeyStore trustStore,
                                                  final List<String> allowedCertificateHostnameAliasesOrig,
                                                  boolean debugMode, final HandleUntrustedCallback handleUntrustedCallback) throws JFedException {
        if (clientCertificateChain == null) throw new RuntimeException("clientCertificateChain == null");
        if (clientCertificateChain.size() == 0) throw new RuntimeException("clientCertificateChain is empty");
        if (privateKey == null) throw new RuntimeException("privateKey == null");
        if (serverUrlStr == null) throw new RuntimeException("serverUrlStr == null");

        final List<String> allowedCertificateHostnameAliases = new ArrayList<String>(allowedCertificateHostnameAliasesOrig);

        final URL serverUrl;
        try {
            serverUrl = new URL(serverUrlStr);
        } catch (MalformedURLException e) {
            LOG.error("ERROR: MalformedURLException url=\"" + serverUrlStr + "\"", e);
            return null;
        }

        try {
            String key_store_pass = "somepass"; //password for internal use. We don;t really need one as we'll never save this keystore.
            String privatekey_store_pass = "someotherpass"; //password for internal use. We don't really need one as we'll never save this keystore or share it with other objects

            KeyStore keyStore = KeyStore.getInstance("JKS", "SUN");
            keyStore.load( null , key_store_pass.toCharArray());

            // Create CertificateChain
            Certificate[] certs = new Certificate[clientCertificateChain.size()];
            for (int i = 0; i < clientCertificateChain.size(); i++)
                certs[i] = clientCertificateChain.get(i);

            // storing private key and certificate to keystore
            keyStore.setKeyEntry("authority", privateKey, privatekey_store_pass.toCharArray()/*password is used to encrypt the key inside the keystore*/, certs );

            String pk = privateKey.toString();
            //            System.out.println("Setting up SSL connection with privateKey="+(pk.length() > 30 ? (pk.substring(0, 30) + "...") : pk)+" and clientCertificateChain.size() "+clientCertificateChain.size());



            ////////// DEBUG //////////////
            //add last client certificate to trust store as well as keystore!
            //            trustStore.setCertificateEntry("clientCertificate", clientCertificateChain.get(clientCertificateChain.size()-1));
            ////////// DEBUG //////////////

            ////////// DEBUG //////////////
            //add all client certificates to trust store as well as keystore!
            for (int i = 0; i < clientCertificateChain.size(); i++)
                trustStore.setCertificateEntry("clientCertificate"+i, clientCertificateChain.get(i));
            ////////// DEBUG //////////////




            //            //check if private key matches certificate public key
            //            PublicKey pubKey = certificate.getPublicKey();
            //            if (pubKey instanceof RSAPublicKey && privateKey instanceof RSAPrivateKey) {
            //                RSAPublicKey rsaPubKey = (RSAPublicKey) pubKey;
            //                RSAPrivateKey rsaPrivateKey = (RSAPrivateKey) privateKey;
            //                if (! rsaPubKey.getModulus().equals(rsaPrivateKey.getModulus()))
            //                    System.out.println("   RSA private and public key modulus does not match: private="+rsaPrivateKey.getModulus()+" public="+rsaPubKey.getModulus());
            //                else
            //                    System.out.println("   RSA private and public key modulus match.");
            //
            //            } else {
            //                System.out.println("cannot compare private and public key (from certificate)");
            //                System.out.println("   private key is class "+privateKey.getClass().getName());
            //                System.out.println("   public key is class "+pubKey.getClass().getName());
            //            }


            /************ Init Trust Store *************/
            HttpParams params = new BasicHttpParams();
            params.setParameter(CoreConnectionPNames.SO_TIMEOUT, 120000); //read timeout in ms (default: 0 = infinite)   (long timeout, as some calls take time to finish)
            params.setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 10000); //connection timeout in ms (default: 0 = infinite)

            DefaultHttpClient httpclient = null;
            if (System.getProperty("proxySet") != null &&
                    System.getProperty("proxySet").equals("true") &&
                    System.getProperty("socksProxyHost") != null) {
                LOG.info("Using SOCKS proxy: "+System.getProperty("socksProxyHost"));
                httpclient = SocksProxyHelper.getHttpClientOverSocksProxy(params);
            }
            else {
                httpclient = new DefaultHttpClient(params);
            }

            String algo = SSLSocketFactory.TLS;
            java.security.SecureRandom random = new SecureRandom();
               /**/
            org.apache.http.conn.ssl.X509HostnameVerifier hostnameVerifier;
            //            if (acceptAllSelfSigned_INSECURE) {
            //                System.out.println("SECURITY WARNING:     using AllowAllHostnameVerifier");
            //                hostnameVerifier = new AllowAllHostnameVerifier();
            //            }
            //            else
            hostnameVerifier = new org.apache.http.conn.ssl.AbstractVerifier(){
                private BrowserCompatHostnameVerifier base = new BrowserCompatHostnameVerifier();

                /**
                 * @param host the hostname of the url to check.
                 * @param cns the CN's of the certificate
                 * @param subjectAlts the aliases fot the CN's that the certificate allows
                 * @throws javax.net.ssl.SSLException
                 */
                @Override
                public final void verify(java.lang.String host, String[] cns, String[] subjectAlts) throws javax.net.ssl.SSLException {
                    //                        System.out.println("hostnameVerifier verify("+host+", "+cns+", "+subjectAlts+")");
                    List<String> modifiedSubjectAlts = new ArrayList<String>();
                    if (subjectAlts != null)
                        for (String subjectAlt : subjectAlts)
                            modifiedSubjectAlts.add(subjectAlt);
                    List<String> modifiedCns = new ArrayList<String>();
                    if (cns != null)
                        for (String cn : cns)
                            modifiedCns.add(cn);

                    //force add of host itself, this makes any certificate we have stored match
                    for (String allowedAlias : allowedCertificateHostnameAliases)
                        if (modifiedCns.contains(allowedAlias) || modifiedSubjectAlts.contains(allowedAlias)) {
                            modifiedSubjectAlts.add(serverUrl.getHost());
                            break;
                        }

                    //                        System.out.println("          allowedCertificateHostnameAliases="+allowedCertificateHostnameAliases);
                    //                        System.out.println("          modified names="+modifiedSubjectAlts);

                    String[] newSubjectAlts = new String[modifiedSubjectAlts.size()];
                    for (int i = 0; i < modifiedSubjectAlts.size(); i++)
                        newSubjectAlts[i] = modifiedSubjectAlts.get(i);
                    base.verify(host, cns, newSubjectAlts);
                }
            };
            SSLSocketFactory socketFactory;
            if (handleUntrustedCallback != null) {
                //                socketFactory = new SSLSocketFactory(TRUSTALL, new AllowAllHostnameVerifier()); //doesn't work as we need client authentication

                //didn't work for some reason. Probably it's missing client certificate (need to check apache source code of SSLSocketFactory to correctly write this)
                //                socketFactory = new MyInsecureSSLAcceptAllSocketFactory(algo, keyStore, privatekey_store_pass/*password is used to encrypt the key inside the keystore*/, trustStore, random, hostnameVerifier);

                //Solved by connecting 2 times. Not best solution, but it works.
                SSLCertificateDownloader.SSLCertificateJFedInfo certInfo = SSLCertificateDownloader.getCertificateInfo(serverUrl);
                if (certInfo != null && certInfo.isSelfSigned() != null && certInfo.isSelfSigned()) {
                    if (handleUntrustedCallback.trust(certInfo)) {
                        //                        System.out.println("User trust certificate -> Adding server certificate to trust store, and connecting again.");
                        trustStore.setCertificateEntry("allTrustCert"+extraTrustCount, certInfo.getCert());
                        if (!certInfo.getSubjectMatchesHostname())
                            allowedCertificateHostnameAliases.add(certInfo.getSubject());
                    } else {
                        LOG.info("User does not trust certificate -> Not adding anything to trust store.");
                    }
                }

                socketFactory = new SSLSocketFactory(algo, keyStore, privatekey_store_pass/*password is used to encrypt the key inside the keystore*/, trustStore, random, hostnameVerifier);
            }
            else {

                if (proxyInfo != null && proxyInfo instanceof JFedConnection.SshProxyInfo) {
                    JFedConnection.SshProxyInfo sshProxyInfo = (JFedConnection.SshProxyInfo) proxyInfo;

                    LOG.debug("Using SSH Proxy for connection: "+sshProxyInfo.getHostname());

                    SSLSocketFactory sslSocketFactory = new SshServerProxyHelper.SslOverSshProxySocketFactory(
                            new SshServerProxyHelper.SshProxyInfo(
                                    new InetSocketAddress(sshProxyInfo.getHostname(), sshProxyInfo.getPort()),
                                    sshProxyInfo.getUsername(),
                                    sshProxyInfo.getHostKey(),
                                    new String(KeyUtil.privateKeyToAnyPem(sshProxyInfo.getSshKeyInfo().getPrivateKey()))
                            ),
                            algo,
                            keyStore,
                            privatekey_store_pass /* password is used to encrypt the key inside the keystore */,
                            trustStore,
                            random,
                            hostnameVerifier);
                    socketFactory = sslSocketFactory;
                } else {
                    SSLSocketFactory sslSocketFactory = new SSLSocketFactory(
                            algo,
                            keyStore,
                            privatekey_store_pass/*password is used to encrypt the key inside the keystore*/,
                            trustStore,
                            random,
                            hostnameVerifier);
                    socketFactory = sslSocketFactory;
                }
            }

            Scheme sch1 = new Scheme("https", 443, socketFactory); //port is the default port for the given protocol
            httpclient.getConnectionManager().getSchemeRegistry().register(sch1);



            return httpclient;
        } catch (Exception e) {
            throw new JFedException("Error creating SSL connection to "+serverUrlStr, e);
        }
    }

    private static int extraTrustCount = 7000;













//    private static final TrustStrategy TRUSTALL = new TrustStrategy() {
//        @Override
//        public boolean isTrusted(X509Certificate[] chain, String authType) {
//            System.out.println("DEBUG:    TRUSTALL is trusting authType="+authType+" chain="+chain);
//            return true;
//        }
//    };
//
//    //Insecure, but can be useful for debugging
//    private static class InsecureTrustAllX509TrustManager implements X509TrustManager {
//        private final KeyStore trustStore;
//        private final X509TrustManager origX509TrustManager;
//        private InsecureTrustAllX509TrustManager(KeyStore trustStore, X509TrustManager origX509TrustManager) {
//            this.trustStore = trustStore;
//            this.origX509TrustManager = origX509TrustManager;
//            System.out.println("SECURITY WARNING:     constructing InsecureTrustAllX509TrustManager");
//
//        }
//        @Override
//        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
//            System.out.println("SECURITY WARNING:     InsecureTrustAllX509TrustManager is calling checkClientTrusted");
//            throw new UnsupportedOperationException();
//        }
//
//        static int count = 5000;
//        @Override
//        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
//            System.out.println("SECURITY WARNING:     InsecureTrustAllX509TrustManager is trusting server with authType="+authType+" chain="+chain);
//            try {
//                trustStore.setCertificateEntry("extraCert"+(count++), chain[0]);
//            } catch (KeyStoreException e) {
//                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
//            }
//            origX509TrustManager.checkServerTrusted(chain, authType);
//        }
//
//        @Override
//        public X509Certificate[] getAcceptedIssuers() {
//            System.out.println("SECURITY WARNING:     InsecureTrustAllX509TrustManager is calling getAcceptedIssuers");
//            //                    LOG.warning("WARNING: MyInsecureSSLAcceptAllSocketFactory.trustAll.getAcceptedIssuers() is called. (method not correctly implemented)");
//            //                    return null;
//            throw new UnsupportedOperationException();
//        }
//    }
//
//    //Insecure, but can be useful for debugging
//    private static class MyInsecureSSLAcceptAllSocketFactory extends SSLSocketFactory {
//        SSLContext sslContext = SSLContext.getInstance("TLS");
//
//        public MyInsecureSSLAcceptAllSocketFactory(java.lang.String algorithm,
//                                                   java.security.KeyStore keystore,
//                                                   java.lang.String keystorePassword,
//                                                   java.security.KeyStore trustStore,
//                                                   java.security.SecureRandom random,
//                                                   org.apache.http.conn.ssl.X509HostnameVerifier hostnameVerifier) throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException, UnrecoverableKeyException {
//            super(algorithm, keystore, keystorePassword, trustStore, random, hostnameVerifier);
//
//            System.out.println("SECURITY WARNING:     constructing MyInsecureSSLAcceptAllSocketFactory");
//
//            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
//            tmf.init(trustStore);
//            X509TrustManager defaultTrustManager = (X509TrustManager) tmf.getTrustManagers()[0];
//            TrustManager trustAll = new InsecureTrustAllX509TrustManager(trustStore, defaultTrustManager);
//
//            sslContext.init(null, new TrustManager[] { trustAll }, null);
//        }
//
//        @Override
//        public Socket createSocket(Socket socket, String host, int port, boolean autoClose) throws IOException {
//            System.out.println("DEBUG  MyInsecureSSLAcceptAllSocketFactory createSocket(Socket socket, String host, int port, boolean autoClose) called");
//            return sslContext.getSocketFactory().createSocket(socket, host, port, autoClose);
//        }
//
//        @Override
//        public Socket createSocket() throws IOException {
//            System.out.println("DEBUG  MyInsecureSSLAcceptAllSocketFactory createSocket() called");
//            return sslContext.getSocketFactory().createSocket();
//        }
//
//        public java.net.Socket createSocket(HttpParams params) throws java.io.IOException {
//            System.out.println("DEBUG  MyInsecureSSLAcceptAllSocketFactory createSocket(HttpParams params) called");
//            return sslContext.getSocketFactory().createSocket();
//        }
//
//
//        public java.net.Socket connectSocket(Socket socket,
//                                             InetSocketAddress remoteAddress,
//                                             InetSocketAddress localAddress,
//                                             HttpParams params) throws java.io.IOException,
//                java.net.UnknownHostException,
//                org.apache.http.conn.ConnectTimeoutException {
//            System.out.println("DEBUG  MyInsecureSSLAcceptAllSocketFactory connectSocket called");
//            return super.connectSocket(socket, remoteAddress, localAddress, params);
//        }
//
//        protected void prepareSocket(javax.net.ssl.SSLSocket socket) throws java.io.IOException {
//            throw new RuntimeException("Unsupported operation");
//        }
//        public java.net.Socket createLayeredSocket(Socket socket,
//                                                   String host,
//                                                   int port,
//                                                   HttpParams params) throws java.io.IOException, java.net.UnknownHostException {
//            throw new RuntimeException("Unsupported operation");
//        }
//
//    }
}
