package be.iminds.ilabt.jfed.lowlevel.connection;

import be.iminds.ilabt.jfed.lowlevel.GeniUser;
import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.ServerType;
import be.iminds.ilabt.jfed.lowlevel.api.*;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.ExtraInfoCallback;
import be.iminds.ilabt.jfed.util.GeniTrustStoreHelper;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * GeniConnectionPool
 */
public class SfaConnectionPool implements GeniConnectionProvider {
    private class AuthTypePair {
        private SfaAuthority authority;
        private ServerType serverType;

        private AuthTypePair(SfaAuthority authority, ServerType serverType) {
            if (authority == null) throw new RuntimeException("authority == null");
            this.authority = authority;
            this.serverType = serverType;
        }

        public SfaAuthority getAuthority() {
            return authority;
        }

        public ServerType getServerType() {
            return serverType;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            AuthTypePair that = (AuthTypePair) o;

            if (!authority.equals(that.authority)) return false;
            if (serverType != that.serverType) return false;

            return true;
        }

        @Override
        public int hashCode() {
            int result = authority.hashCode();
            result = 31 * result + serverType.hashCode();
            return result;
        }
    }
    private Map<AuthTypePair, JFedConnection> conPool;
    private SfaConnection chCon;
    private String chServerUrl;


    private JFedConnection.ProxyInfo proxyInfo = null;
    public JFedConnection.ProxyInfo getProxyInfo() {
        return proxyInfo;
    }
    public void setProxyInfo(JFedConnection.ProxyInfo proxyInfo) {
        this.proxyInfo = proxyInfo;
    }

    /* debug will print out a info during the call */
    private boolean debugMode;
    /** debug mode will print out a info during the call */
    public boolean isDebugMode() {
        return debugMode;
    }
    /** debug mode will print out a info during the call */
    public void setDebugMode(boolean debugMode) {
        boolean prevMode = this.debugMode;
        this.debugMode = debugMode;

        if (debugMode != prevMode) {
            //TODO close connections
            conPool.clear();
            chCon = null;
        }
    }



    public SfaConnectionPool() {
        this.chServerUrl = "https://www.emulab.net/protogeni/xmlrpc/ch";
        conPool = new HashMap<AuthTypePair, JFedConnection>();
        chCon = null;
    }

    @Override
    public JFedConnection getConnectionByAuthority(GeniUser user, SfaAuthority authority, Class targetClass) throws JFedException {
//        assert user != null;
        assert authority != null;
        assert targetClass != null;

        if (authority == null) throw new RuntimeException("authority == null");
        if (targetClass.equals(AggregateManager3.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.AM, 3));
        if (targetClass.equals(AggregateManager2.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.AM, 2));
        if (targetClass.equals(ProtogeniSliceAuthority.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1));
        if (targetClass.equals(ProtoGeniClearingHouse1.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.PROTOGENI_CH, 1));
        if (targetClass.equals(PlanetlabSfaRegistryInterface.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.PlanetLabSliceRegistry, 1));
        if (targetClass.equals(StitchingComputationService.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.SCS, 1));
        if (targetClass.equals(FederationRegistryApi1.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.GENI_CH, 1));
        if (targetClass.equals(FederationMemberAuthorityApi1.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.GENI_CH_MA, 1));
        if (targetClass.equals(FederationSliceAuthorityApi1.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 1));
        if (targetClass.equals(FederationRegistryApi2.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.GENI_CH, 2));
        if (targetClass.equals(FederationMemberAuthorityApi2.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.GENI_CH_MA, 2));
        if (targetClass.equals(FederationSliceAuthorityApi2.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 2));
        if (targetClass.equals(OCCI.class)) return getConnectionByAuthority(user, authority, new ServerType(ServerType.GeniServerRole.OCCI, 1));
        throw new JFedException("Cannot get connection for "+targetClass.getName());
    }

    public JFedConnection getConnectionByUserAuthority(GeniUser user, ServerType serverType) throws JFedException {
        assert serverType != null;
        assert user != null;

        assert user.getUserAuthority() != null : "getConnectionByUserAuthority requires that the user's authority is known";
        SfaAuthority authority = user.getUserAuthority();
        assert authority != null;

        return getConnectionByAuthority(user, authority, serverType);
    }

    /* TODO: not cached yet*/
    @Override
    public JFedConnection getConnectionByUrl(GeniUser user, URL serverUrl, HttpsClientWithUserAuthenticationFactory.HandleUntrustedCallback handleUntrustedCallback, ServerType serverType) throws JFedException {
        assert serverType != null;

        JFedConnection con = null;

        if (serverUrl == null)
            throw new RuntimeException("Connection type has no URL: "+serverType);

        if (serverType.getRole().equals(ServerType.GeniServerRole.OCCI)) {
            assert serverUrl.getProtocol().equals("https") : "Only HTTPS is supported for an OCCI connection";
            ExtraInfoCallback.Login bonfireLogin = ExtraInfoCallback.getBonfireLogin();
            if (bonfireLogin == null) return null;
            con = new RestSslPasswordConnection(null, serverUrl.toString(), proxyInfo, debugMode, bonfireLogin.getUsername(), bonfireLogin.getPassword());
        } else {
            if (serverUrl.getProtocol().equals("https")) {
                assert user != null : "HTTPS connections require that a user is logged in";
                con = new SfaSslConnection(null, serverUrl.toString(), user.getClientCertificateChain(), user.getPrivateKey(), proxyInfo, debugMode, handleUntrustedCallback);
            }
            else
                con = new SfaPlainConnection(null, serverUrl.toString(), proxyInfo, debugMode);
        }

        return con;

//        assert serverUrl != null;
//
//        SfaConnection con;
//
//        if (serverUrl.getProtocol().equals("https")) {
//            assert user != null : "HTTPS connections require that a user is logged in";
//
//            con = new SfaSslConnection(null, serverUrl.toString(), user.getClientCertificateChain(), user.getPrivateKey(), debugMode, handleUntrustedCallback);
//        }
//        else
//            con = new SfaPlainConnection(null, serverUrl.toString(), debugMode);
//
//        return con;
    }

    @Override
    public JFedConnection getConnectionByAuthority(GeniUser user, SfaAuthority authority, ServerType serverType) throws JFedException {
        assert serverType != null;
        if (authority == null) throw new RuntimeException("authority == null");
        assert authority != null;

        AuthTypePair pair = new AuthTypePair(authority, serverType);
        JFedConnection con = conPool.get(pair);

        if (con != null && con.isError()) {
            //something went wrong, we'll kill the connection
            conPool.remove(pair);
            con = null;
        }

        if (con == null) {
            URL serverUrl = authority.getUrl(serverType);
            if (serverUrl == null)
                throw new RuntimeException("Connection type has no URL: "+serverType);

            if (serverType.getRole().equals(ServerType.GeniServerRole.OCCI)) {
                assert serverUrl.getProtocol().equals("https") : "Only HTTPS is supported for an OCCI connection";
                assert user != null : "HTTPS connections require that a user is logged in";
                if (authority.getPemSslTrustCert() != null) {
                    if (authority.getPemSslTrustCert() != null)
                        GeniTrustStoreHelper.addTrustedPemCertificateIfNotAdded(authority.getPemSslTrustCert());
                    if (user.getUserAuthority() != null && user.getUserAuthority().getPemSslTrustCert() != null)
                        GeniTrustStoreHelper.addTrustedPemCertificateIfNotAdded(user.getUserAuthority().getPemSslTrustCert());
                }
                ExtraInfoCallback.Login bonfireLogin = ExtraInfoCallback.getBonfireLogin();
                if (bonfireLogin == null) return null;
                con = new RestSslPasswordConnection(authority, serverUrl.toString(), proxyInfo, debugMode, bonfireLogin.getUsername(), bonfireLogin.getPassword());
            } else {
                if (serverUrl.getProtocol().equals("https")) {
                    assert user != null : "HTTPS connections require that a user is logged in";
                    if (authority.getPemSslTrustCert() != null) {
                        if (authority.getPemSslTrustCert() != null)
                            GeniTrustStoreHelper.addTrustedPemCertificateIfNotAdded(authority.getPemSslTrustCert());
                        if (user.getUserAuthority() != null && user.getUserAuthority().getPemSslTrustCert() != null)
                            GeniTrustStoreHelper.addTrustedPemCertificateIfNotAdded(user.getUserAuthority().getPemSslTrustCert());
                    }
                    con = new SfaSslConnection(authority, serverUrl.toString(), user.getClientCertificateChain(), user.getPrivateKey(), proxyInfo, debugMode, null/*handleUntrustedCallback*/);
                }
                else
                    con = new SfaPlainConnection(authority, serverUrl.toString(), proxyInfo, debugMode);
            }

            //reuse connection next time, if allowed
            if (!authority.isReconnectEachTime())
                conPool.put(pair, con);
        }

        return con;
    }
}
