package be.iminds.ilabt.jfed.lowlevel.api;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;

import java.util.*;

/**
 * FederationMemberAuthorityApi2
 */
public class FederationMemberAuthorityApi2 extends AbstractFederationApi2 {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Member Authority API v2";
     */
    static public String getApiName() {
        return "Uniform Federation Member Authority API v2";
    }
    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Member Authority API v2";
     */
    @Override
    public String getName() {
        return getApiName();
    }

    public FederationMemberAuthorityApi2(Logger logger, boolean autoRetryBusy) {
        super(logger, autoRetryBusy, new ServerType(ServerType.GeniServerRole.GENI_CH_MA, 1));
    }

    public FederationMemberAuthorityApi2(Logger logger) {
        this(logger, true);
    }

    @Override
    public List<GetVersionResult.FieldInfo> getMinimumFields(String objectName) {
        List<GetVersionResult.FieldInfo> res = new ArrayList<GetVersionResult.FieldInfo>();
        if (objectName.equalsIgnoreCase("MEMBER")) {
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_URN", GetVersionResult.FieldInfo.FieldType.URN, true, GetVersionResult.FieldInfo.Protect.PUBLIC));
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_UID", GetVersionResult.FieldInfo.FieldType.UID, true, GetVersionResult.FieldInfo.Protect.PUBLIC));
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_FIRSTNAME", GetVersionResult.FieldInfo.FieldType.STRING, true, GetVersionResult.FieldInfo.Protect.IDENTIFYING));
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_LASTNAME", GetVersionResult.FieldInfo.FieldType.STRING, true, GetVersionResult.FieldInfo.Protect.IDENTIFYING));
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_USERNAME", GetVersionResult.FieldInfo.FieldType.STRING, true, GetVersionResult.FieldInfo.Protect.PUBLIC));
            res.add(new GetVersionResult.FieldInfo("MEMBER", "MEMBER_EMAIL", GetVersionResult.FieldInfo.FieldType.STRING, false, GetVersionResult.FieldInfo.Protect.IDENTIFYING));
        }
        if (objectName.equalsIgnoreCase("KEY")) {
            res.add(new GetVersionResult.FieldInfo("KEY", "KEY_MEMBER", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, true, false));
            res.add(new GetVersionResult.FieldInfo("KEY", "KEY_ID", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("KEY", "KEY_TYPE", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, true, false));
            res.add(new GetVersionResult.FieldInfo("KEY", "KEY_PUBLIC", GetVersionResult.FieldInfo.FieldType.KEY, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, true, false));
            res.add(new GetVersionResult.FieldInfo("KEY", "KEY_PRIVATE", GetVersionResult.FieldInfo.FieldType.KEY, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("KEY", "KEY_DESCRIPTION", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, true, true));
        }
        return res;
    }

    @Override
    public List<String> getApiObjects() {
        List<String> res = new ArrayList<String>();
        res.add("MEMBER");
        res.add("KEY");
        return res;
    }

    @Override
    public List<String> getRequiredApiServices() {
        List<String> res = new ArrayList<String>();
        res.add("MEMBER");
        return res;
    }

    @Override
    public List<String> getOptionalApiServices() {
        List<String> res = new ArrayList<String>();
        res.add("KEY");
        return res;
    }


    @ApiMethod(order=1, hint="get_version call: Provide a structure detailing the version information as well as details of accepted options s for CH API calls.", unprotected=true)
    public FederationApiReply<GetVersionResult> getVersion(SfaConnection con)  throws JFedException {
        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "get_version", new Vector(), null);
        FederationApiReply<GetVersionResult> r = null;
        try {
            r = new FederationApiReply<GetVersionResult>(res, new GetVersionResult(apiSpecifiesHashtableStringToObject(res.getResultValueObject())));
        } catch (Throwable e) {
//            System.err.println("Error parsing get_version reply: "+e);
//            e.printStackTrace();
            handleErrorProcessingArguments(res, "getVersion", "get_version", con, e);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<GetVersionResult>(res, null);
        log(res, r, "getVersion", "get_version", con, null);
        return r;
    }


    @ApiMethod(order=2, hint="lookup call: Lookup information about objects matching given criteria", unprotected=true)
    public FederationApiReply<LookupResult> lookup(SfaConnection con,
                                                   @ApiMethodParameter(name = "type", hint="object type to lookup",
                                                           required = true, guiDefault = "MEMBER", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                                   String type,
                                                   @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                   List<AnyCredential> credentialList,
                                                   @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                   Map<String, ? extends Object> match,
                                                   @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API2_FILTER)
                                                   List<String> filter,
                                                   @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                   Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("type", type, "credentialList", credentialList, "match", match, "filter", filter, "extraOptions", extraOptions);
        LookupResultConverter conv = null;
        return lookup_internal(methodParams, con, "lookup",
                type, conv,
                credentialList, match, filter, extraOptions,
                null/*extraArguments in front of call*/);
    }

    @ApiMethod(order=3, hint="update call: Update information about object")
    public FederationApiReply<String> update(SfaConnection con,
                                             @ApiMethodParameter(name = "type", hint="object type to update",
                                                     required = true, guiDefault = "MEMBER", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                             String type,
                                             @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                             List<AnyCredential> credentialList,
                                             @ApiMethodParameter(name = "urn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                             String urn,
                                             @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                             Map<String, String> fields,
                                             @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                             Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("type", type, "credentialList", credentialList, "urn", urn, "fields", fields, "extraOptions", extraOptions);
        return update_internal(methodParams, con, "update", type, credentialList, urn, null/*urntype*/, fields, extraOptions);
    }

    @ApiMethod(order=4, hint="create method")
    public FederationApiReply<Hashtable<String, Object>> create(SfaConnection con,
                                                                @ApiMethodParameter(name = "type", hint="object type to create",
                                                                        required = true, guiDefault = "KEY", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                                                String type,
                                                                @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                List<AnyCredential> credentialList,
                                                                @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                                                Map<String, String> fields,
                                                                @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("type", type, "credentialList", credentialList, "type", type, "fields", fields, "extraOptions", extraOptions);
        return create_internal(methodParams, con, "update", type, credentialList, fields, extraOptions);
    }


    @ApiMethod(order=5, hint="delete call: delete an OBJECT")
    public FederationApiReply<Boolean> delete(SfaConnection con,
                                              @ApiMethodParameter(name = "type", hint="object type to delete",
                                                      required = true, guiDefault = "KEY", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                              String type,
                                              @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                              List<AnyCredential> credentialList,
                                              @ApiMethodParameter(name = "urnToDelete", hint="", parameterType=ApiMethodParameterType.STRING)
                                              String urnToDelete,
                                              @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                              Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("type", type, "credentialList", credentialList, "urnToDelete", urnToDelete, "extraOptions", extraOptions);
        return delete_internal(methodParams, con, "delete", type, credentialList, urnToDelete, extraOptions);
    }

    @ApiMethod(order=10, hint="Convenience method for lookup call: Lookup information about members matching given criteria", unprotected=true, convenienceMethodFor = "lookup", convenienceMethodObjectType = "MEMBER")
    public FederationApiReply<LookupResult> lookupMember(SfaConnection con,
                                                         @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                         List<AnyCredential> credentialList,
                                                         @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                         Map<String, ? extends Object> match,
                                                         @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API2_FILTER)
                                                         List<String> filter,
                                                         @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                         Map<String, Object> extraOptions)  throws JFedException {
        return lookup(con, "MEMBER", credentialList, match, filter, extraOptions);
    }


    @ApiMethod(order=11, hint="Convenience method for update call: Update MEMBER information", convenienceMethodFor = "update", convenienceMethodObjectType = "MEMBER")
    public FederationApiReply<String> updateMember(SfaConnection con,
                                                   @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                   List<AnyCredential> credentialList,
                                                   @ApiMethodParameter(name = "urn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                   String urn,
                                                   @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                                   Map<String, String> fields,
                                                   @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                   Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "urn", urn, "fields", fields, "extraOptions", extraOptions);
        return update_internal(methodParams, con, "update", "MEMBER", credentialList, urn, "member", fields, extraOptions);
    }



    /**  */
    @ApiMethod(order=20, hint="get_credentials call: Provide list of credentials (signed statements) for given member\n" +
            "This is member-specific information suitable for passing as credentials in an AM API call for aggregate authorization.")
    public FederationApiReply<List<AnyCredential>> getCredentials(SfaConnection con,
                                                                  @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                  List<AnyCredential> credentialList,
                                                                  @ApiMethodParameter(name = "memberUrn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                                  GeniUrn memberUrn,
                                                                  @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                  Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "credentialList", credentialList, "memberUrn", memberUrn, "extraOptions", extraOptions);
        assert credentialList != null;
        assert memberUrn != null;

        if (memberUrn == null || !memberUrn.getResourceType().equals("user"))
            LOG.warn("member URN argument to getCredentials is not a valid member urn: \"" + memberUrn + "\" (will be used anyway)");

        return getCredentials_internal(methodParams, con, "getCredentials", "MEMBER", credentialList, memberUrn, extraOptions);
    }




    @ApiMethod(order=30, hint="Convenience method for lookup call: Lookup information about KEYs matching given criteria", unprotected=true, convenienceMethodFor = "lookup", convenienceMethodObjectType = "KEY")
    public FederationApiReply<LookupResult> lookupKey(SfaConnection con,
                                                      @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                      List<AnyCredential> credentialList,
                                                      @ApiMethodParameter(name = "keyId", hint="", parameterType=ApiMethodParameterType.STRING, required = false, guiDefaultOptional = true)
                                                      GeniUrn keyId,
                                                      @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                      Map<String, ? extends Object> match,
                                                      @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API2_FILTER)
                                                      List<String> filter,
                                                      @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                      Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> matchArg = new HashMap<String, Object>(match);
        if (keyId != null)
            matchArg.put("KEY_ID", keyId.getValue());

        return lookup(con, "KEY", credentialList, matchArg, filter, extraOptions);
    }
      
    @ApiMethod(order=31, hint="Convenience method for lookup call: Lookup information about KEYs matching given criteria", unprotected=true, convenienceMethodFor = "lookup", convenienceMethodObjectType = "KEY")
    public FederationApiReply<LookupResult> lookupKeyForMember(SfaConnection con,
                                                      @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                      List<AnyCredential> credentialList,
                                                      @ApiMethodParameter(name = "memberUrn", hint="", parameterType=ApiMethodParameterType.USER_URN, required = false, guiDefaultOptional = true)
                                                      GeniUrn memberUrn,
                                                      @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                      Map<String, ? extends Object> match,
                                                      @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API2_FILTER)
                                                      List<String> filter,
                                                      @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                      Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> matchArg = new HashMap<String, Object>(match);
        if (memberUrn != null)
            matchArg.put("KEY_MEMBER", memberUrn.getValue());

        return lookup(con, "KEY", credentialList, matchArg, filter, extraOptions);
    }

    @ApiMethod(order=32, hint="Convenience method for update call: Update KEY information", convenienceMethodFor = "update", convenienceMethodObjectType = "KEY")
    public FederationApiReply<String> updateKey(SfaConnection con,
                                                @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                List<AnyCredential> credentialList,
                                                @ApiMethodParameter(name = "id", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                String id,
                                                @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                                Map<String, String> fields,
                                                @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "id", id, "fields", fields, "extraOptions", extraOptions);
        return update_internal(methodParams, con, "update", "KEY", credentialList, id, null, fields, extraOptions);
    }

    @ApiMethod(order=33, hint="Convenience method for create call: create KEY", convenienceMethodFor = "create", convenienceMethodObjectType = "KEY")
    public FederationApiReply<Hashtable<String, Object>> createKey(SfaConnection con,
                                                                   @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                   List<AnyCredential> credentialList,
                                                                   @ApiMethodParameter(name = "memberUrn", hint="URN of the owner of this key",
                                                                           parameterType=ApiMethodParameterType.USER_URN,
                                                                           required = false, guiDefaultOptional = true)
                                                                   GeniUrn memberUrn,
                                                                   @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                                                   Map<String, String> fields,
                                                                   @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                   Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "fields", fields, "extraOptions", extraOptions);

        if (fields == null && memberUrn != null) {
            fields = new HashMap<String, String>();
        }
        if (memberUrn != null) {
            if (fields.containsKey("KEY_MEMBER")) {
                String fieldsKeyMember = fields.get("KEY_MEMBER")+"";
                if (fieldsKeyMember.equals(memberUrn.getValue()))
                    LOG.warn("Note: you specified both memberUrn and added KEY_MEMBER in fields, for createKey call." +
                            "They are equal, so no problem. Note that the createKey call only requires one of them.");
                else
                    LOG.error("WARNING: you specified both memberUrn and added KEY_MEMBER in fields for createKey call." +
                            "They are NOT equal! memberUrn='" + memberUrn + "' " +
                            "KEY_MEMBER field value='" + fieldsKeyMember + "' " +
                            "Will give preference to memberUrn parameter!");
            }
            fields.put("KEY_MEMBER", memberUrn.getValue());
        }

        return create(con, "KEY", credentialList, fields, extraOptions);
    }

    @ApiMethod(order=34, hint="Convenience method for delete call: delete a KEY", convenienceMethodFor = "delete", convenienceMethodObjectType = "KEY")
    public FederationApiReply<Boolean> deleteKey(SfaConnection con,
                                              @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                              List<AnyCredential> credentialList,
                                              @ApiMethodParameter(name = "keyId", hint="", parameterType=ApiMethodParameterType.STRING)
                                              String keyId,
                                              @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false,
                                                      guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                              Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "keyId", keyId, "extraOptions", extraOptions);
        return delete_internal(methodParams, con, "delete", "KEY", credentialList, keyId, extraOptions);
    }
}
