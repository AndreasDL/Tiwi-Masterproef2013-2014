package be.iminds.ilabt.jfed.util;

import org.apache.logging.log4j.LogManager;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.attribute.PosixFilePermission;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 * IOUtils
 */
public class IOUtils {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    public static String askCommandLineInput(String question) {
        Scanner input=new Scanner(System.in);
        System.out.print(question+": ");
        return input.nextLine();
    }
    public static char[] askCommandLinePassword(String question) {
        Console cons = System.console();
        if ((cons = System.console()) != null) {
            char [] passwd = cons.readPassword("%s: ", question);
            return passwd;
        } else {
            //fallback if not a console
            Scanner input=new Scanner(System.in);
            System.out.print("*** everything you type might be shown *** "+question+": ");
            return input.nextLine().toCharArray();
        }
    }

    public static String fileToString(String filename) throws FileNotFoundException, IOException {
        return fileToString(new File(filename));
    }
    public static String fileToString(File file) throws FileNotFoundException, IOException {
        String res = "";
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(file));
            String line = br.readLine();
            while (line != null) {
                res += line + "\n";
                line = br.readLine();
            }
//        } catch (Exception e) {
//            throw e;
//        } catch (IOException e) {
//            throw e;
        } finally {
            try {
                if (br != null) br.close();
            } catch(IOException e) { }
        }
        return res;
    }
    public static byte[] fileToByteArray(File file) throws FileNotFoundException, IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        InputStream is = new FileInputStream(file);
        try {
            int i; byte[] b = new byte[1024];
            while((i=is.read(b))!=-1) baos.write(b, 0, i);
        } finally {
            try {
                if (is != null) is.close();
            } catch(IOException e) { }
        }
        return baos.toByteArray();
    }
    public static void byteArrayToFile(File file, byte[] b) throws FileNotFoundException, IOException {
        BufferedOutputStream os = null;
        try {
            os = new BufferedOutputStream(new FileOutputStream(file));
            os.write(b);
        } finally {
            try {
                if (os != null) os.close();
            } catch(IOException e) { }
        }
    }
    public static String streamToString(final InputStream is, String encoding/*example "UTF-8"*/)
    {
        int BUFFER_SIZE = 2048;
        final char[] buffer = new char[BUFFER_SIZE];
        final StringBuilder out = new StringBuilder();
        try {
            final Reader in = new InputStreamReader(is, encoding);
            try {
                for (;;) {
                    int rsz = in.read(buffer, 0, buffer.length);
                    if (rsz < 0)
                        break;
                    out.append(buffer, 0, rsz);
                }
            }
            finally {
                in.close();
            }
        }
        catch (UnsupportedEncodingException ex) {
        /* ... */
        }
        catch (IOException ex) {
          /* ... */
        }
        return out.toString();
    }

    public static void streamToFile(InputStream is, File outFile) {
        String res = "";
        try {
            FileWriter fw = new FileWriter(outFile);

            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line = br.readLine();
            while (line != null) {
                res += line + "\n";
                fw.write(line);
                line = br.readLine();
            }

            fw.close();
        } catch (IOException e) {
            throw new RuntimeException("Error reading inputstream '"+is+"' or writing to file \""+outFile.getName()+"\": "+e.getMessage(), e);
        }
    }
    public static String exceptionToStacktraceString(Exception e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        pw.close();
        String stacktrace = sw.getBuffer().toString();
        return stacktrace;
    }

    public static void stringToFile(String filename, String text) {
        stringToFile(new File(filename), text);
    }
    public static void stringToFile(File file, String text) {
        try {
            FileWriter fw = new FileWriter(file);
            fw.write(text);
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException("Error writing '"+file+"': "+e.getMessage(), e);
        }
    }

    /** group or others have NO permissions */
    public static void assureUserOnlyPerms(File file, boolean userRead, boolean userWrite, boolean userExecute) throws IOException {
        if (OSDetector.os == OSDetector.OS.UNIX || OSDetector.os == OSDetector.OS.MAC) {
            boolean needToChange = false;
            Set<PosixFilePermission> perms = Files.getPosixFilePermissions(file.toPath());
            if (perms.contains(PosixFilePermission.GROUP_READ)) needToChange = true;
            if (perms.contains(PosixFilePermission.GROUP_WRITE)) needToChange = true;
            if (perms.contains(PosixFilePermission.GROUP_EXECUTE)) needToChange = true;
            if (perms.contains(PosixFilePermission.OTHERS_READ)) needToChange = true;
            if (perms.contains(PosixFilePermission.OTHERS_WRITE)) needToChange = true;
            if (perms.contains(PosixFilePermission.OTHERS_EXECUTE)) needToChange = true;
            if (perms.contains(PosixFilePermission.OWNER_READ) != userRead) needToChange = true;
            if (perms.contains(PosixFilePermission.OWNER_WRITE) != userWrite) needToChange = true;
            if (perms.contains(PosixFilePermission.OWNER_EXECUTE) != userExecute) needToChange = true;
            if (needToChange) setUserOnlyPerms(file, userRead, userWrite, userExecute);
        }
    }

    /** group or others have NO permissions */
    public static void setUserOnlyPerms(String file, boolean userRead, boolean userWrite, boolean userExecute) throws IOException {
        setUserOnlyPerms(new File(file), userRead, userWrite, userExecute);
    }
    /** group or others have NO permissions */
    public static void setUserOnlyPerms(File file, boolean userRead, boolean userWrite, boolean userExecute) throws IOException {
        if (OSDetector.os == OSDetector.OS.UNIX || OSDetector.os == OSDetector.OS.MAC) {
            //this methods works in Java 7
            Set<PosixFilePermission> perms = new HashSet<PosixFilePermission>();
            if (userRead) perms.add(PosixFilePermission.OWNER_READ);
            if (userWrite) perms.add(PosixFilePermission.OWNER_WRITE);
            if (userExecute) perms.add(PosixFilePermission.OWNER_EXECUTE);
            Files.setPosixFilePermissions(file.toPath(), perms);
        }

//        file.setExecutable(false, true);
//        file.setWritable(false, true);
//        file.setReadable(false);
//        file.setReadable(true, true);

//        if (OSDetector.os == OSDetector.OS.UNIX || OSDetector.os == OSDetector.OS.MAC) {
//            try {
//                Process cmdProc = Runtime.getRuntime().exec("chmod 600 "+ file);
//
//                BufferedReader stdoutReader = new BufferedReader(
//                        new InputStreamReader(cmdProc.getInputStream()));
//                String line;
//                while ((line = stdoutReader.readLine()) != null);
//                stdoutReader.close();
//
//                BufferedReader stderrReader = new BufferedReader(
//                        new InputStreamReader(cmdProc.getErrorStream()));
//                while ((line = stderrReader.readLine()) != null);
//                stderrReader.close();
//
//                cmdProc.waitFor();
//            } catch (IOException e) {
//                LOG.warn("chmod on file failed", e);
//
//            } catch (InterruptedException e) {
//                LOG.warn("InterruptedException in chmod on file", e);
//            }
//        }
    }
}
