package be.iminds.ilabt.jfed.lowlevel.connection;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.authority.DebuggingAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.ssh_key_info.SshKeyInfo;

import javax.xml.bind.annotation.*;
import java.security.PrivateKey;

/**
 * jFedConnection: A connection to a server of a SfaAuthority
 * <p/>
 * also has some debugging base functionality (may be removed later)
 */
public abstract class JFedConnection {
    protected String serverUrl;
    protected ProxyInfo proxyInfo;
    protected boolean error;

    /* debug will print out a info during the call */
    protected boolean debugMode;
    protected SfaAuthority geniAuthority;

    /**
     * The entire connection is faked for debugging purposes. Nothing really happens
     */
    public boolean fakeForDebugging = false;


    public JFedConnection(SfaAuthority geniAuthority, String serverUrl, ProxyInfo proxyInfo, boolean debugMode) throws JFedException {
        error = true;
        this.debugMode = debugMode;
        this.proxyInfo = proxyInfo;

        this.geniAuthority = geniAuthority;

        if (geniAuthority != null && DebuggingAuthorityList.isDebuggingAuth(geniAuthority)) {
            fakeForDebugging = true;
            error = false;
            this.serverUrl = serverUrl;
            return;
        }

        if (serverUrl == null) throw new IllegalArgumentException("Illegal argument: serverURL == null");
        this.serverUrl = serverUrl;
    }


    /**
     * debug mode will print out a info during the call
     */
    public boolean isDebugMode() {
        return debugMode;
    }

    /**
     * if isFakeForDebugging is true, the entire connection is faked for debugging purposes. Nothing really happens!
     */
    public boolean isFakeForDebugging() {
        return fakeForDebugging;
    }

    public String getServerUrl() {
        return serverUrl;
    }

    public void markError() {
        error = true;
    }

    public boolean isError() {
        return error;
    }

    /**
     * @return the GeniAuthority this connection is connecting to, or null if not applicable
     */
    public SfaAuthority getGeniAuthority() {
        return geniAuthority;
    }

    public ProxyInfo getProxyInfo() {
        return proxyInfo;
    }


    //XmlTransient might be needed for abstract, but I don't know if that is so in this case: @XmlTransient
    @XmlAccessorType(XmlAccessType.NONE)
    @XmlSeeAlso({SshProxyInfo.class})
    public static abstract class ProxyInfo {
        @XmlElement
        private String hostname;

        @XmlElement
        private int port;


        /**
         * DO NOT USE THIS CONSTRUCTOR
         * <p/>
         * This constructor is provided for JAXB, and should not be used for any other purpose.
         */
        private ProxyInfo() {
            this("localhost", 8888);
        }


        protected ProxyInfo(String hostname, int port) {
            this.hostname = hostname;
            this.port = port;
        }

        public String getHostname() {
            return hostname;
        }

        public int getPort() {
            return port;
        }
    }

    @XmlRootElement(name = "ssh_proxy_info")
    @XmlAccessorType(XmlAccessType.NONE)
    public static class SshProxyInfo extends ProxyInfo {
        @XmlElement
        private String username;

        //privateKey should really never get into the call log info
        //so explicitly stating (with XmlTransient) that privateKey may never be serialized!
        //     Note: XmlAccessorType(XmlAccessType.NONE) would actually have been enough if no @XmlElement is added
        @XmlTransient
        private SshKeyInfo sshKeyInfo;

        @XmlElement
        private String hostKey;

        /**
         * only for jaxb (immutable) object construction
         */
        @SuppressWarnings("unused")
        private SshProxyInfo() {
            this(null, -1, null, null, null);
        }

        public SshProxyInfo(String hostname, int port, String username, SshKeyInfo sshKeyInfo, String hostKey) {
            super(hostname, port);
            this.username = username;
            this.sshKeyInfo = sshKeyInfo;
            this.hostKey = hostKey;
        }

        public String getUsername() {
            return username;
        }

        public SshKeyInfo getSshKeyInfo() {
            return sshKeyInfo;
        }

        public String getHostKey() {
            return hostKey;
        }
    }
}
