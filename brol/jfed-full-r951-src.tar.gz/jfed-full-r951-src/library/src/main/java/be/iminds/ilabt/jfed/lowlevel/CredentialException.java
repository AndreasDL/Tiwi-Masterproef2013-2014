package be.iminds.ilabt.jfed.lowlevel;

/**
 * CredentialException: exception involving Credential (SfaCredential), such as failure creating, failed to verify credential, failed to read creadential, etc.
 */
public class CredentialException extends Exception {
    public CredentialException() {
        super();
    }

    public CredentialException(String message) {
        super(message);
    }

    public CredentialException(String message, Throwable cause) {
        super(message, cause);
    }

    public CredentialException(Throwable cause) {
        super(cause);
    }
}
