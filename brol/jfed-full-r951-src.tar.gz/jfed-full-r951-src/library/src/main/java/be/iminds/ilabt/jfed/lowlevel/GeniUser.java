package be.iminds.ilabt.jfed.lowlevel;

import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniUrn;

import java.io.File;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.List;

/**
 * GeniUser
 */
public interface GeniUser {
    PrivateKey getPrivateKey();
    PublicKey getPublicKey();
    List<X509Certificate> getClientCertificateChain();

    SfaAuthority getUserAuthority();

    //    String getUserName();
    String getUserUrnString();
    GeniUrn getUserUrn();


    //the following may return null
    File getPrivateKeyFile();
    File getCertificateFile();


    /*
    * example getPublicKey implementation:

    @Override
    public PublicKey getPublicKey() {
        List<X509Certificate> certificateChain = getClientCertificateChain();
        if (certificateChain == null || certificateChain.isEmpty())
            return null;
        return certificateChain.get(0).getPublicKey();
    }
    * */
}
