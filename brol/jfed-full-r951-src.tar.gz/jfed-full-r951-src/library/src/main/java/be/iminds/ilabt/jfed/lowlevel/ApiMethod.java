package be.iminds.ilabt.jfed.lowlevel;

import java.lang.annotation.*;

/**
 * ApiMethod
 */
 @Retention(RetentionPolicy.RUNTIME)
 @Target(ElementType.METHOD)
public @interface ApiMethod {
    /**
     * order number is used to order the list of ApiMethods. lower number means first in list.
     * This is useful to get a list of methods as they are ordered in the API (typically a logical ordering)
     * They are now ordered in the same way in the classes, but this order is not kept by reflection.
     * */
    int order() default -1;

    String hint() default "";
    boolean unprotected() default false;

    /** if non empty, the method is a convenience method for the specified method.
     * That is, it fills in some arguments automatically for this method and then calls it.
     * For Ch APi2, the convenience method is typically for a certain object type, which can be filled in in "convenienceMethodObjectType".
     * */
    String convenienceMethodFor() default "";
    String convenienceMethodObjectType() default "";
}
