package be.iminds.ilabt.jfed.lowlevel.authority;

import be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.xml.bind.*;
import java.io.*;

/**
 * StoredAuthorityList
 */
public class StoredAuthorityList {
    private static final Logger logger = LogManager.getLogger();

    /** returns whether successfully loaded. returns false if no file to load. */
    static boolean load(File file, AuthorityListModel authorityListModel) {
        //not important if it doesn't exist
        if (!file.exists()) return false;

        try {
            return load(new FileInputStream(file), authorityListModel);
        } catch (FileNotFoundException e) {
            logger.warn("Error reading authorities from XML file \"" + file + "\": " ,e);
            return false;
        }
    }

    /** returns whether successfully loaded. */
    static boolean load(InputStream is, AuthorityListModel authorityListModel) {
        try {
            Class docClass = be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities.class;
            String packageName = docClass.getPackage().getName();
            JAXBContext jc = JAXBContext.newInstance(packageName);
            Unmarshaller u = jc.createUnmarshaller();
//            JAXBElement<Authorities> doc =
//                    (JAXBElement<Authorities>) u.unmarshal(file);
//            be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities c = doc.getValue();
            be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities c = (Authorities) u.unmarshal(is);

            for (Authorities.Authority xmlAuthority : c.getAuthority()) {
                SfaAuthority sfaAuthority = SfaAuthority.fromXml(xmlAuthority);

                //find existing
                SfaAuthority existingSfaAuthority = authorityListModel.getByUrn(sfaAuthority.getUrnString());
                if (existingSfaAuthority == null)
                    authorityListModel.addAuthority(sfaAuthority);
                else {
                    boolean replace = false;

                    if (existingSfaAuthority.isWasStored()) replace = true;
                    //TODO handle it more intelligently? (example: compare with source of saved, and let for example USER_PROVIDED always take priority?)
                    if (existingSfaAuthority.getSource() != null) {
                        switch (existingSfaAuthority.getSource()) {
                            case BUILTIN: replace = true; break;
                            case USER_PROVIDED: break;
                            case UTAH_CLEARINGHOUSE: break;
                        }
                    }

                    if (replace) {
                        authorityListModel.removeByUrn(sfaAuthority.getUrnString());
                        authorityListModel.addAuthority(sfaAuthority);
                    } else {
                        //update
                        authorityListModel.mergeOrAdd(sfaAuthority);
                    }
                }
            }
        }
        catch (Exception e) {
            logger.warn("Error reading authorities from XML: ",e);
            return false;
        } finally {
            try { is.close(); } catch (IOException e) { /*ignore exceptions when closing*/ }
        }
        return true;
    }

    static void save(File file, AuthorityListModel authorityListModel) {
        try {
            //first see if the dir exists, and try to create it if not.
            File dir = file.getParentFile();
            if (!dir.exists()) dir.mkdir();
            if (!dir.exists()) {
                logger.warn("could not save authorities to \""+file.getName()+"\", as dir \""+dir.getName()+"\" could not be created.");
                return;
            }

            //write to file
            FileWriter writer = new FileWriter(file);
            be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities xmlAuthorities = new be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities();
            for (SfaAuthority auth : authorityListModel.getAuthorities()) {
                be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities.Authority xmlAuth = auth.toXml();
                xmlAuthorities.getAuthority().add(xmlAuth);
            }

            JAXBContext context = JAXBContext.newInstance(be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities.class);
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            m.marshal(xmlAuthorities, writer);

            writer.close();
        } catch (JAXBException e) {
            logger.warn("Error writing authorities to XML: ",e);
        } catch (IOException e) {
            logger.warn("Error writing authorities to XML file \""+file.getName()+"\": ",e);
        }
    }

    public static String toXml(AuthorityListModel authorityListModel) {
        try {
            StringWriter writer = new StringWriter();
            be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities xmlAuthorities = new be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities();
            for (SfaAuthority auth : authorityListModel.getAuthorities()) {
                be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities.Authority xmlAuth = auth.toXml();
                xmlAuthorities.getAuthority().add(xmlAuth);
            }

            JAXBContext context = JAXBContext.newInstance(be.iminds.ilabt.jfed.lowlevel.authority.binding.Authorities.class);
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            m.marshal(xmlAuthorities, writer);

            writer.close();

            String xml = writer.toString();
            return xml;
        } catch (Exception e) {
            logger.warn("WARNING: Error writing authorities to XML: ",e);
          }
        return null;
    }
}
