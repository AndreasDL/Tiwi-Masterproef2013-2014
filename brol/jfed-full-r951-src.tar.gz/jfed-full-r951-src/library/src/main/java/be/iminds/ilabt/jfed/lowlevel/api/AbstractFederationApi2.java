package be.iminds.ilabt.jfed.lowlevel.api;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;

import java.lang.reflect.Method;
import java.util.*;

/**
 * AbstractGeniClearingHouseApi
 */
public abstract class AbstractFederationApi2 extends AbstractFederationApi {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();


    public AbstractFederationApi2(Logger logger, boolean autoRetryBusy, ServerType serverType) {
        super(logger, autoRetryBusy, serverType);
    }


    protected <T> FederationApiReply<LookupResult<T>> lookup_internal(Map<String, Object> methodParams,
                                                                      SfaConnection con,
                                                                      String methodJavaName,
//                                                                      String methodApiName,
                                                                      String objectTypeName,
                                                                      LookupResultConverter<T> lookupResultConverter,
                                                                      List<AnyCredential> credentialList,
                                                                      Map<String, ? extends Object> match,
                                                                      List<String> filter,
                                                                      Map<String, Object> extraOptions,
                                                                      Vector extraArguments /* extraArguments are added in front of call*/)  throws JFedException {
        assert methodJavaName != null;
        String methodApiName = "lookup";

        Vector args = new Vector(4);
        if (extraArguments != null)
            for (Object extraArgument : extraArguments)
                args.add(extraArgument);

        args.add(objectTypeName);

        if (credentialList != null) {
            Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
            args.add(credentials);
        } else {
            //always need to add credential argument
            args.add(new Vector());
        }

        Hashtable options = new Hashtable();
        if (match != null)
            options.put("match", new Hashtable<String, Object>(match));
        if (filter != null/* && !filter.isEmpty()*/)
            options.put("filter", new Vector<String>(filter));
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, methodApiName, args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<LookupResult<T>> r = null;
        try {
            LookupResult resLookupResult = new LookupResult(resultValueObject, lookupResultConverter);
            r = new FederationApiReply<LookupResult<T>>(res, resLookupResult);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, methodJavaName, methodApiName, con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<LookupResult<T>>(res, null);
        log(res, r, methodJavaName, methodApiName, con, methodParams);
        return r;
    }


    /** normally returns nothing at all. Anything that might be returned anyway is converted to string, but normally a null Object will be returned. */
    protected FederationApiReply<String> update_internal(Map<String, Object> methodParams,
                                                         SfaConnection con,
                                                         String methodJavaName,
//                                                         String methodApiName,
                                                         String objectTypeName,
                                                         List<AnyCredential> credentialList,
                                                         String urn,
                                                         String urnType,
                                                         Map<String, String> fields,
                                                         Map<String, Object> extraOptions)  throws JFedException {
        return update_internal(methodParams, con, methodJavaName, objectTypeName, credentialList, urn, urnType, fields, extraOptions, null);
    }
    protected FederationApiReply<String> update_internal(Map<String, Object> methodParams,
                                                         SfaConnection con,
                                                         String methodJavaName,
//                                                         String methodApiName,
                                                         String objectTypeName,
                                                         List<AnyCredential> credentialList,
                                                         String urn,
                                                         String urnType,
                                                         Map<String, String> fields,
                                                         Map<String, Object> extraOptions,
                                                         Vector extraArguments /* extraArguments are added in front of call*/)  throws JFedException {
        assert methodJavaName != null;
        String methodApiName = "update";
        assert credentialList != null;
        assert urn != null;
        assert fields != null;
        assert !fields.isEmpty();

        GeniUrn geniUrn = GeniUrn.parse(urn);
        if (geniUrn == null || (urnType != null && !geniUrn.getResourceType().equals(urnType)))
            System.err.println("WARNING: URN argument to "+methodJavaName+" is not a valid "+(urnType == null ? "" : urnType)+" urn: \""+urn+"\" (will be used anyway)");

        Vector args = new Vector(4);
        if (extraArguments != null)
            for (Object extraArgument : extraArguments)
                args.add(extraArgument);

        args.add(objectTypeName);

        args.add(urn);

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable options = new Hashtable();
        options.put("fields", new Hashtable<String, String>(fields));
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, methodApiName, args, methodParams);
        FederationApiReply<String> r = null;
        try {
            //normally returns nothing at all. Anything that might be returned anyway is converted to string
            Object resultValueObject = res.getResultValueObject();
            String nothing = resultValueObject == null ? null : resultValueObject.toString();
            if (nothing != null && nothing.isEmpty())
                nothing = null;
            r = new FederationApiReply<String>(res, nothing);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, methodJavaName, methodApiName, con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<String>(res, null);
        log(res, r, methodJavaName, methodApiName, con, methodParams);
        return r;
    }

    protected FederationApiReply<Hashtable<String, Object>> create_internal(Map<String, Object> methodParams,
                                                                            SfaConnection con,
                                                                            String methodJavaName,
                                                                            String objectTypeName,
                                                                            List<AnyCredential> credentialList,
                                                                            Map<String, String> fields,
                                                                            Map<String, Object> extraOptions)  throws JFedException {
        assert methodJavaName != null;
        String methodApiName = "create";
        assert credentialList != null;
        assert fields != null;
        assert !fields.isEmpty();

        Vector args = new Vector(3);

        args.add(objectTypeName);

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable options = new Hashtable();
        if (fields != null) {
            Hashtable allFields = new Hashtable<String, String>();
            allFields.putAll(fields);
            options.put("fields", allFields);
        }
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, methodApiName, args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<Hashtable<String, Object>> r = null;
        try {
            Hashtable<String, Object> resHashtable = apiSpecifiesHashtableStringToObject(resultValueObject);
            r = new FederationApiReply<Hashtable<String, Object>>(res, resHashtable);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, methodJavaName, methodApiName, con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<Hashtable<String, Object>>(res, null);
        log(res, r, methodJavaName, methodApiName, con, methodParams);
        return r;
    }

    public FederationApiReply<Boolean> delete_internal(Map<String, Object> methodParams,
                                                       SfaConnection con,
                                                       String methodJavaName,
                                                       String objectTypeName,
                                                       List<AnyCredential> credentialList,
                                                       String urnToDelete,
                                                       Map<String, Object> extraOptions)  throws JFedException {
        assert credentialList != null;
        assert urnToDelete != null;
        String methodApiName = "delete";

        Vector args = new Vector(4);

        args.add(objectTypeName);
        args.add(urnToDelete);

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable options = new Hashtable();
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, methodApiName, args, methodParams);
        FederationApiReply<Boolean> r = null;
        try {
            r = new FederationApiReply<Boolean>(res);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, methodJavaName, methodApiName, con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<Boolean>(res, false);
        log(res, r, methodJavaName, methodApiName, con, methodParams);
        return r;
    }


       public FederationApiReply<List<AnyCredential>> getCredentials_internal(Map<String, Object> methodParams,
                                                                      SfaConnection con,
                                                                      String methodJavaName,
                                                                      String objectTypeName,
                                                                     List<AnyCredential> credentialList,
                                                                     GeniUrn urn,
                                                                     Map<String, Object> extraOptions)  throws JFedException {
           String methodApiName = "get_credentials";
           assert credentialList != null;
           assert urn != null;

           Vector args = new Vector(3);
           args.add(urn.toString());

           Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
           args.add(credentials);

           if (extraOptions == null)
               args.add(new Hashtable<String, Object>());
           else
               args.add(new Hashtable<String, Object>(extraOptions));

           XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, methodApiName, args, methodParams);
           FederationApiReply<List<AnyCredential>> r = null;
           try {
               Object resultValueObject = res.getResultValueObject();
               List<AnyCredential> credList = apiSpecifiesVectorOfCredentials(methodApiName+" "+objectTypeName, resultValueObject);
               r = new FederationApiReply<List<AnyCredential>>(res, credList);
           } catch (Throwable t) {
               handleErrorProcessingArguments(res, methodJavaName, methodApiName, con, t);
               r = null;
           }

           if (r == null)
               r = new FederationApiReply<List<AnyCredential>>(res, null);
           log(res, r, methodJavaName, methodApiName, con, methodParams);
           return r;
       }
}
