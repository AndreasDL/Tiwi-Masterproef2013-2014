package be.iminds.ilabt.jfed.lowlevel.stitching;

import java.util.ArrayList;
import java.util.List;

/**
 * VlanRangeHelper can read Vlan ranges in the stitching rspec format
 * <p/>
 * examples:
 * 3726-3732,3747-3749
 * 3726-3732,3747
 * 670,3726-3750
 * 2-4094
 * 300
 * 580,722
 * 580,722,1024,18-30
 * <p/>
 * This class is a sort of iterator. It starts out at the first of the range, and can be incremented.
 */
public class VlanRangeHelper {
    public static class Range {
        int from, to;

        public Range(String r) {
            if (!r.matches("[0-9-]*"))
                throw new RuntimeException("new Range(\"" + r + "\") -> Range constructor called with invalid string");
            try {
                if (!r.contains("-")) {
                    to = Integer.parseInt(r);
                    from = to;
                    return;
                }

                String[] parts = r.split("-");
                assert parts.length == 2;
                from = Integer.parseInt(parts[0]);
                to = Integer.parseInt(parts[1]);
            } catch (NumberFormatException e) {
                throw new RuntimeException("Error parsing Range \"" + r + "\": " + e.getMessage(), e);
            }
        }

        public Range(Range o) {
            this.from = o.from;
            this.to = o.to;
        }

        public Range(int from, int to) {
            this.from = from;
            this.to = to;
        }

        public Range(int single) {
            this.from = single;
            this.to = single;
        }

        public boolean isEmpty() {
            return to < from;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            Range range = (Range) o;

            if (from != range.from) return false;
            if (to != range.to) return false;

            return true;
        }

        @Override
        public int hashCode() {
            int result = from;
            result = 31 * result + to;
            return result;
        }
    }

    private String rangeString;
    private List<Range> origRanges;
    private List<Range> itRanges;

    public VlanRangeHelper(VlanRangeHelper o) {
        this(o.rangeString);
    }

    public VlanRangeHelper(String rangeString) {
        this.rangeString = rangeString;

        String[] parts = rangeString.split(",");
        origRanges = new ArrayList<Range>();
        itRanges = new ArrayList<Range>();
        for (String part : parts) {
            assert !part.contains(",") :
                    "part contains comma. part=\"" + part + "\" rangeString=\"" + rangeString + "\" parts=" + parts;
            Range r = new Range(part);
            origRanges.add(r);
            itRanges.add(new Range(r));
        }
    }

    public String currentToString() {
        String res = "";
        boolean isFirst = true;
        for (Range r : itRanges) {
            if (!isFirst)
                res += ",";

            if (r.to == r.from)
                res += r.to + "";
            else
                res += r.from + "-" + r.to;

            isFirst = false;
        }
        return res;
    }

    public List<Range> getCurrentRanges() {
        return new ArrayList<Range>(itRanges);
    }

    public List<Range> getOriginalRanges() {
        return new ArrayList<Range>(origRanges);
    }


    /* get current vlan (so multiple calls will return te same) returns null if nothing to return. */
    public Integer getCurrent() {
        if (itRanges.isEmpty()) return null;
        Range first = itRanges.get(0);
        assert !first.isEmpty();
        return first.from;
    }

    /**
     * advance iterator and return. (so multiple calls will return increasing values)
     * returns null if nothing to return. safe to call again if nothing to return, keeps returning null.
     */
    public Integer getNext() {
        if (itRanges.isEmpty()) return null;
        Range first = itRanges.get(0);
        assert !first.isEmpty();
        first.from++;
        if (first.isEmpty())
            itRanges.remove(0);
        else
            return first.from;
        if (itRanges.isEmpty()) return null;
        first = itRanges.get(0);
        return first.from;
    }


    /**
     * Returns the total number of ports in the defined range
     *
     * @return
     */
    public int count() {
        int totalCount = 0;

        for (Range r : origRanges) {
            totalCount += r.to - r.from + 1;
        }
        return totalCount;

    }
}
