package be.iminds.ilabt.jfed.lowlevel.api;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;

import java.util.*;

/**
 * FederationSliceAuthorityApi2
 */
public class FederationSliceAuthorityApi2 extends AbstractFederationApi2 {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Slice Authority API v2";
     */
    static public String getApiName() {
        return "Uniform Federation Slice Authority API v2";
    }
    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Slice Authority API v2";
     */
    @Override
    public String getName() {
        return getApiName();
    }

    public FederationSliceAuthorityApi2(Logger logger, boolean autoRetryBusy) {
        super(logger, autoRetryBusy, new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 1));
    }

    public FederationSliceAuthorityApi2(Logger logger) {
        this(logger, true);
    }

    public static class GetVersionSAResult extends GetVersionResult {
        private List<String> services;//only for Slice Authority
        private List<String> roles;//only for Slice Authority
        public GetVersionSAResult(Hashtable<String, Object> versionInfo) throws BadReplyGeniException {
            super(versionInfo);
            services = new ArrayList(apiSpecifiesVectorOfString(versionInfo.get("SERVICES")));

            //roles is optional
            if (versionInfo.get("ROLES") != null)
                roles = new ArrayList(apiSpecifiesVectorOfString(versionInfo.get("ROLES")));
            else
                roles = new ArrayList<String>();
        }

        public List<String> getServices() {
            return services;
        }

        public List<String> getRoles() {
            return roles;
        }

        @Override
        public String toString() {
            return "GetVersionSAResult{" +
                    "version='" + version + '\'' +
                    ", supportedCredentialTypes=" + supportedCredentialTypes +
                    ", fieldInfos=" + fieldInfos +
                    ", services=" + services +
                    ", roles=" + roles +
                    '}';
        }
    }

    @ApiMethod(order=1, hint="get_version call: Provide a structure detailing the version information as well as details of accepted options s for CH API calls.", unprotected=true)
    public FederationApiReply<GetVersionSAResult> getVersion(SfaConnection con)  throws JFedException {
        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "get_version", new Vector(), null);
        FederationApiReply<GetVersionSAResult> r = null;
        try {
            r = new FederationApiReply<GetVersionSAResult>(res, new GetVersionSAResult(apiSpecifiesHashtableStringToObject(res.getResultValueObject())));
        } catch (Throwable e) {
            handleErrorProcessingArguments(res, "getVersion", "get_version", con, e);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<GetVersionSAResult>(res, null);
        log(res, r, "getVersion", "get_version", con, null);
        return r;
    }

    @Override
    public List<String> getApiObjects() {
        List<String> res = new ArrayList<String>();
        res.add("SLICE");
        res.add("PROJECT");
        res.add("SLIVER_INFO");
        return res;
    }

    @Override
    public List<String> getRequiredApiServices() {
        List<String> res = new ArrayList<String>();
        res.add("SLICE");
        return res;
    }

    @Override
    public List<String> getOptionalApiServices() {
        List<String> res = new ArrayList<String>();
        res.add("PROJECT");
        res.add("SLICE_MEMBER");
        res.add("PROJECT_MEMBER");
        res.add("SLIVER_INFO");
        return res;
    }

    @Override
    public List<GetVersionResult.FieldInfo> getMinimumFields(String objectName) {
        List<GetVersionResult.FieldInfo> res = new ArrayList<GetVersionResult.FieldInfo>();
        //String name, FieldType fieldType, CreationAllowed creationAllowed, boolean match, boolean updateable, Protect protect, String object

        if (objectName.equalsIgnoreCase("SLICE")) {
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_URN", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_UID", GetVersionResult.FieldInfo.FieldType.UID, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_CREATION", GetVersionResult.FieldInfo.FieldType.DATETIME, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, false, false));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_EXPIRATION", GetVersionResult.FieldInfo.FieldType.DATETIME, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, false, true));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_EXPIRED", GetVersionResult.FieldInfo.FieldType.BOOLEAN, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_NAME", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, false, false));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_DESCRIPTION", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, false, true));

            //WARNING: special field: SLICE_PROJECT_URN only exists when the server supports the PROJECT service!
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_PROJECT_URN", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, true, false));
        }
        if (objectName.equalsIgnoreCase("PROJECT")) {
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_URN", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_UID", GetVersionResult.FieldInfo.FieldType.UID, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_CREATION", GetVersionResult.FieldInfo.FieldType.DATETIME, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, false, false));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_EXPIRATION", GetVersionResult.FieldInfo.FieldType.DATETIME, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, false, true));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_EXPIRED", GetVersionResult.FieldInfo.FieldType.BOOLEAN, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_NAME", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, false, false));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_DESCRIPTION", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, false, true));
        }
        if (objectName.equalsIgnoreCase("SLIVER_INFO")) {
            res.add(new GetVersionResult.FieldInfo("SLIVER_INFO", "SLIVER_INFO_SLICE_URN", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, true, false));
            res.add(new GetVersionResult.FieldInfo("SLIVER_INFO", "SLIVER_INFO_URN", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, true, false));
            res.add(new GetVersionResult.FieldInfo("SLIVER_INFO", "SLIVER_INFO_AGGREGATE_URN", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, true, false));
            res.add(new GetVersionResult.FieldInfo("SLIVER_INFO", "SLIVER_INFO_CREATOR_URN", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, true, false));
            res.add(new GetVersionResult.FieldInfo("SLIVER_INFO", "SLIVER_INFO_EXPIRATION", GetVersionResult.FieldInfo.FieldType.DATETIME, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, false, true));
            res.add(new GetVersionResult.FieldInfo("SLIVER_INFO", "SLIVER_INFO_CREATION", GetVersionResult.FieldInfo.FieldType.DATETIME, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, false, false));
        }
        return res;
    }


    @ApiMethod(order=2, hint="lookup call: Lookup information about objects matching given criteria", unprotected=true)
    public FederationApiReply<LookupResult> lookup(SfaConnection con,
                                                   @ApiMethodParameter(name = "type", hint="object type to lookup",
                                                           required = true, guiDefault = "SLICE", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                                   String type,
                                                   @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                   List<AnyCredential> credentialList,
                                                   @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                   Map<String, ? extends Object> match,
                                                   @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API2_FILTER)
                                                   List<String> filter,
                                                   @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                   Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("type", type, "credentialList", credentialList, "match", match, "filter", filter, "extraOptions", extraOptions);
        LookupResultConverter conv = null;
        return lookup_internal(methodParams, con, "lookup",
                type, conv,
                credentialList, match, filter, extraOptions,
                null/*extraArguments in front of call*/);
    }

    @ApiMethod(order=3, hint="update call: Update information about object")
    public FederationApiReply<String> update(SfaConnection con,
                                             @ApiMethodParameter(name = "type", hint="object type to update",
                                                     required = true, guiDefault = "SLICE", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                             String type,
                                             @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                             List<AnyCredential> credentialList,
                                             @ApiMethodParameter(name = "urn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                             String urn,
                                             @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                             Map<String, String> fields,
                                             @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                             Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("type", type, "credentialList", credentialList, "urn", urn, "fields", fields, "extraOptions", extraOptions);
        return update_internal(methodParams, con, "update", type, credentialList, urn, null/*urntype*/, fields, extraOptions);
    }

    @ApiMethod(order=4, hint="create method")
    public FederationApiReply<Hashtable<String, Object>> create(SfaConnection con,
                                                                @ApiMethodParameter(name = "type", hint="object type to create",
                                                                        required = true, guiDefault = "SLICE", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                                                String type,
                                                                @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                List<AnyCredential> credentialList,
                                                                @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                                                Map<String, String> fields,
                                                                @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("type", type, "credentialList", credentialList, "type", type, "fields", fields, "extraOptions", extraOptions);
        return create_internal(methodParams, con, "update", type, credentialList, fields, extraOptions);
    }


    @ApiMethod(order=5, hint="delete call: delete an OBJECT")
    public FederationApiReply<Boolean> delete(SfaConnection con,
                                              @ApiMethodParameter(name = "type", hint="object type to delete",
                                                      required = true, guiDefault = "SLICE", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                              String type,
                                              @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                              List<AnyCredential> credentialList,
                                              @ApiMethodParameter(name = "urnToDelete", hint="", parameterType=ApiMethodParameterType.STRING)
                                              String urnToDelete,
                                              @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                              Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("type", type, "credentialList", credentialList, "urnToDelete", urnToDelete, "extraOptions", extraOptions);
        return delete_internal(methodParams, con, "delete", type, credentialList, urnToDelete, extraOptions);
    }




    @ApiMethod(order=10, hint="Convenience method for lookup call: Lookup information about SLICEs matching given criteria", unprotected=true, convenienceMethodFor = "lookup", convenienceMethodObjectType = "SLICE")
    public FederationApiReply<LookupResult> lookupSlice(SfaConnection con,
                                                        @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                        List<AnyCredential> credentialList,
                                                        @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                        Map<String, ? extends Object> match,
                                                        @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API2_FILTER)
                                                        List<String> filter,
                                                        @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                        Map<String, Object> extraOptions)  throws JFedException {
        return lookup(con, "SLICE", credentialList, match, filter, extraOptions);
    }


    @ApiMethod(order=11, hint="Convenience method for update call: Update SLICE information", convenienceMethodFor = "update", convenienceMethodObjectType = "SLICE")
    public FederationApiReply<String> updateSlice(SfaConnection con,
                                                  @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                  List<AnyCredential> credentialList,
                                                  @ApiMethodParameter(name = "sliceUrn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                  GeniUrn sliceUrn,
                                                  @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                                  Map<String, String> fields,
                                                  @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                  Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "sliceUrn", sliceUrn, "fields", fields, "extraOptions", extraOptions);
        return update_internal(methodParams, con, "update", "SLICE", credentialList, sliceUrn.getValue(), "member", fields, extraOptions);
    }


    @ApiMethod(order=12, hint="Convenience method for create call: create SLICE", convenienceMethodFor = "create", convenienceMethodObjectType = "SLICE")
    public FederationApiReply<Hashtable<String, Object>> createSlice(SfaConnection con,
                                                                     @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                     List<AnyCredential> credentialList,
                                                                     @ApiMethodParameter(name = "sliceName", hint="", parameterType=ApiMethodParameterType.STRING)
                                                                     String sliceName,
                                                                     @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                                                     Map<String, String> fields,
                                                                     @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                     Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "fields", fields, "extraOptions", extraOptions);

        Map allFields = new HashMap<String, String>(fields);
        assert !allFields.containsKey("SLICE_NAME") : "Add SLICE_NAME with the sliceName option, not directly in the \"fields\" argument";
        allFields.put("SLICE_NAME", sliceName);

        return create(con, "SLICE", credentialList, allFields, extraOptions);
    }

    //There is no delete SLICE, as slice deletion is never allowed


    @ApiMethod(order=15, hint="get_credentials call: Provide list of credentials (signed statements) for given slice")
    public FederationApiReply<List<AnyCredential>> getCredentials(SfaConnection con,
                                                                  @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                  List<AnyCredential> credentialList,
                                                                  @ApiMethodParameter(name = "sliceUrn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                                  GeniUrn sliceUrn,
                                                                  @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                  Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "credentialList", credentialList, "sliceUrn", sliceUrn, "extraOptions", extraOptions);
        assert sliceUrn != null;

        if (sliceUrn == null || !sliceUrn.getResourceType().equals("slice"))
            LOG.warn("slice URN argument to getCredentials is not a valid slice urn: \""+sliceUrn+"\" (will be used anyway)");

        return getCredentials_internal(methodParams, con, "getCredentials", "SLICE", credentialList, sliceUrn, extraOptions);
    }


    @ApiMethod(order=20, hint="Convenience method for lookup call: Lookup information about SLIVER_INFOs matching given criteria", unprotected=true, convenienceMethodFor = "lookup", convenienceMethodObjectType = "SLIVER_INFO")
    public FederationApiReply<LookupResult> lookupSliverInfo(SfaConnection con,
                                                             @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                             List<AnyCredential> credentialList,
                                                             @ApiMethodParameter(name = "sliceUrn", hint = "convenience argument: SLIVER_INFO_SLICE_URN to add to match argument", parameterType = ApiMethodParameterType.SLICE_URN)
                                                             GeniUrn sliceUrn,
                                                             @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                             Map<String, ? extends Object> match,
                                                             @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API2_FILTER)
                                                             List<String> filter,
                                                             @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                             Map<String, Object> extraOptions)  throws JFedException {

        Map<String, Object> matchArg = new HashMap<String, Object>(match);
        if (sliceUrn != null)
            matchArg.put("SLIVER_INFO_SLICE_URN", sliceUrn.getValue());

        return lookup(con, "SLIVER_INFO", credentialList, matchArg, filter, extraOptions);
    }


    @ApiMethod(order=21, hint="Convenience method for update call: Update SLIVER_INFO information", convenienceMethodFor = "update", convenienceMethodObjectType = "SLIVER_INFO")
    public FederationApiReply<String> updateSliverInfo(SfaConnection con,
                                                       @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                       List<AnyCredential> credentialList,
                                                       @ApiMethodParameter(name = "urn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                       String urn,
                                                       @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                                       Map<String, String> fields,
                                                       @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                       Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "urn", urn, "fields", fields, "extraOptions", extraOptions);
        return update_internal(methodParams, con, "update", "SLIVER_INFO", credentialList, urn, "member", fields, extraOptions);
    }


    @ApiMethod(order=22, hint="Convenience method for create call: create SLIVER_INFO", convenienceMethodFor = "create", convenienceMethodObjectType = "SLIVER_INFO")
    public FederationApiReply<Hashtable<String, Object>> createSliverInfo(SfaConnection con,
                                                                          @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                          List<AnyCredential> credentialList,
                                                                          @ApiMethodParameter(name = "sliceUrn", hint="convenience argument: add SLIVER_INFO_SLICE_URN to fields option", parameterType=ApiMethodParameterType.SLICE_URN)
                                                                          String sliceUrn,
                                                                          @ApiMethodParameter(name = "sliverUrn", hint="convenience argument: add SLIVER_INFO_URN to fields option", parameterType=ApiMethodParameterType.URN)
                                                                          String sliverUrn,
                                                                          @ApiMethodParameter(name = "aggregateUrn", hint="convenience argument: add SLIVER_INFO_AGGREGATE_URN to fields option", parameterType=ApiMethodParameterType.URN)
                                                                          String aggregateUrn,
                                                                          @ApiMethodParameter(name = "creatorUrn", hint="convenience argument: add SLIVER_INFO_CREATOR_URN to fields option", parameterType=ApiMethodParameterType.URN)
                                                                          String creatorUrn,
                                                                          @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                                                          Map<String, String> fields,
                                                                          @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                          Map<String, Object> extraOptions)  throws JFedException {
//        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "sliceUrn", sliceUrn,
//                "sliverUrn", sliverUrn, "aggregateUrn", aggregateUrn, "creatorUrn", creatorUrn, "fields", fields, "extraOptions", extraOptions);
        Map<String, String> allFields = new HashMap<String, String>(fields);

        assert fields.containsKey("SLIVER_INFO_SLICE_URN") == (sliceUrn == null) :
                "Either specify sliceUrn (non-null) or add \"SLIVER_INFO_SLICE_URN\" to \"fields\". (exactly 1 is required)";
        assert fields.containsKey("SLIVER_INFO_URN") == (sliverUrn == null) :
                "Either specify sliverUrn (non-null) or add \"SLIVER_INFO_URN\" to \"fields\". (exactly 1 is required)";
        assert fields.containsKey("SLIVER_INFO_AGGREGATE_URN") == (aggregateUrn == null) :
                "Either specify aggregateUrn (non-null) or add \"SLIVER_INFO_AGGREGATE_URN\" to \"fields\". (exactly 1 is required)";
        assert fields.containsKey("SLIVER_INFO_CREATOR_URN") == (creatorUrn == null) :
                "Either specify creatorUrn (non-null) or add \"SLIVER_INFO_CREATOR_URN\" to \"fields\". (exactly 1 is required)";

        if (sliceUrn != null)
            allFields.put("SLIVER_INFO_SLICE_URN", sliceUrn);
        if (sliverUrn != null)
            allFields.put("SLIVER_INFO_URN", sliverUrn);
        if (aggregateUrn != null)
            allFields.put("SLIVER_INFO_AGGREGATE_URN", aggregateUrn);
        if (creatorUrn != null)
            allFields.put("SLIVER_INFO_CREATOR_URN", creatorUrn);

        return create(con, "SLIVER_INFO", credentialList, allFields, extraOptions);
    }

    @ApiMethod(order=23, hint="Convenience method for delete call: delete a SLIVER_INFO", convenienceMethodFor = "delete", convenienceMethodObjectType = "SLIVER_INFO")
    public FederationApiReply<Boolean> deleteSliverInfo(SfaConnection con,
                                                        @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                        List<AnyCredential> credentialList,
                                                        @ApiMethodParameter(name = "urnToDelete", hint="", parameterType=ApiMethodParameterType.STRING)
                                                        String urnToDelete,
                                                        @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false,
                                                                guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                        Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "urnToDelete", urnToDelete, "extraOptions", extraOptions);
        return delete_internal(methodParams, con, "delete", "SLIVER_INFO", credentialList, urnToDelete, extraOptions);
    }



    @ApiMethod(order=30, hint="Convenience method for lookup call: Lookup information about PROJECTs matching given criteria", unprotected=true, convenienceMethodFor = "lookup", convenienceMethodObjectType = "PROJECT")
    public FederationApiReply<LookupResult> lookupProject(SfaConnection con,
                                                          @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                          List<AnyCredential> credentialList,
                                                          @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                          Map<String, ? extends Object> match,
                                                          @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API2_FILTER)
                                                          List<String> filter,
                                                          @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                          Map<String, Object> extraOptions)  throws JFedException {
        return lookup(con, "PROJECT", credentialList, match, filter, extraOptions);
    }


    @ApiMethod(order=31, hint="Convenience method for update call: Update PROJECT information", convenienceMethodFor = "update", convenienceMethodObjectType = "PROJECT")
    public FederationApiReply<String> updateProject(SfaConnection con,
                                                    @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                    List<AnyCredential> credentialList,
                                                    @ApiMethodParameter(name = "projectUrn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                    GeniUrn projectUrn,
                                                    @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                                    Map<String, String> fields,
                                                    @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                    Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "projectUrn", projectUrn, "fields", fields, "extraOptions", extraOptions);
        return update_internal(methodParams, con, "update", "PROJECT", credentialList, projectUrn.getValue(), "member", fields, extraOptions);
    }


    @ApiMethod(order=32, hint="Convenience method for create call: create PROJECT", convenienceMethodFor = "create", convenienceMethodObjectType = "PROJECT")
    public FederationApiReply<Hashtable<String, Object>> createProject(SfaConnection con,
                                                                       @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                       List<AnyCredential> credentialList,
                                                                       @ApiMethodParameter(name = "projectName", required=false, hint="", parameterType=ApiMethodParameterType.STRING)
                                                                       String projectName,
                                                                       @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API2_FIELDS)
                                                                       Map<String, String> fields,
                                                                       @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                       Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "fields", fields, "extraOptions", extraOptions);


        Map allFields = new HashMap<String, String>(fields);
        assert fields.containsKey("PROJECT_NAME") == (projectName == null) : "Either specify projectName (non-null) or add \"PROJECT_NAME\" to \"fields\". (exactly 1 is required)";
        if (projectName != null)
            allFields.put("PROJECT_NAME", projectName);

        return create(con, "PROJECT", credentialList, allFields, extraOptions);
    }

    @ApiMethod(order=33, hint="Convenience method for delete call: delete a PROJECT", convenienceMethodFor = "delete", convenienceMethodObjectType = "PROJECT")
    public FederationApiReply<Boolean> deleteProject(SfaConnection con,
                                                     @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                     List<AnyCredential> credentialList,
                                                     @ApiMethodParameter(name = "urnToDelete", hint="", parameterType=ApiMethodParameterType.STRING)
                                                     String urnToDelete,
                                                     @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false,
                                                             guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                     Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "urnToDelete", urnToDelete, "extraOptions", extraOptions);
        return delete_internal(methodParams, con, "delete", "PROJECT", credentialList, urnToDelete, extraOptions);
    }



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////// Member Service Methods /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /*
    */

    public static class UrnRoleTuple {
        public final GeniUrn urn;
        public final String typeName;
        public final String role;
        public final Hashtable dictRaw;

        public UrnRoleTuple(String typeName, GeniUrn urn, String role) {
            this.typeName = typeName;
            this.dictRaw = null;
            this.urn = urn;
            this.role = role;
        }
        public UrnRoleTuple(String typeName, String urn, String role) {
            this.typeName = typeName;
            this.dictRaw = null;
            this.urn = GeniUrn.parse(urn);
            this.role = role;
        }
        public UrnRoleTuple(Hashtable dictRaw, String typeName, String urnKeyName, String roleKeyName) throws BadReplyGeniException {
            this.typeName = typeName;
            Hashtable<String, Object> dict = apiSpecifiesHashtableStringToObject(dictRaw);
            String urnString = (String) dict.get(urnKeyName);
            if (urnString == null) throw new BadReplyGeniException("Dictionary should contain keys '"+urnKeyName+"' and '"+roleKeyName+". It contains only: "+dict.keySet());
            assert urnString != null;
            this.urn = GeniUrn.parse(urnString);
            this.role = (String) dict.get(roleKeyName);
            if (role == null) throw new BadReplyGeniException("Dictionary should contain keys '"+urnKeyName+"' and '"+roleKeyName+". It contains only: "+dict.keySet());
            assert role != null;
            this.dictRaw = dictRaw;
        }
        public Vector toVector() {
            Vector v = new Vector(2);
            v.add(urn.toString());
            v.add(role);
            return v;
        }

        public GeniUrn getUrn() {
            return urn;
        }

        public String getRole() {
            return role;
        }

        @Override
        public String toString() {
            return "UrnRoleTuple{" +
                    "urn=\"" + urn +
                    "\", role=\"" + role + "\"" +
                    '}';
        }
    }
    @ApiMethod(order=40, hint="modify_slice_membership call:")
    public FederationApiReply<String> modifyMembership(SfaConnection con,
                                                       @ApiMethodParameter(name = "type", hint="object type for which members need to change",
                                                               required = true, guiDefault = "SLICE", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                                       String type,
                                                       @ApiMethodParameter(name = "urn", hint="", parameterType=ApiMethodParameterType.URN)
                                                       GeniUrn urn,
                                                       @ApiMethodParameter(name = "membersToAdd", hint="", parameterType=ApiMethodParameterType.CH_API_LIST_MEMBER_TUPLES)
                                                       List<UrnRoleTuple> membersToAdd,
                                                       @ApiMethodParameter(name = "membersToRemove", hint="", parameterType=ApiMethodParameterType.LIST_OF_URN_STRING)
                                                       List<GeniUrn> membersToRemove,
                                                       @ApiMethodParameter(name = "membersToChange", hint="", parameterType=ApiMethodParameterType.CH_API_LIST_MEMBER_TUPLES)
                                                       List<UrnRoleTuple> membersToChange,
                                                       @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                       List<AnyCredential> credentialList,
                                                       @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                       Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("type", type, "urn", urn,
                "membersToAdd", membersToAdd, "membersToRemove", membersToRemove, "membersToChange", membersToChange,
                "credentialList", credentialList, "extraOptions", extraOptions);
        String methodApiName = "modify_membership";

        assert credentialList != null;
        assert urn != null;

        Vector args = new Vector(4);
        args.add(type);

        args.add(urn.getValue());

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable options = new Hashtable();
        Vector membersToAddVector = new Vector();
        for (UrnRoleTuple mt : membersToAdd)
            membersToAddVector.add(mt.toVector());
        options.put("members_to_add", membersToAddVector);

        Vector membersToRemoveVector = new Vector();
        for (GeniUrn u : membersToRemove)
            membersToRemoveVector.add(u.toString());
        options.put("members_to_remove", membersToRemoveVector);

        Vector membersToChangeVector = new Vector();
        for (UrnRoleTuple mt : membersToChange)
            membersToChangeVector.add(mt.toVector());
        options.put("members_to_change", membersToChangeVector);
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, methodApiName, args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        //should return nothing at all, but if there is anything, we convert it to string and return it
        FederationApiReply<String> r = new FederationApiReply<String>(res, resultValueObject == null ? null : resultValueObject+"");
        log(res, r, "modifyMembership", methodApiName, con, methodParams);
        return r;
    }

    /*
    */
    @ApiMethod(order=41, hint="lookup_slice_members call:")
    public FederationApiReply<List<UrnRoleTuple>> lookupMembers(SfaConnection con,
                                                                     @ApiMethodParameter(name = "type", hint="object type for which members need to change",
                                                                             required = true, guiDefault = "SLICE", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                                                     String type,
                                                                     @ApiMethodParameter(name = "sliceUrn", hint="", parameterType=ApiMethodParameterType.SLICE_URN)
                                                                     GeniUrn sliceUrn,
                                                                     @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                     List<AnyCredential> credentialList,
                                                                     Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("type", type, "credentialList", credentialList,
                "sliceUrn", sliceUrn, "extraOptions", extraOptions);
        String methodApiName = "lookup_members";
        assert credentialList != null;

        Vector args = new Vector();
        args.add(sliceUrn.toString());
        if (credentialList != null) {
            Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
            args.add(credentials);
        } else
            args.add(new Vector());
        if (extraOptions != null)
            args.add(extraOptions);
        else
            args.add(new Hashtable());

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, methodApiName, args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<List<UrnRoleTuple>> r = null;
        try {
            Vector<Hashtable> resDicts = apiSpecifiesVectorOfT(Hashtable.class, resultValueObject);
            List<UrnRoleTuple> resList = new ArrayList<UrnRoleTuple>();
            for (Hashtable dict : resDicts) {
                resList.add(new UrnRoleTuple(dict, type, type+"_MEMBER", type+"_ROLE"));
            }
            r = new FederationApiReply<List<UrnRoleTuple>>(res, resList);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "lookupMembers", methodApiName, con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<List<UrnRoleTuple>>(res, null);
        log(res, r, "lookupMembers", methodApiName, con, methodParams);
        return r;
    }

    /*
    */
    @ApiMethod(order=42, hint="lookup_for_member call:")
    public FederationApiReply<List<UrnRoleTuple>> lookupForMember(SfaConnection con,
                                                                  @ApiMethodParameter(name = "type", hint="object type for which members need to change",
                                                                          required = true, guiDefault = "SLICE", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                                                  String type,
                                                                  @ApiMethodParameter(name = "memberUrn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                                  GeniUrn memberUrn,
                                                                  @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                  List<AnyCredential> credentialList,
                                                                  @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                  Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("type", type, "credentialList", credentialList, "memberUrn", memberUrn, "extraOptions", extraOptions);
        String methodApiName = "lookup_for_member";
        assert credentialList != null;
        assert memberUrn != null;

        Vector args = new Vector();
        args.add(memberUrn.toString());
        if (credentialList != null) {
            Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
            args.add(credentials);
        } else
            args.add(new Vector());
        if (extraOptions != null)
            args.add(extraOptions);
        else
            args.add(new Hashtable());

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, methodApiName, args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<List<UrnRoleTuple>> r = null;
        try {
            Vector<Hashtable> resDicts = apiSpecifiesVectorOfT(Hashtable.class, resultValueObject);
            List<UrnRoleTuple> resList = new ArrayList<UrnRoleTuple>();
            for (Hashtable dict : resDicts) {
                resList.add(new UrnRoleTuple(dict, type, type+"_URN", type+"_ROLE"));
            }
            r = new FederationApiReply<List<UrnRoleTuple>>(res, resList);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "lookupForMember", methodApiName, con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<List<UrnRoleTuple>>(res, null);
        log(res, r, "lookupForMember", methodApiName, con, methodParams);
        return r;
    }



//    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    /////////////////////////////////// Sliver Info Service API /////////////////////////////////////////////////
//    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    /*
//        # Create a record of a sliver creation
//        #
//        # Arguments:
//        #   options: 'fields' containing the fields for the sliver info  being registered at SA
//        #
//        # Return:
//        # Dictionary of name/value pairs for created sliver_info record
//    */
//    @ApiMethod(order=9, hint="register_aggregate call:")
//    public FederationApiReply<Hashtable<String, Object>> createSliverInfo(SfaConnection con,
//                                                                          @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
//                                                                          List<AnyCredential> credentialList,
//                                                                          @ApiMethodParameter(name = "sliceUrn", hint="convenience argument: SLIVER_INFO_SLICE_URN to add to fields option", parameterType=ApiMethodParameterType.SLICE_URN)
//                                                                          String sliceUrn,
//                                                                          @ApiMethodParameter(name = "sliverUrn", hint="convenience argument: SLIVER_INFO_URN to add to fields option", parameterType=ApiMethodParameterType.URN)
//                                                                          String sliverUrn,
//                                                                          @ApiMethodParameter(name = "aggregateUrn", hint="convenience argument: SLIVER_INFO_AGGREGATE_URN to add to fields option", parameterType=ApiMethodParameterType.URN)
//                                                                          String aggregateUrn,
//                                                                          @ApiMethodParameter(name = "creatorUrn", hint="convenience argument: SLIVER_INFO_CREATOR_URN to add to fields option", parameterType=ApiMethodParameterType.URN)
//                                                                          String creatorUrn,
//                                                                          @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API_FIELDS)
//                                                                          Map<String, String> fields,
//                                                                          @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
//                                                                          Map<String, Object> extraOptions)  throws JFedException {
//        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "sliceUrn", sliceUrn,
//                "sliverUrn", sliverUrn, "aggregateUrn", aggregateUrn, "creatorUrn", creatorUrn, "fields", fields, "extraOptions", extraOptions);
//
//        assert credentialList != null;
//
//        Vector args = new Vector(2);
//        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
//        args.add(credentials);
//
//        Hashtable<String, String> fieldsHashtable = new Hashtable<String, String>(fields);
//
//        assert fieldsHashtable.containsKey("SLIVER_INFO_SLICE_URN") == (sliceUrn == null) : "Either specify sliceUrn (non-null) or add \"SLIVER_INFO_SLICE_URN\" to \"fields\". (exactly 1 is required)";
//        assert fieldsHashtable.containsKey("SLIVER_INFO_URN") == (sliverUrn == null) : "Either specify sliverUrn (non-null) or add \"SLIVER_INFO_URN\" to \"fields\". (exactly 1 is required)";
//        assert fieldsHashtable.containsKey("SLIVER_INFO_AGGREGATE_URN") == (aggregateUrn == null) : "Either specify aggregateUrn (non-null) or add \"SLIVER_INFO_AGGREGATE_URN\" to \"fields\". (exactly 1 is required)";
//        assert fieldsHashtable.containsKey("SLIVER_INFO_CREATOR_URN") == (creatorUrn == null) : "Either specify creatorUrn (non-null) or add \"SLIVER_INFO_CREATOR_URN\" to \"fields\". (exactly 1 is required)";
//
//        if (sliceUrn != null)
//            fieldsHashtable.put("SLIVER_INFO_SLICE_URN", sliceUrn);
//        if (sliverUrn != null)
//            fieldsHashtable.put("SLIVER_INFO_URN", sliverUrn);
//        if (aggregateUrn != null)
//            fieldsHashtable.put("SLIVER_INFO_AGGREGATE_URN", aggregateUrn);
//        if (creatorUrn != null)
//            fieldsHashtable.put("SLIVER_INFO_CREATOR_URN", creatorUrn);
//
//        Hashtable optionsHashtable = new Hashtable();
//        optionsHashtable.put("fields", fieldsHashtable);
//        if (extraOptions != null)
//            optionsHashtable.putAll(extraOptions);
//        args.add(optionsHashtable);
//
//        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "create_project", args, methodParams);
//        Object resultValueObject = res.getResultValueObject();
//        FederationApiReply<Hashtable<String, Object>> r = null;
//        try {
//            Hashtable<String, Object> resHashtable = apiSpecifiesHashtableStringToObject(resultValueObject);
//            r = new FederationApiReply<Hashtable<String, Object>>(res, resHashtable);
//        } catch (Throwable t) {
//            handleErrorProcessingArguments(res, "createSliverInfo", "create_sliver_info", con, t);
//            r = null;
//        }
//
//        if (r == null)
//            r = new FederationApiReply<Hashtable<String, Object>>(res, null);
//        log(res, r, "createSliverInfo", "create_sliver_info", con, methodParams);
//        return r;
//    }
//




}
