package be.iminds.ilabt.jfed.lowlevel.stitching;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.ServerType;
import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

/**
 * StitchingCallData contains all data about a specific "CreateSLiver" call.
 * This means it contains all data about all hops for the called AM
 *
 * It is uniquely identified by the AM urn
 *
 * It also stores:
 *    - which VLAN's have failed and which vlan succeeded
 *    - how many other failures there where
 *    - logs for all calls
 *    - current status (simple): sliverExists true or false
 *
 * It also stores dependencies to other StitchingCallData. To create:
 *   - first create it,
 *   - then add all StitchingHopData,
 *   - then call linkDeps
 */
public class StitchingCallData {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    private final GeniUrn authUrn;
    private final String authUrnString;
    private final SfaAuthority auth;

    private final List<StitchingHopData> hopData = new ArrayList<StitchingHopData>();

    //links (initialised after linkDeps call)
    private List<StitchingCallData> dependencies = new ArrayList<StitchingCallData>();
    private List<StitchingCallData> dependingOnThis = new ArrayList<StitchingCallData>();

    private Set<Integer> unavailableVlans = new HashSet<Integer>();
    private boolean done = false;

    public StitchingCallData(String authUrnString, String authUrlString, AuthorityListModel authList) {
        this.authUrnString = authUrnString;
        this.authUrn = GeniUrn.parse(authUrnString);
        assert authUrn != null;

        SfaAuthority aggAuth = authList.getByUrn(authUrnString);
        if (aggAuth == null) {
            logger.debug("Unknown Hop aggregate \""+authUrnString+"\". Registering aggregate.");

            if (authUrlString.startsWith("http://")) {
                logger.warn("Aggregate URL in hop is http instead of https! "+
                        "This is unsecure, so this connection protocol will never be used. "+
                        "Trying to fix automatically: Changing http to https (might not work). url="+authUrlString);
                authUrlString = authUrlString.replaceFirst("http", "https");
            }

            Map< ServerType, URL > urls = new HashMap< ServerType, URL >();
            try {
                urls.put(new ServerType(ServerType.GeniServerRole.AM, 2), new URL(authUrlString));
            } catch (MalformedURLException e) {
                throw new RuntimeException("Aggregate URL in hop info is not a valid URL: "+authUrlString);
            }
            SfaAuthority newAuth = null;
            try {
                newAuth = new SfaAuthority(authUrnString, authUrnString, urls, null/*proxies*/, null, "stitching-hop-aggregate");
            } catch (JFedException e) {
                throw new RuntimeException("Error creating SfaAuthority for hop: cannot continue");
            }
            authList.addAuthority(newAuth); //wil update authList automatically
            aggAuth = newAuth;
            assert aggAuth != null : "Bug: Adding newly created SfaAuthority seems to have failed";
        }
        auth = aggAuth;
    }

    public void addHopData(StitchingHopData hop) {
        assert !hopData.contains(hop);
        hopData.add(hop);
    }
    public StitchingHopData getHopData(String linkName, String hopUrn) {
        for (StitchingHopData hop : hopData) {
            if (hop.getLinkName().equals(linkName) && hop.getHopUrn().equals(hopUrn))
                return hop;
        }
        return null;
    }

    public void linkDeps(Collection<StitchingCallData> allData) {
        for (StitchingCallData d : allData)
            if (d != this && !dependencies.contains(d))
                for (StitchingHopData othersHop : d.hopData)
                    for (StitchingHopData myHop : hopData) {
                        if (myHop.getDependencies().contains(othersHop)) {
                            if (!dependencies.contains(d)) {
                                dependencies.add(d);
                                d.dependingOnThis.add(this);
                            }
                        }
                }
    }







    /**
     * Update rspec info from rspec received from this authroity in reply to a CreateSliver call.
     *
     * This will change the suggested and available VLAN.
     *
     * It will only change hops related to this authority!
     * */
    public void updateInfo(String rspec) {
        for (StitchingHopData hop : hopData)
            hop.overwriteWithManifestRspec(rspec);
    }


    /**
     * @returns true if configuration still possible
     *  false if not enough available VLAN's are left
     */
    public boolean setVlanUnavailable(int vlan) {
        //find remaining available VLAN and update hops suggestedVLAN with it
        //keep in account that each hop with same urn but different linkName needs a different VLAN!

        logger.trace("setVlanUnavailable({})", vlan);

        unavailableVlans.add(vlan);
        Map<String, Set<Integer>> vlansUsedByHopUrn = new HashMap<String, Set<Integer>>();
        for (StitchingHopData hop : hopData) {
            logger.trace("hop="+hop.getHopUrn()+"  suggestedVlan="+hop.getSuggestedVlan());
            Set<Integer> s = vlansUsedByHopUrn.get(hop.getHopUrn());
            if (s == null)
                s = new HashSet<Integer>();
            s.add(hop.getSuggestedVlan());
            vlansUsedByHopUrn.put(hop.getHopUrn(), s);
        }
        logger.trace("vlansUsedByHopUrn="+vlansUsedByHopUrn);

        for (StitchingHopData hop : hopData) {
            Set<Integer> sameHopVlans = vlansUsedByHopUrn.get(hop.getHopUrn());
            Integer origVlan = hop.getSuggestedVlan();

            Set<Integer> allForbiddenVLANs = new HashSet<Integer>(sameHopVlans);
            allForbiddenVLANs.remove(origVlan); //remove own vlan, will be added again line below if unavailable
            allForbiddenVLANs.addAll(unavailableVlans);

            //find a new VLAN if old is not available anymore
            logger.debug("hop "+hop.getHopUrn()+" current suggestion="+hop.getSuggestedVlan()+" updateSuggestedVlan: forbidden="+allForbiddenVLANs);
            if (allForbiddenVLANs.contains(origVlan)) {
                Integer foundVlan = hop.updateSuggestedVlan(allForbiddenVLANs);
                logger.debug("    updated hop VLAN to foundVlan={}", foundVlan);
                if (foundVlan == null)
                    return false;
                else
                    sameHopVlans.add(foundVlan);
                if (!foundVlan.equals(origVlan))
                    sameHopVlans.remove(origVlan);
            } else
                logger.debug("   leaving log VLAN unchanged");
        }

        //all was successfully updated
        return true;
    }
    public Set<Integer> getUnavailableVlans() {
        return Collections.unmodifiableSet(unavailableVlans);
    }

    public List<Integer> getSuggestedVlans() {
        List<Integer> res = new ArrayList<Integer>();
        for (StitchingHopData hop : hopData)
            res.add(hop.getSuggestedVlan());
        return res;
    }


    public boolean isDone() {
        return done;
    }
    public boolean isReady() {
        if (done) return false;

        for (StitchingCallData dep : dependencies)
            if (!dep.isDone())
                return false;

        return true;
    }
    public void setDone(boolean done) {
        this.done = done;
        if (done)
            for (StitchingCallData dep : dependencies)
                assert dep.isDone();
    }



    public List<StitchingCallData> getDependencies() {
        return Collections.unmodifiableList(dependencies);
    }
    public List<StitchingCallData> getDependingOnThis() {
        return Collections.unmodifiableList(dependingOnThis);
    }
    public GeniUrn getAuthUrn() {
        return authUrn;
    }
    public String getAuthUrnString() {
        return authUrnString;
    }
    public SfaAuthority getAuth() {
        return auth;
    }

    @Override
    public String toString() {
        List<String> depUrns = new ArrayList<String>();
        for (StitchingCallData stitchingCallData : dependencies)
            depUrns.add(stitchingCallData.getAuthUrnString());
        String hopDataString = "{";
        for (StitchingHopData stitchingHopData : hopData)
            hopDataString += "\n        "+stitchingHopData;
        hopDataString += "}";

        return "StitchingCallData{" +
                "authUrnString='" + authUrnString + '\'' +
                ", hopData=" + hopDataString +
                ", dependencies (urns)=" + depUrns +
                '}';
    }
}
