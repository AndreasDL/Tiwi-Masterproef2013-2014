package be.iminds.ilabt.jfed.lowlevel.userloginmodel;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.GeniUser;
import be.iminds.ilabt.jfed.lowlevel.GeniUserProvider;
import be.iminds.ilabt.jfed.lowlevel.SimpleGeniUser;
import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.IOUtils;
import be.iminds.ilabt.jfed.util.JFedUtils;
import be.iminds.ilabt.jfed.util.KeyUtil;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.logging.log4j.LogManager;

import java.io.File;
import java.io.IOException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

/**
 * UserLoginModelManager acts as a UserLoginModel, by refering to a specific UserLoginModel implementation
 *   UserLoginModelManager has 2 "states"
 *     - itself is a UserLoginModel (GeniUser + GeniUserProvider) that is the active, logged in user
 *     - it gives access to a modifiable UserLoginModel, changes to this model can be committed to the active model
 * <p/>
 * <p/>
 * UserLoginModel is a GeniUser + a GeniUserProvider
 * <p/>
 * GeniUser stores all preferences related to the user login:
 *   - SSL key and certificate file
 * <p/>
 *   it also stores the derived data that is often needed
 *   - authority to use
 *      - info about authority
 *      (stores urn separately, for cases where authority is not known, but urn is)
 *   - username
 *   - user urn
 * <p/>
 * It does not store any passwords (memory or disk), but it does store the unencrypted private key in memory (never on disk *)
 * <p/>
 * (* = the password might off course have been read from a file on disk where it already is in unencrypted form.)
 * <p/>
 * <p/>
 * GeniUserProvider is an interface for accessing the the currently logged in user. It allows for no user to be logged in
 * <p/>
 * <p/>
 * UserLoginModel is an implementation of GeniUser that is used as the underlying model for a control implementing a user login
 * UserLoginModel does not actually store much itself: it stores the real UserLoginModel implementation, which comes in
 * different versions. It does manage the preferences file, which also specifies which subtype is used.
 * <p/>
 * Note that UserLoginModel can be in invalid states, like GeniUserProvider. GeniUser cannot be.
 */
public class UserLoginModelManager implements GeniUser, GeniUserProvider {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();
    private final PropertiesConfiguration config;// = loadConfiguration();

    //    private static String KEY_CERT_INTERNAL_INFO = "KeyCertPemFileWithInternalInfo";
//    private static String KEY_CERT_EXTERNAL_INFO = "KeyCertPemFileWithExternalInfo";
//    private static String PLANETLAB = "Planetlab";
    private GeniUser loggedInUser;
    private UserLoginModelType modelType;

    private KeyCertUserLoginModel keyCertUserLoginModel = null;
    private KeyCertWithManualInfoUserLoginModel keyCertWithManualInfoUserLoginModel = null;
    private PlanetlabUserLoginModel planetlabUserLoginModel = null;

//    private final Preferences preferences;
    private AuthorityListModel authorityListModel;
    private Logger logger;

    public UserLoginModelManager(AuthorityListModel authorityListModel, Logger logger) {
        this.authorityListModel = authorityListModel;
        this.logger = logger;

        Preferences prefsRoot = Preferences.userRoot();
//        preferences = prefsRoot.node("be.iminds.ilabt.jfed.ui.userloginmodel.UserLoginModelManager");
        config = loadConfiguration();
        load();
    }

    static PropertiesConfiguration loadConfiguration() {
        PropertiesConfiguration config;
        try {
            String userDataDir = JFedUtils.getUserDataDirectory();

            if (userDataDir == null)
                throw new RuntimeException("Could not access user data directory. Do you have sufficient rights to access the file system?");

            File propertiesFile = new File(userDataDir, "login.properties");

            if(!propertiesFile.exists()){
                propertiesFile.createNewFile();
            }

            config = new PropertiesConfiguration(propertiesFile);
            config.setAutoSave(true);
        } catch (ConfigurationException e) {
            LOG.error("Could not create PropertiesConfiguration", e);
            throw new RuntimeException(e);
        } catch (IOException e) {
            LOG.error("Could not create PropertiesConfiguration", e);
            throw new RuntimeException(e);
        }

        return config;
    }

    @Override
    public GeniUser getLoggedInGeniUser() {
        if (isUserLoggedIn())
            return this; //or   loggedInUser     difference: this updates automatically,loggedInUser is fixed forever
        else
            return null;
    }

    @Override
    public boolean isUserLoggedIn() {
        return loggedInUser != null;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public PrivateKey getPrivateKey() {
        if (loggedInUser == null) return null;
        return loggedInUser.getPrivateKey();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public PublicKey getPublicKey() {
        List<X509Certificate> certificateChain = getClientCertificateChain();
        if (certificateChain == null || certificateChain.isEmpty())
            return null;
        return certificateChain.get(0).getPublicKey();
    }

    @Override
    public List<X509Certificate> getClientCertificateChain() {
        if (loggedInUser == null) return null;
        return loggedInUser.getClientCertificateChain();
    }

    @Override
    public SfaAuthority getUserAuthority() {
        if (loggedInUser == null) return null;
        return loggedInUser.getUserAuthority();
    }

    @Override
    public String getUserUrnString() {
        if (loggedInUser == null) return null;
        return loggedInUser.getUserUrnString();
    }

    @Override
    public GeniUrn getUserUrn() {
        if (loggedInUser == null) return null;
        return loggedInUser.getUserUrn();
    }

    @Override
    public File getPrivateKeyFile() {
        if (loggedInUser == null) return null;
        return loggedInUser.getPrivateKeyFile();
    }

    @Override
    public File getCertificateFile() {
        if (loggedInUser == null) return null;
        return loggedInUser.getCertificateFile();
    }

    public void save() {
        LOG.debug("UserLoginModelManager.save()   modelType=" + modelType);

        UserLoginModelPreferences prefsToSave = new UserLoginModelPreferences();
        prefsToSave.put("type", modelType.toString());
        getCurrentUserLoginModel().save(prefsToSave);

        prefsToSave.save(config);
    }

    public boolean hasChanged() {
        UserLoginModelPreferences savedPrefs = new UserLoginModelPreferences();
        savedPrefs.load(config);

        UserLoginModelPreferences activePrefs = new UserLoginModelPreferences();
        activePrefs.put("type", modelType.toString());
        getCurrentUserLoginModel().save(activePrefs);

        return !savedPrefs.equals(activePrefs);
    }

    public void reset() {
        modelType = UserLoginModelType.KEY_CERT_INTERNAL_INFO;
        getCurrentUserLoginModel().defaults();
    }

    public void load() {
        UserLoginModelPreferences savedPrefs = new UserLoginModelPreferences();
        savedPrefs.load(config);

        String typeString = savedPrefs.get("type", null);

        if (typeString != null) {
            modelType = UserLoginModelType.valueOf(typeString);
            if (modelType == null) {
                String allVals = "";
                for (UserLoginModelType v : UserLoginModelType.values()) allVals += " " + v.toString();
                LOG.error("BUG: Unknown modelType: \"" + typeString + "\" valid types:" + allVals);
                reset();
                return;
            }
        } else
            modelType = null;

        if (modelType == null) {
            reset();
            return;
        }

        getCurrentUserLoginModel().load(savedPrefs);
    }

    public UserLoginModelType getUserLoginModelType() {
        return modelType;
    }

    public void setUserLoginModelType(UserLoginModelType newModelType) {
        this.modelType = newModelType;
    }

    public UserLoginModel getCurrentUserLoginModel() {
        switch (modelType) {
            case KEY_CERT_INTERNAL_INFO:
                return getKeyCertUserLoginModel();
            case KEY_CERT_EXTERNAL_INFO:
                return getKeyCertWithManualInfoUserLoginModel();
            case PLANETLAB:
                return getPlanetlabUserLoginModel();
            default:
                throw new RuntimeException("No support for modelType " + modelType);
        }
    }

    public KeyCertUserLoginModel getKeyCertUserLoginModel() {
        if (keyCertUserLoginModel == null) {
            keyCertUserLoginModel = new KeyCertUserLoginModel(authorityListModel, this);
            keyCertUserLoginModel.defaults();
        }

        return keyCertUserLoginModel;
    }

    public KeyCertWithManualInfoUserLoginModel getKeyCertWithManualInfoUserLoginModel() {
        if (keyCertWithManualInfoUserLoginModel == null) {
            keyCertWithManualInfoUserLoginModel = new KeyCertWithManualInfoUserLoginModel(authorityListModel, this);
            keyCertWithManualInfoUserLoginModel.defaults();
        }

        return keyCertWithManualInfoUserLoginModel;
    }

    public PlanetlabUserLoginModel getPlanetlabUserLoginModel() {
        if (planetlabUserLoginModel == null) {
            planetlabUserLoginModel = new PlanetlabUserLoginModel(authorityListModel, this, logger);
            planetlabUserLoginModel.defaults();
        }

        return planetlabUserLoginModel;
    }


    public boolean login() {
        UserLoginModel model = getCurrentUserLoginModel();
        if (!model.isUserLoggedIn()) return false;
        loggedInUser = new SimpleGeniUser(model);
        fireChange();
        return true;
    }

    public void logout() {
        loggedInUser = null;
        fireChange();
    }


    public UserLoginModelType getUserLoginModelTypeFromFile(File file) {
        try {
            String content = IOUtils.fileToString(file);

            boolean containsKey = KeyUtil.hasAnyPrivateKey(content);
            boolean containsCert = KeyUtil.hasX509Certificate(content);
            boolean containsSfaHrn = content.contains("#planetlab.sfa.hrn = ");

            if (containsKey && containsCert)
                return UserLoginModelType.KEY_CERT_INTERNAL_INFO;

            if (containsKey && containsSfaHrn)
                return UserLoginModelType.PLANETLAB;

            if (containsKey && !containsCert)
                return UserLoginModelType.PLANETLAB;

            return null;
        } catch (IOException e) {
            return null;
        }
    }

    @Override
    public boolean equals(Object o) {
        throw new RuntimeException("unimplemented");
//        if (this == o) return true;
//
//        //TODO
//
//        return true;
    }

    @Override
    public int hashCode() {
        throw new RuntimeException("unimplemented");
//        //TODO
//        return result;
    }


    public static interface UserLoginListener {
        public void onUserLogin(UserLoginModelManager userLoginModel, boolean valid);
    }
    private List<UserLoginListener> changeListeners = new ArrayList<UserLoginListener>();
    private void fireChange() {
        for (UserLoginListener l : changeListeners)
            l.onUserLogin(this, isUserLoggedIn());
    }
    public void addUserLoginListener(UserLoginListener l) {
        changeListeners.add(l);
    }
    public void removeUserLoginListener(UserLoginListener l){
        changeListeners.remove(l);
    }


 public enum UserLoginModelType {
        KEY_CERT_INTERNAL_INFO, KEY_CERT_EXTERNAL_INFO, PLANETLAB
    }

    //hack to be able to see if preferences changed.
    //   not using a real Preferences implementation, only the very small subset that is used is in here
    class UserLoginModelPreferences {

        private final Map<String, Object> map = new HashMap<String, Object>();

        public UserLoginModelPreferences() {
        }

        public void save(PropertiesConfiguration config) {
            try {
                config.clear();

                for (Map.Entry<String, Object> e : map.entrySet()) {
                    if (e.getValue() == null) continue;
                    if (e.getValue() instanceof Boolean) {
                        Boolean v = (Boolean) e.getValue();
                        config.setProperty(e.getKey(), v);
                    } else {
                        config.setProperty(e.getKey(), e.getValue().toString());
                    }
                }

                config.save();
//            } catch (BackingStoreException e) {
//                throw new RuntimeException("Problem with internal Login data storage", e);
            } catch (ConfigurationException e) {
                throw new RuntimeException("Problem saving login configuration", e);
            }
        }

        public void load(PropertiesConfiguration config) {
//            try {
                Iterator<String> keys = config.getKeys();

                map.clear();

                while (keys.hasNext()) {
                    String key = keys.next();
                    Object val = config.getProperty(key);
                    if (val != null && val instanceof String) {
                        String sval = (String) val;
                        if (sval.equalsIgnoreCase("true") || sval.equalsIgnoreCase("false")) {
                            map.put(key, new Boolean(sval.equalsIgnoreCase("true")));
                        } else {
                            map.put(key, sval);
                        }
                    }
                    if (val != null && val instanceof Boolean) {
                        Boolean bval = (Boolean) val;
                        map.put(key, bval);

                    }
                }

//            } catch (BackingStoreException e) {
//                throw new RuntimeException("Problem with internal Login data storage", e);
//            }
        }

        public void put(String key, String value) {
            map.put(key, value);
        }

        public void putBoolean(String key, boolean value) {
            map.put(key, new Boolean(value));
        }

        public String get(String key, String defaultValue) {
            Object r = map.get(key);
            if (r == null) return defaultValue;
            return r.toString();
        }

        public Boolean getBoolean(String key, Boolean defaultValue) {
            Object v = map.get(key);
            if (v != null && v instanceof Boolean)
                return (Boolean) v;
            return defaultValue;
        }

        public void remove(String key) {
            map.remove(key);
        }

        @Override
        public String toString() {
            return "UserLoginModelPreferences" + map + "";
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            UserLoginModelPreferences that = (UserLoginModelPreferences) o;

            if (!map.equals(that.map)) return false;

            return true;
        }

        @Override
        public int hashCode() {
            return map.hashCode();
        }
    }
}
