package be.iminds.ilabt.jfed.lowlevel.stitching;

import be.iminds.ilabt.jfed.lowlevel.GeniAMResponseCode;
import be.iminds.ilabt.jfed.lowlevel.api.AbstractGeniAggregateManager;
import be.iminds.ilabt.jfed.lowlevel.api.StitchingComputationService;
import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.XmlUtil;
import org.apache.logging.log4j.LogManager;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.*;

/**
 * Stitcher
 */
public class StitchingDirector {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    private static boolean automaticNextSuggestedVlan = true;



    private final AuthorityListModel authList;
    private boolean insecure;

    private StitchingComputationService.ComputePathResult computePathResult;
    private StitchingData computePathResultStitchingData;

    private Set<SfaAuthority> allAuthorities = new HashSet<SfaAuthority>();
    private Set<SfaAuthority> activelyInvolvedAuthorities = new HashSet<SfaAuthority>();


    public StitchingDirector(AuthorityListModel authList) {
        this.authList = authList;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public synchronized void setComputePathResult(StitchingComputationService.ComputePathResult computePathResult) {
        this.computePathResult = computePathResult;

        assert computePathResult != null;

        assert computePathResult.getWorkflowData() != null;

        computePathResultStitchingData = new StitchingData(computePathResult.getServiceRspec(), computePathResult.getWorkflowData(), authList);
        for (StitchingCallData stitchingCallData : computePathResultStitchingData.getOrderedStitchingCallDataList())
            allAuthorities.add(stitchingCallData.getAuth());
    }

    public class ReadyAuthorityDetails {
        private final SfaAuthority authority;
        private final String requestRspec;
        private final StitchingCallData stitchingCallData; //not accessable outside of this class

        //List of all suggestedVlans for hops of this authority
        private List<Integer> vlans;

        private ReadyAuthorityDetails(SfaAuthority authority, String requestRspec, List<Integer> vlans, StitchingCallData stitchingCallData) {
            this.authority = authority;
            this.requestRspec = requestRspec;
            this.stitchingCallData = stitchingCallData;
            this.vlans = vlans;
        }

        public SfaAuthority getAuthority() {
            return authority;
        }

        public String getRequestRspec() {
            return requestRspec;
        }

        @Override
        public String toString() {
            return "ReadyHopDetails{" +
                    ", vlans=" + vlans +
                    ", authority=" + authority +
                    '}';
        }
    }

    public synchronized List<ReadyAuthorityDetails> getReadyHops() {
        assert computePathResult != null : "Call setComputePathResult first";
        assert computePathResultStitchingData  != null : "Call setComputePathResult first";

        List<ReadyAuthorityDetails> res = new ArrayList<ReadyAuthorityDetails>();

        for (StitchingCallData stitchingCallData : computePathResultStitchingData.getOrderedStitchingCallDataList()) {
            if (stitchingCallData.isReady()) {
                logger.debug("getReadyHops() creates ReadyAuthorityDetails for "+stitchingCallData.getAuth().getNameForUrn()+" vlans="+stitchingCallData.getSuggestedVlans());
                ReadyAuthorityDetails readyAuthorityDetails = new ReadyAuthorityDetails(
                        stitchingCallData.getAuth(),
                        computePathResultStitchingData.getCurrentRequestRspec(),
                        stitchingCallData.getSuggestedVlans(),
                        stitchingCallData);
                res.add(readyAuthorityDetails);
            }
        }

        return res;
    }
    /**
     * ready hops and hops waiting for deps. not hops that have returned manifest.
     * */
    public synchronized List<SfaAuthority> getHopsLeft() {
        assert computePathResult != null : "Call setComputePathResult first";
        assert computePathResultStitchingData  != null : "Call setComputePathResult first";

        List<SfaAuthority> res = new ArrayList<SfaAuthority>();

        for (StitchingCallData stitchingCallData : computePathResultStitchingData.getOrderedStitchingCallDataList())
            if (!stitchingCallData.isDone())
                res.add(stitchingCallData.getAuth());

        return res;
    }

    public synchronized void processFailure(ReadyAuthorityDetails readyHopDetails) {
        //TODO? (do we need this in the first place?)
    }

    /**
     * returns true if failure.
     * returns false if success, or if director wants to try again.
     * */
    public synchronized boolean processCreateSliverResult(ReadyAuthorityDetails hop, AbstractGeniAggregateManager.AggregateManagerReply<String> reply) {
        logger.debug("processCreateSliverResult with hop="+hop+" hop.vlans="+hop.vlans+" reply.code="+reply.getGeniResponseCode()+" reply.output="+reply.getOutput());

        /*
         * Special case:   geni error code 1 '1 Bad Arguments: malformed arguments'  with output like 'vlan tag 3748 for 'link0' not available'
         *
         * Solution try again with different VLAN!
         */

        //don't care if it's failure or not: it is involved now!
        if (!activelyInvolvedAuthorities.contains(hop.getAuthority()))
            activelyInvolvedAuthorities.add(hop.getAuthority());

        //if vlan not available
        if (reply.getGeniResponseCode().equals(GeniAMResponseCode.GENIRESPONSE_BADARGS) &&
                reply.getOutput() != null &&
                reply.getOutput().startsWith("vlan tag") && reply.getOutput().endsWith("not available")) {

            if (automaticNextSuggestedVlan) {
                logger.debug("detected error \"vlan tag ... not available\" will try to pick other VLAN automatically. hop.vlans="+hop.vlans);

                //only try 5 different vlans
                if (hop.stitchingCallData.getUnavailableVlans().size() > 5) {
                    logger.debug("error \"vlan tag ... not available\" received too many times. Giving up.   hop.vlans="+hop.vlans+"  unavailable="+hop.stitchingCallData.getUnavailableVlans());
                    return false;
                }

                String vlanPart = reply.getOutput().replaceAll("vlan tag ([0-9]*) for .* not available", "$1");
                if (vlanPart != null && !vlanPart.isEmpty()) {
                    logger.trace("detected that vlan \""+vlanPart+"\" is unavailable.");
                    hop.stitchingCallData.setVlanUnavailable(Integer.parseInt(vlanPart));
                }
                else {
                    logger.warn("Could not find vlan in returned error output \""+reply.getOutput()+"\" (found \""+vlanPart+"\"). " +
                            "Will mark all used vlans as unavailable as fallback: "+hop.vlans);

                    assert hop.vlans != null;
                    assert !hop.vlans.isEmpty();

                    for (int vlan : hop.vlans)
                        hop.stitchingCallData.setVlanUnavailable(vlan);
                }
                return false;
            } else {
                logger.debug("error \"vlan tag ... not available\" received while setting automaticNextSuggestedVlan=false. hop.vlans="+hop.vlans);
                return true;
            }
        } else {
            if (reply.getGeniResponseCode().isSuccess()) {
                logger.debug("CreateSliver call successful. processing manifest.");
                processManifest(hop, reply.getValue());
                return false;
            } else {
                logger.debug("Detected error that cannot be handled in CreateSliver. Giving up on stitching.");
                return true;
            }
        }
    }

    private synchronized void processManifest(ReadyAuthorityDetails readyHopDetails, String manifestRspec) {
        StitchingCallData stitchingCallData = readyHopDetails.stitchingCallData;
        stitchingCallData.updateInfo(manifestRspec);
        stitchingCallData.setDone(true);
    }

    /** List of all authorities that are or have been already involved somehow. Mostly useful for calling Delete */
    public synchronized List<SfaAuthority> getActivelyInvolvedAuthorities() {
        return new ArrayList<SfaAuthority>(activelyInvolvedAuthorities);
    }

    /** List of all authorities that are, have been or will be involved. */
    public synchronized List<SfaAuthority> getAllAuthorities() {
        return new ArrayList<SfaAuthority>(allAuthorities);
    }






    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private static Element quickDomChildHelper(Element e, String tagName) {
        NodeList resList = e.getElementsByTagName(tagName);
        assert resList.getLength() == 1;
        Node resNode = resList.item(0);
        assert resNode != null;
        assert resNode.getNodeType() == Node.ELEMENT_NODE;
        Element resElement = (Element) resNode;
        return resElement;
    }
    private static List<Element> quickDomChildrenHelper(Element e, String tagName) {
        NodeList resList = e.getElementsByTagName(tagName);
        List<Element> resElements = new ArrayList<Element>();
        for (int i = 0 ; i < resList.getLength(); i++) {
            Node resNode = resList.item(i);
            assert resNode != null;
            assert resNode.getNodeType() == Node.ELEMENT_NODE;
            Element resElement = (Element) resNode;
            resElements.add(resElement);
        }
        return resElements;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////// API helpers //////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private static void apiAssert(boolean cond, String msg) {
        if (!cond)
            throw new RuntimeException(msg);
    }
    private static String apiStringInHashtable(Hashtable h, String key) {
        assert h != null;
        Object val = h.get(key);
        apiAssert(val != null, "expected field "+key+" did not exist in: "+h);
        apiAssert(val instanceof String, "expected field "+key+" exists but is "+val.getClass().getName()+" instead of String in: "+h);
        return (String) val;
    }
    private static Hashtable apiHashtableInHashtable(Hashtable h, String key) {
        assert h != null;
        Object val = h.get(key);
        apiAssert(val != null, "expected field "+key+" did not exist in: "+h);
        apiAssert(val instanceof Hashtable, "expected field "+key+" exists but is "+val.getClass().getName()+" instead of Hashtable in: "+h);
        return (Hashtable) val;
    }
    private static Vector apiVectorInHashtable(Hashtable h, String key) {
        assert h != null;
        Object val = h.get(key);
        apiAssert(val != null, "expected field "+key+" did not exist in: "+h);
        apiAssert(val instanceof Vector, "expected field "+key+" exists but is "+val.getClass().getName()+" instead of Vector in: "+h);
        return (Vector) val;
    }
    private static Boolean apiBooleanInHashtable(Hashtable h, String key) {
        assert h != null;
        Object val = h.get(key);
        apiAssert(val != null, "expected field "+key+" did not exist in: "+h);
        apiAssert(val instanceof Boolean, "expected field "+key+" exists but is "+val.getClass().getName()+" instead of Boolean in: "+h);
        return (Boolean) val;
    }
}
