package be.iminds.ilabt.jfed.lowlevel.ssh_key_info;

import java.io.File;
import java.security.PrivateKey;
import java.security.PublicKey;

/**
 * Ssh Key info. This offers access to various info needed for SSH.
 * Sometimes, this might require making temporary files.
 *
 * Call release() to delete any temporary files containing unencrypted private keys
 * */
public interface SshKeyInfo {
    /** file containing private key. may be encrypted. Non putty format. never null. Will also make sure a .pub file with the public key is in the same dir. */
    public File getPrivateKeyFile();
    /** file containing private key. may be encrypted. Putty format. never null (on windows). */
    public File getPuttyKeyFile();

    /** file containing private key. Non putty format. never null. Will also make sure a .pub file with the public key is in the same dir. */
    public File getUnencryptedPrivateKeyFile();
    /** file containing private key. Putty format. never null (on windows). */
    public File getUnlockedPuttyKeyFile();

    public void release();

    /** may be null */
    public PublicKey getPublicKey();
    /** may be null */
    public PrivateKey getPrivateKey();
}