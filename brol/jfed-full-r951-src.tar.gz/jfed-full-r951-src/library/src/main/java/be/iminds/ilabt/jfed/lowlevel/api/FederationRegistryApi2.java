package be.iminds.ilabt.jfed.lowlevel.api;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

/**
 * FederationRegistryApi2
 */
public class FederationRegistryApi2 extends AbstractFederationApi2 {
    private static org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Registry API v2";
     */
    static public String getApiName() {
        return "Uniform Federation Registry API v2";
    }
    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Registry API v2";
     */
    @Override
    public String getName() {
        return getApiName();
    }

    public FederationRegistryApi2(Logger logger, boolean autoRetryBusy) {
        super(logger, autoRetryBusy, new ServerType(ServerType.GeniServerRole.GENI_CH, 2));
    }

    public FederationRegistryApi2(Logger logger) {
        this(logger, true);
    }

    @ApiMethod(order=1, hint="get_version call: Provide a structure detailing the version information as well as details of accepted options for CH API calls.", unprotected=true)
    public FederationApiReply<GetVersionResult> getVersion(SfaConnection con)  throws JFedException {
        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "get_version", new Vector(), null);
        FederationApiReply<GetVersionResult> r = null;
        try {
            r = new FederationApiReply<GetVersionResult>(res, new GetVersionResult(apiSpecifiesHashtableStringToObject(res.getResultValueObject())));
        } catch (Throwable e) {
            handleErrorProcessingArguments(res, "getVersion", "get_version", con, e);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<GetVersionResult>(res, null);
        log(res, r, "getVersion", "get_version", con, null);
        return r;
    }

    @Override
    public List<String> getApiObjects() {
        List<String> res = new ArrayList<String>();
        res.add("SERVICE");
        return res;
    }

    @Override
    public List<String> getRequiredApiServices() {
        List<String> res = new ArrayList<String>();
        res.add("SERVICE");
        return res;
    }

    @Override
    public List<String> getOptionalApiServices() {
        List<String> res = new ArrayList<String>();
        return res;
    }

    @Override
    public List<GetVersionResult.FieldInfo> getMinimumFields(String objectName) {
        assert objectName != null;
        if (!objectName.equalsIgnoreCase("SERVICE")) return null;

        List<GetVersionResult.FieldInfo> res = new ArrayList<GetVersionResult.FieldInfo>();
        //String name, FieldType fieldType, CreationAllowed creationAllowed, boolean updatable, Protect protect, String object
        res.add(new GetVersionResult.FieldInfo("SERVICE", "SERVICE_URN", GetVersionResult.FieldInfo.FieldType.URN, true/*match*/, null/*protect*/)); //required=true
        res.add(new GetVersionResult.FieldInfo("SERVICE", "SERVICE_URL", GetVersionResult.FieldInfo.FieldType.URL, true/*match*/, null/*protect*/)); //required=true
        res.add(new GetVersionResult.FieldInfo("SERVICE", "SERVICE_TYPE", GetVersionResult.FieldInfo.FieldType.STRING, true/*match*/, null/*protect*/)); //required=true
        res.add(new GetVersionResult.FieldInfo("SERVICE", "SERVICE_CERT", GetVersionResult.FieldInfo.FieldType.CERTIFICATE, false/*match*/, null/*protect*/)); //required=false
        res.add(new GetVersionResult.FieldInfo("SERVICE", "SERVICE_NAME", GetVersionResult.FieldInfo.FieldType.STRING, false/*match*/, null/*protect*/)); //required=true
        res.add(new GetVersionResult.FieldInfo("SERVICE", "SERVICE_DESCRIPTION", GetVersionResult.FieldInfo.FieldType.STRING, false/*match*/, null/*protect*/)); //required=false
        res.add(new GetVersionResult.FieldInfo("SERVICE", "SERVICE_PEERS", GetVersionResult.FieldInfo.FieldType.PEERS, false/*match*/, null/*protect*/)); //required=false
        return res;
    }

    public static class Peer {
        private String version;
        private String urlString;
        private URL url;

        public Peer(Hashtable h) {
            version = (String) h.get("version");
            urlString = (String) h.get("url");
            if (urlString != null)
                try {
                    url = new URL(urlString);
                } catch (MalformedURLException e) {
                    LOG.warn("Malformed url: \"" + urlString + "\"", e);
                    url = null;
                }
        }

        public String getVersion() {
            return version;
        }

        public URL getUrl() {
            return url;
        }

        @Override
        public String toString() {
            return "Peer{" +
                    "version='" + version + '\'' +
                    ", urlString='" + urlString + '\'' +
                    ", url=" + url +
                    '}';
        }
    }

    public static class ServiceDetails {
        private String serverRoleString;
        private ServerType.GeniServerRole serverRole;
        private GeniUrn urn;
        private URL url;
        private String certificate;
        private String name;
        private String description;
        private List<Peer> peers;

        private Map<String, Object> extraFields = new HashMap<String, Object>();

        public ServiceDetails(Hashtable fields, boolean failOnMalformedReplies) throws JFedException {
            for (Object entryO : fields.entrySet()) {
                Map.Entry entry = (Map.Entry) entryO;
                assert entry.getKey() instanceof String : "not String in in ServiceDetails fields="+fields;
                String key = (String) entry.getKey();
//                assert entry.getValue() instanceof String : "not String in in ServiceDetails fields="+fields;
                Object value = (Object) entry.getValue();
                String stringValue = null;
                if (value instanceof String)
                    stringValue = (String) value;

                boolean known = false;

                if (key.equals("SERVICE_URN")) {
                    assert stringValue != null : "service value must be String for key SERVICE_URN";
                    urn = GeniUrn.parse(stringValue);
                    known = true;
                }
                if (key.equals("SERVICE_TYPE")) {
                    assert stringValue != null : "service value must be String for key SERVICE_TYPE";
                    this.serverRoleString = stringValue;
                    this.serverRole = null;
                    if (serverRoleString.equalsIgnoreCase("MEMBER_AUTHORITY")) this.serverRole = ServerType.GeniServerRole.GENI_CH_MA;
                    if (serverRoleString.equalsIgnoreCase("SLICE_AUTHORITY")) this.serverRole = ServerType.GeniServerRole.GENI_CH_SA;
                    if (serverRoleString.equalsIgnoreCase("AGGREGATE_MANAGER")) this.serverRole = ServerType.GeniServerRole.AM;
                    if (serverRoleString.equalsIgnoreCase("STITCHING_COMPUTATION_SERVICE")) this.serverRole = ServerType.GeniServerRole.SCS;
                    // also in API:   CREDENTIAL_STORE and LOGGING_SERVICE
                    known = true;
                }
                if (key.equals("SERVICE_URL")){
                    try {
                        assert stringValue != null : "service value must be String for key SERVICE_URL";
                        url = new URL(stringValue);
                    } catch (MalformedURLException e) {
                        if (failOnMalformedReplies)
                            throw new JFedException("Error parsing Federation Registry reply. Malformed URL \""+value+"\". Error: "+e.getMessage(), e);
                        else {
                            LOG.debug("Error parsing Federation Registry reply. Malformed URL \""+value+"\". Error: "+e.getMessage(), e);
                            url = null;
                        }
                    }
                    known = true;
                }
                if (key.equals("SERVICE_CERTIFICATE")) {
                    assert stringValue != null : "service value must be String for key SERVICE_CERTIFICATE";
                    certificate = stringValue;
                    known = true;
                }
                if (key.equals("SERVICE_NAME")) {
                    assert stringValue != null : "service value must be String for key SERVICE_NAME";
                    name = stringValue;
                    known = true;
                }
                if (key.equals("SERVICE_DESCRIPTION")) {
                    assert stringValue != null : "service value must be String for key SERVICE_DESCRIPTION";
                    description = stringValue;
                    known = true;
                }
                if (key.equals("SERVICE_PEERS")) {
                    assert value instanceof Vector : "service value must be Vector for key SERVICE_PEERS";
                    known = true;
                    if (value instanceof Vector) {
                        peers = new ArrayList<Peer>();
                        Vector peersVector = (Vector) value;
                        for (Object o : peersVector) {
                            assert o instanceof Hashtable : "SERVICE_PEERS list must contain Hashtable(s)";
                            if (o instanceof Hashtable) {
                                Hashtable ht = (Hashtable) o;
                                Peer peer = new Peer(ht);
                                peers.add(peer);
                            }
                        }
                    }
                }
                if (!known)
                    extraFields.put(key, value);
            }

            //below is not correct: urn ==null or url == null IS allowed: for example, they are excluded these when the fields argument doesn't include them
//            if (urn == null || url == null) {
//                if (!handleMalformedReplies) {
//                    throw new JFedException("Error processing ServiceDetails. Must contain keys SERVICE_URN and SERVICE_URL, but contained only: "+fields.keySet());
//                }
//                else {
//                    LOG.error("Error processing ServiceDetails. Must contain keys SERVICE_URN and SERVICE_URL, but contained only: "+fields.keySet());
//                }
//            }

        }

        public ServerType.GeniServerRole getServerRole() {
            return serverRole;
        }

        public GeniUrn getUrn() {
            return urn;
        }

        public URL getUrl() {
            return url;
        }

        public String getCertificate() {
            return certificate;
        }

        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }

        @Override
        public String toString() {
            return "ServiceDetails{" +
                    "serverRole=" + serverRole +
                    ", type=" + serverRoleString +
                    ", urn=" + urn +
                    ", url=" + url +
                    ", certificate='" + certificate + '\'' +
                    ", name='" + name + '\'' +
                    ", description='" + description + '\'' +
                    ", peers='" + peers + '\'' +
                    ", extraFields=" + extraFields +
                    '}';
        }
    }

    private static class LookupResultServiceDetailsConverter implements LookupResultConverter<ServiceDetails> {
        private boolean handleMalformedReplies;
        public LookupResultServiceDetailsConverter(boolean handleMalformedReplies) {
            this.handleMalformedReplies = handleMalformedReplies;
        }

        @Override
        public ServiceDetails convert(String urn, Hashtable h) throws JFedException {
            return new ServiceDetails(h, !handleMalformedReplies);
        }
    }

    @ApiMethod(order=2, hint="lookup call: Return information about a service associated with the Federation", unprotected=true)
    public FederationApiReply<LookupResult<ServiceDetails>> lookup(SfaConnection con,
                                                           @ApiMethodParameter(name = "type", hint="object type to lookup",
                                                                   required = true, guiDefault = "SERVICE", parameterType = ApiMethodParameterType.CH_API2_OBJECT_TYPE)
                                                           String type,
                                                           @ApiMethodParameter(name = "filter", hint="fields names included in reply. If omitted: all fields.",
                                                                   required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.CH_API2_FILTER)
                                                           List<String> filter,
                                                           @ApiMethodParameter(name = "match", hint="",
                                                                   required = false, guiDefaultOptional = false,
                                                                   parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                           Map<String, ? extends Object> match,
                                                           @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                           Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("filter", filter, "match", match, "extraOptions", extraOptions);
        String javaMethodName = "lookup";
        String apiMethodName = "lookup";

        return lookup_internal(methodParams, con, javaMethodName,
                type,
                new LookupResultServiceDetailsConverter(handleMalformedReplies),
                null /* credentials */,
                match, filter, extraOptions,
                null /* extra arguments*/);
    }


    @ApiMethod(order=4, hint="convenience method which calls \"lookup\" with SERVICE_TYPE=\"AGGREGATE_MANAGER\"", unprotected=true, convenienceMethodFor="lookup", convenienceMethodObjectType = "SERVICE")
    public FederationApiReply<LookupResult<ServiceDetails>> lookupAM(SfaConnection con,
                                                           @ApiMethodParameter(name = "filter",
                                                                   hint="fields names included in reply. If omitted: all fields.",
                                                                   required = false, guiDefaultOptional = false,
                                                                   parameterType = ApiMethodParameterType.CH_API2_FILTER)
                                                           List<String> filter,
                                                           @ApiMethodParameter(name = "match", hint="",
                                                                   required = false, guiDefaultOptional = false,
                                                                   parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                           Map<String, ? extends Object> match,
                                                           @ApiMethodParameter(name = "extraOptions", hint="extra options",
                                                                   required = false, guiDefaultOptional = false,
                                                                   parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                           Map<String, Object> extraOptions)  throws JFedException {
        if (match == null) {
            match = new HashMap<String, String>();
        }
        if (!match.containsKey("SERVICE_TYPE")) {
            Map<String, Object> helper = (Map<String, Object>) match;
            helper.put("SERVICE_TYPE", "AGGREGATE_MANAGER");
        }

        return lookup(con, "SERVICE", filter, match, extraOptions);
    }

    @ApiMethod(order=4, hint="convenience method which calls \"lookup\" with SERVICE_TYPE=\"SLICE_AUTHORITY\"", unprotected=true, convenienceMethodFor="lookup", convenienceMethodObjectType = "SERVICE")
    public FederationApiReply<LookupResult<ServiceDetails>> lookupSA(SfaConnection con,
                                                           @ApiMethodParameter(name = "filter",
                                                                   hint="fields names included in reply. If omitted: all fields.",
                                                                   required = false, guiDefaultOptional = false,
                                                                   parameterType = ApiMethodParameterType.CH_API2_FILTER)
                                                           List<String> filter,
                                                           @ApiMethodParameter(name = "match", hint="",
                                                                   required = false, guiDefaultOptional = false,
                                                                   parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                           Map<String, ? extends Object> match,
                                                           @ApiMethodParameter(name = "extraOptions", hint="extra options",
                                                                   required = false, guiDefaultOptional = false,
                                                                   parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                           Map<String, Object> extraOptions)  throws JFedException {
        if (match == null) {
            match = new HashMap<String, String>();
        }
        if (!match.containsKey("SERVICE_TYPE")) {
            Map<String, Object> helper = (Map<String, Object>) match;
            helper.put("SERVICE_TYPE", "SLICE_AUTHORITY");
        }

        return lookup(con, "SERVICE", filter, match, extraOptions);
    }

    @ApiMethod(order=5, hint="convenience method which calls \"lookup\" with SERVICE_TYPE=\"MEMBER_AUTHORITY\"", unprotected=true, convenienceMethodFor="lookup", convenienceMethodObjectType = "SERVICE")
    public FederationApiReply<LookupResult<ServiceDetails>> lookupMA(SfaConnection con,
                                                           @ApiMethodParameter(name = "filter",
                                                                   hint="fields names included in reply. If omitted: all fields.",
                                                                   required = false, guiDefaultOptional = false,
                                                                   parameterType = ApiMethodParameterType.CH_API2_FILTER)
                                                           List<String> filter,
                                                           @ApiMethodParameter(name = "match", hint="",
                                                                   required = false, guiDefaultOptional = false,
                                                                   parameterType=ApiMethodParameterType.CH_API2_MATCH)
                                                           Map<String, ? extends Object> match,
                                                           @ApiMethodParameter(name = "extraOptions", hint="extra options",
                                                                   required = false, guiDefaultOptional = false,
                                                                   parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                           Map<String, Object> extraOptions)  throws JFedException {
        if (match == null) {
            match = new HashMap<String, String>();
        }
        if (!match.containsKey("SERVICE_TYPE")) {
            Map<String, Object> helper = (Map<String, Object>) match;
            helper.put("SERVICE_TYPE", "MEMBER_AUTHORITY");
        }

        return lookup(con, "SERVICE", filter, match, extraOptions);
    }

    @ApiMethod(order=10, hint="lookup_authorities_for_urns call: Lookup the authorities for a given URNs", unprotected=true)
    public FederationApiReply<Map<GeniUrn, URL>> lookupAuthoritiesForUrns(SfaConnection con,
                                                                          @ApiMethodParameter(name = "urns", hint="URNs of entities for which the authority is requested",
                                                                                  parameterType = ApiMethodParameterType.LIST_OF_URN_STRING)
                                                                          List<GeniUrn> urns)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("urns", urns);

        Vector args = new Vector(1);
        Vector stringUrns = new Vector();
        for (GeniUrn gu : urns)
            stringUrns.add(gu.toString());
        args.add(stringUrns);
        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "lookup_authorities_for_urns", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<Map<GeniUrn, URL>> r = null;
        if (resultValueObject instanceof Hashtable) {
            Hashtable<Object, Object> resHashtable = (Hashtable) resultValueObject;
            Map<GeniUrn, URL> urls = new HashMap<GeniUrn, URL>();

            for (Map.Entry<Object, Object> e : resHashtable.entrySet()) {
                if (e.getKey() instanceof String && e.getValue() instanceof String) {
                    try {
                        GeniUrn urn = new GeniUrn((String) e.getKey());
                        URL url = new URL((String)e.getValue());
                        urls.put(urn, url);
                    } catch (MalformedURLException ex) {
                        if (!handleMalformedReplies) {
                            log(res, r, "lookupAuthoritiesForUrns", "lookup_authorities_for_urns", con, null);
                            LOG.error("Error processing lookup_authorities_for_urns result (" + ex.getMessage() + " == not an url: " + e.getValue() + "): " + resultValueObject);
                            throw new JFedException("Error processing lookup_authorities_for_urns result, not an url: \""+e.getValue()+"\": "+
                                    " error message: \""+ex.getMessage()+"\"", ex, res);
                        }
                        else {
                            LOG.error("Error processing lookup_authorities_for_urns result (" + ex.getMessage() + " == not an url: " + e.getValue() + "): " + resultValueObject);
                            urls = null;
                        }
                        break;
                    } catch (GeniUrn.GeniUrnParseException ex) {
                        if (!handleMalformedReplies) {
                            log(res, r, "lookupAuthoritiesForUrns", "lookup_authorities_for_urns", con, null);
                            throw new JFedException("Error processing lookup_authorities_for_urns result, not an urn: \""+e.getKey()+"\": "+
                                    " error message: \""+ex.getMessage()+"\"", ex, res);
                        }
                        else {
                            LOG.error("Error processing lookup_authorities_for_urns result (" + ex.getMessage() + " == not an urn: " + e.getKey() + "): " + resultValueObject);
                            urls = null;
                        }
                        break;
                    }
                } else {
                    LOG.error("Error processing lookup_authorities_for_urns result (not an string: " + e.getKey() + " or " + e.getValue() + "): " + resultValueObject);
                    urls = null;
                    break;
                }
            }
            r = new FederationApiReply<Map<GeniUrn, URL>>(res, urls);
        }

        if (r == null)
            r = new FederationApiReply<Map<GeniUrn, URL>>(res, null);
        log(res, r, "lookupAuthoritiesForUrns", "lookup_authorities_for_urns", con, methodParams);
        return r;
    }

    @ApiMethod(order=20, hint="get_trust_roots call: Return list of trust roots (certificates) associated with this CH. " +
            "Often this concatenates of the trust roots of the included authorities.", unprotected=true)
    public FederationApiReply<List<String>> getTrustRoots(SfaConnection con)  throws JFedException {
        Vector args = new Vector();
        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "get_trust_roots", args, null);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<List<String>> r = null;
        try {
            r = new FederationApiReply<List<String>>(res, new ArrayList<String>(apiSpecifiesVectorOfString(resultValueObject)));
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "getTrustRoots", "get_trust_roots", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<List<String>>(res, null);
        log(res, r, "getTrustRoots", "get_trust_roots", con, null);
        return r;
    }
}
