package be.iminds.ilabt.jfed.lowlevel.connection;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.authority.DebuggingAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniTrustStoreHelper;
import org.apache.xmlrpc.XmlRpcClient;

import java.net.URL;
import java.security.KeyStore;

/**
 * GeniConnection: XmlRpc over HTTP without SSL (= unencrypted, plain HTTP)
 */
public class SfaPlainConnection extends SfaConnection {
    private CommonsHttpClientXmlRpcTransportFactory xmlRpcTransportFactory;
    private XmlRpcClient xmlRpcClient;

    /**
     * //@param allowedCertificateHostnameAliases may be null or empty
     * @throws be.iminds.ilabt.jfed.lowlevel.JFedException
     */
    public SfaPlainConnection(SfaAuthority geniAuthority, String serverUrl, ProxyInfo proxyInfo, boolean debugMode) throws JFedException {
        super(geniAuthority, serverUrl, proxyInfo, debugMode);

        xmlRpcTransportFactory = new ClientPlainAuthenticationXmlRpcTransportFactory(serverUrl, debugMode);
        try {
            xmlRpcClient = new XmlRpcClient(new URL(serverUrl), xmlRpcTransportFactory);
            error = false;
        } catch (Exception e) {
            throw new JFedException("Error creating XmlRpcClient in GeniConnection constructor: "+e.getMessage(), e);
        }
    }

    @Override
    public CommonsHttpClientXmlRpcTransportFactory getXmlRpcTransportFactory() {
        assert !fakeForDebugging : "Error: This connection is a fake debugging connection, yet the CommonsHttpClientXmlRpcTransportFactory was requested";
        return xmlRpcTransportFactory;
    }

    @Override
    public XmlRpcClient getXmlRpcClient() {
        assert !fakeForDebugging : "Error: This connection is a fake debugging connection, yet the XmlRpcClient was requested";
        return xmlRpcClient;
    }
}