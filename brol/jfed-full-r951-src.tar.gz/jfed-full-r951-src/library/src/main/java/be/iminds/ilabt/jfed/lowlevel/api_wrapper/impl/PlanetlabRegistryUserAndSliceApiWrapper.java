package be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api.PlanetlabSfaRegistryInterface;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.UserAndSliceApiWrapper;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;

import java.util.*;

/**
 * ProtoGeniSAUserAndSliceApiWrapper
 */
public class PlanetlabRegistryUserAndSliceApiWrapper extends UserAndSliceApiWrapper {
    private final PlanetlabSfaRegistryInterface registry;

    private SfaConnection getCon() throws JFedException {
        return (SfaConnection) getConnection(new ServerType(ServerType.GeniServerRole.PlanetLabSliceRegistry, 1));
    }

    public PlanetlabRegistryUserAndSliceApiWrapper(Logger logger, GeniUserProvider geniUserProvider, GeniConnectionProvider connectionProvider) {
        super(logger, geniUserProvider, connectionProvider);
        this.registry = new PlanetlabSfaRegistryInterface(logger, true);
    }

    @Override
    public AnyCredential getUserCredentials(GeniUrn userUrn) throws JFedException {
        PlanetlabSfaRegistryInterface.SimpleApiCallReply<AnyCredential> replyCred =
            registry.getSelfCredential_AutomaticArguments(getCon(), getUser());

        if (!replyCred.getGeniResponseCode().isSuccess())
            throw new JFedException("Could not retrieve user credential from server: code="+
                    replyCred.getGeniResponseCode()+" output="+replyCred.getOutput(),
                    replyCred.getXmlRpcDetails(), replyCred.getGeniResponseCode());

        return replyCred.getValue();
    }

    @Override
    public AnyCredential getSliceCredentials(AnyCredential userCredential, GeniUrn sliceUrn) throws JFedException {
        PlanetlabSfaRegistryInterface.SimpleApiCallReply<AnyCredential> replyCred =
                registry.getCredential(getCon(), userCredential, sliceUrn.getValue(), "slice");

        if (!replyCred.getGeniResponseCode().isSuccess())
            throw new JFedException("Could not retrieve slice credential from server: code="+
                    replyCred.getGeniResponseCode()+" output="+replyCred.getOutput(),
                    replyCred.getXmlRpcDetails(), replyCred.getGeniResponseCode());

        return replyCred.getValue();
    }

    @Override
    public List<GeniUrn> getSlicesForUser(AnyCredential userCredential, GeniUrn userUrn) throws JFedException {
        List<GeniUrn> res = new ArrayList<GeniUrn>();

        String urnTla = userUrn.getTopLevelAuthority();
        String urnUsername = userUrn.getResourceName();
        String[] splitTla = urnTla.split(":", 2);
        assert splitTla.length == 2;
        String hrnStart = splitTla[0] + "." + splitTla[1];
        String userHrn = hrnStart + "." + urnUsername;

        //TODO resolve userHrn, userUrn or hrnStart ????

        registry.resolve(getCon(), userCredential, hrnStart/*xrn*/);

        //TODO process resolve reply

        return res;
    }

    @Override
    public void getAggregatesForSlice(AnyCredential userCredential, AnyCredential sliceCredential, GeniUrn sliceUrn) throws JFedException {
        //TODO check if planetlab supports this
    }

    @Override
    public SliceInfo createSlice(AnyCredential userCredential, String sliceName, Date expirationDate) throws JFedException {
        //first get authority credential for this users (only PI's have it and it is needed to create slices)

        GeniUser user = getUser();
        SfaAuthority userAuth = getUserAuthority();
        GeniUrn userUrn = GeniUrn.parse(user.getUserUrnString());
        String urnTla = userUrn.getTopLevelAuthority();
        String urnUsername = userUrn.getResourceName();

        String[] splitTla = urnTla.split(":", 2);
        assert splitTla.length == 2;
        String hrnStart = splitTla[0] + "." + splitTla[1];

        String userHrn = hrnStart + "." + urnUsername;

        String sliceHrn = hrnStart + "." + sliceName;
        List<String> researcherHrns = new ArrayList<String>();
        researcherHrns.add(userHrn);
//        List<String> piHrns = new ArrayList<String>();
//        piHrns.add(userHrn);

        GeniUrn sliceUrn = new GeniUrn(urnTla, "slice", sliceName);

        PlanetlabSfaRegistryInterface.SimpleApiCallReply<AnyCredential> replyCred = registry.getCredential(getCon(),
                userCredential/*credential*/,
                hrnStart/*xrn*/,
                "authority"/*type*/);

        if (!replyCred.getGeniResponseCode().isSuccess())
            throw new JFedException("Could not retrieve \"authority credential\" from server: code="+
                    replyCred.getGeniResponseCode()+" output="+replyCred.getOutput(),
                    replyCred.getXmlRpcDetails(), replyCred.getGeniResponseCode());

        AnyCredential authorityCredential = replyCred.getValue();

        if(expirationDate == null){
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.HOUR, 3);
            expirationDate = cal.getTime();
        }

        PlanetlabSfaRegistryInterface.SimpleApiCallReply<String/*gid*/> replyRegister = registry.registerSlice(
                getCon(),
                authorityCredential/*credential*/,
                sliceHrn/*hrn*/,
                null/*sliceUrl*/,
                expirationDate/*expires*/,
                researcherHrns/*researchers*/,
                null/*pis*/,
                null/*description*/);

        if (!replyRegister.getGeniResponseCode().isSuccess())
            throw new JFedException("Could not create slice: code="+
                    replyRegister.getGeniResponseCode()+" output="+replyRegister.getOutput(),
                    replyRegister.getXmlRpcDetails(), replyRegister.getGeniResponseCode());

        //TODO: the returned gid is normally, the slice certificate in the slice credential? Or is it the credential? check and skip next step if needed

        return new SliceInfo(sliceName, sliceUrn, getSliceCredentials(userCredential, sliceUrn));
    }

    @Override
    public AnyCredential renewSlice(AnyCredential sliceCredential, Date newExpirationDate) throws JFedException {
        throw new UnsupportedOperationException();
    }

    @Override
    public void getSshKeysForUser(AnyCredential userCredential, GeniUrn userUrn) throws JFedException {
        //TODO check if planetlab supports this
    }
}
