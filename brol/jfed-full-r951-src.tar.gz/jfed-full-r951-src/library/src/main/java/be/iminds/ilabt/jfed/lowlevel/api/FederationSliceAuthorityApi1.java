package be.iminds.ilabt.jfed.lowlevel.api;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.TextUtil;
import org.apache.logging.log4j.LogManager;

import java.lang.reflect.Method;
import java.util.*;

/**
 * FederationSliceAuthorityApi1
 */
public class FederationSliceAuthorityApi1 extends AbstractFederationApi1 {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Slice Authority API v1";
     */
    static public String getApiName() {
        return "Uniform Federation Slice Authority API v1";
    }
    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Slice Authority API v1";
     */
    @Override
    public String getName() {
        return getApiName();
    }

    public FederationSliceAuthorityApi1(Logger logger, boolean autoRetryBusy) {
        super(logger, autoRetryBusy, new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 1));
    }

    public FederationSliceAuthorityApi1(Logger logger) {
        this(logger, true);
    }

    public static class GetVersionSAResult extends GetVersionResult {
        private List<String> services;//only for Slice Authority
        private List<String> roles;//only for Slice Authority
        public GetVersionSAResult(Hashtable<String, Object> versionInfo) throws BadReplyGeniException {
            super(versionInfo);
            services = new ArrayList(apiSpecifiesVectorOfString(versionInfo.get("SERVICES")));

            //roles is optional
            if (versionInfo.get("ROLES") != null)
                roles = new ArrayList(apiSpecifiesVectorOfString(versionInfo.get("ROLES")));
            else
                roles = new ArrayList<String>();
        }

        public List<String> getServices() {
            return services;
        }

        public List<String> getRoles() {
            return roles;
        }

        @Override
        public String toString() {
            return "GetVersionSAResult{" +
                    "version='" + version + '\'' +
                    ", supportedCredentialTypes=" + supportedCredentialTypes +
                    ", fieldInfos=" + fieldInfos +
                    ", services=" + services +
                    ", roles=" + roles +
                    '}';
        }
    }

    @ApiMethod(order=1, hint="get_version call: Provide a structure detailing the version information as well as details of accepted options s for CH API calls.", unprotected=true)
    public FederationApiReply<GetVersionSAResult> getVersion(SfaConnection con)  throws JFedException {
        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "get_version", new Vector(), null);
        FederationApiReply<GetVersionSAResult> r = null;
        try {
            r = new FederationApiReply<GetVersionSAResult>(res, new GetVersionSAResult(apiSpecifiesHashtableStringToObject(res.getResultValueObject())));
        } catch (Throwable e) {
            handleErrorProcessingArguments(res, "getVersion", "get_version", con, e);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<GetVersionSAResult>(res, null);
        log(res, r, "getVersion", "get_version", con, null);
        return r;
    }

    public String getMethodObject(Method method) {
        if (method.getName().equals("createSlice") ||
                method.getName().equals("lookupSlices") ||
                method.getName().equals("updateSlice"))
            return "SLICE";

        if (method.getName().equals("createProject") ||
                method.getName().equals("lookupProjects") ||
                method.getName().equals("updateProject"))
            return "PROJECT";

        return null;
    }

    @Override
    public List<String> getApiObjects() {
        List<String> res = new ArrayList<String>();
        res.add("SLICE");
        res.add("PROJECT");
        return res;
    }

    @Override
    public List<String> getRequiredApiServices() {
        List<String> res = new ArrayList<String>();
        res.add("SLICE");
        return res;
    }

    @Override
    public List<String> getOptionalApiServices() {
        List<String> res = new ArrayList<String>();
        res.add("PROJECT");
        res.add("SLICE_MEMBER");
        res.add("PROJECT_MEMBER");
        res.add("SLIVER_INFO");
        return res;
    }

    @Override
    public List<GetVersionResult.FieldInfo> getMinimumFields(String objectName) {
        List<GetVersionResult.FieldInfo> res = new ArrayList<GetVersionResult.FieldInfo>();
        //String name, FieldType fieldType, CreationAllowed creationAllowed, boolean match, boolean updateable, Protect protect, String object

        if (objectName.equalsIgnoreCase("SLICE")) {
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_URN", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_UID", GetVersionResult.FieldInfo.FieldType.UID, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_CREATION", GetVersionResult.FieldInfo.FieldType.DATETIME, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, false, false));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_EXPIRATION", GetVersionResult.FieldInfo.FieldType.DATETIME, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, false, true));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_EXPIRED", GetVersionResult.FieldInfo.FieldType.BOOLEAN, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_NAME", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, false, false));
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_DESCRIPTION", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, false, true));

            //WARNING: special field: SLICE_PROJECT_URN only exists when the server supports the PROJECT service!
            res.add(new GetVersionResult.FieldInfo("SLICE", "SLICE_PROJECT_URN", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, true, false));


        }
        if (objectName.equalsIgnoreCase("PROJECT")) {
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_URN", GetVersionResult.FieldInfo.FieldType.URN, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_UID", GetVersionResult.FieldInfo.FieldType.UID, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_CREATION", GetVersionResult.FieldInfo.FieldType.DATETIME, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, false, false));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_EXPIRATION", GetVersionResult.FieldInfo.FieldType.DATETIME, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, false, true));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_EXPIRED", GetVersionResult.FieldInfo.FieldType.BOOLEAN, GetVersionResult.FieldInfo.CreationAllowed.NOT_ALLOWED, true, false));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_NAME", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.REQUIRED, false, false));
            res.add(new GetVersionResult.FieldInfo("PROJECT", "PROJECT_DESCRIPTION", GetVersionResult.FieldInfo.FieldType.STRING, GetVersionResult.FieldInfo.CreationAllowed.ALLOWED, false, true));
        }
        return res;
    }


    @ApiMethod(order=2, hint="create_slice call:")
    public FederationApiReply<Hashtable<String, Object>> createSlice(SfaConnection con,
                                                                     @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                     List<AnyCredential> credentialList,
                                                                     @ApiMethodParameter(name = "sliceName", hint="", parameterType=ApiMethodParameterType.STRING)
                                                                     String sliceName,
                                                                     @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API1_FIELDS)
                                                                     Map<String, String> fields,
                                                                     @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                     Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "sliceName", sliceName, "fields", fields, "extraOptions", extraOptions);
        assert credentialList != null;
        assert fields != null;
        assert !fields.isEmpty();

        Vector args = new Vector(2);
        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable options = new Hashtable();
        Hashtable allFields = new Hashtable<String, String>(fields);
        assert !allFields.containsKey("SLICE_NAME") : "Add SLICE_NAME with the sliceName option, not directly in the \"fields\" argument";
        allFields.put("SLICE_NAME", sliceName);
        options.put("fields", allFields);
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "create_slice", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<Hashtable<String, Object>> r = null;
        try {
            Hashtable<String, Object> resHashtable = apiSpecifiesHashtableStringToObject(resultValueObject);
            r = new FederationApiReply<Hashtable<String, Object>>(res, resHashtable);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "createSlice", "create_slice", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<Hashtable<String, Object>>(res, null);
        log(res, r, "createSlice", "create_slice", con, methodParams);
        return r;
    }



    @ApiMethod(order=3, hint="lookup_slices call:")
    public FederationApiReply<LookupResult> lookupSlices(SfaConnection con,
                                                         @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                         List<AnyCredential> credentialList,
                                                         @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API1_MATCH)
                                                         Map<String, ? extends Object> match,
                                                         @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API1_FILTER)
                                                         List<String> filter,
                                                         @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                         Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "match", match, "filter", filter, "extraOptions", extraOptions);
        assert credentialList != null;
        return genericLookupCall(methodParams, con, "lookupSlices", "lookup_slices", credentialList, match, filter, extraOptions, null);
    }



    @ApiMethod(order=4, hint="update_slice call:")
    /** normally returns nothing at all. Anything that might be returned anyway is converted to string, but normally a null Object will be returned. */
    public FederationApiReply<String> updateSlice(SfaConnection con,
                                                  @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                  List<AnyCredential> credentialList,
                                                  @ApiMethodParameter(name = "sliceUrn", hint="", parameterType=ApiMethodParameterType.SLICE_URN)
                                                  GeniUrn sliceUrn,
                                                  @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API1_FIELDS)
                                                  Map<String, String> fields,
                                                  @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                  Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "sliceUrn", sliceUrn, "fields", fields, "extraOptions", extraOptions);
        return genericUpdateCall(methodParams, con, "updateSlice", "update_slice", credentialList, sliceUrn.toString(), "slice", fields, extraOptions);
    }

    @ApiMethod(order=5, hint="get_credentials call:")
    public FederationApiReply<List<AnyCredential>> getSliceCredentials(SfaConnection con,
                                                                       @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                       List<AnyCredential> credentialList,
                                                                       @ApiMethodParameter(name = "sliceUrn", hint="", parameterType=ApiMethodParameterType.SLICE_URN)
                                                                       GeniUrn sliceUrn,
                                                                       @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                       Map<String, String> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "sliceUrn", sliceUrn, "extraOptions", extraOptions);

        assert credentialList != null;
        assert sliceUrn != null;

        if (sliceUrn == null || !sliceUrn.getResourceType().equals("slice"))
            System.err.println("WARNING: slice URN argument to getSliceCredentials is not a valid slice urn: \""+sliceUrn+"\" (will be used anyway)");

        Vector args = new Vector(3);
        args.add(sliceUrn.toString());

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        if (extraOptions != null)
            args.add(new Hashtable<String, String>(extraOptions));
        else
            args.add(new Hashtable<String, String>());

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "get_credentials", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<List<AnyCredential>> r = null;
        try {
            List<AnyCredential> credList = apiSpecifiesVectorOfCredentials("FederationSliceAuthorityApi1 getSliceCredentials", resultValueObject);
            r = new FederationApiReply<List<AnyCredential>>(res, credList);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "getSliceCredentials", "get_credentials", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<List<AnyCredential>>(res, null);
        log(res, r, "getSliceCredentials", "get_credentials", con, methodParams);
        return r;
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Slice Member Service Methods /////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /*
    Modify slice membership, adding, removing and changing roles of members with respect to given slice
    Arguments:
      Slice_urn: URN of slice for which to modify membership
      members_to_add: List of member_urn/role tuples for members to add to slice
      members_to_remove: List of member_urn of members to remove from slice
      members_to_change: List of member_urn/role tuples for members whose role should change as specified for given slice
    Return:
       None

    function modify_slice_membership (slice_urn, members_to_add, members_to_remove, members_to_modify, credentials, options)
    */

    public static class UrnRoleTuple {
        public final GeniUrn urn;
        public final String role;
        public final Hashtable dictRaw;

        public UrnRoleTuple(GeniUrn urn, String role) {
            this.dictRaw = null;
            this.urn = urn;
            this.role = role;
        }
        public UrnRoleTuple(String urn, String role) {
            this.dictRaw = null;
            this.urn = GeniUrn.parse(urn);
            this.role = role;
        }
        public UrnRoleTuple(Hashtable dictRaw, String urnKeyName, String roleKeyName) throws BadReplyGeniException {
            Hashtable<String, Object> dict = apiSpecifiesHashtableStringToObject(dictRaw);
            String urnString = (String) dict.get(urnKeyName);
            if (urnString == null) throw new BadReplyGeniException("Dictionary should contain keys '"+urnKeyName+"' and '"+roleKeyName+". It contains only: "+dict.keySet());
            assert urnString != null;
            this.urn = GeniUrn.parse(urnString);
            this.role = (String) dict.get(roleKeyName);
            if (role == null) throw new BadReplyGeniException("Dictionary should contain keys '"+urnKeyName+"' and '"+roleKeyName+". It contains only: "+dict.keySet());
            assert role != null;
            this.dictRaw = dictRaw;
        }
        public Vector toVector() {
            Vector v = new Vector(2);
            v.add(urn.toString());
            v.add(role);
            return v;
        }

        public GeniUrn getUrn() {
            return urn;
        }

        public String getRole() {
            return role;
        }

        @Override
        public String toString() {
            return "UrnRoleTuple{" +
                    "urn=\"" + urn +
                    "\", role=\"" + role + "\"" +
                    '}';
        }
    }
    @ApiMethod(order=6, hint="modify_slice_membership call:")
    public FederationApiReply<String> modifySliceMembership(SfaConnection con,
                                                            @ApiMethodParameter(name = "sliceUrn", hint="", parameterType=ApiMethodParameterType.SLICE_URN)
                                                            GeniUrn sliceUrn,
                                                            @ApiMethodParameter(name = "membersToAdd", hint="", parameterType=ApiMethodParameterType.CH_API_LIST_MEMBER_TUPLES)
                                                            List<UrnRoleTuple> membersToAdd,
                                                            @ApiMethodParameter(name = "membersToRemove", hint="", parameterType=ApiMethodParameterType.LIST_OF_URN_STRING)
                                                            List<GeniUrn> membersToRemove,
                                                            @ApiMethodParameter(name = "membersToChange", hint="", parameterType=ApiMethodParameterType.CH_API_LIST_MEMBER_TUPLES)
                                                            List<UrnRoleTuple> membersToChange,
                                                            @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                            List<AnyCredential> credentialList,
                                                            @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                            Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("sliceUrn", sliceUrn,
                "membersToAdd", membersToAdd, "membersToRemove", membersToRemove, "membersToChange", membersToChange,
                "credentialList", credentialList, "extraOptions", extraOptions);

        assert credentialList != null;
        assert sliceUrn != null;

        Vector args = new Vector(6);
        args.add(sliceUrn.getValue());

        Vector membersToAddVector = new Vector();
        for (UrnRoleTuple mt : membersToAdd)
            membersToAddVector.add(mt.toVector());
        args.add(membersToAddVector);

        Vector membersToRemoveVector = new Vector();
        for (GeniUrn u : membersToRemove)
            membersToRemoveVector.add(u.toString());
        args.add(membersToRemoveVector);

        Vector membersToChangeVector = new Vector();
        for (UrnRoleTuple mt : membersToChange)
            membersToChangeVector.add(mt.toVector());
        args.add(membersToChangeVector);

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable options = new Hashtable();
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "modify_slice_membership", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        //should return nothing at all, but if there is anything, we convert it to string and return it
        FederationApiReply<String> r = new FederationApiReply<String>(res, resultValueObject == null ? null : resultValueObject+"");
        log(res, r, "modifySliceMembership", "modify_slice_membership", con, methodParams);
        return r;
    }

    /*
   Lookup members of given slice and their roles within that slice
   Arguments:
     slice_urn: URN of slice for which to provide current members and roles
   Return:
      Dictionary of member_urn/role pairs {‘SLICE_MEMBER’: member_urn, ‘SLICE_ROLE’: role } where ‘role’ is a string of the role name

    function lookup_slice_members (slice_urn, credentials, options)
    */
    @ApiMethod(order=7, hint="lookup_slice_members call:")
    public FederationApiReply<List<UrnRoleTuple>> lookupSliceMembers(SfaConnection con,
                                                                     @ApiMethodParameter(name = "sliceUrn", hint="", parameterType=ApiMethodParameterType.SLICE_URN)
                                                                     GeniUrn sliceUrn,
                                                                     @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                     List<AnyCredential> credentialList,
                                                                     Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList,
                "sliceUrn", sliceUrn, "extraOptions", extraOptions);
        assert credentialList != null;

        Vector args = new Vector();
        args.add(sliceUrn.toString());
        if (credentialList != null) {
            Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
            args.add(credentials);
        } else
            args.add(new Vector());
        if (extraOptions != null)
            args.add(extraOptions);
        else
            args.add(new Hashtable());

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "lookup_slice_members", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<List<UrnRoleTuple>> r = null;
        try {
            Vector<Hashtable> resDicts = apiSpecifiesVectorOfT(Hashtable.class, resultValueObject);
            List<UrnRoleTuple> resList = new ArrayList<UrnRoleTuple>();
            for (Hashtable dict : resDicts) {
                resList.add(new UrnRoleTuple(dict, "SLICE_MEMBER", "SLICE_ROLE"));
            }
            r = new FederationApiReply<List<UrnRoleTuple>>(res, resList);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "lookupSliceMembers", "lookup_slice_members", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<List<UrnRoleTuple>>(res, null);
        log(res, r, "lookupSliceMembers", "lookup_slice_members", con, methodParams);
        return r;
    }

    /*
    Lookup slices for which the given member belongs
    Arguments:
      Member_urn: The member for whom to find slices to which it belongs
    Return:
       Dictionary of slice_urn/role pairs (‘SLICE_URN’ : slice_urn, ‘SLICE_ROLE’ : role} where role is a string of the role name

       function lookup_slices_for_member(member_urn, credentials, options)
    */
    @ApiMethod(order=8, hint="lookup_slices_for_member call:")
    public FederationApiReply<List<UrnRoleTuple>> lookupSlicesForMember(SfaConnection con,
                                                                        @ApiMethodParameter(name = "memberUrn", hint="", parameterType=ApiMethodParameterType.USER_URN)
                                                                        GeniUrn memberUrn,
                                                                        @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                        List<AnyCredential> credentialList,
                                                                        @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                        Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "memberUrn", memberUrn, "extraOptions", extraOptions);
        assert credentialList != null;
        assert memberUrn != null;

        Vector args = new Vector();
        args.add(memberUrn.toString());
        if (credentialList != null) {
            Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
            args.add(credentials);
        } else
            args.add(new Vector());
        if (extraOptions != null)
            args.add(extraOptions);
        else
            args.add(new Hashtable());

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "lookup_slices_for_member", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<List<UrnRoleTuple>> r = null;
        try {
            Vector<Hashtable> resDicts = apiSpecifiesVectorOfT(Hashtable.class, resultValueObject);
            List<UrnRoleTuple> resList = new ArrayList<UrnRoleTuple>();
            for (Hashtable dict : resDicts) {
                resList.add(new UrnRoleTuple(dict, "SLICE_URN", "SLICE_ROLE"));
            }
            r = new FederationApiReply<List<UrnRoleTuple>>(res, resList);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "lookupSlicesForMember", "lookup_slices_for_member", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<List<UrnRoleTuple>>(res, null);
        log(res, r, "lookupSlicesForMember", "lookup_slices_for_member", con, methodParams);
        return r;
    }



    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////// Sliver Info Service API /////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /*
        # Create a record of a sliver creation
        #
        # Arguments:
        #   options: 'fields' containing the fields for the sliver info  being registered at SA
        #
        # Return:
        # Dictionary of name/value pairs for created sliver_info record
    */
    @ApiMethod(order=9, hint="register_aggregate call:")
    public FederationApiReply<Hashtable<String, Object>> createSliverInfo(SfaConnection con,
                                                                          @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                          List<AnyCredential> credentialList,
                                                                          @ApiMethodParameter(name = "sliceUrn", hint="convenience argument: SLIVER_INFO_SLICE_URN to add to fields option", parameterType=ApiMethodParameterType.SLICE_URN)
                                                                          String sliceUrn,
                                                                          @ApiMethodParameter(name = "sliverUrn", hint="convenience argument: SLIVER_INFO_URN to add to fields option", parameterType=ApiMethodParameterType.URN)
                                                                          String sliverUrn,
                                                                          @ApiMethodParameter(name = "aggregateUrn", hint="convenience argument: SLIVER_INFO_AGGREGATE_URN to add to fields option", parameterType=ApiMethodParameterType.URN)
                                                                          String aggregateUrn,
                                                                          @ApiMethodParameter(name = "creatorUrn", hint="convenience argument: SLIVER_INFO_CREATOR_URN to add to fields option", parameterType=ApiMethodParameterType.URN)
                                                                          String creatorUrn,
                                                                          @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API1_FIELDS)
                                                                          Map<String, String> fields,
                                                                          @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                          Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "sliceUrn", sliceUrn,
                "sliverUrn", sliverUrn, "aggregateUrn", aggregateUrn, "creatorUrn", creatorUrn, "fields", fields, "extraOptions", extraOptions);

        assert credentialList != null;

        Vector args = new Vector(2);
        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable<String, String> fieldsHashtable = new Hashtable<String, String>(fields);

        assert fieldsHashtable.containsKey("SLIVER_INFO_SLICE_URN") == (sliceUrn == null) : "Either specify sliceUrn (non-null) or add \"SLIVER_INFO_SLICE_URN\" to \"fields\". (exactly 1 is required)";
        assert fieldsHashtable.containsKey("SLIVER_INFO_URN") == (sliverUrn == null) : "Either specify sliverUrn (non-null) or add \"SLIVER_INFO_URN\" to \"fields\". (exactly 1 is required)";
        assert fieldsHashtable.containsKey("SLIVER_INFO_AGGREGATE_URN") == (aggregateUrn == null) : "Either specify aggregateUrn (non-null) or add \"SLIVER_INFO_AGGREGATE_URN\" to \"fields\". (exactly 1 is required)";
        assert fieldsHashtable.containsKey("SLIVER_INFO_CREATOR_URN") == (creatorUrn == null) : "Either specify creatorUrn (non-null) or add \"SLIVER_INFO_CREATOR_URN\" to \"fields\". (exactly 1 is required)";

        if (sliceUrn != null)
            fieldsHashtable.put("SLIVER_INFO_SLICE_URN", sliceUrn);
        if (sliverUrn != null)
            fieldsHashtable.put("SLIVER_INFO_URN", sliverUrn);
        if (aggregateUrn != null)
            fieldsHashtable.put("SLIVER_INFO_AGGREGATE_URN", aggregateUrn);
        if (creatorUrn != null)
            fieldsHashtable.put("SLIVER_INFO_CREATOR_URN", creatorUrn);

        Hashtable optionsHashtable = new Hashtable();
        optionsHashtable.put("fields", fieldsHashtable);
        if (extraOptions != null)
            optionsHashtable.putAll(extraOptions);
        args.add(optionsHashtable);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "create_project", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<Hashtable<String, Object>> r = null;
        try {
            Hashtable<String, Object> resHashtable = apiSpecifiesHashtableStringToObject(resultValueObject);
            r = new FederationApiReply<Hashtable<String, Object>>(res, resHashtable);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "createSliverInfo", "create_sliver_info", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<Hashtable<String, Object>>(res, null);
        log(res, r, "createSliverInfo", "create_sliver_info", con, methodParams);
        return r;
    }

    /*
         # Delete a sliver_info record
         #
         # Arguments:
         #    sliver_urn: urn of sliver whose record is to be deleted
         #
         # Return:
         #   True if succeeded
         #
         #Should return ARGUMENT_ERROR if no such sliver urn is registered
         def delete_sliver_info(sliver_urn, credentials, options)
    */
    @ApiMethod(order=10, hint="delete_sliver_info call:")
    public FederationApiReply<String> deleteSliverInfo(SfaConnection con,
                                                       @ApiMethodParameter(name = "sliverUrn", hint="", parameterType=ApiMethodParameterType.URN)
                                                       GeniUrn sliverUrn,
                                                       @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                       List<AnyCredential> credentialList,
                                                       @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                       Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "sliverUrn", sliverUrn, "extraOptions", extraOptions);
        assert credentialList != null;
        assert sliverUrn != null;

        Vector args = new Vector(3);
        args.add(sliverUrn);

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable options = new Hashtable();
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "delete_sliver_info", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        //should return nothing at all, but if there is anything, we convert it to string and return it
        FederationApiReply<String> r = new FederationApiReply<String>(res, resultValueObject == null ? null : resultValueObject+"");
        log(res, r, "deleteSliverInfo", "delete_sliver_info", con, methodParams);
        return r;
    }


    /*
        # Lookup sliver_info for given match criteria return fields in given filter criteria
        #
        # Arguments:
        #   options: 'match' for query match criteria, 'filter' for fields to be returned
        #
        # Return:
        #    Dictionary (indexed by sliver_urn) of dictionaries containing name/value pairs for all sliver_infos registered at this SA matching given criteria.
        def lookup_sliver_info(credentials, options)
    */
    @ApiMethod(order=11, hint="lookup_sliver_info call:")
    public FederationApiReply<LookupResult> lookupSliverInfo(SfaConnection con,
                                                             @ApiMethodParameter(name = "credentialList", hint = "", parameterType = ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                             List<AnyCredential> credentialList,
                                                             @ApiMethodParameter(name = "sliceUrn", hint = "convenience argument: SLIVER_INFO_SLICE_URN to add to match argument", parameterType = ApiMethodParameterType.SLICE_URN)
                                                             GeniUrn sliceUrn,
                                                             @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API1_MATCH)
                                                             Map<String, ? extends Object> match,
                                                             @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API1_FILTER)
                                                             List<String> filter,
                                                             @ApiMethodParameter(name = "extraOptions", hint = "extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                             Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "sliceUrn", sliceUrn, "match", match, "filter", filter, "extraOptions", extraOptions);
        assert credentialList != null;
        assert match != null || sliceUrn != null;

        Hashtable<String, Object> matchHashtable;
        if (match == null)
            matchHashtable = new Hashtable<String, Object>();
        else
            matchHashtable = new Hashtable<String, Object>(match);
//        assert matchHashtable.contains("SLIVER_INFO_SLICE_URN") == (sliceUrn == null) : "Either specify sliceUrn (non-null) or add \"SLIVER_INFO_SLICE_URN\" to \"fields\". (exactly 1 is required)";

        if (sliceUrn != null)
            matchHashtable.put("SLIVER_INFO_SLICE_URN", sliceUrn.getValue());

        return genericLookupCall(methodParams, con, "lookupSliverInfo", "lookup_sliver_info", credentialList, matchHashtable, filter, extraOptions, null);
    }

    /*
        # Update the details of a sliver_info record
        #
        #Arguments:
        #   sliver_urn: urn of sliver for which to update
        #   options: 'fields' containing fields for sliver_infos that are permitted for update
        #
        # Return:
        #   True if succeeded
        #
        # Should return ARGUMENT_ERROR if no such sliver_urn is found
        def update_sliver_info(sliver_urn, credentials, options)
    */
    @ApiMethod(order=12, hint="lookup_sliver_info call:")
    public FederationApiReply<String> updateSliverInfo(SfaConnection con,
                                                       @ApiMethodParameter(name = "credentialList", hint = "", parameterType = ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                       List<AnyCredential> credentialList,
                                                       @ApiMethodParameter(name = "sliceUrn", hint = "URN of sliver to update", parameterType = ApiMethodParameterType.SLICE_URN)
                                                       GeniUrn sliceUrn,
                                                       @ApiMethodParameter(name = "fields", hint="fields top update", parameterType=ApiMethodParameterType.CH_API1_FIELDS)
                                                       Map<String, String> fields,
                                                       @ApiMethodParameter(name = "extraOptions", hint = "extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                       Map<String, Object> extraOptions)  throws JFedException {
        assert credentialList != null;
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "sliceUrn", sliceUrn, "fields", fields, "extraOptions", extraOptions);
        return genericUpdateCall(methodParams, con, "updateSliverInfo", "update_sliver_info", credentialList, sliceUrn.getValue(), "slice", fields, extraOptions, null);
    }


    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////// Project Service Methods /////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /*
        Create project with given details. See generic create_* description above.
        Arguments:
           Options: Dictionary of name/value pairs for newly created project.
        Return:
           Dictionary of name/value pairs of newly created project including urn

        function create_project(credentials, options)
    */
    @ApiMethod(order=13, hint="create_project call:")
    public FederationApiReply<Hashtable<String, Object>> createProject(SfaConnection con,
                                                                       @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                       List<AnyCredential> credentialList,
                                                                       @ApiMethodParameter(name = "projectName", required=false, hint="", parameterType=ApiMethodParameterType.STRING)
                                                                       String projectName,
                                                                       @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API1_FIELDS)
                                                                       Map<String, String> fields,
                                                                       @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                       Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList,
                "projectName", projectName,
                "fields", fields,
                "extraOptions", extraOptions);
        assert credentialList != null;
        assert fields != null;
        assert !fields.isEmpty();

        Vector args = new Vector(2);
        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable<String, String> fieldsHashtable = new Hashtable<String, String>(fields);
        assert fieldsHashtable.containsKey("PROJECT_NAME") == (projectName == null) : "Either specify projectName (non-null) or add \"PROJECT_NAME\" to \"fields\". (exactly 1 is required)";
        if (projectName != null)
            fieldsHashtable.put("PROJECT_NAME", projectName);
        Hashtable optionsHashtable = new Hashtable();
        optionsHashtable.put("fields", fieldsHashtable);
        if (extraOptions != null)
            optionsHashtable.putAll(extraOptions);
        args.add(optionsHashtable);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "create_project", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<Hashtable<String, Object>> r = null;
        try {
            Hashtable<String, Object> resHashtable = apiSpecifiesHashtableStringToObject(resultValueObject);
            r = new FederationApiReply<Hashtable<String, Object>>(res, resHashtable);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "createProject", "create_project", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<Hashtable<String, Object>>(res, null);
        log(res, r, "createProject", "create_project", con, methodParams);
        return r;
    }



/*
Lookup project detail for projects matching ‘match options.
‘filter options indicate what detail to provide.
Arguments:
options: What details to provide (filter options) for which members (match options)
Return: Dictionary of name/value pairs from ‘filter’ options for each project matching ‘match’ option criteria.

function lookup_projects (credentials, options)
*/

    @ApiMethod(order=14, hint="lookup_projects call:")
    public FederationApiReply<LookupResult> lookupProjects(SfaConnection con,
                                                           @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                           List<AnyCredential> credentialList,
                                                           @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API1_MATCH)
                                                           Map<String, ? extends Object> match,
                                                           @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API1_FILTER)
                                                           List<String> filter,
                                                           @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                           Map<String, Object> extraOptions)  throws JFedException {
        assert credentialList != null;
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "match", match, "filter", filter, "extraOptions", extraOptions);
        return genericLookupCall(methodParams, con, "lookupProjects", "lookup_projects", credentialList, match, filter, extraOptions, null);
    }

    /*
    Update fields in given project object, as allowed in Get_version advertisement. See generic update_* description above.
    Arguments:
    project_urn: URN of project to update
    Options: What details to update (key/value pairs)
    Return: None
    function update_project(project_urn, credentials, options)
    */
    @ApiMethod(order=15, hint="update_project call:")
    /** normally returns nothing at all. Anything that might be returned anyway is converted to string, but normally a null Object will be returned. */
    public FederationApiReply<String> updateProject(SfaConnection con,
                                                    @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                    List<AnyCredential> credentialList,
                                                    @ApiMethodParameter(name = "projectUrn", hint="", parameterType=ApiMethodParameterType.URN)
                                                    GeniUrn projectUrn,
                                                    @ApiMethodParameter(name = "fields", hint="", parameterType=ApiMethodParameterType.CH_API1_FIELDS)
                                                    Map<String, String> fields,
                                                    @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false,
                                                            parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                    Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "projectUrn", projectUrn, "fields", fields, "extraOptions", extraOptions);
        return genericUpdateCall(methodParams, con, "updateProject", "update_project", credentialList, projectUrn.getValue(), "project", fields, extraOptions);
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Project Member Service Methods /////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
Modify project membership, adding, removing and changing roles of members with respect to given project
Arguments:
  project_urn: Name of project for which to modify membership
  members_to_add: List of member_urn/role tuples for members to add to project
  members_to_remove: List of member_urn of members to remove from project
  members_to_change: List of member_urn/role tuples for members whose role should change as specified for given project
Return:
   None

    function modify_project_membership (project_urn, members_to_add, members_to_remove, members_to_modify, credentials, options)
*/

    @ApiMethod(order=16, hint="modify_project_membership call:")
    public FederationApiReply<String> modifyProjectMembership(SfaConnection con,
                                                              @ApiMethodParameter(name = "projectUrn", hint="", parameterType=ApiMethodParameterType.URN)
                                                              GeniUrn projectUrn,
                                                              @ApiMethodParameter(name = "membersToAdd", hint="", parameterType=ApiMethodParameterType.CH_API_LIST_MEMBER_TUPLES)
                                                              List<UrnRoleTuple> membersToAdd,
                                                              @ApiMethodParameter(name = "membersToRemove", hint="", parameterType=ApiMethodParameterType.LIST_OF_URN_STRING)
                                                              List<GeniUrn> membersToRemove,
                                                              @ApiMethodParameter(name = "membersToChange", hint="", parameterType=ApiMethodParameterType.CH_API_LIST_MEMBER_TUPLES)
                                                              List<UrnRoleTuple> membersToChange,
                                                              @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                              List<AnyCredential> credentialList,
                                                              @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                              Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("projectUrn", projectUrn,
                "membersToAdd", membersToAdd, "membersToRemove", membersToRemove, "membersToChange", membersToChange,
                "credentialList", credentialList, "extraOptions", extraOptions);
        assert credentialList != null;
        assert projectUrn != null;

        Vector args = new Vector(6);
        args.add(projectUrn.getValue());

        Vector membersToAddVector = new Vector();
        for (UrnRoleTuple mt : membersToAdd)
            membersToAddVector.add(mt.toVector());
        args.add(membersToAddVector);

        Vector membersToRemoveVector = new Vector();
        for (GeniUrn u : membersToRemove)
            membersToRemoveVector.add(u.toString());
        args.add(membersToRemoveVector);

        Vector membersToChangeVector = new Vector();
        for (UrnRoleTuple mt : membersToChange)
            membersToChangeVector.add(mt.toVector());
        args.add(membersToChangeVector);

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        Hashtable options = new Hashtable();
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "modify_project_membership", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        //should return nothing at all, but if there is anything, we convert it to string and return it
        FederationApiReply<String> r = new FederationApiReply<String>(res, resultValueObject == null ? null : resultValueObject+"");
        log(res, r, "modifyProjectMembership", "modify_project_membership", con, methodParams);
        return r;
    }
    /*
    Lookup members of given project and their roles within that project
    Arguments:
      project_urn: project_urn for which to provide current members and roles
    Return:
       Dictionary of member_urn/role pairs

        function lookup_project_members (project_urn, credentials, options)
    */
    @ApiMethod(order=17, hint="lookup_project_members call: Lookup members of given project and their roles within that project")
    public FederationApiReply<List<UrnRoleTuple>> lookupProjectMembers(SfaConnection con,
                                                                       @ApiMethodParameter(name = "projectUrn", hint="project_urn for which to provide current members and roles", parameterType=ApiMethodParameterType.URN)
                                                                       GeniUrn projectUrn,
                                                                       @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                       List<AnyCredential> credentialList,
                                                                       @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                       Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "projectUrn", projectUrn, "extraOptions", extraOptions);
        assert credentialList != null;

        Vector args = new Vector();
        args.add(projectUrn.getValue());

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);

        if (extraOptions != null)
            args.add(extraOptions);
        else
            args.add(new Hashtable());

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "lookup_project_members", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<List<UrnRoleTuple>> r = null;
        try {
            Vector<Hashtable> resDicts = apiSpecifiesVectorOfT(Hashtable.class, resultValueObject);
            List<UrnRoleTuple> resList = new ArrayList<UrnRoleTuple>();
            for (Hashtable dict : resDicts) {
                resList.add(new UrnRoleTuple(dict, "PROJECT_MEMBER", "PROJECT_ROLE"));
            }
            r = new FederationApiReply<List<UrnRoleTuple>>(res, resList);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "lookupProjectMembers", "lookup_project_members", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<List<UrnRoleTuple>>(res, null);
        log(res, r, "lookupProjectMembers", "lookup_project_members", con, methodParams);
        return r;
    }


    public FederationApiReply<List<UrnRoleTuple>> lookupProjectsForMember(SfaConnection con,
                                                                          @ApiMethodParameter(name = "memberUrn", hint="", parameterType=ApiMethodParameterType.URN)
                                                                          GeniUrn memberUrn,
                                                                          @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                          List<AnyCredential> credentialList,
                                                                          @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false,
                                                                                  guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                          Map<String, Object> extraOptions)  throws JFedException {
        return this.lookupProjectsForMember(con, memberUrn, credentialList, null, null, extraOptions);
    }
    /*
    Lookup projects for which the given member belongs
    Arguments:
      Member_urn: The member for whom to find projects to which it belongs
    Return:
       Dictionary of project_urn/role pairs (‘PROJECT_URN’ : project_urn, ‘PROJECT_ROLE’ : role} where role is a string of the role name

       function lookup_projects_for_member(member_urn, credentials, options)
    */
    @ApiMethod(order=18, hint="lookup_projects_for_member call  (doesn't actually support match or filter, but you can provide them anyway):")
    public FederationApiReply<List<UrnRoleTuple>> lookupProjectsForMember(SfaConnection con,
                                                                          @ApiMethodParameter(name = "memberUrn", hint="", parameterType=ApiMethodParameterType.URN)
                                                                          GeniUrn memberUrn,
                                                                          @ApiMethodParameter(name = "credentialList", hint="", parameterType=ApiMethodParameterType.LIST_OF_CREDENTIAL)
                                                                          List<AnyCredential> credentialList,
                                                                          @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API1_MATCH)
                                                                          Map<String, ? extends Object> match,
                                                                          @ApiMethodParameter(name = "filter", hint="", parameterType=ApiMethodParameterType.CH_API1_FILTER)
                                                                          List<String> filter,
                                                                          @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                          Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("credentialList", credentialList, "memberUrn", memberUrn, "extraOptions", extraOptions);
        assert credentialList != null;

        Vector args = new Vector();
        args.add(memberUrn.toString());

        Vector credentials = createCredentialsVectorWithTypeAndVersion(credentialList);
        args.add(credentials);
        Hashtable options = new Hashtable();
        if (match != null) {
            Map<String, Object> newmatch = new HashMap<String, Object>(match);
            if (match.containsKey("EXPIRED")) {
                Object t = match.get("EXPIRED");
                newmatch.put("EXPIRED", TextUtil.objectToBoolean(t));
            }
            options.put("match", new Hashtable<String, Object>(newmatch));
        }
        if (filter != null/* && !filter.isEmpty()*/) {
            options.put("filter", new Vector<String>(filter));
        }
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "lookup_projects_for_member", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<List<UrnRoleTuple>> r = null;
        try {
            Vector<Hashtable> resDicts = apiSpecifiesVectorOfT(Hashtable.class, resultValueObject);
            List<UrnRoleTuple> resList = new ArrayList<UrnRoleTuple>();
            for (Hashtable dict : resDicts) {
                resList.add(new UrnRoleTuple(dict, "PROJECT_URN", "PROJECT_ROLE"));
            }
            r = new FederationApiReply<List<UrnRoleTuple>>(res, resList);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "lookupProjectsForMember", "lookup_projects_for_member", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<List<UrnRoleTuple>>(res, null);
        log(res, r, "lookupProjectsForMember", "lookup_projects_for_member", con, methodParams);
        return r;
    }



}
