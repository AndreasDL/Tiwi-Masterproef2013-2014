package be.iminds.ilabt.jfed.lowlevel;

import org.apache.http.StatusLine;

import java.util.Date;
import java.util.Vector;

/**
 * XMLRPCCallDetails
 */
public interface HttpCallDetails {
    public String getServerUrl();
    public String getRequestHttpRequestLine();
    public String getRequestHttpHeaders();
    public String getRequestHttpContent();
    public int getResultHttpStatusCode();
    public String getResultHttpStatusReasonPhrase();
    public String getResultHttpStatusLine();
    public StatusLine getResultHttpStatusLineObject();
    public String getResultHttpHeaders();
    public String getResultHttpContent();

    public Date getStartTime();
    public Date getStopTime();

    public Throwable getException();
}
