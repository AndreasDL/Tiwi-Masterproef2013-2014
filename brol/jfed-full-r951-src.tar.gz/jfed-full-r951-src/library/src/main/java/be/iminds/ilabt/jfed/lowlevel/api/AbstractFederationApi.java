package be.iminds.ilabt.jfed.lowlevel.api;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;

import java.util.*;

/**
 * AbstractGeniClearingHouseApi
 */
public abstract class AbstractFederationApi extends AbstractApi {
    private static org.apache.logging.log4j.Logger l4jLogger = LogManager.getLogger();
    /*
     * How to handle errors due to malformed replies
     * if true, will try to handle errors as much as possible.
     * if false, will throw errors on malformed replies.
     *
     *  true is useful when creating a client tool that needs to be robust
     *  false is useful when creating a test
     * */
    protected boolean handleMalformedReplies = true;

    protected void handleErrorProcessingArguments(XMLRPCCallDetailsGeni res, String methodJavaName, String methodGeniName, SfaConnection con, Throwable t) throws JFedException {
        boolean isSuccess = true;
        Object resultCode = res.getResultCode();
//        if (resultCode != null && resultCode instanceof Hashtable) {
//            Hashtable codeStruct = (Hashtable) resultCode;
//            int code = (Integer) codeStruct.get("geni_code");
//            GeniResponseCode genicode = GeniAMResponseCode.getByCode(code);
//            isSuccess = genicode.isSuccess();
//        }
        if (resultCode != null && resultCode instanceof Integer) {
            int code = (Integer) resultCode;
            try {
            GeniResponseCode genicode = GeniCHResponseCode.getByCode(code);
            isSuccess = genicode.isSuccess();
            } catch (Exception e) { /* ignore */ isSuccess = false; }
//            isSuccess = code == 0;
        }

        if (!handleMalformedReplies && isSuccess) {
            //If call failed, error may be ignored.
            log(res, null, methodJavaName, methodGeniName, con, null);
            throw new JFedException("Error parsing "+methodGeniName+" reply: "+(t == null ? "null" : t.getMessage()), t, res);
        }
        else {
            l4jLogger.error("Error parsing "+methodGeniName+" reply: "+t);
        }
    }

    public static class GetVersionResult {
        protected String version;
        protected List<String> supportedCredentialTypes;
        protected Map<String, FieldInfo> fieldInfos; //field name -> multiple attributes (attributes have name and value)

        public static class FieldInfo {
            public enum FieldType { URN, URL, UID, STRING, DATETIME, EMAIL, KEY, BOOLEAN, CERTIFICATE, CREDENTIALS, INTEGER,
                PEERS/*Vector of Hastables containing "url" and "version"*/
            };
            public enum CreationAllowed { REQUIRED, ALLOWED, NOT_ALLOWED };
            public enum Protect { PUBLIC, PRIVATE, IDENTIFYING };

            private Map<String, Object> attributes; //all attributes
            private Map<String, Object> extraAttributes; //only non recognized

            private final String name;
            //known fields with defaults
            private FieldType fieldType;
            private CreationAllowed creationAllowed = CreationAllowed.NOT_ALLOWED;
            private boolean match = true;
            private boolean updateable = false;
            private Protect protect = Protect.PUBLIC; //default
            private String object = null;

            @Override
            public String toString() {
                return "FieldInfo{" +
                        "name=" + name +
                        ", fieldType=" + fieldType +
                        ", creationAllowed=" + creationAllowed +
                        ", match=" + match +
                        ", updateable=" + updateable +
                        ", protect=" + protect +
                        ", object='" + object + '\'' +
                        '}';
            }

            public FieldInfo(String name, FieldType fieldType) {
                this.name = name;
                this.fieldType = fieldType;
                //TODO initialise and fill in attributes and extraAttributes
            }
            public FieldInfo(String object, String name, FieldType fieldType, CreationAllowed creationAllowed, boolean match, boolean updateable) {
                this.name = name;
                this.fieldType = fieldType;
                this.creationAllowed = creationAllowed;
                this.match = match;
                this.updateable = updateable;
                this.object = object;
                //TODO initialise and fill in attributes and extraAttributes
            }
            public FieldInfo(String object, String name, FieldType fieldType, boolean match, Protect protect) {
                this.name = name;
                this.fieldType = fieldType;
                this.match = match;
                this.protect = protect;
                this.object = object;
                //TODO initialise and fill in attributes and extraAttributes
            }
            public FieldInfo(String object, String name, FieldType fieldType, CreationAllowed creationAllowed, boolean match, boolean updateable, Protect protect) {
                this.name = name;
                this.fieldType = fieldType;
                this.creationAllowed = creationAllowed;
                this.match = match;
                this.updateable = updateable;
                this.protect = protect;
                this.object = object;
                //TODO initialise and fill in attributes and extraAttributes
            }

            public FieldInfo(String name, Hashtable<String, Object> attributesTable) throws BadReplyGeniException {
                attributes = new HashMap<String, Object>();
                extraAttributes = new HashMap<String, Object>();

                this.name = name;
                for (Map.Entry<String, Object> entry : attributesTable.entrySet()) {
                    boolean known = false;

                    assert entry != null;
                    assert entry.getKey() != null;
                    assert entry.getValue() != null;

                    if (entry.getKey().equals("TYPE")) {
                        try {
                            fieldType = FieldType.valueOf((String) entry.getValue()); //throws exception when unknown value
                        } catch (IllegalArgumentException e) {
                            throw new BadReplyGeniException("field TYPE with value \""+entry.getValue()+"\" is unknown");
                        }
                        if (fieldType == null)
                            throw new BadReplyGeniException("field TYPE with value \""+entry.getValue()+"\" is unknown");
                        known = true;
                    }

                    if (entry.getKey().equals("CREATE")) {
                        try {
                            creationAllowed = CreationAllowed.valueOf((String) entry.getValue()); //throws exception when unknown value
                        } catch (IllegalArgumentException e) {
                            throw new BadReplyGeniException("field CREATE with value \""+entry.getValue()+"\" is unknown");
                        }
                        if (creationAllowed == null)
                            throw new BadReplyGeniException("field CREATE with value \""+entry.getValue()+"\" is unknown");
                        known = true;
                    }

                    if (entry.getKey().equals("UPDATE")) {
                        if (entry.getValue() instanceof String && ((String) entry.getValue()).equalsIgnoreCase("true")) {
                            updateable = true;
                            known = true;
                        }
                        if (entry.getValue() instanceof Boolean) {
                            updateable = (Boolean) entry.getValue();
                            known = true;
                        }
                        if (entry.getValue() instanceof String && ((String) entry.getValue()).equalsIgnoreCase("false")) {
                            updateable = false;
                            known = true;
                        }
                        if (!known)
                            throw new BadReplyGeniException("field UPDATE with value \""+entry.getValue()+"\" is unknown");
                    }

                    if (entry.getKey().equals("MATCH")) {
                        if (entry.getValue() instanceof String && ((String) entry.getValue()).equalsIgnoreCase("true")) {
                            match = true;
                            known = true;
                        }
                        if (entry.getValue() instanceof Boolean) {
                            match = (Boolean) entry.getValue();
                            known = true;
                        }
                        if (entry.getValue() instanceof String && ((String) entry.getValue()).equalsIgnoreCase("false")) {
                            match = false;
                            known = true;
                        }
                        if (!known)
                            throw new BadReplyGeniException("field MATCH with value \""+entry.getValue()+"\" is unknown");
                    }

                    if (entry.getKey().equals("PROTECT")) {
                        try {
                            protect = Protect.valueOf((String) entry.getValue()); //throws exception when unknown value
                        } catch (IllegalArgumentException e) {
                            throw new BadReplyGeniException("field PROTECT with value \""+entry.getValue()+"\" is unknown");
                        }
                        if (protect == null)
                            throw new BadReplyGeniException("field PROTECT with value \""+entry.getValue()+"\" is unknown");
                        known = true;
                    }

                    if (entry.getKey().equals("OBJECT")) {
                        object = (String) entry.getValue();
                        known = true;
                    }

                    if (!known)
                        extraAttributes.put(entry.getKey(), entry.getValue());
                    attributes.put(entry.getKey(), entry.getValue());
                }


            }

            /** query all attributes, including the known ones (TYPE, CREATE, UPDATE, PROTECT). */
            public Object getAttribute(String name) {
                return attributes.get(name);
            }

            /** query only unknown attributes, excluding the known ones (TYPE, CREATE, UPDATE, PROTECT). */
            public Object getExtraAttribute(String name) {
                return extraAttributes.get(name);
            }

            public FieldType getType() {
                return fieldType;
            }

            public CreationAllowed getCreationAllowed() {
                return creationAllowed;
            }

            public boolean isUpdateable() {
                return updateable;
            }

            public Protect getProtect() {
                return protect;
            }

            public String getName() {
                return name;
            }

            public boolean isMatchable() {
                return match;
            }

            /**
             * @return null if OBJECT not specified. In that case it is the default for the API
             *   (i.e. SLICE for Slice Authority, MEMBER for Member Authority, SERVICE for Clearinghouse) */
            public String getObject() {
                return object;
            }
        }

        public GetVersionResult(Hashtable<String, Object> versionInfo) throws BadReplyGeniException {
            version = apiSpecifiesNonNullString(versionInfo.get("VERSION"));

            if (versionInfo.containsKey("CREDENTIAL_TYPES"))
                supportedCredentialTypes = new ArrayList(apiSpecifiesVectorOfString(versionInfo.get("CREDENTIAL_TYPES")));

            fieldInfos = new HashMap<String, FieldInfo>(); //always initialize, even if FIELDS not specified
            if (versionInfo.containsKey("FIELDS")) {
                Hashtable<String, Object> fields = apiSpecifiesHashtableStringToObject(versionInfo.get("FIELDS"));
                for (Map.Entry<String, Object> entry : fields.entrySet()) {
                    FieldInfo fieldInfo = new FieldInfo(entry.getKey(), apiSpecifiesHashtableStringToObject(entry.getValue()));
                    fieldInfos.put(entry.getKey(), fieldInfo);
                }
            }
        }

        public String getVersion() {
            return version;
        }

        public List<String> getSupportedCredentialTypes() {
            return supportedCredentialTypes;
        }

        public Map<String, FieldInfo> getFields() {
            return fieldInfos;
        }

        public Map<String, FieldInfo> getFieldsForObject(String objectName) {
            if (fieldInfos == null) return null;
            Map<String, FieldInfo> objectFields = new HashMap<String, FieldInfo>();
            for (Map.Entry<String, FieldInfo> e : fieldInfos.entrySet()) {
                String fieldName = e.getKey();
                FieldInfo fieldInfo = e.getValue();
                if (fieldInfo.getObject() != null && objectName != null && fieldInfo.getObject().equals(objectName))
                    objectFields.put(fieldName, fieldInfo);
            }
            return objectFields;
        }

        @Override
        public String toString() {
            return "GetVersionResult{" +
                    "version='" + version + '\'' +
                    ", supportedCredentialTypes=" + supportedCredentialTypes +
                    ", fieldInfos=" + fieldInfos +
                    '}';
        }
    }

    public static class FederationApiReply<T> implements ApiCallReply<T> {
        private GeniCHResponseCode genicode;
        private T val;
        /* output is typically set only on error*/
        private String output;

        private Hashtable rawResult;

        private XMLRPCCallDetailsGeni xmlRpcCallDetailsGeni;

        public int getCode() {
            return genicode.getCode();
        }
        public GeniCHResponseCode getGeniResponseCode() {
            return genicode;
        }

        public T getValue() {
            return val;
        }

        /** can be null */
        public String getOutput() {
            return output;
        }

        public XMLRPCCallDetailsGeni getXmlRpcCallDetailsGeni() {
            return xmlRpcCallDetailsGeni;
        }

        public static boolean isSuccess(XMLRPCCallDetails res) {
            if (res instanceof XMLRPCCallDetailsGeni) {
                XMLRPCCallDetailsGeni geniDetails = (XMLRPCCallDetailsGeni) res;
                if (!(geniDetails.getResultCode() instanceof Integer))
                    return false;
                int code = (Integer) geniDetails.getResultCode();
                GeniResponseCode genicode = GeniCHResponseCode.getByCode(code);
                return genicode.isSuccess();
            }
            return false; //not a geni reply, so not successful
        }
        public FederationApiReply(XMLRPCCallDetailsGeni res) {
            this.xmlRpcCallDetailsGeni = res;
            this.rawResult = res.getResult();

            Hashtable r = res.getResult();
            try {
                this.val = (T) r.get("value");
            } catch (/*ClassCast*/Exception e) {
                //ignore
                this.val = null;
            }
            Object codeObject = res.getResultCode();
            int code = codeObject == null || !(codeObject instanceof Integer) ? GeniCHResponseCode.SERVER_REPLY_ERROR.getCode() : (Integer) codeObject;
            this.genicode = GeniCHResponseCode.getByCode(code);
            this.output = null; //this should be a string, but we allow more. This may be null on success.
            if (r != null && r.get("output") != null) {
                this.output = r.get("output").toString();
                //any empty structure is interpreted as an empty string
                if (r.get("output") instanceof Hashtable && ((Hashtable)r.get("output")).isEmpty() )
                    this.output = "";
                if (r.get("output") instanceof Vector && ((Vector)r.get("output")).isEmpty() )
                    this.output = "";
            }
        }

        public FederationApiReply(XMLRPCCallDetailsGeni res, T val) {
            this(res);
            this.val = val;
        }

        public Hashtable getRawResult() {
            return rawResult;
        }
        public Object getRawValue() {
            if (rawResult == null) return null;
            return rawResult.get("value");
        }
    }

    @Override
    protected boolean isBusyReply(XMLRPCCallDetails res) {
        //TODO: see AbstractGeniAggregateManager
        return false;
    }

    public AbstractFederationApi(Logger logger, boolean autoRetryBusy, ServerType serverType) {
        super(logger, autoRetryBusy, serverType);
    }


    public static List<AnyCredential> apiSpecifiesVectorOfCredentials(String credentialBaseName, Object o) throws BadReplyGeniException, CredentialException {
        Vector<Hashtable> vectOfDicts = AbstractApi.<Hashtable>apiSpecifiesVectorOfT(Hashtable.class, o);

        int i = 0;

        List<AnyCredential> res = new ArrayList<AnyCredential>();
        for (Hashtable ht : vectOfDicts) {

            String credName = credentialBaseName;
            if (vectOfDicts.size() > 1)
                credName += " "+i;

            AnyCredential cred = AnyCredential.createFromV3Hashtable(credName, ht);

            res.add(cred);

            i++;
        }

        return res;
    }

    /**
     * The result of a lookup operation.
     *
     * This is indexed in 2 ways:
     *   - by urn (String or GeniUrn)
     *   - by index nr
     *
     * The objects returned are accessable as either:
     *  - Hashtable<String, Object>
     *  - an object of the class "T"
     * */
    public static class LookupResult<T> {
        Hashtable<String, Hashtable<String, Object>> raw;
        private List<String> keys;
        private LookupResultConverter<T> converter;

        public LookupResult(Object res, LookupResultConverter<T> converter) throws BadReplyGeniException {
            this.converter = converter;
            Hashtable<String, Object> res2 = apiSpecifiesHashtableStringToObject(res);
            raw = new Hashtable<String, Hashtable<String, Object>>();
            for (Map.Entry<String, Object> o : res2.entrySet()) {
                Hashtable<String, Object> o2 = apiSpecifiesHashtableStringToObject(o.getValue());
                raw.put(o.getKey(), o2);
            }
            keys = new ArrayList<String>(raw.keySet());
            assert keys.size() == raw.size();
        }

        public int size() {
            return raw.size();
        }

        public boolean isEmpty() {
            return raw.isEmpty();
        }

        public Hashtable<String, Object> get(int i) {
            return raw.get(keys.get(i));
        }

        public Hashtable<String, Object> get(String urn) {
            return raw.get(urn);
        }
        public Hashtable<String, Object> get(GeniUrn urn) {
            return raw.get(urn.getValue());
        }

        public T getConverted(int i) throws JFedException {
            if (convertedList != null) return convertedList.get(i); //use cache if available
            if (converter == null) throw new RuntimeException("No LookupResultConverter specified");
            String urn = keys.get(i);
            Hashtable<String, Object> val = raw.get(urn);
            return converter.convert(urn, val);
        }

        public T getConverted(String urn) throws JFedException {
            if (converter == null) throw new RuntimeException("No LookupResultConverter specified");
            Hashtable<String, Object> val = raw.get(urn);
            return converter.convert(urn, val);
        }

        public T getConverted(GeniUrn urn) throws JFedException {
            if (converter == null) throw new RuntimeException("No LookupResultConverter specified");
            Hashtable<String, Object> val = raw.get(urn.getValue());
            return converter.convert(urn.getValue(), val);
        }

        private List<T> convertedList; //cached version of list: conversion is only done once
        public List<T> getConvertedList() throws JFedException {
            if (convertedList != null) return convertedList;

            List<T> res = new ArrayList<T>(raw.size());
            for (Map.Entry<String, Hashtable<String, Object>> e :  raw.entrySet()) {
                T t = converter.convert(e.getKey(), e.getValue());
                res.add(t);
            }
            convertedList = Collections.unmodifiableList(res);
            return convertedList;
        }

        public Hashtable<String, Hashtable<String, Object>> getRaw() {
            return raw;
        }
    };

    public static interface LookupResultConverter<T> {
        T convert(String urn, Hashtable<String, Object> o) throws JFedException;
    };



    public abstract List<GetVersionResult.FieldInfo> getMinimumFields(String objectName);
    public List<String> getMinimumFieldNames(String objectName) {
        assert objectName != null;
        List<String> res = new ArrayList<String>();
        List<GetVersionResult.FieldInfo> minFields = getMinimumFields(objectName);
        if (minFields == null) return null;
        for (GetVersionResult.FieldInfo f :  minFields)
            res.add(f.getName());
        return res;
    }
    public Map<String, String> getMinimumFieldsMap(String objectName) {
        assert objectName != null;
        Map<String, String> res = new HashMap<String, String>();
        List<String> minFieldNames = getMinimumFieldNames(objectName);
        if (minFieldNames == null) return null;
        for (String key : minFieldNames) {
            res.put(key, key+" value");
        }
        return res;
    }
    public abstract List<String> getApiObjects();
    public abstract List<String> getOptionalApiServices();
    public abstract List<String> getRequiredApiServices();


    public void setHandleMalformedReplies(boolean handleErrors) {
        this.handleMalformedReplies = handleErrors;
    }
}
