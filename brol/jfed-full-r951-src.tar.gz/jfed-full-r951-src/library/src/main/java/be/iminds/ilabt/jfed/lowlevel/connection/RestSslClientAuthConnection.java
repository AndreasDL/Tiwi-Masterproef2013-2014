package be.iminds.ilabt.jfed.lowlevel.connection;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.authority.DebuggingAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniTrustStoreHelper;
import org.apache.http.impl.client.DefaultHttpClient;

import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.LinkedList;
import java.util.List;

/**
 * SfaSslConnection: SSL HTTP
 */
public class RestSslClientAuthConnection extends JFedConnection {
    private DefaultHttpClient httpClient;

    /**
     * @param clientCertificateChain the X509Certificates to use for the SSL connection
     * @param privateKey PrivateKey to use for client authentication of the SSL connection
     * //@param allowedCertificateHostnameAliases may be null or empty
     * @throws be.iminds.ilabt.jfed.lowlevel.JFedException
     */
    public RestSslClientAuthConnection(SfaAuthority geniAuthority, String serverUrl, List<X509Certificate> clientCertificateChain,
                                       PrivateKey privateKey,
                                       ProxyInfo proxyInfo,
                                       boolean debugMode, HttpsClientWithUserAuthenticationFactory.HandleUntrustedCallback handleUntrustedCallback) throws JFedException {
        super(geniAuthority, serverUrl, proxyInfo, debugMode);

        error = true;
        this.debugMode = debugMode;

        this.geniAuthority = geniAuthority;

        if (geniAuthority != null && DebuggingAuthorityList.isDebuggingAuth(geniAuthority)) {
            fakeForDebugging = true;
            error = false;
            this.serverUrl = serverUrl;
            return;
        }

        if (serverUrl == null) throw new IllegalArgumentException("Illegal argument: serverURL == null");
        if (clientCertificateChain == null) throw new IllegalArgumentException("Illegal argument: clientCertificateChain == null");
        if (clientCertificateChain.isEmpty()) throw new IllegalArgumentException("Illegal argument: clientCertificateChain is empty");
        if (privateKey == null) throw new IllegalArgumentException("Illegal argument: privateKey == null");

        this.serverUrl = serverUrl;

        if (geniAuthority != null && geniAuthority.getPemSslTrustCert() != null)
            GeniTrustStoreHelper.addTrustedPemCertificateIfNotAdded(geniAuthority.getPemSslTrustCert());
        KeyStore trustStore = GeniTrustStoreHelper.getFullTrustStore();

        try {
            httpClient = HttpsClientWithUserAuthenticationFactory.getHttpClient(
                    proxyInfo,
                    clientCertificateChain,
                    privateKey,
                    serverUrl,
                    trustStore,
                    geniAuthority == null ? new LinkedList<String>() : geniAuthority.getAllowedCertificateHostnameAliases(),
                    debugMode,
                    handleUntrustedCallback);
            error = false;
        } catch (Exception e) {
            throw new JFedException("Error creating XmlRpcClient in GeniConnection constructor: "+e.getMessage(), e);
        }
    }


    public DefaultHttpClient getHttpClient() {
        assert !fakeForDebugging : "Error: This connection is a fake debugging connection, yet the httpClient was requested";
        return httpClient;
    }

}