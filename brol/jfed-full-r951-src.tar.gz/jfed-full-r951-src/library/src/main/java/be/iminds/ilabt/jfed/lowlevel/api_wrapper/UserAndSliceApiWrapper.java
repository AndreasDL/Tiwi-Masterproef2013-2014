package be.iminds.ilabt.jfed.lowlevel.api_wrapper;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;

import java.util.Date;
import java.util.List;

/**
 * CredentialApiWrapper wraps API's to expose generic calls about getting client and slice info and credentials
 *
 * Can currently wrap "ProtoGeni Slice Authority API v1" and "Uniform Federation Slice Authority API draft"+"Uniform Federation Member Authority API draft"
 *
 * Some calls might result in multiple calls.
 *
 *
 * These calls does not return anything!  (it is assumed this is used from the "HighLevelController", while you are processing the results asynchronously)
 * If needed, return values could be added to this system
 */
public abstract class UserAndSliceApiWrapper {
    protected final GeniUserProvider geniUserProvider;
    protected final GeniConnectionProvider connectionProvider;
    protected final Logger logger;

    protected UserAndSliceApiWrapper(Logger logger, GeniUserProvider geniUserProvider, GeniConnectionProvider connectionProvider) {
        this.logger = logger;
        this.geniUserProvider = geniUserProvider;
        this.connectionProvider = connectionProvider;
    }

    protected SfaConnection getConnection(ServerType serverType) throws JFedException {
        GeniUser user = geniUserProvider.getLoggedInGeniUser();
        SfaAuthority userAuth = user.getUserAuthority();
        return (SfaConnection)connectionProvider.getConnectionByAuthority(user, userAuth, serverType);
    }

    protected GeniUser getUser() {
        return geniUserProvider.getLoggedInGeniUser();
    }

    protected SfaAuthority getUserAuthority() {
        GeniUser user = geniUserProvider.getLoggedInGeniUser();
        SfaAuthority userAuth = user.getUserAuthority();
        return userAuth;
    }

    /**
     * get one or more credentials for the currently logged in user
     *
     * This call does not return anything!  (it is assumed this is used from the "HighLevelController", while you are processing the results asynchronously)
     * */
    public abstract AnyCredential getUserCredentials(GeniUrn userUrn) throws JFedException;

    /**
     * get one or more credentials for the given slice
     *
     * This call does not return anything!  (it is assumed this is used from the "HighLevelController", while you are processing the results asynchronously)
     * */
    public abstract AnyCredential getSliceCredentials(AnyCredential userCredential, GeniUrn sliceUrn) throws JFedException;

    /**
     * get the list of slices for the currently given user (typically the logged in user)
     *
     * This call does not return anything!  (it is assumed this is used from the "HighLevelController", while you are processing the results asynchronously)
     * */
    public abstract List<GeniUrn> getSlicesForUser(AnyCredential userCredential, GeniUrn userUrn) throws JFedException;

    /**
     * get info about the slivers the slice is running on.
     *
     * This call does not return anything!  (it is assumed this is used from the "HighLevelController", while you are processing the results asynchronously)
     * */
    public abstract void getAggregatesForSlice(AnyCredential userCredential, AnyCredential sliceCredential, GeniUrn sliceUrn) throws JFedException;

    public class SliceInfo {
        private final String name;
        private final GeniUrn urn;
        private final AnyCredential credential;

        public SliceInfo(String name, GeniUrn urn, AnyCredential credential) {
            assert name != null;
            assert urn != null;
            assert credential != null;

            this.name = name;
            this.urn = urn;
            this.credential = credential;
        }

        public String getName() {
            return name;
        }

        public GeniUrn getUrn() {
            return urn;
        }

        public AnyCredential getCredential() {
            return credential;
        }
    }
    /**
     * create a new slice with the given name
     *
     * This call does not return anything!  (it is assumed this is used from the "HighLevelController", while you are processing the results asynchronously)
     * */
    public SliceInfo createSlice(AnyCredential userCredential, String sliceName) throws JFedException{
        return createSlice(userCredential, sliceName, null);
    }


    /**
     * create a new slice with the given name
     *
     * This call does not return anything!  (it is assumed this is used from the "HighLevelController", while you are processing the results asynchronously)
     * */
    public abstract SliceInfo createSlice(AnyCredential userCredential, String sliceName, Date expirationDate) throws JFedException;

    /**
     * Renew the slice and set the expiration time to newExpirationDate
     * @param sliceCredential
     * @param newExpirationDate
     */
    public abstract AnyCredential renewSlice(AnyCredential sliceCredential, Date newExpirationDate) throws JFedException;


    /**
     * get all SSH keys for the given user (typically the logged in user)
     *
     * This call does not return anything!  (it is assumed this is used from the "HighLevelController", while you are processing the results asynchronously)
     * */
    public abstract void getSshKeysForUser(AnyCredential userCredential, GeniUrn userUrn) throws JFedException;
}
