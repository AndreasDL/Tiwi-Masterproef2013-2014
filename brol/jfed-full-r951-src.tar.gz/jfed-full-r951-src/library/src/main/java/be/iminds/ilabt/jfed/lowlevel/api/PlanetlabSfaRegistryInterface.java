package be.iminds.ilabt.jfed.lowlevel.api;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.KeyUtil;
import be.iminds.ilabt.jfed.util.RFC3339Util;

import java.security.cert.X509Certificate;
import java.util.*;

/**
 * <p>This is a simple wrapper for the methods specified in the {@link <a href="http://svn.planet-lab.org/wiki/SfaRegistryInterface">SFA Registry Interface</a>}.
 * <p>Some functionality provided by the API is available in this implementation, and not much processing of results is done.
 * This class stores no internal state, except for the logger used. It sends all results and debug info to this {@link be.iminds.ilabt.jfed.log.Logger} if it is non null.
 *
 * <p>All methods require a {@link be.iminds.ilabt.jfed.lowlevel.connection.SfaSslConnection} argument and return a {@link PlanetlabSfaRegistryInterface.SimpleApiCallReply}
 * which wraps the actual return value of the call, if any.
 *
 * @see <a href="http://svn.planet-lab.org/wiki/SfaRegistryInterface">SFA Registry Interface</a>
 * @author Wim Van de Meerssche
 */
public class PlanetlabSfaRegistryInterface extends AbstractApi {
    /**
     * A human readable name for the implemented API
     *
     * @return "PlanetLab SFA Registry Interface"
     */
    static public String getApiName() {
        return "PlanetLab SFA Registry Interface";
    }
    /**
     * A human readable name for the implemented API
     *
     * @return "PlanetLab SFA Registry Interface"
     */
    @Override
    public String getName() {
        return getApiName();
    }

    /**
     * Construct a new PlanterlabSfaRegistryInterface, with a certain logger.
     *
     * <p>This class stores no internal state, except for the logger used. It sends all results and debug info to this {@link be.iminds.ilabt.jfed.log.Logger} if it is non null.
     *
     * @param logger the logger to use. May be null if no logger is used.
     * @param autoRetryBusy whether or not to retry when a "busy" reply is received.
     */
    public PlanetlabSfaRegistryInterface(Logger logger, boolean autoRetryBusy) {
        super(logger, autoRetryBusy, new ServerType(ServerType.GeniServerRole.PlanetLabSliceRegistry, 1));
    }
    /**
     * Construct a new PlanetlabSfaRegistryInterface, with a certain logger.
     *
     * <p>This class stores no internal state, except for the logger used. It sends all results and debug info to this {@link be.iminds.ilabt.jfed.log.Logger} if it is non null.
     *
     * <p>This constructor sets autoRetryBusy to true, so "busy" replies are retried.
     *
     * @param logger the logger to use. May be null if no logger is used.
     */
    public PlanetlabSfaRegistryInterface(Logger logger) {
        super(logger, true, new ServerType(ServerType.GeniServerRole.PlanetLabSliceRegistry, 1));
    }

    @Override
    protected boolean isBusyReply(be.iminds.ilabt.jfed.lowlevel.XMLRPCCallDetails res) {
        //API has no special reply to indicate "busy"
        return false;
    }

    public static class SimpleApiCallReply<T> implements ApiCallReply<T> {
        private T val;
        private Object rawResult;

        public Object getRawResult() {
            return rawResult;
        }

        public T getValue() {
            return val;
        }

        private XMLRPCCallDetails xmlRpcDetails;
        public SimpleApiCallReply(XMLRPCCallDetails res) {
            xmlRpcDetails = res;
            rawResult = res.getResult();
            try {
                this.val = (T) res.getResultValueObject();
            } catch (Exception e) {
                this.val = null;
            }
        }
        public SimpleApiCallReply(XMLRPCCallDetails res, T val) {
            xmlRpcDetails = res;
            this.rawResult = res.getResult();
            this.val = val;
        }
        public XMLRPCCallDetails getXmlRpcDetails() {
            return xmlRpcDetails;
        }


        //not used for this API
        @Override
        public GeniAMResponseCode getGeniResponseCode() {
            return GeniAMResponseCode.GENIRESPONSE_SUCCESS;

        }
        @Override
        public String getOutput() {
            return "";
        }
    }

    class GetVersionReply {
        private int geniApi;
        private int sfa;
        private String codeUrl;
        private String codeTag;
        private String hrn;
        private String urn;
        private Map<String,String> peers;

        public GetVersionReply(XMLRPCCallDetails reply) {
            Hashtable replyTable = (Hashtable) reply.getResult();
            geniApi = (Integer) replyTable.get("geni_api");
            sfa = (Integer) replyTable.get("sfa");
            codeUrl = (String) replyTable.get("code_url");
            codeTag = (String) replyTable.get("code_tag");
            hrn = (String) replyTable.get("hrn");
            urn = (String) replyTable.get("urn");
            Hashtable peersTable = (Hashtable) replyTable.get("peers");
            peers = new HashMap<String,String>();
            for (Object p : peersTable.keySet()) {
                String peer = (String) p;
                String peerUrl = (String) peersTable.get(p);
                peers.put(peer, peerUrl);
            }
        }

        public int getGeniApi() {
            return geniApi;
        }

        public int getSfa() {
            return sfa;
        }

        public String getCodeUrl() {
            return codeUrl;
        }

        public String getCodeTag() {
            return codeTag;
        }

        public String getHrn() {
            return hrn;
        }

        public String getUrn() {
            return urn;
        }

        public Map<String,String> getPeers() {
            return peers;
        }

        @Override
        public String toString() {
            return "GetVersionReply{" +
                    "geniApi=" + geniApi +
                    ", sfa=" + sfa +
                    ", codeUrl='" + codeUrl + '\'' +
                    ", codeTag='" + codeTag + '\'' +
                    ", hrn='" + hrn + '\'' +
                    ", urn='" + urn + '\'' +
                    ", peers=" + peers +
                    '}';
        }
    }

    /**
     * GetVersion call
     *
     * @param con the {@link be.iminds.ilabt.jfed.lowlevel.connection.SfaSslConnection} to use for this call. Must be a connection to a SfaRegistry.
     * @return The version info, wrapped in a {@code PlanetlabSfaRegistryInterface.SimpleApiCallReply}
     * @throws be.iminds.ilabt.jfed.lowlevel.JFedException
     */
    @ApiMethod(order=1, hint="GetVersion call: Get info about the version of the API supported at the server.")
    public SimpleApiCallReply<GetVersionReply> getVersion(SfaConnection con) throws JFedException {
        XMLRPCCallDetails res = executeXmlRpcCommand(con, "GetVersion", new Vector(), null, false);
        GetVersionReply r = new GetVersionReply(res);
        SimpleApiCallReply<GetVersionReply> wrappedres = new SimpleApiCallReply<GetVersionReply>(res, r);
        log(res, wrappedres, "getVersion", "GetVersion", con, null);
        return wrappedres;
    }

    /**
     * GetSelfCredential call:  A degenerate version of GetCredential used by a client to get his initial credential when de doesn't have one.

     The registry ensures that the client is the principal that is named by (type, name) by comparing the public key in the record's GID to
     the private key used to encrypt the client side of the HTTPS connection. Thus it is impossible for one principal to retrieve another
     principal's credential without having the appropriate private key.
     *
     * @param con the {@code GeniConnection} to use for this call. Must be a connection to a SfaRegistry.
     * @return the {@code AnyCredential} for the current user, wrapped in a {@code PlanetlabSfaRegistryInterface.SimpleApiCallReply}
     * @throws be.iminds.ilabt.jfed.lowlevel.JFedException
     */
    @ApiMethod(order=2, hint="GetSelfCredential call: Get the credential of the current user.")
    public SimpleApiCallReply<AnyCredential> getSelfCredential(SfaConnection con,
               @ApiMethodParameter(name = "certificate", hint="The client's certificate.", multiLineString=true)
                    String certificate,
               @ApiMethodParameter(name = "xrn", hint="The client's URN or HRN.")
                    String xrn,
               @ApiMethodParameter(name = "type", hint="The client's type (if HRN is specified).", required=false)
                    String type) throws JFedException {
        Vector args = new Vector(3);
        args.add(certificate);
        args.add(xrn);
        if (type != null)
            args.add(type);
        else
            args.add("");

        XMLRPCCallDetails res = executeXmlRpcCommand(con, "GetSelfCredential", args, null, false);
        SimpleApiCallReply<AnyCredential> r = null;
        try {
            AnyCredential signedCredential = AnyCredential.create("PlanetlabSfaRegistryInterface GetSelfCredential", res.getResultValueObject().toString());
            r = new SimpleApiCallReply<AnyCredential>(res, signedCredential);
        } catch (Exception e) {
            log(res, null, "getSelfCredential", "GetSelfCredential", con, null);
            throw new JFedException("Exception retrieving Credential for GetSelfCredential call.", e, res, null);
        }

        log(res, r, "getSelfCredential", "GetSelfCredential", con, null);
        return r;

    }

    /**
     * GetSelfCredential call:  A degenerate version of GetCredential used by a client to get his initial credential when de doesn't have one.

     The registry ensures that the client is the principal that is named by (type, name) by comparing the public key in the record's GID to
     the private key used to encrypt the client side of the HTTPS connection. Thus it is impossible for one principal to retrieve another
     principal's credential without having the appropriate private key.
     *
     * @param con the {@code GeniConnection} to use for this call. Must be a connection to a SfaRegistry.
     * @return the {@code AnyCredential} for the current user, wrapped in a {@code PlanetlabSfaRegistryInterface.SimpleApiCallReply}
     * @throws be.iminds.ilabt.jfed.lowlevel.JFedException
     */
    @ApiMethod(order=3, hint="GetSelfCredential call, with automatic argument: Get the credential of the current user.", convenienceMethodFor="getSelfCredential")
    public SimpleApiCallReply<AnyCredential> getSelfCredential_AutomaticArguments(SfaConnection con, GeniUser geniUser) throws JFedException {
        List<X509Certificate> certChain = geniUser.getClientCertificateChain();
        String certificate = "";
        for (X509Certificate c : certChain)
            certificate += KeyUtil.x509certificateToPem(c);
        String xrn = geniUser.getUserUrnString();

        Vector args = new Vector(3);
        args.add(certificate);
        args.add(xrn);
        args.add("");

        XMLRPCCallDetails res = executeXmlRpcCommand(con, "GetSelfCredential", args, null, false);
        SimpleApiCallReply<AnyCredential> r = null;
        try {
            AnyCredential signedCredential = AnyCredential.create("PlanetlabSfaRegistryInterface GetSelfCredential", res.getResultValueObject().toString());
            r = new SimpleApiCallReply<AnyCredential>(res, signedCredential);
        } catch (Exception e) {
            log(res, null, "getSelfCredential_AutomaticArguments", "GetSelfCredential", con, null);
            throw new JFedException("Exception retrieving Credential for GetSelfCredential call.", e, res, null);
        }

        log(res, r, "getSelfCredential_AutomaticArguments", "GetSelfCredential", con, null);
        return r;

    }

    /**
     * GetCredential call:  Retrieve a credential for an object.

     string GetCredential(string credentials[], string xrn, string type)

     @param credential  A single credential string or an array of credentials.
     @param xrn The objects URN or HRN.
     @param type The objects type (if HRN is specified).

     Returns a string representation of a credential object.
     *
     * @param con the {@code GeniConnection} to use for this call. Must be a connection to a SfaRegistry.
     * @return the {@code AnyCredential} for the current user, wrapped in a {@code PlanetlabSfaRegistryInterface.SimpleApiCallReply}
     * @throws be.iminds.ilabt.jfed.lowlevel.JFedException
     */
    @ApiMethod(order=4, hint="GetCredential call, without arguments: Get the credential of the current user.")
    public SimpleApiCallReply<AnyCredential> getCredential(SfaConnection con,
               @ApiMethodParameter(name = "credential", hint="A single credential string or an array of credentials (jFed currently only supports a single credential here)")
                    AnyCredential credential,
               @ApiMethodParameter(name = "xrn", hint="The objects URN or HRN.")
                    String xrn,
               @ApiMethodParameter(name = "type", hint="The objects type (if HRN is specified).", required=false)
                    String type) throws JFedException {
//        boolean isHrn = !xrn.startsWith("urn:");
        //let the user decide
//        if (isHrn == (type != null)) {
//            throw new GeniException("Error, an XRN that is a HRN, implies that type is specified. XRN is HRN (\""+xrn+"\"): "+isHrn+" type present: "+(type != null));
//        }

        Vector args = new Vector(3);
        args.add(credential.getCredentialXml());
        args.add(xrn);
        if (type != null)
            args.add(type);
        else
            args.add("");

        XMLRPCCallDetails res = executeXmlRpcCommand(con, "GetCredential", args, null, false);
        SimpleApiCallReply<AnyCredential> r = null;
        try {
            AnyCredential signedCredential = AnyCredential.create("PlanetlabSfaRegistryInterface GetCredential", res.getResultValueObject().toString());
            r = new SimpleApiCallReply<AnyCredential>(res, signedCredential);
        } catch (Exception e) {
            log(res, null, "getCredential", "GetCredential", con, null);
            throw new JFedException("Exception retrieving Credential for GetCredential call.", e, res, null);
        }

        log(res, r, "getCredential", "GetCredential", con, null);
        return r;

    }

//TODO add "Remove" from "SFA Registry Interface"

    /**
     * Resolve call:
     *
     * struct Resolve(string xrns[], string credentials[])
     *
     * @param credential  A single credential string or an array of credentials.
     * @param xrn A single object URN or HRN or an array of URNs/HRNs.
     * @param con the {@code GeniConnection} to use for this call. Must be a connection to a SfaRegistry.
     * @return a struct packed as a Hashtable (wrapped in a {@code PlanetlabSfaRegistryInterface.SimpleApiCallReply})
     *         with at least the following attributes:
     *
     *       {
     *         string hrn,
     *         string type,
     *         string date_created,
     *         string last_updated,
     *         string authority,
     *         string peer_authority,
     *         struct gid
     *         {
     *             string hrn,
     *             string urn,
     *             string uuid
     *         }
     *
     *       }
     * @throws be.iminds.ilabt.jfed.lowlevel.JFedException
     */
    @ApiMethod(order=5, hint="GetCredential call, without arguments: Get the credential of the current user.")
    public SimpleApiCallReply<Hashtable> resolve(SfaConnection con,
               @ApiMethodParameter(name = "credential", hint="A single credential string or an array of credentials (jFed currently only supports a single credential here)")
                    AnyCredential credential,
               @ApiMethodParameter(name = "xrn", hint="A single object URN or HRN or an array of URNs/HRNs. (jFed currently only supports a single object here)")
                    String xrn) throws JFedException {
        Vector args = new Vector( 2);
        args.add(xrn);
        args.add(credential.getCredentialXml());

        XMLRPCCallDetails res = executeXmlRpcCommand(con, "Resolve", args, null, false);
        SimpleApiCallReply<Hashtable> r = null;
        try {
            Hashtable table = (Hashtable) res.getResultValueObject();
            r = new SimpleApiCallReply<Hashtable>(res, table);
        } catch (Exception e) {
            log(res, null, "resolve", "Resolve", con, null);
            throw new JFedException("Exception in Resolve call.", e, res, null);
        }

        log(res, r, "resolve", "Resolve", con, null);
        return r;
    }
    /**
     * List call: List the records in an authority.
     *
     * struct[] List(string xrn, string credentials[])
     *
     * @param credential An array of credentials. At least one credential must be a valid slice credential for the slice specified in slice_urn.
     * @param xrn The authority's URN or HRN.
     * @param con the {@code GeniConnection} to use for this call. Must be a connection to a SfaRegistry.
     * @return  Returns a list of structs where each struct represents a registry record. packed as a Vector of Hashtable (wrapped in a {@code PlanetlabSfaRegistryInterface.SimpleApiCallReply})
     *
     * @throws be.iminds.ilabt.jfed.lowlevel.JFedException
     */
    @ApiMethod(order=6, hint="GetCredential call, without arguments: Get the credential of the current user.")
    public SimpleApiCallReply<Vector> list(SfaConnection con,
               @ApiMethodParameter(name = "credential", hint="A single credential string or an array of credentials (jFed currently only supports a single credential here)")
                    AnyCredential credential,
               @ApiMethodParameter(name = "xrn", hint="A single object URN or HRN or an array of URNs/HRNs. (jFed currently only supports a single object here)")
                    String xrn) throws JFedException {
        Vector args = new Vector( 2);
        args.add(xrn);
        Vector creds = new Vector(1);
        creds.add(credential.getCredentialXml());
        args.add(creds);

        XMLRPCCallDetails res = executeXmlRpcCommand(con, "List", args, null, false);
        SimpleApiCallReply<Vector> r = null;
        try {
            Vector list = (Vector) res.getResultValueObject();
            r = new SimpleApiCallReply<Vector>(res, list);
        } catch (Exception e) {
            log(res, null, "list", "List", con, null);
            throw new JFedException("Exception in List call.", e, res, null);
        }

        log(res, r, "list", "List", con, null);
        return r;
    }

/*
* info on register for slice record as found in record.py:
*
  class SliceRecord(SfaRecord):
    fields = {
        'name': Parameter(str, 'Slice name'),
        'url': Parameter(str, 'Slice url'),
        'expires': Parameter(int, 'Date and time this slice exipres'),
        'researcher': Parameter([str], 'List of users for this slice'),
        'PI': Parameter([str], 'List of PIs responsible for this slice'),
        'description': Parameter([str], 'Description of this slice'),
        }
    fields.update(SfaRecord.fields)
* */

    /**
     * Register call: Register an object with the registry.
     *
     * string Register(struct record, string credentials[])
     *
     * record: A struct containing the attributes required to register a particular object (depends on the object's type).
     * credentials: A single credential string or an array of credentials.
     *
     * Returns string representation of the object's GID if successful, faults otherwise.
     *
     * @param credential An array of credentials. At least one credential must be a valid slice credential for the slice specified in slice_urn.
     * @param con the {@code GeniConnection} to use for this call. Must be a connection to a SfaRegistry.
     * @return  Returns a list of structs where each struct represents a registry record. packed as a Vector of Hashtable (wrapped in a {@code PlanetlabSfaRegistryInterface.SimpleApiCallReply})
     *
     * @throws be.iminds.ilabt.jfed.lowlevel.JFedException
     */
    @ApiMethod(order=7, hint="Register call, without Slice record as argument: Create a slice")
    public SimpleApiCallReply<String> registerSlice(SfaConnection con,
               @ApiMethodParameter(name = "credential", hint="A single credential string or an array of credentials (jFed currently only supports a single credential here)")
                    AnyCredential credential,
//               @ApiMethodParameter(name = "sliceName", hint="A name for the new slice")
//                    String sliceName,
               @ApiMethodParameter(name = "hrn", hint="hrn")
                    String hrn,
               @ApiMethodParameter(name = "sliceUrl", hint="sliceUrl", required=false, parameterType = ApiMethodParameterType.URL)
                    String sliceUrl,
               @ApiMethodParameter(name = "expiresRRC3339", hint="expires String in RFC3339 format", required=false, parameterType = ApiMethodParameterType.STRING_DATE_RFC3339)
                    String expiresRRC3339,
               @ApiMethodParameter(name = "researchers", hint="researchers", required=false, parameterType = ApiMethodParameterType.LIST_OF_STRING)
                    List<String> researchers,
               @ApiMethodParameter(name = "pis", hint="principle investigators", required=false, parameterType = ApiMethodParameterType.LIST_OF_STRING)
                    List<String> pis,
               @ApiMethodParameter(name = "description", hint="description", required=false, parameterType = ApiMethodParameterType.LIST_OF_STRING)
                    List<String> description) throws JFedException {
        Hashtable sliceRecord = new Hashtable();
//        sliceRecord.put("name", sliceName);
        sliceRecord.put("hrn", hrn);
        sliceRecord.put("type", "slice");
        if (sliceUrl != null) sliceRecord.put("url", sliceUrl);
//        if (expires != null) sliceRecord.put("expires", RFC3339Util.dateToRFC3339String(expires));
        if (expiresRRC3339 != null) sliceRecord.put("expires", expiresRRC3339);
        if (researchers != null) {
            Vector researchersVector = new Vector(researchers);
            sliceRecord.put("researchers", researchersVector);
        }
        if (pis != null) {
            Vector pisVector = new Vector(pis);
            sliceRecord.put("pis", pisVector);
        }
        if (description != null) {
            Vector descriptionVector = new Vector(description);
            sliceRecord.put("description", descriptionVector);
        }

        Vector args = new Vector( 2);
        args.add(sliceRecord);
        Vector creds = new Vector(1);
        creds.add(credential.getCredentialXml());
        args.add(creds);

        XMLRPCCallDetails res = executeXmlRpcCommand(con, "Register", args, null, false);
        SimpleApiCallReply<String> r = null;
        try {
            String gid = (String) res.getResultValueObject();
            r = new SimpleApiCallReply<String>(res, gid);
        } catch (Exception e) {
            log(res, null, "registerSlice", "Register", con, null);
            throw new JFedException("Exception in Register call.", e, res, null);
        }

        log(res, r, "registerSlice", "Register", con, null);
        return r;
    }

    //conveniance method not exposed to probe command line or GUI
    public SimpleApiCallReply<String> registerSlice(SfaConnection con,
                    AnyCredential credential,
                    String hrn,
                    String sliceUrl,
                    Date expires,
                    List<String> researchers,
                    List<String> pis,
                    List<String> description) throws JFedException
    {
        return registerSlice(con, credential, hrn, sliceUrl, RFC3339Util.dateToRFC3339String(expires, true, true, true), researchers, pis, description);
    }



    //TODO add other methods from interface (register and update, but problem is they take a struct as argument)
}
