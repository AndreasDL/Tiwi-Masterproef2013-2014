package be.iminds.ilabt.jfed.lowlevel.userloginmodel;

import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;

/**
 * UserLoginModel stores all preferences related to the user login:
 *   - SSL key and certificate file
 *
 *   it also stores the derived data, or allows overriding it:
 *   - authority to use
 *      - info about authority
 *      (stores urn seperately, for cases where authority is not known, but urn is)
 *   - username
 *   - user urn
 *
 *   - clearinghouse to use
 * It does not store the password, but it does store the unencrypted private key
 *
 * It is an implementation of GeniUser that is used as the underlying model for the UserLoginPanel
 *
 * Note that UserLoginModel can be in invalid states, where this is not expected users of the GeniUser interface
 */
public class KeyCertWithManualInfoUserLoginModel extends KeyCertUserLoginModel {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();
    private static org.apache.logging.log4j.Logger l4jLogger = LogManager.getLogger();


    public KeyCertWithManualInfoUserLoginModel(AuthorityListModel authorityListModel, UserLoginModelManager userLoginModelManager) {
        super(authorityListModel, userLoginModelManager);
    }

    @Override
    protected boolean processPemContent() {
        boolean success = processBasicPemContent();
        return success;
    }

    public void setAuthority(SfaAuthority auth) {
        this.authority = auth;
        if (authority != null)
            this.authorityUrn = auth.getUrnString();
        else
            this.authorityUrn = null;
    }

    public void setUserUrn(String urn) {
        GeniUrn parsedUrn = null;
        try {
            parsedUrn = new GeniUrn(urn);
            this.userUrn = parsedUrn;
        } catch (GeniUrn.GeniUrnParseException e) {
            LOG.warn("provided urn is NOT a valid urn");
            this.userUrn = null;
        }
    }

    public boolean isValidUserUrn() {
        if (userUrn == null) return false;
//        GeniUrn u = GeniUrn.parse(userUrn);
//        if (u == null) return false;
        if (!userUrn.getResourceType().equals("user")) return false;
        return true;
    }

    public boolean deriveAuthorityFromUrn() {
//        if (userUrn == null) return false;
//        GeniUrn u = GeniUrn.parse(userUrn);
        if (userUrn == null) return false;
        String userAuthPart = userUrn.getTopLevelAuthority();

        //find authority
        for (SfaAuthority curAuth : authorityListModel.getAuthorities())
            if (curAuth.getNameForUrn().equals(userAuthPart)) {
                authority = curAuth;
                if (debug) errorInfo += "DEBUG:    found authority of user matching \""+userAuthPart+"\": "+authority.getName()+"\n";
                authorityUrn = authority.getUrnString();
                return true;
            }

        return false;
    }

    public boolean authorityMatchesUrn() {
        if (authority == null) return false;
        if (userUrn == null) return false;
        String userAuthPart = userUrn.getTopLevelAuthority();

        return authority.getNameForUrn().equals(userAuthPart);
    }

    @Override
    public void save(UserLoginModelManager.UserLoginModelPreferences prefs) {
        super.save(prefs);
        prefs.put("keyCertFileURI", keyCertFile.toURI().toString());

        if (authorityUrn != null)
            prefs.put("userauthurn", authorityUrn);
        else
            prefs.remove("userauthurn");

        if (userUrn != null)
            prefs.put("userurn", userUrn.getValue());
        else
            prefs.remove("userurn");
    }

    @Override
    public void load(UserLoginModelManager.UserLoginModelPreferences prefs) {
        super.load(prefs);

        authority = null;
        authorityUrn = prefs.get("userauthurn", null);
        userUrn = GeniUrn.parse(prefs.get("userurn", null));

        if (authorityUrn != null)
            for (SfaAuthority curAuth : authorityListModel.getAuthorities())
                if (curAuth.getUrnString().equals(authorityUrn)) {
                    authority = curAuth;
                    if (debug) errorInfo += "DEBUG:    found authority of user matching \""+authorityUrn+"\": "+authority.getName()+"\n";
                    return;
                }
    }
}
