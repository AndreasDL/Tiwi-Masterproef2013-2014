package be.iminds.ilabt.jfed.lowlevel;

import java.util.HashMap;
import java.util.Map;

/**
* GeniResponseCode
*/
public enum SCSResponseCode implements GeniResponseCode {
    SCSRESPONSE_SUCCESS          (0,  "Success"                                                                                           ),
    SCSRESPONSE_UNKNOWN1 (1,  "Unknown error code"                                                                ),
    SCSRESPONSE_UNKNOWN2 (2,  "Unknown error code"),
    SCSRESPONSE_UNKNOWN3 (3,  "Unknown error code"),
    SCSRESPONSE_UNKNOWN4 (4,  "Unknown error code"),
    SCSRESPONSE_UNKNOWN5 (5,  "Unknown error code"),
    SCSRESPONSE_UNKNOWN6 (6,  "Unknown error code"),
    SCSRESPONSE_UNKNOWN7 (7,  "Unknown error code"),
    SCSRESPONSE_UNKNOWN8 (8,  "Unknown error code"),
    SCSRESPONSE_UNKNOWN9 (9,  "Unknown error code"),
    SCSRESPONSE_UNKNOWN10 (10, "Unknown error code"),
    SCSRESPONSE_UNKNOWN11 (11, "Unknown error code"),
    SCSRESPONSE_UNKNOWN12 (12, "Unknown error code"),
    SCSRESPONSE_UNKNOWN13 (13, "Unknown error code"),
    SCSRESPONSE_UNKNOWN14 (14, "Unknown error code"),
    SCSRESPONSE_UNKNOWN15 (15, "Unknown error code"),
    SCSRESPONSE_UNKNOWN16 (16, "Unknown error code"),
    SCSRESPONSE_UNKNOWN17 (17, "Unknown error code"),
    SCSRESPONSE_UNKNOWN24 (24, "Unknown error code"),
    SERVERBUSY 	                  (-32001, "Server is (temporarily) too busy; try again later"                                             ),

    INTERNAL_NONGENI_ERROR 	      (50, "Internal error in client application"),  //SPECIFIC FOR THIS CODE, NOT IN GENI API SPECIFICATION!
    SERVER_REPLY_ERROR            (51, "The client could not parse the server's reply. Either the server sent something strange, or this is a bug in the client");//SPECIFIC FOR THIS CODE, NOT IN GENI API SPECIFICATION!

    private int code;
    private String description;
    SCSResponseCode(int code, String description) {
        this.code = code;
        this.description = description;
    }
    @Override
    public boolean isSuccess() { return code == 0; }
    @Override
    public boolean isBusy() { return code == 14 || code == -32001; }
    @Override
    public int getCode() { return code; }
    @Override
    public String getDescription() { return description; }

    private static Map<Integer, SCSResponseCode> responseCode_by_code = null;
    public static SCSResponseCode getByCode(int c) {
        if (responseCode_by_code == null) {
            responseCode_by_code = new HashMap<Integer, SCSResponseCode>();
            SCSResponseCode[] allCode = SCSResponseCode.values();
            for (int i = 0; i < allCode.length; i++) {
                SCSResponseCode grc = allCode[i];
                responseCode_by_code.put(grc.getCode(), grc);
            }
        }
        SCSResponseCode res = responseCode_by_code.get(c);
        if (res == null)
            throw new RuntimeException("GeniAMResponseCode "+c+" does not exists");
        if (res.getCode() != c)
            throw new RuntimeException("BUG in GeniAMResponseCode: mapped "+c+" onto "+res.getCode());
        return res;
    }

    @Override
    public String toString() {
        return "GeniAMResponseCode{" +
                "code=" + code +
                ", description='" + description + '\'' +
                '}';
    }
}
