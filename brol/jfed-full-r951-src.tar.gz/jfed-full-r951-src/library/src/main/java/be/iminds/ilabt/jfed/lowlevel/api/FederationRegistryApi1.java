package be.iminds.ilabt.jfed.lowlevel.api;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;

import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

/**
 * FederationRegistryApi1
 */
public class FederationRegistryApi1 extends AbstractFederationApi1 {
    private static org.apache.logging.log4j.Logger l4jLogger = LogManager.getLogger();

    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Registry API v1";
     */
    static public String getApiName() {
        return "Uniform Federation Registry API v1";
    }
    /**
     * A human readable name for the implemented API
     *
     * @return "Uniform Federation Registry API v1";
     */
    @Override
    public String getName() {
        return getApiName();
    }

    public FederationRegistryApi1(Logger logger, boolean autoRetryBusy) {
        super(logger, autoRetryBusy, new ServerType(ServerType.GeniServerRole.GENI_CH, 1));
    }

    public FederationRegistryApi1(Logger logger) {
        this(logger, true);
    }

    @ApiMethod(order=1, hint="get_version call: Provide a structure detailing the version information as well as details of accepted options for CH API calls.", unprotected=true)
    public FederationApiReply<GetVersionResult> getVersion(SfaConnection con)  throws JFedException {
        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "get_version", new Vector(), null);
        FederationApiReply<GetVersionResult> r = null;
        try {
            r = new FederationApiReply<GetVersionResult>(res, new GetVersionResult(apiSpecifiesHashtableStringToObject(res.getResultValueObject())));
        } catch (Throwable e) {
            handleErrorProcessingArguments(res, "getVersion", "get_version", con, e);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<GetVersionResult>(res, null);
        log(res, r, "getVersion", "get_version", con, null);
        return r;
    }

    @Override
    public List<String> getApiObjects() {
        List<String> res = new ArrayList<String>();
        res.add("SERVICE");
        return res;
    }

    @Override
    public List<String> getRequiredApiServices() {
        List<String> res = new ArrayList<String>();
        res.add("SERVICE");
        return res;
    }

    @Override
    public List<String> getOptionalApiServices() {
        List<String> res = new ArrayList<String>();
        return res;
    }

    @Override
    public List<GetVersionResult.FieldInfo> getMinimumFields(String objectName) {
        if (!objectName.equalsIgnoreCase("SERVICE")) return null;

        List<GetVersionResult.FieldInfo> res = new ArrayList<GetVersionResult.FieldInfo>();
        //String name, FieldType fieldType, CreationAllowed creationAllowed, boolean updatable, Protect protect, String object
        res.add(new GetVersionResult.FieldInfo("SERVICE_URN", GetVersionResult.FieldInfo.FieldType.URN));
        res.add(new GetVersionResult.FieldInfo("SERVICE_URL", GetVersionResult.FieldInfo.FieldType.URL));
        res.add(new GetVersionResult.FieldInfo("SERVICE_CERT", GetVersionResult.FieldInfo.FieldType.CERTIFICATE));
        res.add(new GetVersionResult.FieldInfo("SERVICE_NAME", GetVersionResult.FieldInfo.FieldType.STRING));
        res.add(new GetVersionResult.FieldInfo("SERVICE_DESCRIPTION", GetVersionResult.FieldInfo.FieldType.STRING));
        return res;
    }

    @Override
    public String getMethodObject(Method method) {
        if (method.getName().equals("lookupAggregates")
                || method.getName().equals("lookupMemberAuthorities")
                || method.getName().equals("lookupSliceAuthorities")
//                || method.getName().equals("lookupAuthoritiesForUrns")
//                || method.getName().equals("getTrustRoots")
                )
            return "SERVICE";

        return null;
    }

    public class ServiceDetails {
        private ServerType.GeniServerRole serverRole;
        private GeniUrn urn;
        private URL url;
        private String certificate;
        private String name;
        private String description;

        private Map<String, Object> extraFields = new HashMap<String, Object>();

        public ServiceDetails(ServerType.GeniServerRole serverRole, Hashtable fields) throws JFedException {
            this.serverRole = serverRole;
            for (Object entryO : fields.entrySet()) {
                Map.Entry entry = (Map.Entry) entryO;
                assert entry.getKey() instanceof String : "not String in in ServiceDetails fields="+fields;
                String key = (String) entry.getKey();
//                assert entry.getValue() instanceof String : "not String in in ServiceDetails fields="+fields;
                Object value = (Object) entry.getValue();
                String stringValue = null;
                if (value instanceof String)
                    stringValue = (String) value;

                boolean known = false;

                if (key.equals("SERVICE_URN")) {
                    assert stringValue != null : "service value must be String for key SERVICE_URN";
                    urn = GeniUrn.parse(stringValue);
                    known = true;
                }
                if (key.equals("SERVICE_URL")){
                    try {
                        assert stringValue != null : "service value must be String for key SERVICE_URL";
                        url = new URL(stringValue);
                    } catch (MalformedURLException e) {
                        if (!handleMalformedReplies)
                            throw new JFedException("Error parsing Federation Registry reply. Malformed URL \""+value+"\". Error: "+e.getMessage(), e);
                        else {
                            e.printStackTrace();
                            url = null;
                        }
                    }
                    known = true;
                }
                if (key.equals("SERVICE_CERTIFICATE")) {
                    assert stringValue != null : "service value must be String for key SERVICE_CERTIFICATE";
                    certificate = stringValue;
                    known = true;
                }
                if (key.equals("SERVICE_NAME")) {
                    assert stringValue != null : "service value must be String for key SERVICE_NAME";
                    name = stringValue;
                    known = true;
                }
                if (key.equals("SERVICE_DESCRIPTION")) {
                    assert stringValue != null : "service value must be String for key SERVICE_DESCRIPTION";
                    description = stringValue;
                    known = true;
                }
                if (!known)
                    extraFields.put(key, value);
            }

            //not true, could exclude these if fields argument doesn't include them
//            if (urn == null || url == null) {
//                if (!handleMalformedReplies) {
//                    throw new JFedException("Error processing ServiceDetails. Must contain keys SERVICE_URN and SERVICE_URL, but contained only: "+fields.keySet());
//                }
//                else {
//                    l4jLogger.error("Error processing ServiceDetails. Must contain keys SERVICE_URN and SERVICE_URL, but contained only: "+fields.keySet());
//                }
//            }

        }

        public ServerType.GeniServerRole getServerRole() {
            return serverRole;
        }

        public GeniUrn getUrn() {
            return urn;
        }

        public URL getUrl() {
            return url;
        }

        public String getCertificate() {
            return certificate;
        }

        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }

        @Override
        public String toString() {
            return "ServiceDetails{" +
                    "serverRole=" + serverRole +
                    ", urn=" + urn +
                    ", url=" + url +
                    ", certificate='" + certificate + '\'' +
                    ", name='" + name + '\'' +
                    ", description='" + description + '\'' +
                    ", extraFields=" + extraFields +
                    '}';
        }
    }

    private FederationApiReply<List<ServiceDetails>> genericLookupServiceDetails(Map<String, Object> methodParams,
                                                                                 SfaConnection con,
                                                                                 String javaMethodName,
                                                                                 String apiMethodName,
                                                                                 ServerType.GeniServerRole role,
                                                                                 List<String> filter,
                                                                                 Map<String, ? extends Object> match,
                                                                                 Map<String, Object> extraOptions)  throws JFedException {

        assert javaMethodName != null;
        assert apiMethodName != null;

        Vector args = new Vector();

        Hashtable options = new Hashtable();
        if (match != null)
            options.put("match", new Hashtable<String, Object>(match));
        if (filter != null/* && !filter.isEmpty()*/)
            options.put("filter", new Vector<String>(filter));
        if (extraOptions != null)
            options.putAll(extraOptions);
        args.add(options);

        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, apiMethodName, args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<List<ServiceDetails>> r = null;
        List<ServiceDetails> resList = new ArrayList<ServiceDetails>();
        try {
            Vector<Hashtable> resultVector = apiSpecifiesVectorOfT(Hashtable.class, res.getResultValueObject());
            for (Hashtable h : resultVector) {
                ServiceDetails serviceDetails = new ServiceDetails(role, h);
                resList.add(serviceDetails);
            }
            r = new FederationApiReply<List<ServiceDetails>>(res, resList);
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, javaMethodName, apiMethodName, con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<List<ServiceDetails>>(res, null);
        log(res, r, javaMethodName, apiMethodName, con, methodParams);

        return r;
    }
    @ApiMethod(order=2, hint="lookup_aggregates call: Return information about all aggregates associated with the Federation", unprotected=true)
    public FederationApiReply<List<ServiceDetails>> lookupAggregates(SfaConnection con,
                                                                     @ApiMethodParameter(name = "filter", hint="fields names included in reply. If omitted: all fields.",
                                                                             required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.CH_API1_FILTER)
                                                                     List<String> filter,
                                                                     @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API1_MATCH)
                                                                     Map<String, ? extends Object> match,
                                                                     @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                     Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("filter", filter, "match", match, "extraOptions", extraOptions);
        return genericLookupServiceDetails(methodParams, con, "lookupAggregates", "lookup_aggregates", ServerType.GeniServerRole.AM, filter, match, extraOptions);
    }

    @ApiMethod(order=3, hint="lookup_member_authorities call: Return information about all MA’s associated with the Federation", unprotected=true)
    public FederationApiReply<List<ServiceDetails>> lookupMemberAuthorities(SfaConnection con,
                                                                            @ApiMethodParameter(name = "filter", hint="fields names included in reply. If omitted: all fields.", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.CH_API1_FILTER)
                                                                            List<String> filter,
                                                                            @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API1_MATCH)
                                                                            Map<String, ? extends Object> match,
                                                                            @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                            Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("filter", filter, "match", match, "extraOptions", extraOptions);
        return genericLookupServiceDetails(methodParams, con, "lookupMemberAuthorities", "lookup_member_authorities", ServerType.GeniServerRole.GENI_CH_MA, filter, match, extraOptions);
    }

    @ApiMethod(order=4, hint="lookup_slice_authorities call: Return information about all SA’s associated with the Federation", unprotected=true)
    public FederationApiReply<List<ServiceDetails>> lookupSliceAuthorities(SfaConnection con,
                                                                           @ApiMethodParameter(name = "filter", hint="fields names included in reply. If omitted: all fields.", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.CH_API1_FILTER)
                                                                           List<String> filter,
                                                                           @ApiMethodParameter(name = "match", hint="", parameterType=ApiMethodParameterType.CH_API1_MATCH)
                                                                           Map<String, ? extends Object> match,
                                                                           @ApiMethodParameter(name = "extraOptions", hint="extra options", required = false, guiDefaultOptional = false, parameterType = ApiMethodParameterType.GENI_EXTRA_OPTIONS)
                                                                           Map<String, Object> extraOptions)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("filter", filter, "match", match, "extraOptions", extraOptions);
        return genericLookupServiceDetails(methodParams, con, "lookupSliceAuthorities", "lookup_slice_authorities", ServerType.GeniServerRole.GENI_CH_SA, filter, match, extraOptions);
    }

    @ApiMethod(order=5, hint="lookup_authorities_for_urns call: Lookup the authorities for a given URNs", unprotected=true)
    public FederationApiReply<Map<GeniUrn, URL>> lookupAuthoritiesForUrns(SfaConnection con,@
            ApiMethodParameter(name = "urns", hint="URNs of entities for which the authority is requested", parameterType = ApiMethodParameterType.LIST_OF_URN_STRING)
    List<GeniUrn> urns)  throws JFedException {
        Map<String, Object> methodParams = makeMethodParameters("urns", urns);

        Vector args = new Vector(1);
        Vector stringUrns = new Vector();
        for (GeniUrn gu : urns)
            stringUrns.add(gu.toString());
        args.add(stringUrns);
        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "lookup_authorities_for_urns", args, methodParams);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<Map<GeniUrn, URL>> r = null;
        if (resultValueObject instanceof Hashtable) {
            Hashtable<Object, Object> resHashtable = (Hashtable) resultValueObject;
            Map<GeniUrn, URL> urls = new HashMap<GeniUrn, URL>();

            for (Map.Entry<Object, Object> e : resHashtable.entrySet()) {
                if (e.getKey() instanceof String && e.getValue() instanceof String) {
                    try {
                        GeniUrn urn = new GeniUrn((String) e.getKey());
                        URL url = new URL((String)e.getValue());
                        urls.put(urn, url);
                    } catch (MalformedURLException ex) {
                        if (!handleMalformedReplies) {
                            log(res, r, "lookupAuthoritiesForUrns", "lookup_authorities_for_urns", con, null);
                            l4jLogger.error("Error processing lookup_authorities_for_urns result ("+ex.getMessage()+" == not an url: "+e.getValue()+"): "+resultValueObject);
                            throw new JFedException("Error processing lookup_authorities_for_urns result, not an url: \""+e.getValue()+"\": "+
                                    " error message: \""+ex.getMessage()+"\"", ex, res);
                        }
                        else {
                            l4jLogger.error("Error processing lookup_authorities_for_urns result ("+ex.getMessage()+" == not an url: "+e.getValue()+"): "+resultValueObject);
                            urls = null;
                        }
                        break;
                    } catch (GeniUrn.GeniUrnParseException ex) {
                        if (!handleMalformedReplies) {
                            log(res, r, "lookupAuthoritiesForUrns", "lookup_authorities_for_urns", con, null);
                            throw new JFedException("Error processing lookup_authorities_for_urns result, not an urn: \""+e.getKey()+"\": "+
                                    " error message: \""+ex.getMessage()+"\"", ex, res);
                        }
                        else {
                            l4jLogger.error("Error processing lookup_authorities_for_urns result ("+ex.getMessage()+" == not an urn: "+e.getKey()+"): "+resultValueObject);
                            urls = null;
                        }
                        break;
                    }
                } else {
                    l4jLogger.error("Error processing lookup_authorities_for_urns result (not an string: "+e.getKey()+" or "+e.getValue()+"): "+resultValueObject);
                    urls = null;
                    break;
                }
            }
            r = new FederationApiReply<Map<GeniUrn, URL>>(res, urls);
        }

        if (r == null)
            r = new FederationApiReply<Map<GeniUrn, URL>>(res, null);
        log(res, r, "lookupAuthoritiesForUrns", "lookup_authorities_for_urns", con, methodParams);
        return r;
    }

    @ApiMethod(order=6, hint="get_trust_roots call: Return list of trust roots (certificates) associated with this CH. " +
            "Often this concatenates of the trust roots of the included authorities.", unprotected=true)
    public FederationApiReply<List<String>> getTrustRoots(SfaConnection con)  throws JFedException {
        Vector args = new Vector();
        XMLRPCCallDetailsGeni res = executeXmlRpcCommandGeni(con, "get_trust_roots", args, null);
        Object resultValueObject = res.getResultValueObject();
        FederationApiReply<List<String>> r = null;
        try {
            r = new FederationApiReply<List<String>>(res, new ArrayList<String>(apiSpecifiesVectorOfString(resultValueObject)));
        } catch (Throwable t) {
            handleErrorProcessingArguments(res, "getTrustRoots", "get_trust_roots", con, t);
            r = null;
        }

        if (r == null)
            r = new FederationApiReply<List<String>>(res, null);
        log(res, r, "getTrustRoots", "get_trust_roots", con, null);
        return r;
    }
}
