xjc -d library/src/main/java -p be.iminds.ilabt.jfed.lowlevel.authority.binding library/src/main/resources/be/iminds/ilabt/jfed/lowlevel/authority/authority.xsd
