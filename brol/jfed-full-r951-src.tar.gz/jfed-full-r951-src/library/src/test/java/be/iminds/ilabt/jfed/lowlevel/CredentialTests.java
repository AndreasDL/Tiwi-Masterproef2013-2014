package be.iminds.ilabt.jfed.lowlevel;

import be.iminds.ilabt.jfed.util.*;
import junit.framework.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.appender.OutputStreamManager;
import org.apache.xml.security.Init;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.ElementProxy;
import org.testng.annotations.Test;
import org.testng.xml.XmlUtils;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import sun.security.x509.*;

import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.KeyValue;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.charset.Charset;
import java.security.*;
import java.security.cert.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.*;

/**
 * CredentialTests:
 *
 *   various tests of credentials.
 *   This creates fake credentials, for an authority, a user and a tool.
 *   It creates speaksFor and Delegated credentials for both.
 *   It tests the validity of all credentials.
 *
 *   @see be.iminds.ilabt.jfed.util.KeyUtil
 *   @see be.iminds.ilabt.jfed.util.SSHKeyHelper
 *   @see be.iminds.ilabt.jfed.lowlevel.userloginmodel.PlanetlabUserLoginModel#fetchCertificate()
 *   @see be.iminds.ilabt.jfed.lowlevel.planetlab.PlanetlabCertificateFetcher
 *
 *   Geni requirements for Certificates
 *   @link http://groups.geni.net/geni/wiki/GeniApiCertificates
 *
 *   @link http://groups.geni.net/geni/wiki/GAPI_AM_API_DRAFT/SpeaksFor
 */
public class CredentialTests {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    private static final int validityDays = 2;

    private static final String authorityHostname = "authority.example.com";
    private static final String authorityUrn = "urn:publicid:IDN+"+authorityHostname+"+auth+ma";
    private static final String authority2Hostname = "authority2.example.com";
    private static final String authority2Urn = "urn:publicid:IDN+"+authorityHostname+"+auth+ma";

    private static final String username = "tester";
    private static final String userUuid = UUID.randomUUID().toString();
    private static final String userEmail = username+"@"+authorityHostname;
    private static final String userUuidUrn = "urn:uuid:"+userUuid;
    private static final String userUrn = "urn:publicid:IDN+"+authorityHostname+"+user+"+username;

    private static final String saUuid = UUID.randomUUID().toString();
    private static final String saEmail = "sa@"+authorityHostname;
    private static final String saUuidUrn = "urn:uuid:"+saUuid;
    private static final String saUrn = "urn:publicid:IDN+"+authorityHostname+"+authority+sa";

    private static final String toolUuid = UUID.randomUUID().toString();
    private static final String toolUrn = "urn:publicid:IDN+"+authority2Hostname+"+tool+jfed_unit_test";
    private static final String toolUuidUrn = "urn:uuid:"+toolUuid;


    private SSHKeyHelper authorityKeys;
    private SSHKeyHelper userKeys;
    private SSHKeyHelper saKeys;
    private SSHKeyHelper toolKeys;

    private X509Certificate authorityCert;
    private X509Certificate saCert;
    private X509Certificate userCert;
    private X509Certificate toolCert;

    private SfaCredential userCredential; //signed by authority
    private SfaCredential toolCredential; //signed by tool itself or other authority (to be decided)


    @Test
    public void generateCertificates()
            throws NoSuchAlgorithmException, IOException, CertificateException, SignatureException,
            NoSuchProviderException, InvalidKeyException, CertPathBuilderException,
            KeyStoreException, InvalidAlgorithmParameterException {
        authorityKeys = new SSHKeyHelper();
        userKeys = new SSHKeyHelper();
        saKeys = new SSHKeyHelper();
        toolKeys = new SSHKeyHelper();

        makeAuthCert();
        makeUserCert();
        makeSaCert();
        makeToolCert();

        System.out.println("Authority cert self-signed:\n"+KeyUtil.x509certificateToPem(authorityCert));
        System.out.println("\nUser cert signed by authority:\n"+KeyUtil.x509certificateToPem(userCert));
        System.out.println("\nTool cert signed by authority:\n"+KeyUtil.x509certificateToPem(toolCert));

        Assert.assertTrue(checkCert(authorityCert, userCert));
        Assert.assertTrue(checkCert(authorityCert, toolCert));
    }

    public void makeUserCert() throws NoSuchAlgorithmException, IOException, CertificateException, SignatureException, NoSuchProviderException, InvalidKeyException {
        Calendar expiry = Calendar.getInstance();
        expiry.add(Calendar.DAY_OF_YEAR, validityDays);

        PublicKey pubKey = userKeys.getSshPublicKey(); //user public key!
        assert pubKey != null;
        PrivateKey privKey = authorityKeys.getSshPrivateKey();
        assert privKey != null;

        // Determine the signature algorithm
        String sigAlgName = KeyUtil.getCompatibleSigAlgName(privKey.getAlgorithm());

        Date firstDate = new Date(System.currentTimeMillis() - (24L*60*60*1000));
        Date lastDate = new Date(System.currentTimeMillis() + (validityDays*24L*60*60*1000));
        CertificateValidity interval = new CertificateValidity(firstDate, lastDate);
        X500Name issuer = new X500Name("CN="+authorityHostname);
        X500Name subject = new X500Name("EMAILADDRESS="+userEmail+", CN="+userUuid);


        X509CertInfo info = new X509CertInfo();
        // Add all mandatory attributes
        info.set(X509CertInfo.VERSION,
                new CertificateVersion(CertificateVersion.V3));
        info.set(X509CertInfo.SERIAL_NUMBER, new CertificateSerialNumber(
                new java.util.Random().nextInt() & 0x7fffffff));
        AlgorithmId algID = AlgorithmId.getAlgorithmId(sigAlgName);
        info.set(X509CertInfo.ALGORITHM_ID,
                new CertificateAlgorithmId(algID));
        info.set(X509CertInfo.SUBJECT, new CertificateSubjectName(subject));
        GeneralNames subjectAltNames = new GeneralNames();
        subjectAltNames.add(new GeneralName(new RFC822Name(userEmail)));
        subjectAltNames.add(new GeneralName(new URIName(userUrn)));
        subjectAltNames.add(new GeneralName(new URIName(userUuidUrn)));
        CertificateExtensions extensions = new CertificateExtensions();
        extensions.set(SubjectAlternativeNameExtension.NAME, new SubjectAlternativeNameExtension(subjectAltNames));
        info.set(X509CertInfo.EXTENSIONS, extensions);
        info.set(X509CertInfo.VALIDITY, interval);
        info.set(X509CertInfo.ISSUER, new CertificateIssuerName(issuer));

        info.set(X509CertInfo.KEY, new CertificateX509Key(pubKey));

        X509CertImpl cert = new X509CertImpl(info);
        cert.sign(privKey, sigAlgName);

        userCert = cert;
    }

    public void makeSaCert() throws NoSuchAlgorithmException, IOException, CertificateException, SignatureException, NoSuchProviderException, InvalidKeyException {
        Calendar expiry = Calendar.getInstance();
        expiry.add(Calendar.DAY_OF_YEAR, validityDays);

        PublicKey pubKey = saKeys.getSshPublicKey(); //sa public key
        assert pubKey != null;
        PrivateKey privKey = authorityKeys.getSshPrivateKey();
        assert privKey != null;

        // Determine the signature algorithm
        String sigAlgName = KeyUtil.getCompatibleSigAlgName(privKey.getAlgorithm());

        Date firstDate = new Date(System.currentTimeMillis() - (24L*60*60*1000));
        Date lastDate = new Date(System.currentTimeMillis() + (validityDays*24L*60*60*1000));
        CertificateValidity interval = new CertificateValidity(firstDate, lastDate);
        X500Name issuer = new X500Name("CN="+authorityHostname);
        X500Name subject = new X500Name("EMAILADDRESS="+saEmail+", CN="+saUuid);


        X509CertInfo info = new X509CertInfo();
        // Add all mandatory attributes
        info.set(X509CertInfo.VERSION,
                new CertificateVersion(CertificateVersion.V3));
        info.set(X509CertInfo.SERIAL_NUMBER, new CertificateSerialNumber(
                new java.util.Random().nextInt() & 0x7fffffff));
        AlgorithmId algID = AlgorithmId.getAlgorithmId(sigAlgName);
        info.set(X509CertInfo.ALGORITHM_ID,
                new CertificateAlgorithmId(algID));
        info.set(X509CertInfo.SUBJECT, new CertificateSubjectName(subject));
        GeneralNames subjectAltNames = new GeneralNames();
        subjectAltNames.add(new GeneralName(new RFC822Name(saEmail)));
        subjectAltNames.add(new GeneralName(new URIName(saUrn)));
        subjectAltNames.add(new GeneralName(new URIName(saUuidUrn)));
        CertificateExtensions extensions = new CertificateExtensions();
        extensions.set(SubjectAlternativeNameExtension.NAME, new SubjectAlternativeNameExtension(subjectAltNames));
        info.set(X509CertInfo.EXTENSIONS, extensions);
        info.set(X509CertInfo.VALIDITY, interval);
        info.set(X509CertInfo.ISSUER, new CertificateIssuerName(issuer));

        info.set(X509CertInfo.KEY, new CertificateX509Key(pubKey));

        X509CertImpl cert = new X509CertImpl(info);
        cert.sign(privKey, sigAlgName);

        saCert = cert;
    }

    public void makeToolCert() throws NoSuchAlgorithmException, IOException, CertificateException, SignatureException, NoSuchProviderException, InvalidKeyException {
        Calendar expiry = Calendar.getInstance();
        expiry.add(Calendar.DAY_OF_YEAR, validityDays);

        PublicKey pubKey = toolKeys.getSshPublicKey(); //user public key!
        assert pubKey != null;
        PrivateKey privKey = authorityKeys.getSshPrivateKey();
        assert privKey != null;

        // Determine the signature algorithm
        String sigAlgName = KeyUtil.getCompatibleSigAlgName(privKey.getAlgorithm());

        Date firstDate = new Date(System.currentTimeMillis() - (24L*60*60*1000));
        Date lastDate = new Date(System.currentTimeMillis() + (validityDays*24L*60*60*1000));
        CertificateValidity interval = new CertificateValidity(firstDate, lastDate);
        X500Name issuer = new X500Name("CN="+authorityHostname);
        X500Name subject = new X500Name("CN="+toolUuid);


        X509CertInfo info = new X509CertInfo();
        // Add all mandatory attributes
        info.set(X509CertInfo.VERSION,
                new CertificateVersion(CertificateVersion.V3));
        info.set(X509CertInfo.SERIAL_NUMBER, new CertificateSerialNumber(
                new java.util.Random().nextInt() & 0x7fffffff));
        AlgorithmId algID = AlgorithmId.getAlgorithmId(sigAlgName);
        info.set(X509CertInfo.ALGORITHM_ID,
                new CertificateAlgorithmId(algID));
        info.set(X509CertInfo.SUBJECT, new CertificateSubjectName(subject));
        GeneralNames subjectAltNames = new GeneralNames();
        subjectAltNames.add(new GeneralName(new URIName(toolUrn)));
        subjectAltNames.add(new GeneralName(new URIName(toolUuidUrn)));
        CertificateExtensions extensions = new CertificateExtensions();
        extensions.set(SubjectAlternativeNameExtension.NAME, new SubjectAlternativeNameExtension(subjectAltNames));
        info.set(X509CertInfo.EXTENSIONS, extensions);
        info.set(X509CertInfo.VALIDITY, interval);
        info.set(X509CertInfo.ISSUER, new CertificateIssuerName(issuer));

        info.set(X509CertInfo.KEY, new CertificateX509Key(pubKey));

        X509CertImpl cert = new X509CertImpl(info);
        cert.sign(privKey, sigAlgName);

        toolCert = cert;
    }

    /* self signed
    *
    * needs to be CA:
    * X509v3 extensions:
               X509v3 Basic Constraints: critical
                   CA:TRUE
    * */
    public void makeAuthCert() throws NoSuchAlgorithmException, IOException, CertificateException, SignatureException, NoSuchProviderException, InvalidKeyException {
        Calendar expiry = Calendar.getInstance();
        expiry.add(Calendar.DAY_OF_YEAR, validityDays);

        PublicKey pubKey = authorityKeys.getSshPublicKey();
        assert pubKey != null;
        PrivateKey privKey = authorityKeys.getSshPrivateKey();
        assert privKey != null;

        // Determine the signature algorithm
        String sigAlgName = KeyUtil.getCompatibleSigAlgName(privKey.getAlgorithm());

        Date firstDate = new Date(System.currentTimeMillis() - (24L*60*60*1000));
        Date lastDate = new Date(System.currentTimeMillis() + (validityDays*24L*60*60*1000));
        CertificateValidity interval = new CertificateValidity(firstDate, lastDate);
        X500Name issuer = new X500Name("CN="+authorityHostname);
        X500Name subject = new X500Name("CN="+authorityHostname);


        X509CertInfo info = new X509CertInfo();
        // Add all mandatory attributes
        info.set(X509CertInfo.VERSION,
                new CertificateVersion(CertificateVersion.V3));
        info.set(X509CertInfo.SERIAL_NUMBER, new CertificateSerialNumber(
                new java.util.Random().nextInt() & 0x7fffffff));
        AlgorithmId algID = AlgorithmId.getAlgorithmId(sigAlgName);
        info.set(X509CertInfo.ALGORITHM_ID, new CertificateAlgorithmId(algID));

        info.set(X509CertInfo.SUBJECT, new CertificateSubjectName(subject));
        GeneralNames subjectAltNames = new GeneralNames();
        subjectAltNames.add(new GeneralName(new URIName(authorityUrn)));

        /* depth of the certification path
            = max number of "hops" to end entity cert.
            1 means this can issue a CA certificate, but that CA cannot issue a CA certificate itself
         */
        BasicConstraintsExtension basicConstraintsExtension = new BasicConstraintsExtension(true/*is CA*/, 1 /*depth of the certification path*/);

        CertificateExtensions extensions = new CertificateExtensions();
        extensions.set(SubjectAlternativeNameExtension.NAME, new SubjectAlternativeNameExtension(subjectAltNames));
        extensions.set(BasicConstraintsExtension.NAME, basicConstraintsExtension);

        info.set(X509CertInfo.EXTENSIONS, extensions);
        info.set(X509CertInfo.VALIDITY, interval);
        info.set(X509CertInfo.ISSUER, new CertificateIssuerName(issuer));

        info.set(X509CertInfo.KEY, new CertificateX509Key(pubKey));

        X509CertImpl cert = new X509CertImpl(info);
        cert.sign(privKey, sigAlgName);

        authorityCert = cert;
    }

    public boolean checkCert(X509Certificate trustedAuthority, X509Certificate certToCheck)
            throws KeyStoreException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, CertPathBuilderException {
        List<X509Certificate> chain = new ArrayList<X509Certificate>();
        chain.add(certToCheck);

        /* Construct a valid path. */
        KeyStore anchors = GeniTrustStoreHelper.getFullTrustStore();
        anchors.setCertificateEntry("test-authority", trustedAuthority);

        X509CertSelector target = new X509CertSelector();
        target.setCertificate(chain.get(0));
        PKIXBuilderParameters params = new PKIXBuilderParameters(anchors, target);
        CertStoreParameters intermediates = new CollectionCertStoreParameters(chain);
        params.addCertStore(CertStore.getInstance("Collection", intermediates));
//        CertStoreParameters revoked = new CollectionCertStoreParameters(crls);
//        params.addCertStore(CertStore.getInstance("Collection", revoked));
        CertPathBuilder builder = CertPathBuilder.getInstance("PKIX");
        /*
         * If build() returns successfully, the certificate is valid. More details
         * about the valid path can be obtained through the PKIXBuilderResult.
         * If no valid path can be found, a CertPathBuilderException is thrown.
         */
        CertPathBuilderResult r = (CertPathBuilderResult) builder.build(params);
        return r != null && r.getCertPath() != null;
    }


    public static String signXml(Document doc, String elementToSignId, String elementToAddSignatureToName, X509Certificate cert, Key privateKey) throws Exception {
        doc.normalizeDocument();

        if (cert.getPublicKey() instanceof RSAPublicKey && privateKey instanceof RSAPrivateKey) {
            assert ((RSAPublicKey)cert.getPublicKey()).getModulus().equals(((RSAPrivateKey)privateKey).getModulus());
            if (logger.isDebugEnabled()) {
                boolean same = ((RSAPublicKey)cert.getPublicKey()).getModulus().equals(((RSAPrivateKey)privateKey).getModulus());
                logger.debug("signXml input cert and privateKey have same modulus");
            }
        }
        else
            logger.debug("not Rsa private and/or public key: no check done");


//        return signXmlWithoutSanturio(doc, elementToSignId, elementToAddSignatureToName, cert, privateKey);
        return signXmlWithSanturio(doc, elementToSignId, elementToAddSignatureToName, cert, privateKey);
    }
    public static String signXmlWithoutSanturio(Document doc, String elementToSignId, String elementToAddSignatureToName, X509Certificate cert, Key privateKey)
            throws Exception {
        Element elementToAddSignatureTo = (Element) doc.getElementsByTagName(elementToAddSignatureToName).item(0);
//        Element elementToSign = doc.getElementById(elementToSignId);
        assert elementToAddSignatureTo != null;
//        assert elementToSign != null;

        XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

        Reference ref = fac.newReference
                ("#" + elementToSignId, fac.newDigestMethod(DigestMethod.SHA1, null),
                        Collections.singletonList
                                (fac.newTransform
                                        (Transform.ENVELOPED, (TransformParameterSpec) null)),
                        null, null);

        // Create the SignedInfo
        SignedInfo si = fac.newSignedInfo
                (fac.newCanonicalizationMethod
                        (CanonicalizationMethod.INCLUSIVE,
                                (C14NMethodParameterSpec) null),
                        fac.newSignatureMethod(SignatureMethod.RSA_SHA1, null),
                        Collections.singletonList(ref));



        // Create a KeyValue
        KeyInfoFactory kif = fac.getKeyInfoFactory();
        KeyValue kv = kif.newKeyValue(cert.getPublicKey());
        List x509DataList = new ArrayList();
        x509DataList.add(cert); //adds X509Certificate element
//        x509DataList.add(""); //adds X509SubjectName element
        //can also use X509IssuerSerial, see newX509Data javadoc
        X509Data x509Data = kif.newX509Data(x509DataList);

        // Create a KeyInfo and add the KeyValue to it
        List kiList = new ArrayList();
        kiList.add(kv);
        kiList.add(x509Data);
        KeyInfo ki = kif.newKeyInfo(/*Collections.singletonList(kv)*/kiList);


        // Create a DOMSignContext and specify the PrivateKey and
        // location of the resulting XMLSignature's parent element
        DOMSignContext dsc = new DOMSignContext(privateKey, elementToAddSignatureTo);

        // Create the XMLSignature (but don't sign it yet)
        javax.xml.crypto.dsig.XMLSignature signature = fac.newXMLSignature(si, ki);

        // Marshal, generate (and sign) the enveloped signature
        signature.sign(dsc);


        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer trans = tf.newTransformer();
        trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
        trans.setOutputProperty(OutputKeys.ENCODING, "utf-8");
        trans.setOutputProperty(OutputKeys.INDENT, "no");
        final StringWriter stringWriter = new StringWriter();
        trans.transform(new DOMSource(doc), new StreamResult(stringWriter));
        return stringWriter.getBuffer().toString();

    }
    public static String signXmlWithSanturio(Document doc, String elementToSignId, String elementToAddSignatureToName, X509Certificate cert, Key privateKey)
            throws Exception {
        Init.init();
        ElementProxy.setDefaultPrefix(Constants.SignatureSpecNS, "");
        final org.apache.xml.security.signature.XMLSignature sig =
                new org.apache.xml.security.signature.XMLSignature(doc, null, org.apache.xml.security.signature.XMLSignature.ALGO_ID_SIGNATURE_RSA);
//        final XMLSignature sig = new XMLSignature(elementToSign, null);
        Element elementToAddSignatureTo = (Element) doc.getElementsByTagName(elementToAddSignatureToName).item(0);
        elementToAddSignatureTo.appendChild(sig.getElement());
        final Transforms transforms = new Transforms(doc);
        transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);
//        transforms.addTransform(Transforms.TRANSFORM_C14N_OMIT_COMMENTS);
        sig.addDocument("#" + elementToSignId, transforms, Constants.ALGO_ID_DIGEST_SHA1);
        sig.addKeyInfo(cert);
        sig.addKeyInfo(cert.getPublicKey());
        sig.sign(privateKey);


        final StringWriter stringWriter = new StringWriter();
        TransformerFactory transFactory = TransformerFactory.newInstance();
        Transformer transformer = transFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
        transformer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
        transformer.setOutputProperty(OutputKeys.INDENT, "no");
        transformer.transform(new DOMSource(doc), new StreamResult(stringWriter));
        return stringWriter.getBuffer().toString();


        //meses up xsi:xmlns
//        ByteArrayOutputStream os = new ByteArrayOutputStream();
//        os.write(Canonicalizer.getInstance(Canonicalizer.ALGO_ID_C14N_WITH_COMMENTS).canonicalizeSubtree(doc));
//        return os.toString("UTF-8");
    }


//    @Test
//    public void checkRealCredentials() {
//        logger.debug("Checking w Credential");
//        SfaCredential wCred = new SfaCredential("w-sa-cred", wCredential, "geni_sfa", "3");
//
//        Assert.assertTrue(wCred.check());
//
//        logger.debug("Checking f Credential");
//        SfaCredential fCred = new SfaCredential("f-sa-cred", fCredential, "geni_sfa", "3");
//
//        Assert.assertTrue(fCred.check());
//    }

    @Test(dependsOnMethods = {"generateCertificates", /*"checkRealCredentials"*/})
    public void createUserCredential()
            throws Exception {
        Date expireDate = new Date(System.currentTimeMillis()+(2*24*60*60*1000)); //2 days from now

        logger.debug("Creating User Credential");

        userCredential = SfaCredential.create("privilege", userUrn, saUrn, userCert, saCert, saCert, saKeys.getSshPrivateKey(), expireDate, "*", false, "Test User Credential");
        System.out.println("User credential:\n" + userCredential.getCredentialXml() + "\n");
        logger.trace("User credential:\n" + userCredential.getCredentialXml());
    }

    @Test(dependsOnMethods = {"createUserCredential"})
    public void checkUserCredential() throws KeyStoreException, CredentialException {
        logger.debug("Checking User Credential");

        KeyStore trustStore = GeniTrustStoreHelper.getFullTrustStore();
        trustStore.setCertificateEntry("test-authority", authorityCert);
        Assert.assertTrue(userCredential.check(trustStore));

        logger.debug("User Credential check passed");
    }

    @Test(dependsOnMethods = {"checkUserCredential"})
    public void createAndCheckToolCredential()
            throws Exception {
        Date expireDate = new Date(System.currentTimeMillis()+(2*24*60*60*1000)); //2 days from now
        toolCredential = SfaCredential.create("privilege", authorityUrn, toolUrn, authorityCert, toolCert, authorityCert, authorityKeys.getSshPrivateKey(), expireDate, "*", false, "Test Tool Credential");

        KeyStore trustStore = GeniTrustStoreHelper.getFullTrustStore();
        trustStore.setCertificateEntry("test-authority", authorityCert);
        Assert.assertTrue(toolCredential.check(trustStore));
    }

    SfaCredential speaksForCred;
    @Test(dependsOnMethods = {"createAndCheckToolCredential"})
    public void createSpeaksForCredential() throws Exception {
        Date expireDate = new Date(System.currentTimeMillis()+(3*12*60*60*1000)); //1.5 days from now
        speaksForCred = SfaCredential.createSpeaksFor(userUrn, toolUrn, userCert, toolCert, userKeys.getSshPrivateKey(), expireDate, "*", false);
    }

    @Test(dependsOnMethods = {"createSpeaksForCredential"})
    public void checkSpeaksForCredential() throws Exception {
        assert speaksForCred != null;
        logger.debug("Checking Speaks For credential");
        Assert.assertTrue(speaksForCred.check());
    }

    SfaCredential delegatedCred;
    @Test(dependsOnMethods = {"checkSpeaksForCredential"})
    public void createDelegatedCredential() throws Exception {


        Date expireDate = new Date(System.currentTimeMillis()+(3*12*60*60*1000)); //1.5 days from now
        delegatedCred = userCredential.delegate(toolUrn, toolCert, userKeys.getSshPrivateKey(), expireDate, "info", false);
    }

    @Test(dependsOnMethods = {"createDelegatedCredential"})
    public void checkDelegatedCredential() throws CredentialException {
        assert delegatedCred != null;
        logger.debug("Checking Delegated credential");
        Assert.assertTrue(delegatedCred.check());
    }


    //below are only predefined string needed for the tests



//    private static String fCredential = ...
//    private static String wCredential= ...
}
