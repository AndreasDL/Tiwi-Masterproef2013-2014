package be.iminds.ilabt.jfed.lowlevel.stitching;

import junit.framework.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * VlanRangeHelperTest
 */
public class VlanRangeHelperTest {
    @Test
    public void testRange() {
        String a = "5012";
        String b = "1";
        String c = "13-987";

        VlanRangeHelper.Range rA = new VlanRangeHelper.Range(a);
        VlanRangeHelper.Range rb = new VlanRangeHelper.Range(b);
        VlanRangeHelper.Range rc = new VlanRangeHelper.Range(c);

        Assert.assertEquals(rA.from, 5012);
        Assert.assertEquals(rA.to, 5012);
        Assert.assertEquals(rb.from, 1);
        Assert.assertEquals(rb.to, 1);
        Assert.assertEquals(rc.from, 13);
        Assert.assertEquals(rc.to, 987);
        Assert.assertEquals(rA, new VlanRangeHelper.Range(5012, 5012));
        Assert.assertEquals(rA, new VlanRangeHelper.Range(5012));
        Assert.assertEquals(rc, new VlanRangeHelper.Range(13, 987));
        Assert.assertEquals(rc, new VlanRangeHelper.Range(rc));
        Assert.assertEquals(rb, new VlanRangeHelper.Range(rb));
        Assert.assertEquals(rA, new VlanRangeHelper.Range(rA));
    }
    @Test
    public void testVlanRangeHelper() {
        String exa = "3726-3732,3747-3749";
        String exb = "3726-3732,3747";
        String exc = "670,3726-3750";
        String exd = "2-4094";
        String exe = "300";
        String exf = "580,722";
        String exg = "580,722,1024,18-30";

        VlanRangeHelper ha = new VlanRangeHelper(exa);
        VlanRangeHelper hb = new VlanRangeHelper(exb);
        VlanRangeHelper hc = new VlanRangeHelper(exc);
        VlanRangeHelper hd = new VlanRangeHelper(exd);
        VlanRangeHelper he = new VlanRangeHelper(exe);
        VlanRangeHelper hf = new VlanRangeHelper(exf);
        VlanRangeHelper hg = new VlanRangeHelper(exg);

        Assert.assertEquals(ha.getOriginalRanges().size(), ha.getCurrentRanges().size());
        Assert.assertEquals(hb.getOriginalRanges().size(), hb.getCurrentRanges().size());
        Assert.assertEquals(hc.getOriginalRanges().size(), hc.getCurrentRanges().size());
        Assert.assertEquals(hd.getOriginalRanges().size(), hd.getCurrentRanges().size());
        Assert.assertEquals(he.getOriginalRanges().size(), he.getCurrentRanges().size());
        Assert.assertEquals(hf.getOriginalRanges().size(), hf.getCurrentRanges().size());
        Assert.assertEquals(hg.getOriginalRanges().size(), hg.getCurrentRanges().size());

        Assert.assertEquals(ha.getOriginalRanges(), ha.getCurrentRanges());
        Assert.assertEquals(hb.getOriginalRanges(), hb.getCurrentRanges());
        Assert.assertEquals(hc.getOriginalRanges(), hc.getCurrentRanges());
        Assert.assertEquals(hd.getOriginalRanges(), hd.getCurrentRanges());
        Assert.assertEquals(he.getOriginalRanges(), he.getCurrentRanges());
        Assert.assertEquals(hf.getOriginalRanges(), hf.getCurrentRanges());
        Assert.assertEquals(hg.getOriginalRanges(), hg.getCurrentRanges());

        Assert.assertEquals(ha.getOriginalRanges().size(), 2);
        Assert.assertEquals(hb.getOriginalRanges().size(), 2);
        Assert.assertEquals(hc.getOriginalRanges().size(), 2);
        Assert.assertEquals(hd.getOriginalRanges().size(), 1);
        Assert.assertEquals(he.getOriginalRanges().size(), 1);
        Assert.assertEquals(hf.getOriginalRanges().size(), 2);
        Assert.assertEquals(hg.getOriginalRanges().size(), 4);

        List<VlanRangeHelper.Range> rangesa = new ArrayList<VlanRangeHelper.Range>();
        List<VlanRangeHelper.Range> rangesb = new ArrayList<VlanRangeHelper.Range>();
        List<VlanRangeHelper.Range> rangesc = new ArrayList<VlanRangeHelper.Range>();
        List<VlanRangeHelper.Range> rangesd = new ArrayList<VlanRangeHelper.Range>();
        List<VlanRangeHelper.Range> rangese = new ArrayList<VlanRangeHelper.Range>();
        List<VlanRangeHelper.Range> rangesf = new ArrayList<VlanRangeHelper.Range>();
        List<VlanRangeHelper.Range> rangesg = new ArrayList<VlanRangeHelper.Range>();
        rangesa.add(new VlanRangeHelper.Range(3726, 3732));
        rangesa.add(new VlanRangeHelper.Range(3747, 3749));
        rangesb.add(new VlanRangeHelper.Range(3726, 3732));
        rangesb.add(new VlanRangeHelper.Range(3747));
        rangesc.add(new VlanRangeHelper.Range(670));
        rangesc.add(new VlanRangeHelper.Range(3726,3750));
        rangesd.add(new VlanRangeHelper.Range(2,4094));
        rangese.add(new VlanRangeHelper.Range(300));
        rangesf.add(new VlanRangeHelper.Range(580));
        rangesf.add(new VlanRangeHelper.Range(722));
        rangesg.add(new VlanRangeHelper.Range(580));
        rangesg.add(new VlanRangeHelper.Range(722));
        rangesg.add(new VlanRangeHelper.Range(1024));
        rangesg.add(new VlanRangeHelper.Range(18,30));

        Assert.assertEquals(ha.getOriginalRanges(), rangesa);
        Assert.assertEquals(hb.getOriginalRanges(), rangesb);
        Assert.assertEquals(hc.getOriginalRanges(), rangesc);
        Assert.assertEquals(hd.getOriginalRanges(), rangesd);
        Assert.assertEquals(he.getOriginalRanges(), rangese);
        Assert.assertEquals(hf.getOriginalRanges(), rangesf);
        Assert.assertEquals(hg.getOriginalRanges(), rangesg);

        int rA1 = ha.getCurrent();
        int rA2 = ha.getNext();
        int rA3 = ha.getNext();
        Assert.assertEquals(rA1, 3726);
        Assert.assertEquals(rA2, 3727);
        Assert.assertEquals(rA3, 3728);

        int rC1 = hc.getCurrent();
        int rC2 = hc.getNext();
        int rC3 = hc.getNext();
        Assert.assertEquals(rC1, 670);
        Assert.assertEquals(rC2, 3726);
        Assert.assertEquals(rC3, 3727);

        Integer rF1 = hf.getCurrent();
        Integer rF2 = hf.getNext();
        Integer rF3 = hf.getNext();
        Assert.assertEquals(rF1, (Integer) 580);
        Assert.assertEquals(rF2, (Integer) 722);
        Assert.assertNull(rF3);

        int rG1 = hg.getCurrent();
        int rG2 = hg.getNext();
        int rG3 = hg.getNext();
        int rG4 = hg.getNext();
        Assert.assertEquals(rG1, 580);
        Assert.assertEquals(rG2, 722);
        Assert.assertEquals(rG3, 1024);
        Assert.assertEquals(rG4, 18);
        for (Integer i = 19; i <= 30; i++) {
            Integer rG = hg.getNext();
            Assert.assertEquals(rG, i);
        }
        Integer rGNull = hg.getNext();
        Assert.assertNull(rGNull);
    }
}
