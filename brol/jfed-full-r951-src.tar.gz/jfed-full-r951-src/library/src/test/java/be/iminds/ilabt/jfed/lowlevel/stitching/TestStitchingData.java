package be.iminds.ilabt.jfed.lowlevel.stitching;

import be.iminds.ilabt.jfed.lowlevel.GeniAMResponseCode;
import be.iminds.ilabt.jfed.lowlevel.api.AbstractGeniAggregateManager;
import be.iminds.ilabt.jfed.lowlevel.api.StitchingComputationService;
import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.BuiltinAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.authority.JFedAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

/**
 * TestStitchingData
 */
public class TestStitchingData {
    private StitchingData sd;
    @Test
    public void testCreateStitchingData() throws IOException, SAXException, ParserConfigurationException {
        AuthorityListModel authList = new AuthorityListModel();
        BuiltinAuthorityList.load(authList);

        sd = new StitchingData(scenario2Hop_rspec, scenario2Hop_workflow, authList);

        System.out.println("Order of authorities:");
        for (SfaAuthority auth : sd.getOrderedSfaAuths())
            System.out.println("  - \""+auth.getUrn()+"\"");

        Assert.assertEquals(3, sd.getOrderedSfaAuths().size());
        Assert.assertEquals("urn:publicid:IDN+ion.internet2.edu+authority+am", sd.getOrderedSfaAuths().get(2).getUrn().getValue());

        System.out.println("\nStitchingData: "+sd+"\n\n");
        //todo test more?

        Assert.assertEquals("3731", getSuggestedVLANforHopId(sd.getCurrentRequestRspec(), "link1", "urn:publicid:IDN+instageni.gpolab.bbn.com+interface+procurve2:5.24"));
        Assert.assertEquals("3731", getSuggestedVLANforHopId(sd.getCurrentRequestRspec(), "link1", "urn:publicid:IDN+ion.internet2.edu+interface+rtr.newy:ae0:bbn"));
        Assert.assertEquals("986",  getSuggestedVLANforHopId(sd.getCurrentRequestRspec(), "link1", "urn:publicid:IDN+ion.internet2.edu+interface+rtr.atla:ge-10/3/2:protogeni"));
        Assert.assertEquals("986",  getSuggestedVLANforHopId(sd.getCurrentRequestRspec(), "link1", "urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21"));
        Assert.assertEquals("3730", getSuggestedVLANforHopId(sd.getCurrentRequestRspec(), "link2", "urn:publicid:IDN+instageni.gpolab.bbn.com+interface+procurve2:5.24"));
        Assert.assertEquals("3730", getSuggestedVLANforHopId(sd.getCurrentRequestRspec(), "link2", "urn:publicid:IDN+ion.internet2.edu+interface+rtr.newy:ae0:bbn"));
        Assert.assertEquals("990", getSuggestedVLANforHopId(sd.getCurrentRequestRspec(), "link2", "urn:publicid:IDN+ion.internet2.edu+interface+rtr.atla:ge-10/3/2:protogeni"));
        Assert.assertEquals("990", getSuggestedVLANforHopId(sd.getCurrentRequestRspec(), "link2", "urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21"));
    }

    StitchingCallData gpoCallData;
    StitchingCallData ionCallData;
    StitchingCallData emulabCallData;

    @Test(dependsOnMethods= {"testCreateStitchingData"})
    public void testCallData() {
        gpoCallData = sd.getStitchingCallData("urn:publicid:IDN+instageni.gpolab.bbn.com+authority+cm");
        ionCallData = sd.getStitchingCallData("urn:publicid:IDN+ion.internet2.edu+authority+am");
        emulabCallData = sd.getStitchingCallData("urn:publicid:IDN+emulab.net+authority+cm");

        Assert.assertNotNull(gpoCallData);
        Assert.assertNotNull(ionCallData);
        Assert.assertNotNull(emulabCallData);

        Assert.assertEquals(3731, gpoCallData.getHopData("link1", "urn:publicid:IDN+instageni.gpolab.bbn.com+interface+procurve2:5.24").getSuggestedVlan().intValue());
        Assert.assertEquals(3731, ionCallData.getHopData("link1", "urn:publicid:IDN+ion.internet2.edu+interface+rtr.newy:ae0:bbn").getSuggestedVlan().intValue());
        Assert.assertEquals(986, ionCallData.getHopData("link1", "urn:publicid:IDN+ion.internet2.edu+interface+rtr.atla:ge-10/3/2:protogeni").getSuggestedVlan().intValue());
        Assert.assertEquals(986, emulabCallData.getHopData("link1", "urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21").getSuggestedVlan().intValue());

        Assert.assertEquals(3730, gpoCallData.getHopData("link2", "urn:publicid:IDN+instageni.gpolab.bbn.com+interface+procurve2:5.24").getSuggestedVlan().intValue());
        Assert.assertEquals(3730, ionCallData.getHopData("link2", "urn:publicid:IDN+ion.internet2.edu+interface+rtr.newy:ae0:bbn").getSuggestedVlan().intValue());
        Assert.assertEquals(990, ionCallData.getHopData("link2", "urn:publicid:IDN+ion.internet2.edu+interface+rtr.atla:ge-10/3/2:protogeni").getSuggestedVlan().intValue());
        Assert.assertEquals(990, emulabCallData.getHopData("link2", "urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21").getSuggestedVlan().intValue());
    }

    @Test(dependsOnMethods= {"testCallData"})
    public void testUpdate() {
        ionCallData.setVlanUnavailable(990);
        emulabCallData.setVlanUnavailable(990);

        StitchingHopData testedIonHop = ionCallData.getHopData("link2", "urn:publicid:IDN+ion.internet2.edu+interface+rtr.atla:ge-10/3/2:protogeni");
        StitchingHopData testedemulabHop = emulabCallData.getHopData("link2", "urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21");
        Assert.assertNotNull(testedIonHop);
        Assert.assertNotNull(testedemulabHop);
        Assert.assertNotNull(testedIonHop.getSuggestedVlan());
        Assert.assertNotNull(testedemulabHop.getSuggestedVlan());
        System.out.println("testUpdate ion Hop VLAN=" + testedIonHop.getSuggestedVlan());
        System.out.println("testUpdate emulab Hop VLAN=" + testedemulabHop.getSuggestedVlan());
        Assert.assertNotEquals(990, testedIonHop.getSuggestedVlan().intValue(), "a different VLAN should have been chosen");
        Assert.assertNotEquals(990, testedemulabHop.getSuggestedVlan().intValue(), "a different VLAN should have been chosen");


        //for gpoCallData: available 3726-3732,3747-3749
        for (int i = 3726; i <= 3732; i++)
            if (i != 3728)
                gpoCallData.setVlanUnavailable(i);
        gpoCallData.setVlanUnavailable(3747);
        gpoCallData.setVlanUnavailable(3749);
        //left: 3728 and 3748

        StitchingHopData testedGpoLink1Hop = gpoCallData.getHopData("link1", "urn:publicid:IDN+instageni.gpolab.bbn.com+interface+procurve2:5.24");
        StitchingHopData testedGpoLink2Hop = gpoCallData.getHopData("link2", "urn:publicid:IDN+instageni.gpolab.bbn.com+interface+procurve2:5.24");
        Assert.assertNotNull(testedGpoLink1Hop);
        Assert.assertNotNull(testedGpoLink2Hop);
        Assert.assertNotNull(testedGpoLink1Hop.getSuggestedVlan());
        Assert.assertNotNull(testedGpoLink2Hop.getSuggestedVlan());
        int vlan1 = testedGpoLink1Hop.getSuggestedVlan().intValue();
        int vlan2 = testedGpoLink2Hop.getSuggestedVlan().intValue();

        System.out.println("testUpdate vlan1=" + vlan1 + " vlan2=" + vlan2);

        Assert.assertTrue(vlan1 == 3728 || vlan1 == 3748, "VLAN for GPO on link1 must be either 3728 or 3748 but it is "+vlan1);
        Assert.assertTrue(vlan2 == 3728 || vlan2 == 3748, "VLAN for GPO on link2 must be either 3728 or 3748 but it is " + vlan2);
        Assert.assertNotEquals(vlan1, vlan2, "VLAN for GPO on link1 and link2 must differ. But they are both " + vlan1);
    }


    StitchingDirector director;

    @Test(dependsOnMethods= {"testUpdate"})
    public void testStitchingDirectorInit() {
        AuthorityListModel authList = new AuthorityListModel();
        BuiltinAuthorityList.load(authList);
        director = new StitchingDirector(authList);

        StitchingComputationService.ComputePathResult computePathResult =  new StitchingComputationService.ComputePathResult(scenario2Hop_workflow, scenario2Hop_rspec);
        director.setComputePathResult(computePathResult);

        Assert.assertTrue(director.getAllAuthorities().size() > 0);
        Assert.assertTrue(director.getHopsLeft().size() > 0);
        Assert.assertTrue(director.getReadyHops().size() > 0);
        Assert.assertEquals(director.getHopsLeft().size(), director.getAllAuthorities().size(),
                "director getHopsLeft().size() != getAllAuthorities().size()  -> "+
                        director.getHopsLeft().size()+" != "+director.getAllAuthorities().size());
    }

    @Test(dependsOnMethods= {"testStitchingDirectorInit"})
    public void testStitchingDirectorHandleUnavailable() throws IOException, SAXException, ParserConfigurationException {
        List<StitchingDirector.ReadyAuthorityDetails> readyHops = director.getReadyHops();
        Assert.assertEquals(2, readyHops.size(), "Readyhops size should be 2");
        StitchingDirector.ReadyAuthorityDetails emuHop = null;
        StitchingDirector.ReadyAuthorityDetails gpoHop = null;
        for (StitchingDirector.ReadyAuthorityDetails readyHop : readyHops) {
            if (readyHop.getAuthority().getNameForUrn().equals("emulab.net")) emuHop = readyHop;
            if (readyHop.getAuthority().getNameForUrn().equals("instageni.gpolab.bbn.com")) gpoHop = readyHop;
        }
        Assert.assertNotNull(emuHop);
        Assert.assertNotNull(gpoHop);

        Assert.assertEquals("986", getSuggestedVLANforHopId(emuHop.getRequestRspec(), "link1", "urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21"));

        AbstractGeniAggregateManager.AggregateManagerReply<String> reply = new AbstractGeniAggregateManager.AggregateManagerReply<String>() {
            @Override public int getCode() { return GeniAMResponseCode.GENIRESPONSE_BADARGS.getCode(); }
            @Override public GeniAMResponseCode getGeniResponseCode() { return GeniAMResponseCode.GENIRESPONSE_BADARGS; }
            @Override public String getValue() { return ""; }
            public String getOutput() { return "vlan tag 986 for 'link1' not available"; }
        };

        String vlanPart = "vlan tag 986 for 'link1' not available".replaceAll("vlan tag ([0-9]*) for .* not available", "$1");
        Assert.assertEquals(vlanPart, "986", "vlanPart should be 986 but is \""+vlanPart+"\"");

        boolean failure = director.processCreateSliverResult(emuHop, reply);
        Assert.assertFalse(failure);



        List<StitchingDirector.ReadyAuthorityDetails> readyHops2 = director.getReadyHops();
        Assert.assertEquals(2, readyHops.size(), "Readyhops size should be 2");
        StitchingDirector.ReadyAuthorityDetails emuHop2 = null;
        StitchingDirector.ReadyAuthorityDetails gpoHop2 = null;
        for (StitchingDirector.ReadyAuthorityDetails readyHop : readyHops2) {
            if (readyHop.getAuthority().getNameForUrn().equals("emulab.net")) emuHop2 = readyHop;
            if (readyHop.getAuthority().getNameForUrn().equals("instageni.gpolab.bbn.com")) gpoHop2 = readyHop;
        }
        Assert.assertNotNull(emuHop2);
        Assert.assertNotNull(gpoHop2);

        String vlanLink1 = getSuggestedVLANforHopId(emuHop2.getRequestRspec(), "link1", "urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21");
        Assert.assertNotEquals("986", vlanLink1, "VLAN should not be 986. it is \""+vlanLink1+"\" full rspec="+emuHop2.getRequestRspec());
        Assert.assertNotEquals("986", getSuggestedVLANforHopId(emuHop2.getRequestRspec(), "link2", "urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21"));
    }

    @Test(dependsOnMethods= {"testStitchingDirectorHandleUnavailable"})
    public void testStitchingDirectorHandleSuccess() {

    }





    //extract suggested VLAN for testing (some code duplication with code in StitchingHopData here)
    private String getSuggestedVLANforHopId(String rspec, String linkName, String hopUrn) throws ParserConfigurationException, IOException, SAXException {
        //first parse rspec
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = null;
        dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(new InputSource(new StringReader(rspec)));

        doc.getDocumentElement().normalize();

        NodeList rspecListNoNS = doc.getElementsByTagName("rspec");
        assert rspecListNoNS.getLength() == 1 : "not a single rspec element, but "+rspecListNoNS.getLength()+" in "+rspec;
        Node rspecNode = rspecListNoNS.item(0);
        assert rspecNode != null;
        assert rspecNode.getNodeType() == Node.ELEMENT_NODE;
        Element rspecElement = (Element) rspecNode;

        NodeList stitchingListNoNS = rspecElement.getElementsByTagName("stitching");
        assert stitchingListNoNS.getLength() == 1  : "not a single stitching element, but "+stitchingListNoNS.getLength()+" in "+rspec;
        Node stitchingNode = stitchingListNoNS.item(0);
        assert stitchingNode != null;
        assert stitchingNode.getNodeType() == Node.ELEMENT_NODE;
        Element stitchingElement = (Element) stitchingNode;

        List<Element> pathEls = quickDomChildrenHelper(stitchingElement, "path");
        for (Element pathEl : pathEls) {
            String linkId = pathEl.getAttribute("id");
            assert linkId != null : "<stitching> has <path> element without id attribute: "+pathEl;

            if (!linkId.equals(linkName))
                continue;

            NodeList hopList = pathEl.getElementsByTagName("hop");
            for (int i = 0; i < hopList.getLength(); i++) {
                Node hopNode = hopList.item(i);
                assert hopNode != null;
                assert hopNode.getNodeType() == Node.ELEMENT_NODE;
                Element hopElement = (Element) hopNode;

                Element linkEl = quickDomChildHelper(hopElement, "link");

                String linkIdUrn = linkEl.getAttribute("id");
                if (!linkIdUrn.equals(hopUrn))
                    continue;

                Element scDescriptorEl = quickDomChildHelper(linkEl, "switchingCapabilityDescriptor");
                Element scSpecificInfoEl = quickDomChildHelper(scDescriptorEl, "switchingCapabilitySpecificInfo");
                Element scSpecificInfo_L2scEl = quickDomChildHelper(scSpecificInfoEl, "switchingCapabilitySpecificInfo_L2sc");
                Element vlanRangeAvailabilityEl = quickDomChildHelper(scSpecificInfo_L2scEl, "vlanRangeAvailability");
                Element suggestedVLANRangeEl = quickDomChildHelper(scSpecificInfo_L2scEl, "suggestedVLANRange");

                String hopElId = hopElement.getAttribute("id");
                String vlanRangeAvailability = vlanRangeAvailabilityEl.getTextContent();
                String suggestedVLANRange = suggestedVLANRangeEl.getTextContent();

                return suggestedVLANRange;
            }
        }

        return null;
    }
    private static Element quickDomChildHelper(Element e, String tagName) {
        NodeList resList = e.getElementsByTagName(tagName);
        assert resList.getLength() == 1;
        Node resNode = resList.item(0);
        assert resNode != null;
        assert resNode.getNodeType() == Node.ELEMENT_NODE;
        Element resElement = (Element) resNode;
        return resElement;
    }
    private static List<Element> quickDomChildrenHelper(Element e, String tagName) {
        NodeList resList = e.getElementsByTagName(tagName);
        List<Element> resElements = new ArrayList<Element>();
        for (int i = 0 ; i < resList.getLength(); i++) {
            Node resNode = resList.item(i);
            assert resNode != null;
            assert resNode.getNodeType() == Node.ELEMENT_NODE;
            Element resElement = (Element) resNode;
            resElements.add(resElement);
        }
        return resElements;
    }


    private static class HopHtHelper {
        public String hopUrn;
        public String aggUrn;
        public String aggUrl;
        public Boolean importVlans;

        private HopHtHelper(String hopUrn, String aggUrn, String aggUrl, Boolean importVlans) {
            assert aggUrn.startsWith("urn");
            assert hopUrn.startsWith("urn");
            assert aggUrl.startsWith("http");
            this.hopUrn = hopUrn;
            this.aggUrn = aggUrn;
            this.aggUrl = aggUrl;
            this.importVlans = importVlans;
        }

        public List<HopHtHelper> deps = new ArrayList<HopHtHelper>();

        public Hashtable toHt() {
            Hashtable res = new Hashtable();
            res.put("hop_urn", hopUrn);
            res.put("aggregate_urn", aggUrn);
            res.put("aggregate_url", aggUrl);
            res.put("import_vlans", importVlans);

            if (!deps.isEmpty()) {
                Vector vDeps = new Vector();
                for (HopHtHelper d : deps)
                    vDeps.add(d.toHt());
                res.put("dependencies", vDeps);
            }
            return res;
        }
    }
    private static class LinkHtHelper {
        public List<HopHtHelper> deps = new ArrayList<HopHtHelper>();

        final String linkName;
        private LinkHtHelper(String linkName) {
            this.linkName = linkName;
        }

        public Hashtable toHt() {
            Hashtable res = new Hashtable();
            Vector vDeps = new Vector();
            for (HopHtHelper d : deps)
                vDeps.add(d.toHt());
            res.put("dependencies", vDeps);
            return res;
        }
    }
    private static class WorkFlowHtHelper {
        public List<LinkHtHelper> links = new ArrayList<LinkHtHelper>();

        public Hashtable toHt() {
            Hashtable wf = new Hashtable();
            for (LinkHtHelper l : links)
                wf.put(l.linkName, l.toHt());
            return wf;
//            Hashtable res = new Hashtable();
//            res.put("workflow_data", wf);
//            return res;
        }
    }

    private static Hashtable create_scenario2Hop_workflow() {
        WorkFlowHtHelper w = new WorkFlowHtHelper();
        LinkHtHelper link1 = new LinkHtHelper("link1");
        LinkHtHelper link2 = new LinkHtHelper("link2");
        w.links.add(link1);
        w.links.add(link2);

        HopHtHelper h1 = new HopHtHelper("urn:publicid:IDN+ion.internet2.edu+interface+rtr.newy:ae0:bbn",
                "urn:publicid:IDN+ion.internet2.edu+authority+am", "http://geni-am.net.internet2.edu:12346", true);
        HopHtHelper h2 = new HopHtHelper("urn:publicid:IDN+instageni.gpolab.bbn.com+interface+procurve2:5.24",
                "urn:publicid:IDN+instageni.gpolab.bbn.com+authority+cm", "https://boss.instageni.gpolab.bbn.com:12369/protogeni/xmlrpc/am", false);
        HopHtHelper h3 = new HopHtHelper("urn:publicid:IDN+ion.internet2.edu+interface+rtr.atla:ge-10/3/2:protogeni",
                "urn:publicid:IDN+ion.internet2.edu+authority+am", "http://geni-am.net.internet2.edu:12346", true);
        HopHtHelper h4 = new HopHtHelper("urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21",
                "urn:publicid:IDN+emulab.net+authority+cm", "https://www.emulab.net:12369/protogeni/xmlrpc/am", false);
        h1.deps.add(h2);
        h3.deps.add(h4);
        link1.deps.add(h1);
        link1.deps.add(h3);
        link2.deps.add(h1);
        link2.deps.add(h3);

        return w.toHt();
    }

    /*
    * "workflow_data" -> {
      "link2" -> {
        "dependencies" -> [
               {
                  "hop_urn" -> "urn:publicid:IDN+ion.internet2.edu+interface+rtr.newy:ae0:bbn",
                  "import_vlans" -> true,
                  "aggregate_urn" -> "urn:publicid:IDN+ion.internet2.edu+authority+am",
                  "dependencies" -> [
                         {
                            "hop_urn" -> "urn:publicid:IDN+instageni.gpolab.bbn.com+interface+procurve2:5.24",
                            "import_vlans" -> false,
                            "aggregate_urn" -> "urn:publicid:IDN+instageni.gpolab.bbn.com+authority+cm",
                            "aggregate_url" -> "https://boss.instageni.gpolab.bbn.com:12369/protogeni/xmlrpc/am"
                            }
                         ],
                  "aggregate_url" -> "http://geni-am.net.internet2.edu:12346"
                  },
               {
                  "hop_urn" -> "urn:publicid:IDN+ion.internet2.edu+interface+rtr.atla:ge-10/3/2:protogeni",
                  "import_vlans" -> true,
                  "aggregate_urn" -> "urn:publicid:IDN+ion.internet2.edu+authority+am",
                  "dependencies" -> [
                         {
                            "hop_urn" -> "urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21",
                            "import_vlans" -> false,
                            "aggregate_urn" -> "urn:publicid:IDN+emulab.net+authority+cm",
                            "aggregate_url" -> "https://www.emulab.net:12369/protogeni/xmlrpc/am"
                            }
                         ],
                  "aggregate_url" -> "http://geni-am.net.internet2.edu:12346"
                  }
               ]
        },
      "link1" -> {
        "dependencies" -> [
               {
                  "hop_urn" -> "urn:publicid:IDN+ion.internet2.edu+interface+rtr.newy:ae0:bbn",
                  "import_vlans" -> true,
                  "aggregate_urn" -> "urn:publicid:IDN+ion.internet2.edu+authority+am",
                  "dependencies" -> [
                         {
                            "hop_urn" -> "urn:publicid:IDN+instageni.gpolab.bbn.com+interface+procurve2:5.24",
                            "import_vlans" -> false,
                            "aggregate_urn" -> "urn:publicid:IDN+instageni.gpolab.bbn.com+authority+cm",
                            "aggregate_url" -> "https://boss.instageni.gpolab.bbn.com:12369/protogeni/xmlrpc/am"
                            }
                         ],
                  "aggregate_url" -> "http://geni-am.net.internet2.edu:12346"
                  },
               {
                  "hop_urn" -> "urn:publicid:IDN+ion.internet2.edu+interface+rtr.atla:ge-10/3/2:protogeni",
                  "import_vlans" -> true,
                  "aggregate_urn" -> "urn:publicid:IDN+ion.internet2.edu+authority+am",
                  "dependencies" -> [
                         {
                            "hop_urn" -> "urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21",
                            "import_vlans" -> false,
                            "aggregate_urn" -> "urn:publicid:IDN+emulab.net+authority+cm",
                            "aggregate_url" -> "https://www.emulab.net:12369/protogeni/xmlrpc/am"
                            }
                         ],
                  "aggregate_url" -> "http://geni-am.net.internet2.edu:12346"
                  }
               ]
        }
    * */

    private Hashtable scenario2Hop_workflow = create_scenario2Hop_workflow();
    private String scenario2Hop_rspec = "<?xml version=\"1.0\"?>\n" +
            "<rspec xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd http://hpn.east.isi.edu/rspec/ext/stitch/0.1/ http://hpn.east.isi.edu/rspec/ext/stitch/0.1/stitch-schema.xsd\">\n" +
            "  <node client_id=\"bbnNode1\" component_manager_id=\"urn:publicid:IDN+instageni.gpolab.bbn.com+authority+cm\" exclusive=\"false\">\n" +
            "    <sliver_type name=\"emulab-openvz\"/>\n" +
            "    <interface client_id=\"node0:if0\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"emuNode1\" component_manager_id=\"urn:publicid:IDN+emulab.net+authority+cm\" exclusive=\"false\">\n" +
            "    <sliver_type name=\"emulab-openvz\"/>\n" +
            "    <interface client_id=\"node1:if0\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"bbnNode2\" component_manager_id=\"urn:publicid:IDN+instageni.gpolab.bbn.com+authority+cm\" exclusive=\"false\">\n" +
            "    <sliver_type name=\"emulab-openvz\"/>\n" +
            "    <interface client_id=\"node2:if0\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"emuNode2\" component_manager_id=\"urn:publicid:IDN+emulab.net+authority+cm\" exclusive=\"false\">\n" +
            "    <sliver_type name=\"emulab-openvz\"/>\n" +
            "    <interface client_id=\"node3:if0\"/>\n" +
            "  </node>\n" +
            "  <link client_id=\"link1\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+instageni.gpolab.bbn.com+authority+cm\"/>\n" +
            "    <component_manager name=\"urn:publicid:IDN+ion.internet2.edu+authority+am\"/>\n" +
            "    <component_manager name=\"urn:publicid:IDN+emulab.net+authority+cm\"/>\n" +
            "    <property source_id=\"node0:if0\" dest_id=\"node1:if0\" capacity=\"100000\"/>\n" +
            "    <property source_id=\"node1:if0\" dest_id=\"node0:if0\" capacity=\"100000\"/>\n" +
            "    <interface_ref client_id=\"node0:if0\"/>\n" +
            "    <interface_ref client_id=\"node1:if0\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"link2\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+instageni.gpolab.bbn.com+authority+cm\"/>\n" +
            "    <component_manager name=\"urn:publicid:IDN+ion.internet2.edu+authority+am\"/>\n" +
            "    <component_manager name=\"urn:publicid:IDN+emulab.net+authority+cm\"/>\n" +
            "    <property source_id=\"node2:if0\" dest_id=\"node3:if0\" capacity=\"10000\"/>\n" +
            "    <property source_id=\"node3:if0\" dest_id=\"node2:if0\" capacity=\"10000\"/>\n" +
            "    <interface_ref client_id=\"node2:if0\"/>\n" +
            "    <interface_ref client_id=\"node3:if0\"/>\n" +
            "  </link>\n" +
            "  <stitching xmlns=\"http://hpn.east.isi.edu/rspec/ext/stitch/0.1/\" lastUpdateTime=\"20131029:03:33:21\">\n" +
            "    <path id=\"link1\">\n" +
            "      <hop id=\"1\">\n" +
            "        <link id=\"urn:publicid:IDN+instageni.gpolab.bbn.com+interface+procurve2:5.24\">\n" +
            "          <trafficEngineeringMetric>10</trafficEngineeringMetric>\n" +
            "          <capacity>100000</capacity>\n" +
            "          <switchingCapabilityDescriptor>\n" +
            "            <switchingcapType>l2sc</switchingcapType>\n" +
            "            <encodingType>ethernet</encodingType>\n" +
            "            <switchingCapabilitySpecificInfo>\n" +
            "              <switchingCapabilitySpecificInfo_L2sc>\n" +
            "                <interfaceMTU>9000</interfaceMTU>\n" +
            "                <vlanRangeAvailability>3726-3732,3747-3749</vlanRangeAvailability>\n" +
            "                <suggestedVLANRange>3731</suggestedVLANRange>\n" +
            "                <vlanTranslation>false</vlanTranslation>\n" +
            "              </switchingCapabilitySpecificInfo_L2sc>\n" +
            "            </switchingCapabilitySpecificInfo>\n" +
            "          </switchingCapabilityDescriptor>\n" +
            "        </link>\n" +
            "        <nextHop>2</nextHop>\n" +
            "      </hop>\n" +
            "      <hop id=\"2\">\n" +
            "        <link id=\"urn:publicid:IDN+ion.internet2.edu+interface+rtr.newy:ae0:bbn\">\n" +
            "          <trafficEngineeringMetric>10</trafficEngineeringMetric>\n" +
            "          <capacity>100000</capacity>\n" +
            "          <switchingCapabilityDescriptor>\n" +
            "            <switchingcapType>l2sc</switchingcapType>\n" +
            "            <encodingType>ethernet</encodingType>\n" +
            "            <switchingCapabilitySpecificInfo>\n" +
            "              <switchingCapabilitySpecificInfo_L2sc>\n" +
            "                <interfaceMTU>9000</interfaceMTU>\n" +
            "                <vlanRangeAvailability>670,3726-3750</vlanRangeAvailability>\n" +
            "                <suggestedVLANRange>3731</suggestedVLANRange>\n" +
            "                <vlanTranslation>true</vlanTranslation>\n" +
            "              </switchingCapabilitySpecificInfo_L2sc>\n" +
            "            </switchingCapabilitySpecificInfo>\n" +
            "          </switchingCapabilityDescriptor>\n" +
            "        </link>\n" +
            "        <nextHop>3</nextHop>\n" +
            "      </hop>\n" +
            "      <hop id=\"3\">\n" +
            "        <link id=\"urn:publicid:IDN+ion.internet2.edu+interface+rtr.atla:ge-10/3/2:protogeni\">\n" +
            "          <trafficEngineeringMetric>10</trafficEngineeringMetric>\n" +
            "          <capacity>100000</capacity>\n" +
            "          <switchingCapabilityDescriptor>\n" +
            "            <switchingcapType>l2sc</switchingcapType>\n" +
            "            <encodingType>ethernet</encodingType>\n" +
            "            <switchingCapabilitySpecificInfo>\n" +
            "              <switchingCapabilitySpecificInfo_L2sc>\n" +
            "                <interfaceMTU>9000</interfaceMTU>\n" +
            "                <vlanRangeAvailability>2-4094</vlanRangeAvailability>\n" +
            "                <suggestedVLANRange>986</suggestedVLANRange>\n" +
            "                <vlanTranslation>true</vlanTranslation>\n" +
            "              </switchingCapabilitySpecificInfo_L2sc>\n" +
            "            </switchingCapabilitySpecificInfo>\n" +
            "          </switchingCapabilityDescriptor>\n" +
            "        </link>\n" +
            "        <nextHop>4</nextHop>\n" +
            "      </hop>\n" +
            "      <hop id=\"4\">\n" +
            "        <link id=\"urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21\">\n" +
            "          <trafficEngineeringMetric>10</trafficEngineeringMetric>\n" +
            "          <capacity>100000</capacity>\n" +
            "          <switchingCapabilityDescriptor>\n" +
            "            <switchingcapType>l2sc</switchingcapType>\n" +
            "            <encodingType>ethernet</encodingType>\n" +
            "            <switchingCapabilitySpecificInfo>\n" +
            "              <switchingCapabilitySpecificInfo_L2sc>\n" +
            "                <interfaceMTU>9000</interfaceMTU>\n" +
            "                <vlanRangeAvailability>750-1000</vlanRangeAvailability>\n" +
            "                <suggestedVLANRange>986</suggestedVLANRange>\n" +
            "                <vlanTranslation>false</vlanTranslation>\n" +
            "              </switchingCapabilitySpecificInfo_L2sc>\n" +
            "            </switchingCapabilitySpecificInfo>\n" +
            "          </switchingCapabilityDescriptor>\n" +
            "        </link>\n" +
            "        <nextHop>null</nextHop>\n" +
            "      </hop>\n" +
            "    </path>\n" +
            "    <path id=\"link2\">\n" +
            "      <hop id=\"1\">\n" +
            "        <link id=\"urn:publicid:IDN+instageni.gpolab.bbn.com+interface+procurve2:5.24\">\n" +
            "          <trafficEngineeringMetric>10</trafficEngineeringMetric>\n" +
            "          <capacity>10000</capacity>\n" +
            "          <switchingCapabilityDescriptor>\n" +
            "            <switchingcapType>l2sc</switchingcapType>\n" +
            "            <encodingType>ethernet</encodingType>\n" +
            "            <switchingCapabilitySpecificInfo>\n" +
            "              <switchingCapabilitySpecificInfo_L2sc>\n" +
            "                <interfaceMTU>9000</interfaceMTU>\n" +
            "                <vlanRangeAvailability>3726-3730,3732,3747-3749</vlanRangeAvailability>\n" +
            "                <suggestedVLANRange>3730</suggestedVLANRange>\n" +
            "                <vlanTranslation>false</vlanTranslation>\n" +
            "              </switchingCapabilitySpecificInfo_L2sc>\n" +
            "            </switchingCapabilitySpecificInfo>\n" +
            "          </switchingCapabilityDescriptor>\n" +
            "        </link>\n" +
            "        <nextHop>2</nextHop>\n" +
            "      </hop>\n" +
            "      <hop id=\"2\">\n" +
            "        <link id=\"urn:publicid:IDN+ion.internet2.edu+interface+rtr.newy:ae0:bbn\">\n" +
            "          <trafficEngineeringMetric>10</trafficEngineeringMetric>\n" +
            "          <capacity>10000</capacity>\n" +
            "          <switchingCapabilityDescriptor>\n" +
            "            <switchingcapType>l2sc</switchingcapType>\n" +
            "            <encodingType>ethernet</encodingType>\n" +
            "            <switchingCapabilitySpecificInfo>\n" +
            "              <switchingCapabilitySpecificInfo_L2sc>\n" +
            "                <interfaceMTU>9000</interfaceMTU>\n" +
            "                <vlanRangeAvailability>670,3726-3730,3732-3750</vlanRangeAvailability>\n" +
            "                <suggestedVLANRange>3730</suggestedVLANRange>\n" +
            "                <vlanTranslation>true</vlanTranslation>\n" +
            "              </switchingCapabilitySpecificInfo_L2sc>\n" +
            "            </switchingCapabilitySpecificInfo>\n" +
            "          </switchingCapabilityDescriptor>\n" +
            "        </link>\n" +
            "        <nextHop>3</nextHop>\n" +
            "      </hop>\n" +
            "      <hop id=\"3\">\n" +
            "        <link id=\"urn:publicid:IDN+ion.internet2.edu+interface+rtr.atla:ge-10/3/2:protogeni\">\n" +
            "          <trafficEngineeringMetric>10</trafficEngineeringMetric>\n" +
            "          <capacity>10000</capacity>\n" +
            "          <switchingCapabilityDescriptor>\n" +
            "            <switchingcapType>l2sc</switchingcapType>\n" +
            "            <encodingType>ethernet</encodingType>\n" +
            "            <switchingCapabilitySpecificInfo>\n" +
            "              <switchingCapabilitySpecificInfo_L2sc>\n" +
            "                <interfaceMTU>9000</interfaceMTU>\n" +
            "                <vlanRangeAvailability>2-985,987-4094</vlanRangeAvailability>\n" +
            "                <suggestedVLANRange>990</suggestedVLANRange>\n" +
            "                <vlanTranslation>true</vlanTranslation>\n" +
            "              </switchingCapabilitySpecificInfo_L2sc>\n" +
            "            </switchingCapabilitySpecificInfo>\n" +
            "          </switchingCapabilityDescriptor>\n" +
            "        </link>\n" +
            "        <nextHop>4</nextHop>\n" +
            "      </hop>\n" +
            "      <hop id=\"4\">\n" +
            "        <link id=\"urn:publicid:IDN+emulab.net+interface+procurve-pgeni-atla:3.21\">\n" +
            "          <trafficEngineeringMetric>10</trafficEngineeringMetric>\n" +
            "          <capacity>10000</capacity>\n" +
            "          <switchingCapabilityDescriptor>\n" +
            "            <switchingcapType>l2sc</switchingcapType>\n" +
            "            <encodingType>ethernet</encodingType>\n" +
            "            <switchingCapabilitySpecificInfo>\n" +
            "              <switchingCapabilitySpecificInfo_L2sc>\n" +
            "                <interfaceMTU>9000</interfaceMTU>\n" +
            "                <vlanRangeAvailability>750-985,987-1000</vlanRangeAvailability>\n" +
            "                <suggestedVLANRange>990</suggestedVLANRange>\n" +
            "                <vlanTranslation>false</vlanTranslation>\n" +
            "              </switchingCapabilitySpecificInfo_L2sc>\n" +
            "            </switchingCapabilitySpecificInfo>\n" +
            "          </switchingCapabilityDescriptor>\n" +
            "        </link>\n" +
            "        <nextHop>null</nextHop>\n" +
            "      </hop>\n" +
            "    </path>\n" +
            "  </stitching>\n" +
            "</rspec>\n";
}
