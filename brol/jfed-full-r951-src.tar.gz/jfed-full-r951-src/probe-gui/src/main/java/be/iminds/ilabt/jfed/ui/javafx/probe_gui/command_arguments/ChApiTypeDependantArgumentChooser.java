package be.iminds.ilabt.jfed.ui.javafx.probe_gui.command_arguments;

/**
 * ChApiTypeDependantArgumentChooser
 */
public interface ChApiTypeDependantArgumentChooser {
    public void setObjectType(String typeName);
}
