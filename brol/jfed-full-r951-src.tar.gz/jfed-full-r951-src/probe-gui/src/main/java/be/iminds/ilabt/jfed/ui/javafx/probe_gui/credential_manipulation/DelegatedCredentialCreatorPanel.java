package be.iminds.ilabt.jfed.ui.javafx.probe_gui.credential_manipulation;

import be.iminds.ilabt.jfed.gui_model.GuiModel;
import be.iminds.ilabt.jfed.highlevel.model.CredentialInfo;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.userloginmodel.KeyCertUserLoginModel;
import be.iminds.ilabt.jfed.ui.javafx.probe_gui.command_arguments.CommandArgumentChooser;
import be.iminds.ilabt.jfed.ui.javafx.probe_gui.command_arguments.CredentialArgumentChooser;
import be.iminds.ilabt.jfed.util.*;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.util.Pair;
import org.apache.logging.log4j.LogManager;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.PrivateKey;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.*;

/**
 * CredentialCreatorPanel
 */
public class DelegatedCredentialCreatorPanel extends CredentialCreatorPanel implements Initializable {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    @FXML private Label credentialLabel;
    @FXML private VBox credentialChooserBox;
    @FXML private CredentialArgumentChooser credentialChooser;

    @FXML private Label targetLabel;
    @FXML private TextField targetText;

    @FXML private Button generateButton;

    @FXML private Label resultLabel;
    @FXML private TextArea resultText;
    @FXML private Button saveResultButton;

    @FXML private Label privNameLabel;
    @FXML private TextField privNameText;
    @FXML private CheckBox canDelegateCheckBox;
    @FXML private Label expireLabel;
    @FXML private TextField expireText;

    @FXML private RadioButton targetViaUrn;
    @FXML private RadioButton targetViaCert;

    @FXML private VBox targetUrnBox;
    @FXML private VBox targetCertfileBox;

    @FXML private TextField targetCertFilename;
    @FXML private Button loadCertButton;


    public DelegatedCredentialCreatorPanel() {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("DelegatedCredentialCreator.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        credentialLabel.managedProperty().bind(credentialLabel.visibleProperty());
        credentialChooserBox.managedProperty().bind(credentialChooserBox.visibleProperty());
        targetLabel.managedProperty().bind(targetLabel.visibleProperty());
        targetText.managedProperty().bind(targetText.visibleProperty());
        generateButton.managedProperty().bind(generateButton.visibleProperty());
        resultLabel.managedProperty().bind(resultLabel.visibleProperty());
        resultText.managedProperty().bind(resultText.visibleProperty());
        saveResultButton.managedProperty().bind(saveResultButton.visibleProperty());
        targetUrnBox.managedProperty().bind(targetUrnBox.visibleProperty());
        targetCertfileBox.managedProperty().bind(targetCertfileBox.visibleProperty());

        privNameLabel.managedProperty().bind(privNameLabel.visibleProperty());
        privNameText.managedProperty().bind(privNameText.visibleProperty());
        canDelegateCheckBox.managedProperty().bind(canDelegateCheckBox.visibleProperty());
        expireLabel.managedProperty().bind(expireLabel.visibleProperty());
        expireText.managedProperty().bind(expireText.visibleProperty());

        credentialLabel.visibleProperty().bind(credentialChooserBox.visibleProperty());
        targetLabel.managedProperty().bind(targetText.visibleProperty());
        resultLabel.managedProperty().bind(resultText.visibleProperty());
        saveResultButton.managedProperty().bind(resultText.visibleProperty());

        privNameLabel.visibleProperty().bind(privNameText.visibleProperty());
        expireLabel.visibleProperty().bind(expireText.visibleProperty());

        targetUrnBox.visibleProperty().bind(targetViaUrn.selectedProperty());
        targetCertfileBox.visibleProperty().bind(targetViaCert.selectedProperty());
    }

    public void setGuiModel(GuiModel guiModel) {
        super.setGuiModel(guiModel);

        //should be initialised already
        assert credentialLabel != null;

        //TODO: listen for user login/logout easyModel.getGeniUserProvider().addListener

        credentialChooser = new CredentialArgumentChooser(guiModel, CommandArgumentChooser.CredentialSubject.ANY);
        credentialChooserBox.getChildren().add(credentialChooser);
    }

    private X509Certificate userCert;
    @FXML private void loadCertFile() {
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showOpenDialog(null);

        if(file != null) {
            String filename = file.getPath();
            targetCertFilename.setText(filename);
            String fileContent = null;
            try {
                fileContent = IOUtils.fileToString(file);
                userCert = KeyUtil.pemToX509Certificate(fileContent);
            } catch (Exception e) {
                logger.error("Error reading user certificate file \""+filename+"\": "+e.getMessage(), e);
                targetCertFilename.setText("ERROR: " + e.getMessage());
                userCert = null;
            }
        }
    }


    protected void setResult(final String text) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                resultText.setText(text);
            }
        });

    }


    Thread generateDelegatedThread = null;
    public void generate() {
        if (targetViaCert.isSelected() && userCert == null) {
            logger.info("button clicked: generateDelegate not called since no certificate loaded yet");
            return;
        }

        if (generateDelegatedThread != null) {
            logger.debug("button clicked: generateDelegate still running, so not called");
            return;
        }
        else
            logger.debug("button clicked: generateDelegate called");

        generateButton.setDisable(true);


        AnyCredential delegatedCredential_any = credentialChooser.valueProperty().getValue().getCredential();
        if (delegatedCredential_any == null || !(delegatedCredential_any instanceof SfaCredential)) {
            logger.debug("generateDelegate_Helper() no usable credential selected: "+delegatedCredential_any == null ? "null" :
                    ("class="+delegatedCredential_any.getClass().getName()+
                            " type="+delegatedCredential_any.getType()+
                            " version="+delegatedCredential_any.getVersion())
            );
            return;
        }
        final SfaCredential delegatedCredential = (SfaCredential) delegatedCredential_any;

        int expireInDaysHelper;
        try{
            expireInDaysHelper = Integer.parseInt(expireText.getText());
        } catch (NumberFormatException e) {
            logger.debug("Error processing \"expire\": \"" + expireText.getText() + "\" is not a valid integer", e);
            setResult("Error processing \"expire\": \""+expireText.getText()+"\" is not a valid integer");
            return;
        }
        final int expireInDays = expireInDaysHelper;

        final String privilegeName = privNameText.getText();
        final boolean canDelegate = canDelegateCheckBox.isSelected();

        generateDelegatedThread = new Thread(new Runnable() {
            @Override
            public void run() {
                String targetUrn;
                if (targetViaUrn.isSelected()) {
                    targetUrn = targetText.getText();
                    userCert = certificateRetriever(targetUrn);
                } else {
                    assert userCert != null;
                    targetUrn = findUrnInCertificate(userCert);
                    assert targetUrn != null;
                }
                generate_Helper(delegatedCredential, targetUrn, userCert, expireInDays, privilegeName, canDelegate);
                logger.trace("generateDelegate_Helper() returned");
                generateDelegatedThread = null;
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        generateButton.setDisable(false);
                    }
                });
            }
        });
        generateDelegatedThread.start();
    }

    public void generate_Helper(SfaCredential delegatedCredential, String targetUrn, X509Certificate targetCert, int expireInDays, String privilegeName, boolean canDelegate) {
        assert !Platform.isFxApplicationThread();
        assert guiModel != null;
        assert credentialChooser != null;

        assert guiModel.getGeniUserProvider().isUserLoggedIn();

        logger.trace("generateDelegate_Helper() has target info");

        PrivateKey userPrivateKey = guiModel.getGeniUserProvider().getLoggedInGeniUser().getPrivateKey();

        Date expireDate = new Date(System.currentTimeMillis()+(expireInDays*24*60*60*1000)); //expireInDays days from now

        try {
            logger.trace("generateDelegate_Helper() creating credential");
            final SfaCredential delegateCredential = delegatedCredential.delegate(
                    targetUrn, targetCert,
                    userPrivateKey,
                    expireDate, privilegeName, canDelegate);

            logger.trace("generateDelegate_Helper() showing result");
            setResult(delegateCredential.getCredentialXml());

            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    guiModel.getEasyModel().getParameterHistoryModel().getUserCredentials().add(new CredentialInfo(delegateCredential));
                }
            });
        } catch (CredentialException e) {
            logger.error("Exception creating speaks for credential", e);
            setResult("ERROR creating speaks for credential: " + e.getMessage());
        }
    }

    public void save() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Credential File");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Credential XML Files", "*.xml"));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("All Files", "*.*"));
        File file = fileChooser.showSaveDialog(this.getScene().getWindow());
        if (file != null) {
            try {
                IOUtils.stringToFile(file, resultText.getText());
            } catch (Exception e) {
                logger.error("Failed to save to file: "+file.getPath(), e);
            }
        }
    }
}
