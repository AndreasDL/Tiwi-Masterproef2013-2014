package be.iminds.ilabt.jfed.ui.javafx.probe_gui.credential_manipulation;

import be.iminds.ilabt.jfed.gui_model.GuiModel;
import be.iminds.ilabt.jfed.highlevel.controller.SingleTask;
import be.iminds.ilabt.jfed.highlevel.controller.Task;
import be.iminds.ilabt.jfed.highlevel.controller.TaskThread;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.ServerType;
import be.iminds.ilabt.jfed.lowlevel.api.ProtogeniSliceAuthority;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnectionPool;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.KeyUtil;
import javafx.application.Platform;
import javafx.scene.layout.BorderPane;
import javafx.util.Pair;
import org.apache.logging.log4j.LogManager;

import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.concurrent.CountDownLatch;

/**
 * CredentialCreatorPanel
 */
public abstract class CredentialCreatorPanel extends BorderPane {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    protected GuiModel guiModel;

    protected CredentialCreatorPanel() {
        super();
    }

    public void setGuiModel(GuiModel guiModel) {
        this.guiModel = guiModel;
    }

    private Map<GeniUrn, X509Certificate> resolvedUserCredentials = new HashMap<GeniUrn, X509Certificate>();

    protected Task resolveUser(final GeniUrn otherUserUrn) {
        final SfaAuthority otherUserAuth = guiModel.getAuthorityList().getFromAnyUrn(otherUserUrn.getValue()).getSfaAuthority();

        Task resolveUserCall = new Task("Resolve User "+otherUserUrn) {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                logger.debug("Resolving target to get certificate");
                SfaConnection con = (SfaConnection) new SfaConnectionPool().getConnectionByAuthority(
                        guiModel.getGeniUserProvider().getLoggedInGeniUser(),    //try to log in as local user. Might not work at all off course if this is different authority
                        otherUserAuth,
                        new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1));
                ProtogeniSliceAuthority sa = new ProtogeniSliceAuthority(guiModel.getLogger());

                AnyCredential userCred = guiModel.getEasyModel().getUserCredential();
                assert userCred != null;
                ProtogeniSliceAuthority.SliceAuthorityReply<Hashtable> reply = sa.resolveUser(con, userCred, otherUserUrn);

                if (!reply.getGeniResponseCode().isSuccess())
                    return ;
                Object gidO = reply.getValue().get("gid");
                if (gidO == null || !(gidO instanceof String))
                    return ;
                String gid = (String) gidO;

                X509Certificate cert = KeyUtil.pemToX509Certificate(gid);
                resolvedUserCredentials.put(otherUserUrn, cert);
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(guiModel.getHighLevelController().getUserCredential());
                return res;
            }
        };
        return resolveUserCall;
    }

    protected Pair<GeniUrn, X509Certificate> getUserInfo(String urnString) throws GeniUrn.GeniUrnParseException, JFedException {
        GeniUrn otherUserUrn = new GeniUrn(urnString);

        X509Certificate cert;
        if (guiModel.getGeniUserProvider().getLoggedInGeniUser().getUserUrnString().equals(otherUserUrn.getValue())) {
            logger.debug("getUserInfo() User is logged in user: all information already known for "+otherUserUrn.getValue());
            cert = guiModel.getGeniUserProvider().getLoggedInGeniUser().getClientCertificateChain().get(0); //TODO handle if not first
        }
        else {
            logger.debug("getUserInfo() Getting needed information using ProtoGeni SA for urn: "+otherUserUrn.getValue());
            //TODO support more than just protogeni slice authority

            if (!resolvedUserCredentials.containsKey(otherUserUrn)) {
                logger.trace("getUserInfo() Fetching user info");
                Task task = resolveUser(otherUserUrn);
                CountDownLatch latch = task.getCompletionCountDownLatch();
                TaskThread.getInstance().addTask(task);
                try {
                    assert !Platform.isFxApplicationThread(); //should not wait on JavaFX thread, will lock up as JavaFXLogger has thread that waits for Platform.runLater to occur!

                    logger.trace("getUserInfo() waiting for task completion");
                    latch.await();
                    logger.trace("getUserInfo() task completion");
                } catch (InterruptedException e) {
                    logger.warn("CountDownLatch InterruptedException", e);
                }

                cert = resolvedUserCredentials.get(otherUserUrn);
            } else
                cert = resolvedUserCredentials.get(otherUserUrn);
        }
        logger.trace("getUserInfo() return");

        return new Pair<GeniUrn, X509Certificate>(otherUserUrn, cert);
    }



    protected String findUrnInCertificate(X509Certificate cert) {
        Collection<List<?>> altNames = null;
        try {
            altNames = cert.getSubjectAlternativeNames();
        } catch (CertificateParsingException e) {
            logger.error("Error processing certificate alternate names: "+e.getMessage());
            return null;
        }

        String userAuth = null;

        logger.trace("certificate has alt names: "+(altNames != null && altNames.isEmpty())+"\n");

        if (altNames != null) {
            String invalidUrnErrors = "";
            boolean hasvalidUrn = false;
            for (List<?> altName : altNames) {
                Integer nameType = (Integer) altName.get(0);
                logger.trace("certificate has altname of type "+nameType+"\n");
                if (nameType == 6) {
                    //uniformResourceIdentifier
                    String urn = (String) altName.get(1);
                    GeniUrn geniUrn = GeniUrn.parse(urn);
                    if (geniUrn == null || !geniUrn.getResourceType().equals("user"))
                        invalidUrnErrors += "Warning: certificate alternative name URI is not a valid user urn: \"" + urn + "\"  (will be ignored)";
                    else {
                        hasvalidUrn = true;
                        userAuth = geniUrn.getTopLevelAuthority();
                        String userName = geniUrn.getResourceName();
                        String userUrn = urn;
                        logger.trace("processed altName of URN type. userUrn="+userUrn+"\n");
                        return userUrn;
                    }
                }
            }
            if (!hasvalidUrn && !invalidUrnErrors.isEmpty()) {
                logger.warn(invalidUrnErrors);
            }
        }

        logger.warn("no urn found in certificate: "+cert);
        setResult("ERROR: no urn found in certificate: "+cert);
        return null;
    }

    protected abstract void setResult(final String text);
    protected X509Certificate certificateRetriever(String targetUrn) {
        logger.trace("certificateRetriever() getting target info for urn "+targetUrn);
        Pair<GeniUrn, X509Certificate> targetInfo = null;
        try {
            targetInfo = getUserInfo(targetUrn);
            if (targetInfo == null || targetInfo.getValue() == null) {
                setResult("ERROR getting certificate for urn: " + targetUrn);
                return null;
            }
            return targetInfo.getValue();
        } catch (GeniUrn.GeniUrnParseException e) {
            logger.error("ERROR urn is invalid: "+ targetUrn, e);
            setResult("ERROR urn is invalid: " + targetUrn);
            return null;
        } catch (JFedException e) {
            logger.error("Error in call retrieving info for urn: "+ targetUrn, e);
            setResult("Error in call retrieving info for urn: " + targetUrn);
            return null;
        }
    }
}
