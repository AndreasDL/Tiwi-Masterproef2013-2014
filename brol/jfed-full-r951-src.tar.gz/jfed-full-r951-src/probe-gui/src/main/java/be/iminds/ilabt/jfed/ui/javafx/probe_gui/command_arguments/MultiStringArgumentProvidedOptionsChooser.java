package be.iminds.ilabt.jfed.ui.javafx.probe_gui.command_arguments;

import be.iminds.ilabt.jfed.highlevel.model.CredentialInfo;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.util.Callback;
import javafx.util.Pair;
import javafx.util.StringConverter;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

/**
 * StringArgumentChooser
 */
public class MultiStringArgumentProvidedOptionsChooser extends CommandArgumentChooser<List<String>> {
    @FXML protected ListView<SelectableMutableString> valueField;
    @FXML protected TextField addTextField;

    //
    //
    // Important note: There are multiple *options* shown, *valueProperty* contains only the SELECTED options.
    //
    //

    protected ObservableList<SelectableMutableString> selectableOptions = FXCollections.observableArrayList();
    private ObservableList<SelectableMutableString> selectedOptionsList = FXCollections.observableArrayList();
    private ObjectProperty<List<String>> valueProperty = new SimpleObjectProperty<List<String>>();

    private class SelectableMutableString {
        private BooleanProperty selected;
        private final String text;

        private SelectableMutableString(String text, boolean selected) {
            this.text = text;
            this.selected = new SimpleBooleanProperty(selected);
            this.selected.addListener(new ChangeListener<Boolean>() {
                @Override
                public void changed(ObservableValue<? extends Boolean> observableValue, Boolean oldValue, Boolean newValue) {
                    if (selectedOptionsList != null) {
                        if (!newValue)
                            selectedOptionsList.removeAll(SelectableMutableString.this);
                        else {
                            assert !selectedOptionsList.contains(SelectableMutableString.this);
                            selectedOptionsList.add(SelectableMutableString.this);
                        }
                    }
                }
            });
            if (selected)
                selectedOptionsList.add(this);
        }

        public boolean getSelected() {
            return selected.get();
        }

        public BooleanProperty selectedProperty() {
            return selected;
        }

        public String getText() {
            return text;
        }
    }

    public MultiStringArgumentProvidedOptionsChooser(List<String> options) {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("MultiStringArgumentProvidedOptionsChooser.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();

            assert valueField != null;

            valueField.setCellFactory(new Callback<ListView<SelectableMutableString>,
                    ListCell<SelectableMutableString>>() {
                @Override
                public ListCell<SelectableMutableString> call(ListView<SelectableMutableString> list) {
                    CheckBoxListCell<SelectableMutableString> cb = new CheckBoxListCell<SelectableMutableString>();
                    cb.setConverter(new StringConverter<SelectableMutableString>() {
                        @Override
                        public String toString(SelectableMutableString selectableMutableString) {
                            return selectableMutableString.getText();
                        }

                        @Override
                        public SelectableMutableString fromString(String s) {
                            throw new RuntimeException("This direction doesn't work and is not needed");
                        }
                    });
                    cb.setSelectedStateCallback(new Callback<SelectableMutableString, ObservableValue<Boolean>>() {
                        @Override
                        public ObservableValue<Boolean> call(SelectableMutableString selectableMutableString) {
                            return selectableMutableString.selectedProperty();
                        }
                    });
                    return cb;
//                    return new SelectableItemCell();
                }
            }
            );

            setAllOptions(options);

            valueField.setItems(this.selectableOptions);
//            valueField.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

            if (!valueField.getItems().isEmpty())
                valueField.getSelectionModel().selectLast();


            selectedOptionsList.addListener(new ListChangeListener<SelectableMutableString>() {
                @Override
                public void onChanged(Change<? extends SelectableMutableString> change) {
                    //not the best way to link this, but I want to keep "value" in CommandArgumentChooser the type it is: ObjectProperty<List<String>>
                    valueProperty.set(new ArrayList<String>(getSelectedStrings()));
                }
            });
            //init
            valueProperty.set(new ArrayList<String>(getSelectedStrings()));
            value = valueProperty;
            assert value != null;
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    private List<String> getSelectedStrings() {
        List<String> selectedItemsStr = new ArrayList<>();
        for (SelectableMutableString sms : selectedOptionsList) {
            selectedItemsStr.add(sms.getText());
        }
        return selectedItemsStr;
    }

    protected void setAllOptions(List<String> options) {
        selectableOptions.clear();
        selectedOptionsList.clear();
        for (String option : options) {
            SelectableMutableString selMutStr = new SelectableMutableString(option, false);
            selectableOptions.add(selMutStr);
        }
        selectedOptionsList.clear();
    }


    public void add() {
        SelectableMutableString toAdd = new SelectableMutableString(addTextField.getText(), true);
        selectableOptions.add(toAdd);
    }



//    static class SelectableItemCell extends ListCell<Pair<Boolean, String>> {
//        private CheckBox checkbox;
//
//        public SelectableItemCell() {
//            checkbox = new CheckBox();
//            checkbox.setOnAction(new EventHandler<ActionEvent>() {
//                @Override
//                public void handle(ActionEvent actionEvent) {
//                    SelectableItemCell.this.commitEdit(new Pair<Boolean, String>(checkbox.isSelected(), checkbox.getText()));
//                }
//            });
//        }
//
//        @Override
//        public void updateItem(Pair<Boolean, String> item, boolean empty) {
//            super.updateItem(item, empty);
//            if (item != null) {
//                checkbox.setSelected(item.getKey());
//                checkbox.setText(item.getValue());
//                setGraphic(checkbox);
//            } else {
//                checkbox.setText("");
//                checkbox.setSelected(false);
//            }
//        }
//    }
}
