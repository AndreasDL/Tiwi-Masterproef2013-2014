package be.iminds.ilabt.jfed.ui.javafx.probe_gui.dialog;

import be.iminds.ilabt.jfed.highlevel.model.CredentialInfo;
import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.CredentialException;
import be.iminds.ilabt.jfed.ui.javafx.util.JavaFXDialogUtil;
import be.iminds.ilabt.jfed.util.IOUtils;
import javafx.application.Platform;
import javafx.beans.property.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.apache.logging.log4j.LogManager;

import java.io.File;
import java.io.IOException;

/**
 * CredentialEditDialog
 */
public class CredentialEditDialog {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    public static CredentialInfo showAddDialog() {
        return showDialog(true, null);
    }
    public static CredentialInfo showDialog(final boolean add, final CredentialInfo credentialInfo) {
        assert add || credentialInfo != null;

        final Stage dialog = new Stage();
        dialog.initStyle(StageStyle.UTILITY);
        //        dialog.initModality(Modality.WINDOW_MODAL);
        dialog.initModality(Modality.APPLICATION_MODAL);


        final ObjectProperty<CredentialInfo> resultProp = new SimpleObjectProperty(null);

        VBox box = new VBox();
        HBox box2 = new HBox();
        HBox.setHgrow(box2, Priority.ALWAYS);
//        box.setAlignment(Pos.CENTER);
        box2.setAlignment(Pos.CENTER);
        Button butOk = new Button("Use this Credential");
        Button butCancel = new Button(add ? "Do not add" : "Cancel Edit");
        Button butLoad = new Button("Load from file...");

        Label internalNameLabel = new Label("Internal Name:");
        final TextField internalNameField = new TextField(credentialInfo == null ? "User Imported Credential" : credentialInfo.getCredential().getName());

        Label credentialTypeLabel = new Label("Type:");
        final TextField credentialTypeField = new TextField(credentialInfo == null ? "geni_sfa" : credentialInfo.getCredential().getType());

        Label credentialVersionLabel = new Label("Version:");
        final TextField credentialVersionField = new TextField(credentialInfo == null ? "3" : credentialInfo.getCredential().getVersion());

        Label valueLabel = new Label("Xml value:");
        final TextArea valueArea = new TextArea(credentialInfo == null ? "" : credentialInfo.getCredential().getCredentialXml());
        valueArea.setEditable(true);
        VBox.setVgrow(valueArea, Priority.ALWAYS);
//        box2.getChildren().add(butLoad);
        box2.getChildren().addAll(butOk, butCancel);
        box.getChildren().addAll(internalNameLabel, internalNameField, credentialTypeLabel, credentialTypeField,
                credentialVersionLabel, credentialVersionField, valueLabel, butLoad, valueArea, box2);

        JavaFXDialogUtil.addDialogStyle(box);
        Scene scene = new Scene(box);
        dialog.setScene(scene);
        dialog.sizeToScene();

        butOk.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
//                String newName = "User Imported Credential";
//                    if (!add && credentialInfo != null) {
//                        newName = credentialInfo.getCredential().getName();
//                        if (!newName.endsWith(" (Edited)"))
//                            newName += " (Edited)";
//                    }
                String newName = internalNameField.getText();
                AnyCredential resGeniCredential = null;
                try {
                    resGeniCredential = AnyCredential.create(newName, valueArea.getText(), credentialTypeField.getText(), credentialVersionField.getText());
                    CredentialInfo resCredentialInfo = new CredentialInfo(resGeniCredential);
                    resultProp.set(resCredentialInfo);
                } catch (CredentialException e) {
                    resultProp.set(null);
                    logger.error("Error creating credential: "+e.getMessage(), e);
                }
                dialog.close();
            }
        });
        butCancel.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                resultProp.set(null);
                dialog.close();
            }
        });
        butLoad.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Open Credential File");
                fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Credential XML Files", "*.xml"));
                fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("All Files", "*.*"));
                File file = fileChooser.showOpenDialog(dialog);
                if (file != null) {
                    final String content;
                    try {
                        content = IOUtils.fileToString(file);
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                valueArea.setText(content);
                            }
                        });
                    } catch (IOException e) {
                        logger.error("Failed to open file: "+file.getPath(), e);
                    }
                }
            }
        });

        dialog.showAndWait();

        return resultProp.get();
    }
}
