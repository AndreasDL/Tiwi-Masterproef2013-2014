package be.iminds.ilabt.jfed.ui.javafx.probe_gui.command_arguments;

import be.iminds.ilabt.jfed.lowlevel.api.AbstractFederationApi2;
import javafx.collections.FXCollections;

import java.util.List;
import java.util.Map;

/**
 * ChApi2FieldsArgumentChooser
 */
public class ChApi2FieldsArgumentChooser extends MapStringToStringArgumentChooser implements ChApiTypeDependantArgumentChooser {
    private AbstractFederationApi2 api;
       private String objectName;

       public ChApi2FieldsArgumentChooser(AbstractFederationApi2 api, String objectName) {
           super(api.getMinimumFieldsMap(objectName), "Field", "Value");
           this.api = api;
           this.objectName = objectName;
       }

       @Override
       public void setObjectType(String newObjectName) {
           if (newObjectName == null || objectName.equals(newObjectName))
               return;

           this.objectName = newObjectName;

           Map<String, String> newFieldsMap = api.getMinimumFieldsMap(objectName);

           argument.clear();
           if (newFieldsMap != null)
               for (Map.Entry<String, String> e : newFieldsMap.entrySet())
                   argument.add(new MyEntry(e.getKey(), e.getValue()));
//           table.setItems(this.argument);
       }
}
