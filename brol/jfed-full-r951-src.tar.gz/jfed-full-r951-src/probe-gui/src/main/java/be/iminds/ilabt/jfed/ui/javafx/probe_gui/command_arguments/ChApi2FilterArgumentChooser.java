package be.iminds.ilabt.jfed.ui.javafx.probe_gui.command_arguments;

import be.iminds.ilabt.jfed.lowlevel.api.AbstractFederationApi1;
import be.iminds.ilabt.jfed.lowlevel.api.AbstractFederationApi2;
import be.iminds.ilabt.jfed.ui.javafx.probe_gui.ProbeController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;
import java.util.List;

/**
 * ChApi2FilterArgumentChooser
 */
public class ChApi2FilterArgumentChooser extends MultiStringArgumentProvidedOptionsChooser implements ChApiTypeDependantArgumentChooser {
    private AbstractFederationApi2 api;
    private String objectName;

    public ChApi2FilterArgumentChooser(AbstractFederationApi2 api, String objectName) {
        super(FXCollections.observableArrayList(api.getMinimumFieldNames(objectName)));
        this.api = api;
        this.objectName = objectName;
    }

    @Override
    public void setObjectType(String newObjectName) {
        if (newObjectName == null || objectName.equals(newObjectName))
            return;

        this.objectName = newObjectName;

        List<String> newOptions = api.getMinimumFieldNames(objectName);
        setAllOptions(newOptions);
    }
}
