package be.iminds.ilabt.jfed.ui.javafx.probe_gui.command_arguments;

import be.iminds.ilabt.jfed.gui_model.GuiModel;
import be.iminds.ilabt.jfed.highlevel.model.AuthorityInfo;

import be.iminds.ilabt.jfed.lowlevel.ApiMethodParameter;
import be.iminds.ilabt.jfed.lowlevel.ApiMethodParameterType;
import be.iminds.ilabt.jfed.lowlevel.api.AbstractFederationApi1;
import be.iminds.ilabt.jfed.lowlevel.api.AbstractFederationApi2;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.resourceid.ResourceId;
import be.iminds.ilabt.jfed.lowlevel.resourceid.ResourceUrn;
import be.iminds.ilabt.jfed.ui.javafx.probe_gui.ProbeController;
import be.iminds.ilabt.jfed.util.RFC3339Util;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.layout.VBox;
import org.apache.logging.log4j.LogManager;

import java.util.*;

/**
 * CommandArgumentChooser
 */
public abstract class CommandArgumentChooser<T> extends VBox {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    protected ReadOnlyProperty<T> value;
    public ReadOnlyProperty<T> valueProperty() {
        return value;
    }

    public enum CredentialSubject { USER, SLICE, ANY }

    public CommandArgumentChooser() {
        setMaxWidth(10000.0);
    }

    public static ApiMethodParameterType deriveType(String parameterName, Class parameterClass, ApiMethodParameter annotation,
                                                    ProbeController.MethodInfo methodInfo) {
        if (annotation.name().equals("credentialList"))
            return ApiMethodParameterType.LIST_OF_CREDENTIAL;

        if (annotation.name().equals("slice") || annotation.name().equals("sliceUrn"))
            return ApiMethodParameterType.SLICE_URN;

        if (annotation.name().equals("urns"))
            return ApiMethodParameterType.LIST_OF_URN_STRING;


        if (annotation.name().equals("userCredential"))
            return ApiMethodParameterType.USER_CREDENTIAL_STRING;

        if (annotation.name().equals("credential"))
            return ApiMethodParameterType.CREDENTIAL_STRING;

        if (annotation.name().equals("sliceCredential"))
            return ApiMethodParameterType.SLICE_CREDENTIAL_STRING;

        if (annotation.name().equals("clearingHouseCredential"))
            return ApiMethodParameterType.CREDENTIAL_STRING;

        if (annotation.name().equals("UserSpecList") || annotation.name().equals("users"))
            return ApiMethodParameterType.LIST_OF_USERSPEC;


        if (annotation.name().equals("user") || annotation.name().equals("userUrn"))
            return ApiMethodParameterType.USER_URN;

        if (annotation.name().equals("rspec"))
            return ApiMethodParameterType.RSPEC_STRING;

        if (parameterClass.equals(ResourceId.class))
            return ApiMethodParameterType.URN;

        if (parameterClass.equals(ResourceUrn.class))
            return ApiMethodParameterType.URN;

        if (parameterClass.equals(String.class))
            if (annotation.multiLineString())
                return ApiMethodParameterType.STRING_MULTILINE;
            else
                return ApiMethodParameterType.STRING;

        if (parameterClass.equals(Boolean.class))
            return ApiMethodParameterType.BOOLEAN;

        if (parameterClass.equals(Integer.class))
            return ApiMethodParameterType.INTEGER;

        return ApiMethodParameterType.NOT_SPECIFIED;
    }

    @SuppressWarnings("unchecked")
    public static <T> CommandArgumentChooser<T> getCommandArgumentChooser(
            String parameterName,
            Class<T> parameterClass,
            ApiMethodParameter annotation,
            GuiModel guiModel,
            ProbeController.MethodInfo methodInfo,
            final ObservableList<CommandArgumentChooser> otherCommandArgumentChoosers) {
        AuthorityInfo userAuth = null;
        if (guiModel.getGeniUserProvider().isUserLoggedIn()) {
            SfaAuthority sfaAuth = guiModel.getGeniUserProvider().getLoggedInGeniUser().getUserAuthority();
            userAuth = guiModel.getAuthorityList().get(sfaAuth);
        }

        ApiMethodParameterType paramType = ApiMethodParameterType.NOT_SPECIFIED;

        paramType = annotation.parameterType();

        if (paramType == ApiMethodParameterType.NOT_SPECIFIED)
            paramType = deriveType(parameterName, parameterClass, annotation, methodInfo);

        switch (paramType) {
            case STRING: { return (CommandArgumentChooser<T>) new StringArgumentChooser(annotation.guiDefault().equals("") ? null : annotation.guiDefault()); }
            case STRING_MULTILINE: { return (CommandArgumentChooser<T>) new MultiLineStringArgumentChooser(annotation.guiDefault().equals("") ? null : annotation.guiDefault(), false); }
            case INTEGER: {
                Integer defaultValue = null;
                if (!annotation.guiDefault().equals(""))
                    defaultValue = Integer.parseInt(annotation.guiDefault());
                return (CommandArgumentChooser<T>) new IntegerArgumentChooser(defaultValue);
            }
            case BOOLEAN: {
                Boolean defaultValue = null;
                if (!annotation.guiDefault().equals("")) {
                    defaultValue = false;
                    if (annotation.guiDefault().equalsIgnoreCase("true"))
                        defaultValue = true;
                    if (annotation.guiDefault().equalsIgnoreCase("yes"))
                        defaultValue = true;
                    if (annotation.guiDefault().equalsIgnoreCase("1"))
                        defaultValue = true;
                }
                return (CommandArgumentChooser<T>) new BooleanArgumentChooser(defaultValue);
            }
            case CREDENTIAL_STRING: { return (CommandArgumentChooser<T>) new CredentialArgumentChooser(guiModel, CredentialSubject.ANY); }
            case USER_CREDENTIAL_STRING: { return (CommandArgumentChooser<T>) new CredentialArgumentChooser(guiModel, CredentialSubject.USER); }
            case SLICE_CREDENTIAL_STRING: { return (CommandArgumentChooser<T>) new CredentialArgumentChooser(guiModel, CredentialSubject.SLICE); }
            case URN: {  return (CommandArgumentChooser<T>) new StringArgumentProvidedOptionsChooser(guiModel.getEasyModel().getParameterHistoryModel().getAllUrnList()); }
            case SLICE_URN: { return (CommandArgumentChooser<T>) new UrnArgumentProvidedOptionsChooser(guiModel.getEasyModel().getParameterHistoryModel().getSliceUrnsList(), "slice", userAuth); }
            case USER_URN: { return (CommandArgumentChooser<T>) new UrnArgumentProvidedOptionsChooser(guiModel.getEasyModel().getParameterHistoryModel().getUserUrnsList(), "user", userAuth); }
            case RSPEC_STRING: {
                String defaultRspec = "<rspec type=\"request\" generated=\"2013-01-16T14:20:39Z\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
                        "  <node client_id=\"PC\" component_manager_id=\"urn:publicid:IDN+"+
                        (guiModel.getGeniUserProvider().isUserLoggedIn() ? guiModel.getGeniUserProvider().getLoggedInGeniUser().getUserAuthority().getNameForUrn() : "<AM>")+
                        "+authority+cm\" exclusive=\"true\">\n" +
                        "    <sliver_type name=\"raw-pc\"/>\n" +
                        "  </node>\n" +
                        "</rspec>\n";
                return (CommandArgumentChooser<T>) new MultiLineStringArgumentChooser(annotation.guiDefault().equals("") ? defaultRspec : annotation.guiDefault(), true);
            }
            case LIST_OF_CREDENTIAL: { return (CommandArgumentChooser<T>) new MultiCredentialArgumentChooser(guiModel, CredentialSubject.ANY); }
            case LIST_OF_URN_STRING: { return (CommandArgumentChooser<T>) new MultiStringArgumentProvidedOptionsChooser(guiModel.getEasyModel().getParameterHistoryModel().getAllUrnList()); }
            case LIST_OF_USERSPEC: { return (CommandArgumentChooser<T>) new UserSpecListArgumentChooser(guiModel); }
            case LIST_OF_STRING: { return (CommandArgumentChooser<T>) new MultiStringArgumentProvidedOptionsChooser(FXCollections.<String>observableArrayList()); }
            case LIST_OF_SLICE_URN_STRING: { return (CommandArgumentChooser<T>) new MultiStringArgumentProvidedOptionsChooser(guiModel.getEasyModel().getParameterHistoryModel().getSliceUrnsList()); }
            case LIST_OF_USER_URN_STRING: { return (CommandArgumentChooser<T>) new MultiStringArgumentProvidedOptionsChooser(guiModel.getEasyModel().getParameterHistoryModel().getUserUrnsList());  }

            //TODO: smart selection of specific API fields
            //TODO: if GetVersion reply cached, use all fields from it
            case CH_API1_FILTER: { return (CommandArgumentChooser<T>)
                    new MultiStringArgumentProvidedOptionsChooser(FXCollections.observableArrayList(getChApiFields1(methodInfo))); }
            case CH_API1_MATCH: { return (CommandArgumentChooser<T>)
                    new ChApi1MatchArgumentChooser(getChApiFieldsMap1(methodInfo)); } //TODO: allow multiple values per field! And make a more convenient GUI for searching using this.
            case CH_API1_FIELDS: { return (CommandArgumentChooser<T>)
                    new MapStringToStringArgumentChooser(getChApiFieldsMap1(methodInfo), "Field", "Value"); }


            //TODO: implement these for APIv2  (they need a selector for object TYPE, in addition to what they had in v1.
            //                                  Or even better, this selector should be linked to the type parameter for the same method!)
            case CH_API2_OBJECT_TYPE: {
                List<String> objectNames = getChApi2Objects(methodInfo);
                StringArgumentProvidedOptionsChooser res =
                        new StringArgumentProvidedOptionsChooser(FXCollections.observableArrayList(objectNames), getChApi2DefaultObject(methodInfo), false/*limitToOptions*/);

                res.valueProperty().addListener(new ChangeListener<String>() {
                    @Override
                    public void changed(ObservableValue<? extends String> observableValue, String from, String to) {
                        if (to != null) {
                            for (CommandArgumentChooser commandArgumentChooser : otherCommandArgumentChoosers) {
                                if (ChApiTypeDependantArgumentChooser.class.isAssignableFrom(commandArgumentChooser.getClass())) {
                                    ((ChApiTypeDependantArgumentChooser) commandArgumentChooser).setObjectType(to);
                                }
                            }
                        }
                    }
                });

                return (CommandArgumentChooser<T>) res;
            }
            case CH_API2_FILTER: {
                return (CommandArgumentChooser<T>)
                    new ChApi2FilterArgumentChooser(getChApi2(methodInfo), getChApi2ConvenientOrDefaultObject(methodInfo));
            }
            case CH_API2_MATCH: {
                return (CommandArgumentChooser<T>)
                    new ChApi2MatchArgumentChooser(getChApi2(methodInfo), getChApi2ConvenientOrDefaultObject(methodInfo));
            }

            case CH_API2_FIELDS: {
                return (CommandArgumentChooser<T>)
                    new ChApi2FieldsArgumentChooser(getChApi2(methodInfo), getChApi2ConvenientOrDefaultObject(methodInfo));
            }


            case LIST_OF_URN: { return (CommandArgumentChooser<T>) new MultiUrnArgumentProvidedOptionsChooser(guiModel.getEasyModel().getParameterHistoryModel().getAllUrnList()); }
            case LIST_OF_SLICE_URN: { return (CommandArgumentChooser<T>) new MultiUrnArgumentProvidedOptionsChooser(guiModel.getEasyModel().getParameterHistoryModel().getSliceUrnsList()); }
            case LIST_OF_USER_URN: { return (CommandArgumentChooser<T>) new MultiUrnArgumentProvidedOptionsChooser(guiModel.getEasyModel().getParameterHistoryModel().getUserUrnsList()); }


            case GENI_EXTRA_OPTIONS: { return (CommandArgumentChooser<T>) new MapStringToStringArgumentChooser(new HashMap<String, String>()); }

            case CH_API_LIST_MEMBER_TUPLES: { return (CommandArgumentChooser<T>) new ChApiMemberArgumentChooser(null/* todo cached members*/); }

            case MAP_OF_STRING_TO_STRING: { return (CommandArgumentChooser<T>) new MapStringToStringArgumentChooser(new HashMap<String, String>()); }
            case MAP_OF_STRING_TO_OBJECT: { return new UnsupportedArgumentChooser<T>(parameterClass); }

            case DATE: { return new UnsupportedArgumentChooser<T>(parameterClass); }
            case STRING_DATE_RFC3339: { return (CommandArgumentChooser<T>) new StringArgumentChooser(RFC3339Util.dateToRFC3339String(new Date(), true, true, true)); } //TODO support with date picker
            case URL: { return (CommandArgumentChooser<T>) new StringArgumentChooser(annotation.guiDefault().equals("") ? "http://example.com" : annotation.guiDefault()); }
            case EMAIL: { return (CommandArgumentChooser<T>) new StringArgumentChooser(annotation.guiDefault().equals("") ? "example@example.com" : annotation.guiDefault()); }

            case NOT_SPECIFIED:
            default: { return new UnsupportedArgumentChooser<T>(parameterClass); }
        }
    }

    public static Map<String, String> getChApiFieldsMap1(ProbeController.MethodInfo methodInfo) {
        if (methodInfo.api instanceof AbstractFederationApi1) {
            AbstractFederationApi1 gch = (AbstractFederationApi1) methodInfo.api;
            String objectName = gch.getMethodObject(methodInfo.method);
            if (objectName == null) {
                System.err.println("Tiny bug: method \""+methodInfo.name+"\" not registered as object CRUD method.");
                return new HashMap<>();
            }
            return gch.getMinimumFieldsMap(objectName);
        }
        return null;
    }

    public static List<String> getChApiFields1(ProbeController.MethodInfo methodInfo) {
        if (methodInfo.api instanceof AbstractFederationApi1) {
            AbstractFederationApi1 gch = (AbstractFederationApi1) methodInfo.api;
            String objectName = gch.getMethodObject(methodInfo.method);
            if (objectName == null) {
                System.err.println("Tiny bug: method \""+methodInfo.name+"\" not registered as object CRUD method.");
                return new ArrayList<>();
            }
            return gch.getMinimumFieldNames(objectName);
        }
        return null;
    }

    public static String getChApi2DefaultObject(ProbeController.MethodInfo methodInfo) {
        if (methodInfo.api instanceof AbstractFederationApi2) {
            AbstractFederationApi2 api = (AbstractFederationApi2) methodInfo.api;
            List<String> objs = api.getApiObjects();
            assert objs != null;
            assert !objs.contains(null) : "api.getApiObjects() may not contain null: "+objs;
            assert objs.get(0) != null : "api.getApiObjects() may not contain null: "+objs;
            List<String> reqs = api.getRequiredApiServices();
            objs.retainAll(reqs);
            if (objs.size() > 0) {
                assert objs.get(0) != null : "objs may not contain null: "+objs;
                return objs.get(0);
            }
            return api.getApiObjects().get(0);
        }
        return null;
    }

    public static String getChApi2ConvenientOrDefaultObject(ProbeController.MethodInfo methodInfo) {
        if (!methodInfo.annotation.convenienceMethodFor().isEmpty() &&
            !methodInfo.annotation.convenienceMethodObjectType().isEmpty())
            return methodInfo.annotation.convenienceMethodObjectType();

        return getChApi2DefaultObject(methodInfo);
    }

    public static AbstractFederationApi2 getChApi2(ProbeController.MethodInfo methodInfo) {
        if (methodInfo.api instanceof AbstractFederationApi2) {
            AbstractFederationApi2 api = (AbstractFederationApi2) methodInfo.api;
            return api;
        }
        return null;
    }

    public static List<String> getChApi2Objects(ProbeController.MethodInfo methodInfo) {
        if (methodInfo.api instanceof AbstractFederationApi2) {
            AbstractFederationApi2 fedapi = (AbstractFederationApi2) methodInfo.api;
            return fedapi.getApiObjects();
        }
        return null;
    }
}
