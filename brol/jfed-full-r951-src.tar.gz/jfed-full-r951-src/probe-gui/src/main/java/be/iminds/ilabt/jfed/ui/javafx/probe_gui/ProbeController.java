package be.iminds.ilabt.jfed.ui.javafx.probe_gui;

import be.iminds.ilabt.jfed.gui_model.GuiModel;
import be.iminds.ilabt.jfed.highlevel.controller.SingleTask;
import be.iminds.ilabt.jfed.highlevel.controller.Task;
import be.iminds.ilabt.jfed.highlevel.controller.TaskThread;
import be.iminds.ilabt.jfed.highlevel.model.AuthorityInfo;
import be.iminds.ilabt.jfed.highlevel.model.CredentialInfo;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api.*;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.*;
import be.iminds.ilabt.jfed.lowlevel.resourceid.ResourceId;
import be.iminds.ilabt.jfed.lowlevel.resourceid.ResourceIdParser;
import be.iminds.ilabt.jfed.lowlevel.resourceid.ResourceUrn;
import be.iminds.ilabt.jfed.lowlevel.stitching.VlanRangeHelper;
import be.iminds.ilabt.jfed.ssh_terminal_tool.ssh_key_info.UserSshKeyInfo;
import be.iminds.ilabt.jfed.ui.javafx.choosers.AuthorityChooser;
import be.iminds.ilabt.jfed.ui.javafx.log_gui.LogHistoryPanel;
import be.iminds.ilabt.jfed.ui.javafx.probe_gui.command_arguments.CommandArgumentChooser;
import be.iminds.ilabt.jfed.ui.javafx.probe_gui.credential_manipulation.DelegatedCredentialCreatorPanel;
import be.iminds.ilabt.jfed.ui.javafx.probe_gui.credential_manipulation.SpeaksForCredentialCreatorPanel;
import be.iminds.ilabt.jfed.ui.javafx.util.ExpandableHelp;
import be.iminds.ilabt.jfed.ui.javafx.util.JavaFXDialogUtil;
import be.iminds.ilabt.jfed.util.*;
import javafx.beans.binding.Binding;
import javafx.beans.binding.ListBinding;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.apache.logging.log4j.LogManager;

import javax.script.Bindings;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.net.URL;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.List;

/**
 * ProbeController
 */
public class ProbeController implements Initializable {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    private GuiModel guiModel;

    @FXML private LogHistoryPanel logPanel;

    @FXML private TreeView apiAndMethodTreeView;

    @FXML private VBox commandConfigurationBox; //Box containing server selection, call button and argumentGrid

    @FXML private VBox speaksForCredentialCreatorBox;
    @FXML private VBox delegatedCredentialCreatorBox;

    @FXML private SpeaksForCredentialCreatorPanel speaksForCredentialCreatorPanel;
    @FXML private DelegatedCredentialCreatorPanel delegatedCredentialCreatorPanel;

    @FXML private Button callButton;


    //////////////////////////////// selection of URL ///////////////////////////////////
    @FXML private RadioButton useUserRadioButton;
    @FXML private RadioButton userAuthorityRadioButton;
    @FXML private RadioButton userCustomServerRadioButton;

    @FXML private CheckBox useSshProxyCheckBox;

    @FXML private HBox userAuthChoiceBox;
    @FXML private AuthorityChooser authChooser;

    @FXML private Label loggedInUserLabel;

    @FXML private HBox fixedServerURLBox;
    @FXML private VBox editableServerURLBox;

    @FXML private TextField serverUrlField;

    @FXML private TextField customServerUrlField;
    @FXML private CheckBox ignoreSelfSignedCheckBox;
    @FXML private Label ignoreSelfSignedCheckLabel;
    /////////////////////////////////////////////////////////////////////////////////////

    @FXML private VBox commandNameBox;
    @FXML private Label commandNameLabel;
    @FXML private ExpandableHelp commandHelp;


    @FXML private ScrollPane argumentScrollPane;
    @FXML private GridPane argumentGrid;
    private final ObservableList<CommandParameterController> argumentControllers = FXCollections.observableArrayList();
    private final ObservableList<CommandParameterModel> argumentModels = FXCollections.observableArrayList();


    private final ObservableList<AbstractApi> apis = FXCollections.observableArrayList();
    final ObservableList<MethodInfo> methods = FXCollections.observableArrayList();

    @FXML private VBox includeHeader;
    @FXML private VBox nameHeader;
    @FXML private VBox valueHeader;

    public ProbeController() {
    }

    public GuiModel getGuiModel() { return guiModel; }

    public void setGuiModel(GuiModel guiModel) {
        assert this.guiModel == null;
        this.guiModel = guiModel;
        /*JavaFX*/Logger logger = guiModel.getLogger();

        apis.add(new ProtogeniSliceAuthority(logger));
        apis.add(new PlanetlabSfaRegistryInterface(logger));
        apis.add(new AggregateManager2(logger));
        apis.add(new AggregateManager3(logger));
        apis.add(new ProtoGeniClearingHouse1(logger));

        apis.add(new StitchingComputationService(logger));

        apis.add(new FederationRegistryApi1(logger));
        apis.add(new FederationMemberAuthorityApi1(logger));
        apis.add(new FederationSliceAuthorityApi1(logger));

        apis.add(new FederationRegistryApi2(logger));
        apis.add(new FederationMemberAuthorityApi2(logger));
        apis.add(new FederationSliceAuthorityApi2(logger));

        apis.add(new OCCI(logger));

        if (logPanel != null && (apiAndMethodTreeView != null))
            doAllInit();
    }

    public void updateServerUrlChoiceOnApiChange(AbstractApi newSelectedAbstractApi) {
        boolean isSA = newSelectedAbstractApi == null ? false : newSelectedAbstractApi.getServerType().getRole().equals(ServerType.GeniServerRole.PROTOGENI_SA);

        if (true) {
            if (guiModel.getGeniUserProvider().isUserLoggedIn()) {
                loggedInUserLabel.setText("User "+guiModel.getGeniUserProvider().getLoggedInGeniUser().getUserUrnString()+"");
                boolean wasInvisible = !useUserRadioButton.isVisible();
                useUserRadioButton.setVisible(true);
                if (wasInvisible && isSA)
                    useUserRadioButton.setSelected(true);
            }
            else {
                useUserRadioButton.setVisible(false);
                //loggedInUserLabel will not be visible now, we update text anyway
                loggedInUserLabel.setText("No User logged in.");
            }
        }
        else {
            useUserRadioButton.setVisible(false);
            //loggedInUserLabel will not be visible now, we update text anyway
            loggedInUserLabel.setText("Not using user's auth server URL");
        }

        updateFixedServerUrlField(newSelectedAbstractApi);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        assert logPanel != null;
        assert apiAndMethodTreeView != null;
        assert useUserRadioButton != null;

        //if any of these is set invisible, remove them from layout as well
        useUserRadioButton.managedProperty().bind(useUserRadioButton.visibleProperty());
        userAuthChoiceBox.managedProperty().bind(userAuthChoiceBox.visibleProperty());
        fixedServerURLBox.managedProperty().bind(fixedServerURLBox.visibleProperty());
        editableServerURLBox.managedProperty().bind(editableServerURLBox.visibleProperty());
        ignoreSelfSignedCheckLabel.managedProperty().bind(ignoreSelfSignedCheckLabel.visibleProperty());
        loggedInUserLabel.managedProperty().bind(loggedInUserLabel.visibleProperty());

        commandConfigurationBox.managedProperty().bind(commandConfigurationBox.visibleProperty());
        speaksForCredentialCreatorBox.managedProperty().bind(speaksForCredentialCreatorBox.visibleProperty());
        speaksForCredentialCreatorBox.setVisible(false);
        delegatedCredentialCreatorBox.managedProperty().bind(delegatedCredentialCreatorBox.visibleProperty());
        delegatedCredentialCreatorBox.setVisible(false);

        //bind radiobuttons to visible regions
        userAuthChoiceBox.visibleProperty().bind(userAuthorityRadioButton.selectedProperty().or(useUserRadioButton.selectedProperty()));
        fixedServerURLBox.visibleProperty().bind(userAuthorityRadioButton.selectedProperty().or(useUserRadioButton.selectedProperty()));
        editableServerURLBox.visibleProperty().bind(userCustomServerRadioButton.selectedProperty());

        //bind other logical connections
        loggedInUserLabel.visibleProperty().bind(useUserRadioButton.selectedProperty());
        authChooser.editableProperty().bind(userAuthorityRadioButton.selectedProperty());
        ignoreSelfSignedCheckLabel.visibleProperty().bind(ignoreSelfSignedCheckBox.selectedProperty());
        useUserRadioButton.visibleProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean oldIsVisible, Boolean newIsVisible) {
                if (!newIsVisible && useUserRadioButton.isSelected())
                    userAuthorityRadioButton.selectedProperty().set(true);
            }
        });

        //set label min max and preferred size so it fills grid
        includeHeader.setMinWidth(includeHeader.getMaxWidth());
        includeHeader.setPrefWidth(includeHeader.getMaxWidth());
        includeHeader.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

        nameHeader.setMinWidth(nameHeader.getMaxWidth());
        nameHeader.setPrefWidth(nameHeader.getMaxWidth());
        nameHeader.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

        valueHeader.setMinWidth(valueHeader.getMaxWidth());
        valueHeader.setPrefWidth(valueHeader.getMaxWidth());
        valueHeader.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);


        if (guiModel != null)
            doAllInit();
    }

    private MethodInfo currentlySelectedTreeMethod = null;
    public AbstractApi currentlySelectedTreeApi() { return currentlySelectedTreeMethod == null ? null : currentlySelectedTreeMethod.api; }
    private Map<TreeItem<String>, MethodInfo> treeItemToMethodInfo;
    private Map<TreeItem<String>, AbstractApi> treeItemToAbstractApi;
    private TreeItem<String> credentialManipulationCategoryTreeItem;
    private TreeItem<String> credentialManipulationSpeaksForTreeItem;
    private TreeItem<String> credentialManipulationDelegationTreeItem;
    public void initTreeView() {
        TreeItem<String> rootItem = new TreeItem<String> ("APIs and Methods", null/*icon*/);
        rootItem.setExpanded(true);

        treeItemToMethodInfo = new HashMap<TreeItem<String>, MethodInfo>();
        treeItemToAbstractApi = new HashMap<TreeItem<String>, AbstractApi>();

        for (AbstractApi api : apis) {
            TreeItem<String> apiItem = new TreeItem<String> (api.getName());
            rootItem.getChildren().add(apiItem);
//            apiItem.setExpanded(true);
            treeItemToAbstractApi.put(apiItem, api);

            List<MethodInfo> methods = findAvailableMethods(api);
            for (MethodInfo method : methods) {
                TreeItem<String> methodItem = new TreeItem<String> (method.name);
                apiItem.getChildren().add(methodItem);
                treeItemToMethodInfo.put(methodItem, method);
            }
        }

        credentialManipulationCategoryTreeItem = new TreeItem<String>("Credential Manipulation");
        rootItem.getChildren().add(credentialManipulationCategoryTreeItem);
        credentialManipulationSpeaksForTreeItem = new TreeItem<String>("Speaks For");
        credentialManipulationCategoryTreeItem.getChildren().add(credentialManipulationSpeaksForTreeItem);
        credentialManipulationDelegationTreeItem = new TreeItem<String>("Delegation");
        credentialManipulationCategoryTreeItem.getChildren().add(credentialManipulationDelegationTreeItem);

        apiAndMethodTreeView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observableValue, Object oldTreeItem, Object newTreeItem) {
                MethodInfo oldMethodInfo = treeItemToMethodInfo.get(oldTreeItem);
                MethodInfo newMethodInfo = treeItemToMethodInfo.get(newTreeItem);

                AbstractApi newAbstractApi = treeItemToAbstractApi.get(newTreeItem);
                if (newAbstractApi != null) {
                    TreeItem treeItem = (TreeItem) newTreeItem;
                    treeItem.setExpanded(!treeItem.isExpanded());
                }

                //this debug showed that this actually skips some changes! (weird)
//                System.out.println("changed from "+oldTreeItem+" to "+newTreeItem+"   "+
//                    (oldMethodInfo == null ? "null" : oldMethodInfo.name)+
//                    " -> "+
//                        (newMethodInfo == null ? "null" : newMethodInfo.name));

                currentlySelectedTreeMethod = newMethodInfo;
                selectMethod(oldMethodInfo, newMethodInfo);

                updateServerUrlChoiceOnApiChange(currentlySelectedTreeApi());

                //show either commandConfigurationBox or credentialManipulationBox
                if (newTreeItem == credentialManipulationSpeaksForTreeItem) {
                    commandConfigurationBox.setVisible(false);
                    speaksForCredentialCreatorBox.setVisible(true);
                    delegatedCredentialCreatorBox.setVisible(false);
                } else {
                    if (newTreeItem == credentialManipulationDelegationTreeItem) {
                        commandConfigurationBox.setVisible(false);
                        speaksForCredentialCreatorBox.setVisible(false);
                        delegatedCredentialCreatorBox.setVisible(true);
                    } else {
                        commandConfigurationBox.setVisible(true);
                        speaksForCredentialCreatorBox.setVisible(false);
                        delegatedCredentialCreatorBox.setVisible(false);
                    }
                }
            }
        });

        apiAndMethodTreeView.setShowRoot(false);
        apiAndMethodTreeView.setRoot(rootItem);
    }

    public void updateFixedServerUrlField(AbstractApi newApi) {
        String authUrl = "NONE";
        boolean error = true;

        if (newApi != null) {
            ServerType st = newApi.getServerType();
            boolean isSA = st.getRole().equals(ServerType.GeniServerRole.PROTOGENI_SA);

            if (isSA && !useUserRadioButton.isSelected()) {
                if (!guiModel.getGeniUserProvider().isUserLoggedIn()) {
                    authUrl = "No user logged in";
                    error = true;
                }
                else {
                    GeniUser geniUser = guiModel.getGeniUserProvider().getLoggedInGeniUser();
                    assert geniUser != null;
                    SfaAuthority userSfaAuth = geniUser.getUserAuthority();
                    URL url = userSfaAuth.getUrl(st);
                    if (url == null) {
                        authUrl = "User Authority "+userSfaAuth.getName()+" has no URL for "+st;
                        error = true;
                    }
                    else {
                        authUrl = url.toExternalForm();
                        error = false;
                    }
                }
            } else {
                AuthorityInfo authorityInfo = authChooser.getSelectedAuthority();
                if (authorityInfo != null) {
                    URL url = authorityInfo.getSfaAuthority().getUrl(st);
                    if (url == null) {
                        authUrl = "Authority "+authorityInfo.getSfaAuthority().getName()+" has no URL for "+st;
                        error = true;
                    }
                    else {
                        authUrl = url.toExternalForm();
                        error = false;
                    }
                }
            }
        }

        serverUrlField.getStyleClass().remove("textFieldError");
        if (error)
            serverUrlField.getStyleClass().add("textFieldError");
        serverUrlField.setText(authUrl);
    }


    private ColumnConstraints colInfoInclude;
    private ColumnConstraints colInfoName;
    private ColumnConstraints colInfoValue;

    /** init after easymodel set, and fxml loaded. (typically after setEasyModel, but you never know)*/
    private void doAllInit() {
        assert logPanel != null;
        assert authChooser != null;

        assert guiModel != null;

        authChooser.setGuiModel(guiModel);

        speaksForCredentialCreatorPanel.setGuiModel(guiModel);
        delegatedCredentialCreatorPanel.setGuiModel(guiModel);

        initTreeView();

        authChooser.selectedAuthorityProperty().addListener(new ChangeListener<AuthorityInfo>() {
            @Override
            public void changed(ObservableValue<? extends AuthorityInfo> observableValue, AuthorityInfo oldAuthorityInfo, AuthorityInfo newAuthorityInfo) {
                updateFixedServerUrlField(currentlySelectedTreeApi());
            }
        });
        useUserRadioButton.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean oldBool, Boolean newIsSelected) {
                if (newIsSelected) updateFixedServerUrlField(currentlySelectedTreeApi());
                if (newIsSelected && guiModel.getGeniUserProvider().isUserLoggedIn())
                    authChooser.select(guiModel.getGeniUserProvider().getLoggedInGeniUser().getUserAuthority());
            }
        });
        userAuthorityRadioButton.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean oldBool, Boolean newIsSelected) {
                if (newIsSelected) updateFixedServerUrlField(currentlySelectedTreeApi());
            }
        });


        colInfoInclude = new ColumnConstraints();
        colInfoName = new ColumnConstraints();
        colInfoValue = new ColumnConstraints();
        colInfoValue.setHgrow(Priority.ALWAYS);
        colInfoValue.setMaxWidth(Double.MAX_VALUE);
        colInfoInclude.setFillWidth(true);
        colInfoName.setFillWidth(true);
        colInfoValue.setFillWidth(true);

//        colInfoInclude.setPercentWidth(10);
//        colInfoName.setPercentWidth(30);
//        colInfoValue.setPercentWidth(60);

        argumentGrid.getColumnConstraints().add(colInfoInclude);
        argumentGrid.getColumnConstraints().add(colInfoName);
        argumentGrid.getColumnConstraints().add(colInfoValue);

        RowConstraints headerRowinfo = new RowConstraints();
        headerRowinfo.setFillHeight(true);
        argumentGrid.getRowConstraints().add(headerRowinfo);

        logPanel.setApiCallHistory(guiModel.getEasyModel().getApiCallHistory());

        //if content of scrollpane is smaller than scrollpane, resize it to fit
////        argumentScrollPane.setFitToHeight(true);
//        argumentScrollPane.setFitToWidth(true);

////        argumentGrid.setPrefHeight(Region.USE_COMPUTED_SIZE);
////        argumentGrid.setPrefWidth(Region.USE_COMPUTED_SIZE);
//
//        argumentScrollPane.prefViewportWidthProperty().bind(argumentGrid.prefWidthProperty());
//        argumentScrollPane.prefViewportHeightProperty().bind(argumentGrid.prefHeightProperty());
//
////        argumentScrollPane.maxWidthProperty().bind(argumentGrid.prefWidthProperty());
////        argumentScrollPane.maxHeightProperty().bind(argumentGrid.prefHeightProperty());
////        argumentScrollPane.maxHeightProperty().set(Region.USE_PREF_SIZE);
//
////        argumentScrollPane.prefWidthProperty().bind(argumentGrid.prefWidthProperty());
////        argumentScrollPane.prefHeightProperty().bind(argumentGrid.prefHeightProperty());
    }

    private static class CommandParameterController {
        public final CommandParameterModel model;

        public final CheckBox includedCheckBox;
        public final Label requiredLabel;
        public final Control includedColumnItem;
        public final VBox includedColumnItemBox;

        public final Label nameLabel;
        public final VBox nameLabelBox;
        public final VBox commandArgumentChooserBox;
        public final ExpandableHelp commandArgumentChooserHelper;
        public final CommandArgumentChooser commandArgumentChooser;

        private ObservableList<CommandParameterController> otherControllers;
        private ObservableList<CommandArgumentChooser> otherCommandArgumentChoosers;

        public static class OtherCommandArgumentsObservableList extends ListBinding<CommandArgumentChooser> {
            private final ObservableList<CommandParameterController> otherControllers;
            public OtherCommandArgumentsObservableList(ObservableList<CommandParameterController> otherControllers) {
                this.otherControllers = otherControllers;
                otherControllers.addListener(new ListChangeListener<CommandParameterController>() {
                    @Override
                    public void onChanged(Change<? extends CommandParameterController> change) {

                    }
                });
            }

            private List<CommandArgumentChooser> buildList() {
                List<CommandArgumentChooser> res = new ArrayList<>();
                if (otherControllers == null) return res;
                for (CommandParameterController c : otherControllers)
                    if (c.commandArgumentChooser != null) res.add(c.commandArgumentChooser);
                return res;
            }

            /** using computeValue() here is not very efficient, but it is good enough. (it's just for a limited number of GUI components) */
            @Override
            protected ObservableList<CommandArgumentChooser> computeValue() {
                return FXCollections.observableArrayList(buildList());
            }
        }

        public CommandParameterController(CommandParameterModel model, GuiModel guiModel, ObservableList<CommandParameterController> otherControllers) {
            this.model = model;
            this.otherControllers = otherControllers;
            this.otherCommandArgumentChoosers = new OtherCommandArgumentsObservableList(otherControllers);

            includedCheckBox = new CheckBox();
            requiredLabel = new Label("required");

            if (model.isRequired()) {
                includedColumnItem = requiredLabel;
            } else {
                includedColumnItem = includedCheckBox;
                includedCheckBox.selectedProperty().bindBidirectional(model.includedProperty());
            }
            includedColumnItemBox = new VBox();
            includedColumnItemBox.setPadding(new Insets(10));
            includedColumnItemBox.getChildren().add(includedColumnItem);

            nameLabel = new Label(model.getParameterName());
            nameLabelBox = new VBox();
            nameLabelBox.setPadding(new Insets(10));
            nameLabelBox.getChildren().add(nameLabel);

            commandArgumentChooser = CommandArgumentChooser.getCommandArgumentChooser(
                    model.getParameterName(),
                    model.getParameterClass(),
                    model.getAnnotation(),
                    guiModel,
                    model.getMethodInfo(),
                    otherCommandArgumentChoosers);
            assert commandArgumentChooser != null;
            assert commandArgumentChooser.valueProperty() != null : "commandArgumentChooser.valueProperty() is null for name="+model.getParameterName()+" class="+model.getParameterClass()+" chooserClass="+commandArgumentChooser.getClass().getName();
            model.valueProperty().bind(commandArgumentChooser.valueProperty());
            commandArgumentChooser.disableProperty().bind(model.includedProperty().not()); //disable if not included

            commandArgumentChooserBox = new VBox();
            commandArgumentChooserBox.setPadding(new Insets(10));
            String helpText = model.getAnnotation().hint();
            commandArgumentChooserHelper = new ExpandableHelp(helpText);
            if (helpText != null && !helpText.isEmpty())
                commandArgumentChooserBox.getChildren().add(commandArgumentChooserHelper);
            commandArgumentChooserBox.getChildren().add(commandArgumentChooser);

            commandArgumentChooserHelper.setMaxWidth(500.0);
            commandArgumentChooser.setMaxWidth(500.0);
        }

        /*
         * add this item to the argument grid
         * */
        public void add(GridPane gridPane, int row) {
            GridPane.setConstraints(includedColumnItemBox, 0/*col*/, row/*row*/);
            GridPane.setConstraints(nameLabelBox, 1, row);
            GridPane.setConstraints(commandArgumentChooserBox, 2, row);

//            GridPane.setMargin(includedColumnItem, new Insets(10, 10, 10, 10));
            GridPane.setHalignment(includedColumnItemBox, HPos.CENTER);

//            GridPane.setMargin(nameParent, new Insets(10, 10, 10, 10));
            GridPane.setHalignment(nameLabelBox, HPos.RIGHT);

//            GridPane.setMargin(commandArgumentChooserBox, new Insets(10, 10, 10, 10));
            GridPane.setHalignment(commandArgumentChooserBox, HPos.CENTER);

            GridPane.setHgrow(includedColumnItemBox, Priority.NEVER);
            GridPane.setHgrow(nameLabelBox, Priority.NEVER);
            GridPane.setHgrow(commandArgumentChooserBox, Priority.ALWAYS);

            includedColumnItem.getStyleClass().removeAll("argumentGridA", "argumentGridB");
            includedColumnItemBox.getStyleClass().removeAll("argumentGridA", "argumentGridB");
            nameLabel.getStyleClass().removeAll("argumentGridA", "argumentGridB");
            nameLabelBox.getStyleClass().removeAll("argumentGridA", "argumentGridB");
            commandArgumentChooserBox.getStyleClass().removeAll("argumentGridA", "argumentGridB");
//            if (row % 2 == 0) {
//                includedColumnItem.getStyleClass().add("argumentGridA");
//                nameLabel.getStyleClass().add("argumentGridB");
//                commandArgumentChooserBox.getStyleClass().add("argumentGridA");
//            } else {
//                includedColumnItem.getStyleClass().add("argumentGridB");
//                nameLabel.getStyleClass().add("argumentGridA");
//                commandArgumentChooserBox.getStyleClass().add("argumentGridB");
//            }
            if (row % 2 == 0) {
                includedColumnItem.getStyleClass().add("argumentGridA");
                includedColumnItemBox.getStyleClass().add("argumentGridA");
                nameLabel.getStyleClass().add("argumentGridA");
                nameLabelBox.getStyleClass().add("argumentGridA");
                commandArgumentChooserBox.getStyleClass().add("argumentGridA");
            } else {
                includedColumnItem.getStyleClass().add("argumentGridB");
                includedColumnItemBox.getStyleClass().add("argumentGridB");
                nameLabel.getStyleClass().add("argumentGridB");
                nameLabelBox.getStyleClass().add("argumentGridB");
                commandArgumentChooserBox.getStyleClass().add("argumentGridB");
            }

            gridPane.getChildren().add(includedColumnItemBox);
            gridPane.getChildren().add(nameLabelBox);
            gridPane.getChildren().add(commandArgumentChooserBox);

            includedColumnItem.setMinWidth(includedColumnItem.getMaxWidth());
            nameLabel.setMinWidth(nameLabel.getMaxWidth());
            includedColumnItem.setPrefWidth(includedColumnItem.getMaxWidth());
            nameLabel.setPrefWidth(nameLabel.getMaxWidth());

            includedColumnItem.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
            nameLabel.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
            commandArgumentChooserBox.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

            gridPane.getStyleClass().add("argumentGrid");
        }

        public void remove(GridPane gridPane) {
            model.valueProperty().unbind();
            boolean removedItem = gridPane.getChildren().remove(includedColumnItemBox);
            boolean removedItem2 = gridPane.getChildren().remove(nameLabelBox);
            boolean removedItem3 = gridPane.getChildren().remove(commandArgumentChooserBox);
            assert removedItem;
            assert removedItem2;
            assert removedItem3;
        }
    }

    public static class MethodInfo {
        public AbstractApi api;
        public Method method;
        public ApiMethod annotation;
        public String name;

        public MethodInfo (AbstractApi api, Method method, ApiMethod annotation) {
            this.api = api;
            this.method = method;
            this.annotation = annotation;
            this.name = method.getName();
        }
        public MethodInfo (AbstractApi api, Method method) { this(api, method, method.getAnnotation(ApiMethod.class)); }

        public String toString() {
            return name;
        }
    }

    public static Comparator<MethodInfo> methodInfoComparator = new Comparator<MethodInfo>() {
        @Override
        public int compare(MethodInfo m1, MethodInfo m2) {
            int m1o = m1.annotation.order();
            int m2o = m2.annotation.order();

            //first use order
            if (m1o != m2o)
                return m1o - m2o;

            //the use fallback
            return m1.name.compareTo(m2.name);
        }
    };

    private static List<MethodInfo> findAvailableMethods(AbstractApi api) {
        Class targetClass = api.getClass();
        List<MethodInfo> res = new ArrayList<MethodInfo>();

        for (Method m : targetClass.getDeclaredMethods()) {//GeniConnection con,
            if (m.isAnnotationPresent(ApiMethod.class)) {
                ApiMethod am = m.getAnnotation(ApiMethod.class);
                Class[] parameterTypes = m.getParameterTypes();
                if (parameterTypes.length == 0 || !JFedConnection.class.isAssignableFrom(parameterTypes[0]))
                    throw new RuntimeException("Method "+m+" does not have JFedConnection as first parameter but it does have @ApiMethod");
                res.add(new MethodInfo(api, m, am));
            }
        }

        Collections.sort(res, methodInfoComparator);

        return res;
    }

    private void selectMethod(MethodInfo oldMethod, MethodInfo newMethod) {
        if (oldMethod != null || newMethod != null) {
            for (CommandParameterController controller: argumentControllers) {
                controller.remove(argumentGrid);
            }
            argumentControllers.clear();
            argumentModels.clear();

            argumentGrid.getRowConstraints().clear();
        }

        if (commandHelp != null)
            commandNameBox.getChildren().remove(commandHelp);

        if (newMethod != null) {
            assert argumentModels.isEmpty();

            RowConstraints headerRowinfo = new RowConstraints();
            headerRowinfo.setFillHeight(true);
            argumentGrid.getRowConstraints().add(headerRowinfo);

            int rowIndex = 1;
            argumentModels.setAll(createCommandParameterModels(newMethod));
            for (CommandParameterModel model : argumentModels) {
                RowConstraints rowinfo = new RowConstraints();
                rowinfo.setFillHeight(true);
//                rowinfo.setPercentHeight(50);
                argumentGrid.getRowConstraints().add(rowinfo);

                CommandParameterController controller = new CommandParameterController(model, guiModel, argumentControllers);
                controller.add(argumentGrid, rowIndex++);

                argumentControllers.add(controller);
            }

            commandHelp = new ExpandableHelp(newMethod.annotation.hint());
            commandNameBox.getChildren().add(commandHelp);
            commandNameLabel.setText(newMethod.name);
            if (!commandNameLabel.getStyleClass().contains("boldText"))
                commandNameLabel.getStyleClass().add("boldText");
        } else {
            commandNameLabel.setText("None selected");
            commandNameLabel.getStyleClass().remove("boldText");
        }

        updateFixedServerUrlField(currentlySelectedTreeApi());
    }

    public List<CommandParameterModel> createCommandParameterModels(MethodInfo methodInfo) {
        List<CommandParameterModel> parameterModels = new ArrayList<CommandParameterModel>();

        Method method = methodInfo.method;
        String methodName = method.getName();

        Class[] parameterTypes = method.getParameterTypes();
        Annotation[][] annotations = method.getParameterAnnotations();

        for (int i = 0; i < parameterTypes.length; i++) {
            Annotation[] paramAnnotations = annotations[i];
            Class paramClass = parameterTypes[i];

            for (int j = 0; j < paramAnnotations.length; j++)
                if (paramAnnotations[j].annotationType().equals(ApiMethodParameter.class)) {
                    ApiMethodParameter amp = (ApiMethodParameter) paramAnnotations[j];

                    CommandParameterModel commandParameterModel = new CommandParameterModel(amp.name(), paramClass, amp, methodInfo);

                    parameterModels.add(commandParameterModel);
                }
        }

        return parameterModels;
    }


    private SfaConnectionPool/*GeniConnectionProvider*/ connectionProvider = new SfaConnectionPool();
    private GeniUser geniUserOfPreviousProxySetup = null; //prevent setup up proxy each time. Once is enough.
    @FXML private void call() {
        if (useSshProxyCheckBox.isSelected() &&
                guiModel.getGeniUserProvider().isUserLoggedIn()) {
            GeniUser geniUser = guiModel.getGeniUserProvider().getLoggedInGeniUser();

            if (geniUserOfPreviousProxySetup != geniUser) {
                geniUserOfPreviousProxySetup = geniUser;
                SfaAuthority userAuth = geniUser.getUserAuthority();
                if (!userAuth.getProxies().isEmpty()) { //currently, only SSH proxies are supported here!
                    SfaAuthority.ProxyInfo pi = userAuth.getProxies().get(0);

                    assert pi.getProxyType().equals("jFed SSH Proxy");

                    VlanRangeHelper range = pi.getPortRange();
                    int port = range.getCurrent();

                    LOG.info("SSH Proxy is activated, and there is an SSH Proxy for user authority "+userAuth.getName()+": "+pi.getHostname()+":"+port);

                    JFedConnection.ProxyInfo proxyInfo = new JFedConnection.SshProxyInfo(
                            pi.getHostname(),
                            port,
                            geniUser.getUserUrn().getResourceName(),
                            new UserSshKeyInfo(geniUser),
                            pi.getHostKey());
                    connectionProvider.setProxyInfo(proxyInfo);
                } else {
                    LOG.info("SSH Proxy is activated, but there is no SSH Proxy for user authority "+userAuth.getName());
                }
            }
        }


        MethodInfo calledMethod = currentlySelectedTreeMethod;
        if (calledMethod == null) return;
        AbstractApi calledApi = calledMethod.api;

        System.out.println("Call method "+calledMethod.name+" with parameters:");
        for (CommandParameterModel param : argumentModels) {
            if (param.isRequired() || param.includedProperty().get())
                System.out.println("  - "+param.getParameterName()+" -> \""+param.valueProperty().get()+"\"");
            else
                System.out.println("  - Not included: "+param.getParameterName());
        }

        try {
            boolean debugMode = false; /*TODO*/
            JFedConnection con = null;
            connectionProvider.setDebugMode(debugMode);

            assert calledApi != null;
            GeniUser geniUser = null;
            if (guiModel.getGeniUserProvider().isUserLoggedIn())
                geniUser = guiModel.getGeniUserProvider().getLoggedInGeniUser();

            if (useUserRadioButton.isSelected()) {
                assert con == null;
                con = connectionProvider.getConnectionByUserAuthority(geniUser, calledApi.getServerType());
            }
            if (userAuthorityRadioButton.isSelected()) {
                assert con == null;
                con = connectionProvider.getConnectionByAuthority(geniUser, authChooser.getSelectedAuthority().getSfaAuthority(), calledApi.getClass());
            }
            if (userCustomServerRadioButton.isSelected()) {
                assert con == null;
                System.out.println("SECURITY WARNING: making connection which accepts all certificates");
                HttpsClientWithUserAuthenticationFactory.HandleUntrustedCallback handleUntrustedCallback;
                if (ignoreSelfSignedCheckBox.isSelected())
                    handleUntrustedCallback = new HttpsClientWithUserAuthenticationFactory.INSECURE_TRUSTALL_HandleUntrustedCallback();
                else {
                    handleUntrustedCallback = new HttpsClientWithUserAuthenticationFactory.HandleUntrustedCallback() {
                        @Override
                        public boolean trust(SSLCertificateDownloader.SSLCertificateJFedInfo sslCertificateJFedInfo) {
                            if (sslCertificateJFedInfo.isTrusted()) return true;

                            String problemDescription = "";
                            if (sslCertificateJFedInfo.isSelfSigned()) {
                                problemDescription += "The server's certificate is self signed. Certificate info:\n";
                                for (X509Certificate cert : sslCertificateJFedInfo.getChain()) {
                                    problemDescription += ""+cert.toString();
                                    problemDescription += "\n\n";
                                }
                            }
                            if (!sslCertificateJFedInfo.getSubjectMatchesHostname()) {
                                if (!problemDescription.equals(""))
                                    problemDescription += "\n\nADDITIONAL SECURITY PROBLEM:\n";
                                problemDescription += "The certificate's subject hostname does not match the server URL:\n";
                                problemDescription += "    Certificate Subject: "+sslCertificateJFedInfo.getSubject()+"\n";
                                problemDescription += "    Server Hostname: "+sslCertificateJFedInfo.getHostname()+"\n";
                            }
                            return JavaFXDialogUtil.show2ChoiceDialog(problemDescription,
                                    "I know what I am doing, I checked the certificate manually, and I trust the server",
                                    "I do not trust this",
                                    callButton);
                        }
                    };
                }
                con = connectionProvider.getConnectionByUrl(geniUser, new URL(customServerUrlField.getText()), handleUntrustedCallback, calledApi.getServerType());
            }

            if (con == null) {
                throw new RuntimeException("Authority to use for needed ServerType is unknown, or URL for needed ServerType is unknown: serverType="+calledApi.getServerType());
            }

            execute(calledMethod, con, geniUser, debugMode);
        } catch (Exception e) {
            throw new RuntimeException("Call failed: "+e.getMessage(), e);
        }
    }

    public void execute(MethodInfo methodInfo, final JFedConnection connection, final GeniUser geniUser, boolean debugMode) throws JFedException {
        final Method method = methodInfo.method;
        final AbstractApi targetObject = methodInfo.api;

        int chooserIndex = 0;

        final Class[] parameterTypes = method.getParameterTypes();
        Annotation[][] annotations = method.getParameterAnnotations();

        final Object[] parameters = new Object[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            Annotation[] paramAnnotations = annotations[i];
            Class paramClass = parameterTypes[i];

            if (JFedConnection.class.isAssignableFrom(paramClass))
                parameters[i] = connection;
            else {
                if (paramClass.equals(GeniUser.class)) { //TODO is this still useful? What is this for?
                    assert geniUser != null : "parameter required user, but no user is provided";
                    parameters[i] = geniUser;
                }
                else
                    for (int j = 0; j < paramAnnotations.length; j++)
                        if (paramAnnotations[j].annotationType().equals(ApiMethodParameter.class)) {
                            ApiMethodParameter amp = (ApiMethodParameter) paramAnnotations[j];
                            CommandParameterModel commandParameterModel = argumentModels.get(chooserIndex++);
                            Object c = null;
                            if (commandParameterModel.isRequired() || commandParameterModel.includedProperty().get()) {
                                c = commandParameterModel.valueProperty().get();
                                assert c != null : "c==null when isRequired="+commandParameterModel.isRequired()+" included="+commandParameterModel.includedProperty().get();

                                //The GUI elements sometimes return "higher level" objects, that the low level API does not know.
                                //We extract the lower level Objects that the API understands from them here
                                //Also, some classes can be converted to and from string, so here we make sure the correct one is used

                                //ResourceId needs to be converted to String in some cases
                                if (ResourceId.class.isInstance(c) && paramClass.equals(String.class))
                                    c = ((ResourceId) c).getValue();
                                //String needs to be converted to other classes in some cases
                                if (String.class.isInstance(c) && paramClass.equals(ResourceId.class))
                                    c = ResourceIdParser.parse((String) c);
                                if (String.class.isInstance(c) && paramClass.equals(ResourceUrn.class))
                                    c = new ResourceUrn((String) c);
                                if (String.class.isInstance(c) && paramClass.equals(GeniUrn.class))
                                    try {
                                        c = new GeniUrn((String) c);
                                    } catch (GeniUrn.GeniUrnParseException e) {
                                        throw new RuntimeException("Failed to convert user specified String to GeniUrn. Is it a valid urn?", e);
                                    }

                                //CredentialInfo needs to be converted to AnyCredential
                                if (CredentialInfo.class.isInstance(c) && paramClass.equals(AnyCredential.class))
                                    c = ((CredentialInfo) c).getCredential();

                                //list of CredentialInfo needs to be converted to list of AnyCredential
                                if (amp.name().equals("credentialList") || amp.parameterType().equals(ApiMethodParameterType.LIST_OF_CREDENTIAL)) {
                                    assert c != null;
                                    assert List.class.isInstance(c) : "Argument with name \"credentialList\" has type "+c.getClass().getName()+" instead of List. Value: "+c;

                                    List<AnyCredential> credentials = new ArrayList<AnyCredential>();
                                    List l = (List) c;

                                    for (Object o : l) {
                                        if (CredentialInfo.class.isInstance(o)) {
                                            CredentialInfo ci = (CredentialInfo) o;
                                            credentials.add(ci.getCredential());
                                        } else {
                                            if (AnyCredential.class.isInstance(o)) {
                                                AnyCredential cred = (AnyCredential) o;
                                                credentials.add(cred);
                                            } else {
                                                throw new RuntimeException("In list of credentials, expected a credential class (AnyCredential or CredentialInfo) but got incompatible "+o.getClass()+".");
                                            }
                                        }
                                    }

                                    c = credentials;
                                }
                            }

                            if (c != null && !paramClass.isInstance(c))
                                System.err.println("WARNING: (for argument "+amp.name()+") expected class "+paramClass+" but got incompatible "+c.getClass()+". This will cause an error later on.");

                            parameters[i] = c;
                        } else {
                            //ignored parameter
                            parameters[i] = null;
                        }
            }
            if (debugMode)
                System.out.println("DEBUG CommandPanel.execute parameters["+i+"]="+parameters[i]);
        }

        targetObject.setDebugMode(debugMode);

        Task call = new Task("Probe "+methodInfo.name+" Call") {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                try {
                    //Note: add and remove listener is NOT the same as adding the logger. The difference is that an added
                    // logger will see calls to other API's on other threads as well, since it is added to the global
                    // logger instead of a logger specific for this call

                    Logger globalLogger = targetObject.getLogger();
                    assert globalLogger instanceof JavaFXLogger;
                    Logger myLogger = globalLogger.getWrappingLogger(singleTask);
                    assert myLogger instanceof JavaFXLogger;

//               don't do this:     targetObject.getLogger().addResultListener(singleTask);
                    targetObject.setLogger(myLogger);

                    Object methodRes = method.invoke(targetObject, parameters);

                    targetObject.setLogger(globalLogger);

//               don't do this:     targetObject.getLogger().removeResultListener(singleTask);


                    //cleanup: remove singleTask from myLogger
                    myLogger.removeResultListener(singleTask);

                    System.out.println("Calling probe task completed");

                    ApiCallReply methodResRep = (ApiCallReply) methodRes;
                    //invoke hides InterruptedException
//                } catch (InterruptedException e) {
//                    throw e;
//                }
                } catch (Exception e) { //TODO better exception handling?
                    if (e instanceof InterruptedException)
                        throw (InterruptedException) e;

                    System.out.println("Exception calling probe task: "+e); e.printStackTrace();
                    if (e.getCause() != null && e.getCause() instanceof JFedException) {
                        //                System.err.println("Note: GeniException in invoked call => unwrapping GeniException and throwing it. see CommandPanel.execute(...)");
                        throw (JFedException) e.getCause();
                    }
                    throw new JFedException("Exception invoking API call", e);
                }
            }
        };
        TaskThread.getInstance().addTask(call);
    }

    private static Stage probeStage = null;
    public static Stage showProbe(GuiModel guiModel) {
        return showProbe(guiModel, null);
    }
    public static Stage showProbe(GuiModel guiModel, Stage stage) {
        try {
            if (probeStage == null) {

                URL location = ProbeController.class.getResource("Probe.fxml");
                assert location != null;
                FXMLLoader fxmlLoader = new FXMLLoader(location, null);

                BorderPane root = (BorderPane)fxmlLoader.load();
                ProbeController controller = fxmlLoader.getController();

                controller.setGuiModel(guiModel);

                Scene scene = new Scene(root);

                if (stage != null)
                    probeStage = stage;
                else
                    probeStage = new Stage();
                probeStage.setScene(scene);
            }
            if (stage != null)
                assert probeStage == stage;
            assert probeStage != null;
            probeStage.show();
            return probeStage;
        } catch (Exception e) {
            throw new RuntimeException("Something went wrong showing the Probe: "+e.getMessage(), e);
        }
    }
}
