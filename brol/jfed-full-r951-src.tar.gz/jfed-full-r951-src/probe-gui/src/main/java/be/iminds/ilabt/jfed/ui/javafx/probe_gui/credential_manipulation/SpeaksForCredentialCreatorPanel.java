package be.iminds.ilabt.jfed.ui.javafx.probe_gui.credential_manipulation;

import be.iminds.ilabt.jfed.gui_model.GuiModel;
import be.iminds.ilabt.jfed.highlevel.model.CredentialInfo;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.IOUtils;
import be.iminds.ilabt.jfed.util.KeyUtil;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.util.Pair;
import org.apache.logging.log4j.LogManager;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.*;

/**
 * CredentialCreatorPanel
 */
public class SpeaksForCredentialCreatorPanel extends CredentialCreatorPanel implements Initializable {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    @FXML private Label spokenForUrnLabel;
    @FXML private TextField spokenForUrnText;
    @FXML private Label spokenForUrnNoteLabel;

    @FXML private Label targetLabel;
    @FXML private TextField targetText;
    @FXML private RadioButton targetViaUrn;
    @FXML private RadioButton targetViaCert;

    @FXML private VBox targetUrnBox;
    @FXML private VBox targetCertfileBox;

    @FXML private TextField targetCertFilename;
    @FXML private Button loadCertButton;

    @FXML private Button generateButton;
    @FXML private Label generateNoteLabel;

    @FXML private Label resultLabel;
    @FXML private TextArea resultText;
    @FXML private Button saveResultButton;

    @FXML private Label privNameLabel;
    @FXML private TextField privNameText;
    @FXML private CheckBox canDelegateCheckBox;
    @FXML private Label expireLabel;
    @FXML private TextField expireText;


    public SpeaksForCredentialCreatorPanel() {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("SpeaksForCredentialCreator.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        spokenForUrnLabel.managedProperty().bind(spokenForUrnLabel.visibleProperty());
        spokenForUrnText.managedProperty().bind(spokenForUrnText.visibleProperty());
        spokenForUrnNoteLabel.managedProperty().bind(spokenForUrnNoteLabel.visibleProperty());
        generateButton.managedProperty().bind(generateButton.visibleProperty());
        generateNoteLabel.managedProperty().bind(generateNoteLabel.visibleProperty());
        resultLabel.managedProperty().bind(resultLabel.visibleProperty());
        resultText.managedProperty().bind(resultText.visibleProperty());
        targetUrnBox.managedProperty().bind(targetUrnBox.visibleProperty());
        targetCertfileBox.managedProperty().bind(targetCertfileBox.visibleProperty());

        privNameLabel.managedProperty().bind(privNameLabel.visibleProperty());
        privNameText.managedProperty().bind(privNameText.visibleProperty());
        canDelegateCheckBox.managedProperty().bind(canDelegateCheckBox.visibleProperty());
        expireLabel.managedProperty().bind(expireLabel.visibleProperty());
        expireText.managedProperty().bind(expireText.visibleProperty());

        spokenForUrnLabel.visibleProperty().bind(spokenForUrnText.visibleProperty());
        spokenForUrnNoteLabel.visibleProperty().bind(spokenForUrnText.visibleProperty());
        generateNoteLabel.visibleProperty().bind(generateButton.visibleProperty());
        resultLabel.visibleProperty().bind(resultText.visibleProperty());
        saveResultButton.visibleProperty().bind(resultText.visibleProperty());

        privNameLabel.visibleProperty().bind(privNameText.visibleProperty());
        expireLabel.visibleProperty().bind(expireText.visibleProperty());

        targetUrnBox.visibleProperty().bind(targetViaUrn.selectedProperty());
        targetCertfileBox.visibleProperty().bind(targetViaCert.selectedProperty());
    }


    private X509Certificate userCert;
    @FXML private void loadCertFile() {
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showOpenDialog(null);

        if(file != null) {
            String filename = file.getPath();
            targetCertFilename.setText(filename);
            String fileContent = null;
            try {
                fileContent = IOUtils.fileToString(file);
                userCert = KeyUtil.pemToX509Certificate(fileContent);
            } catch (Exception e) {
                logger.error("Error reading user certificate file \""+filename+"\": "+e.getMessage(), e);
                targetCertFilename.setText("ERROR: " + e.getMessage());
                userCert = null;
            }
        }
    }

    public void setGuiModel(GuiModel guiModel) {
        assert guiModel != null;
        super.setGuiModel(guiModel);
        assert this.guiModel != null;

        //should be initialised already
        assert spokenForUrnText != null;

        //TODO: listen for user login/logout easyModel.getGeniUserProvider().addListener

        updateUser();
    }

    private void updateUser() {
        assert guiModel != null;
        if (guiModel.getGeniUserProvider().isUserLoggedIn()) {
            spokenForUrnText.setText(guiModel.getGeniUserProvider().getLoggedInGeniUser().getUserUrnString());
            generateButton.setDisable(false);
        }
        else {
            spokenForUrnText.setText("no user logged in");
            generateButton.setDisable(true);
        }
    }

    protected void setResult(final String text) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                resultText.setText(text);
            }
        });

    }

    Thread generateSpeaksForThread = null;
    public void generate() {
        if (targetViaCert.isSelected() && userCert == null) {
            logger.info("button clicked: generateDelegate not called since no certificate loaded yet");
            return;
        }

        if (generateSpeaksForThread != null) {
            logger.debug("button clicked: generateSpeaksFor still running, so not called");
            return;
        }
        else
            logger.debug("button clicked: generateSpeaksFor called");

        generateButton.setDisable(true);

        int expireInDaysHelper;
        try{
            expireInDaysHelper = Integer.parseInt(expireText.getText());
        } catch (NumberFormatException e) {
            logger.debug("Error processing \"expire\": \""+expireText.getText()+"\" is not a valid integer", e);
            setResult("Error processing \"expire\": \""+expireText.getText()+"\" is not a valid integer");
            return;
        }
        final int expireInDays = expireInDaysHelper;

        final String privilegeName = privNameText.getText();
        final boolean canDelegate = canDelegateCheckBox.isSelected();

        generateSpeaksForThread = new Thread(new Runnable() {
            @Override
            public void run() {
                String targetUrn;
                if (targetViaUrn.isSelected()) {
                    targetUrn = targetText.getText();
                    userCert = certificateRetriever(targetUrn);
                } else {
                    assert userCert != null;
                    targetUrn = findUrnInCertificate(userCert);
                    assert targetUrn != null;
                }

                generate_Helper(targetUrn, userCert, expireInDays, privilegeName, canDelegate);
                logger.trace("generateSpeaksFor_Helper() returned");
                generateSpeaksForThread = null;
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        generateButton.setDisable(false);
                    }
                });
            }
        });
        generateSpeaksForThread.start();
    }
    public void generate_Helper(String speakerUrn, X509Certificate speakerCert, int expireInDays, String privilegeName, boolean canDelegate) {
        assert !Platform.isFxApplicationThread();

        assert guiModel.getGeniUserProvider().isUserLoggedIn();

        logger.trace("generateSpeaksFor_Helper() getting user info");
        Pair<GeniUrn, X509Certificate> userInfo = null;
        try {
            userInfo = getUserInfo(guiModel.getGeniUserProvider().getLoggedInGeniUser().getUserUrnString());
        } catch (GeniUrn.GeniUrnParseException e) {
            logger.error("User urn is invallid (should not occur!)", e);
            setResult("ERROR user urn is invalid: " + guiModel.getGeniUserProvider().getLoggedInGeniUser().getUserUrnString());
            return;
        } catch (JFedException e) {
            logger.error("Error in call for user urn info retrieval (should not occur!)", e);
            setResult("ERROR user urn is invalid: " + guiModel.getGeniUserProvider().getLoggedInGeniUser().getUserUrnString());
            return;
        }
//        logger.trace("generateSpeaksFor_Helper() getting target info");
//        Pair<GeniUrn, X509Certificate> targetInfo = null;
//        try {
//            targetInfo = getUserInfo(speakerUrn);
//            if (targetInfo == null || targetInfo.getValue() == null) {
//                setResult("ERROR getting info for urn: " + speakerUrn);
//                return;
//            }
//        } catch (GeniUrn.GeniUrnParseException e) {
//            logger.error("ERROR urn is invalid: "+ speakerUrn, e);
//            setResult("ERROR urn is invalid: " + speakerUrn);
//            return;
//        } catch (JFedException e) {
//            logger.error("Error in call retrieving info for urn: "+ speakerUrn, e);
//            setResult("Error in call retrieving info for urn: " + speakerUrn);
//            return;
//        }

//        logger.trace("generateSpeaksFor_Helper() has target info");

        PrivateKey userPrivateKey = guiModel.getGeniUserProvider().getLoggedInGeniUser().getPrivateKey();

        Date expireDate = new Date(System.currentTimeMillis()+(expireInDays*24*60*60*1000)); //expireInDays days from now

        try {
            logger.trace("generateSpeaksFor_Helper() creating credential");
            SfaCredential speakForCredential = SfaCredential.createSpeaksFor(
                    userInfo.getKey().getValue(), speakerUrn,
                    userInfo.getValue(), speakerCert,
                    userPrivateKey, expireDate, privilegeName, canDelegate);

            logger.trace("generateSpeaksFor_Helper() showing result");
            setResult(speakForCredential.getCredentialXml());

            guiModel.getEasyModel().getParameterHistoryModel().getUserCredentials().add(new CredentialInfo(speakForCredential));
        } catch (CredentialException e) {
            logger.error("Exception creating speaks for credential", e);
            setResult("ERROR creating speaks for credential: " + e.getMessage());
        }
    }

    public void save() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Credential File");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Credential XML Files", "*.xml"));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("All Files", "*.*"));
        File file = fileChooser.showSaveDialog(this.getScene().getWindow());
        if (file != null) {
            try {
                IOUtils.stringToFile(file, resultText.getText());
            } catch (Exception e) {
                logger.error("Failed to save to file: "+file.getPath(), e);
            }
        }
    }
}
