package be.iminds.ilabt.jfed.lowlevel.api.test;

import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api.AggregateManager2;
import be.iminds.ilabt.jfed.lowlevel.api.UserSpec;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.NodeContents;
import be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents;
import be.iminds.ilabt.jfed.testing.base.ApiTest;
import be.iminds.ilabt.jfed.util.CommandExecutionContext;
import be.iminds.ilabt.jfed.util.GeniUrn;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.IOException;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/**
 * TestAggregateManager2
 */
public class TestAggregateManager2 extends ApiTest {
    public String getTestDescription() {
        return "Many Aggregate Manager (Geni AM API v2) Tests. 2 slices and a sliver will be created during the tests. "+
                "The sliver will be deleted. "+
                "This will not test ListResources when requesting an advertisement request "+
                "(takes too long, use TestAggregateManager2AllListResources).";
    }

    @Override
    public List<String> getOptionalConfigKeys() {
        List<String> res = new ArrayList<String>();
        /* fixed_ssh_private_key_file and fixed_ssh_public_key_file option:
              There are 3 cases:
                  option not specified: use randomly generated key that is different each time
                  option specified, with private key file specified: use public and private key from files (public key can be read from PEM certificate)
                  option specified, with private key file specified, AND this file is the same file for both and is a user login file (key+cert file): use public and private key from file. Note that some site might only use this ssh key anyhow (such as perhaps fuseco?)

         */
        res.add("fixed_ssh_public_key_file"); //needed if fixed_ssh_private_key_file is specified (file containing PEM x509certificate is also allowed)
        res.add("fixed_ssh_private_key_file"); //needed if fixed_ssh_public_key_file is specified
        res.add("fixed_ssh_private_key_password"); //may be null,even if fixed_ssh_private_key_file is not (in case no password is needed)
        return res;
    }




    private CommonAMTest commonAMTest;
    private AggregateManager2 am2;

    private CommandExecutionContext testContext;

    private AnyCredential userCredential;
    private List<AnyCredential> getUserCredentialList() {
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(userCredential);
        return res;
    }
    private static List<AnyCredential> toCredentialList(AnyCredential c) {
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(c);
        return res;
    }

    public SfaConnection getAM2Connection() throws JFedException {
        return (SfaConnection) testContext.getConnectionProvider().getConnectionByAuthority(testContext.getGeniUser(), testContext.getTestedAuthority(), new ServerType(ServerType.GeniServerRole.AM, 2));
    }

    private NodeLoginTester nodeLoginTester;


    private void assertValidStatus(String status) {
        List<String> apiPossibleStatus = new ArrayList<String>();
        apiPossibleStatus.add("ready");
        apiPossibleStatus.add("configuring");
        apiPossibleStatus.add("failed");
        apiPossibleStatus.add("unknown");

        List<String> otherPossibleStatus = new ArrayList<String>();
        //not valid! but it does occur a lot in practice, so we will not fail but warn for it
        otherPossibleStatus.add("changing");
        otherPossibleStatus.add("notready");

        List<String> possibleStatus = new ArrayList<String>();
        possibleStatus.addAll(apiPossibleStatus);
        possibleStatus.addAll(otherPossibleStatus);

        assertTrue(possibleStatus.contains(status),
                "Invalid geni_status: \"" + status + "\" is not one of " + possibleStatus);

        if (!apiPossibleStatus.contains(status))
            warn("SliverStatus returns invalid geni_status: \"" + status + "\" is not one of " + apiPossibleStatus);
    }

    /**
     * Check for correctness of a AM2 XmlRpc result. Should be tested for each reply received.
     * */
    public void testAM2CorrectnessXmlRpcResult(Hashtable res) {
        assertNotNull(res, "testAM2CorrectnessXmlRpcResult res is null");
        Object code = res.get("code");
        Object value = res.get("value");
        Object output = res.get("output");
        assertNotNull(code, "testAM2CorrectnessXmlRpcResult code == null in " + res);
        assertNotNull(value, "testAM2CorrectnessXmlRpcResult value == null in " + res);
        assertEquals(code.getClass(), Hashtable.class, "testAM2CorrectnessXmlRpcResult code is not Hashtable in " + res);
        Hashtable codeHt = (Hashtable) code;
        Object genicode = codeHt.get("geni_code");
        assertNotNull(genicode, "testAM2CorrectnessXmlRpcResult code does not contain \"geni_code\" in " + res);
        assertEquals(genicode.getClass(), Integer.class, "testAM2CorrectnessXmlRpcResult code.geni_code is not int in " + res);

        int genicodevalue = (Integer) genicode;
        //output should be present if code is not 0
        if (genicodevalue != 0) {
            assertNotNull(output, "testAM2CorrectnessXmlRpcResult: while geni_code is non success ("+genicodevalue+"), output == null in "+res);
            assertEquals(output.getClass(), String.class, "testAM2CorrectnessXmlRpcResult: while geni_code is non success ("+genicodevalue+"), output is not String (it is "+output.getClass().getName()+" with value \""+output.toString()+"\") in \"+res+\"");
        }
        else {
            if (output == null)
                note("testAM2CorrectnessXmlRpcResult: while geni_code is success ("+genicodevalue+"), output is ommited. This is allowed by the API.");
            if (output != null && !(output instanceof String))
                warn("testAM2CorrectnessXmlRpcResult: while geni_code is success ("+genicodevalue+"), output is not String (it is "+output.getClass().getName()+" with value \""+output.toString()+"\"). This is allowed but not recommended by jFed.");
        }
    }


//    @DataProvider(name = "authorities")
//    public Object[][] testAllAuthorites() {
//        List<GeniAuthority> authorities = BuiltinAuthorityList.getBuiltinAuthorities();
//        Object[][] res = new Object[authorities.size()][1];
//        int i = 0;
//        for (GeniAuthority auth: authorities) {
//            res[i++][0] = auth;
//        }
//        return res;
//    }

    public void setUp(CommandExecutionContext testContext) {
        this.testContext = testContext;

        //commonAMTest can create slices on demand and get user credential
        commonAMTest = new CommonAMTest(this, testContext);
        am2 = new AggregateManager2(testContext.getLogger());

        //user credential needs to be retrieved from SA for most tests
        System.out.println("Fetching User credential needed for AM tests");
        userCredential = commonAMTest.getUserCredential();
    }


    private Hashtable versionRawResult = null;
    private AggregateManager2.VersionInfo versionInfo = null;
    @Test(groups = {"getversion"})
    public void testGetVersionXmlRpcCorrectness() throws JFedException {
        AggregateManager2.AggregateManagerReply<AggregateManager2.VersionInfo> reply = am2.getVersion(getAM2Connection());

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        //GetVersion is the only method where we have to check for something extra in the raw XMLRPC result
        versionRawResult = reply.getRawResult();
        assertNotNull(versionRawResult);

        Object ver = versionRawResult.get("geni_api"); //this is here for backward compatibility with v1. GetVersion returns this on all versions.
        assertTrue(ver != null);
        assertTrue(ver instanceof Integer);
        int v = ((Integer) ver).intValue();
        assertTrue(v == 2);

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS, "GeniResponse code is not SUCCESS (0)");

        versionInfo = reply.getValue();
        assertNotNull(versionInfo);
    }
    @Test(hardDepends = { "testGetVersionXmlRpcCorrectness" } )
    public void testGetVersionResultCorrectness() throws JFedException {
        Hashtable value = (Hashtable) versionRawResult.get("value");

        //check if all required fields are present
        assertEquals(value.get("geni_api"), new Integer(2));

        assertNotNull(value.get("geni_api_versions"), "geni_api_versions not in version result");
        assertTrue(value.get("geni_api_versions") instanceof Hashtable, "geni_api_versions is not a Hashtable but a " + value.get("geni_api_versions").getClass().getName());

        String [] rspecVersionListnames = { "geni_request_rspec_versions", "geni_ad_rspec_versions" };
        for (String name : rspecVersionListnames) {
            assertNotNull(value.get(name), name + " not in version result");
            assertTrue(value.get(name) instanceof Vector, name + " is not a Vector but a " + value.get(name).getClass().getName());

            Vector v = (Vector) value.get(name);
            assertTrue(v.size() > 0, name + " array is empty");
            for (Object o : v) {
                assertTrue(o instanceof Hashtable, name + " array should contain only Hashtable not a " + o.getClass().getName());
                Hashtable t = (Hashtable) o;
                assertHashTableContainsNonemptyString(t, "type");
                assertHashTableContainsNonemptyString(t, "version");
                assertHashTableContainsString(t, "schema");
                assertHashTableContainsString(t, "namespace");
                Object extensionsO = t.get("extensions");
                assertNotNull(extensionsO);
                assertTrue(extensionsO instanceof Vector, "value for extensions of " + name + " is not a String but a " + extensionsO.getClass().getName());
                Vector extensions = (Vector) extensionsO;
                for (Object e : extensions)
                    assertTrue(e instanceof String, "an extension of \"+name+\" is not a string but a " + e.getClass().getName());
            }
        }
    }
    @Test(hardDepends = { "testGetVersionResultCorrectness" } )
    public void testGetVersionResultApiVersionsCorrectness() throws JFedException, MalformedURLException {
        Hashtable value = (Hashtable) versionRawResult.get("value");
        Hashtable versions = (Hashtable) value.get("geni_api_versions");

        //test if contains self reference
        Object o = versions.get(new Integer(2));
        if (o == null) {
            warn("geni_api_versions for Integer 2 is null. (Note that for String \"2\" it is \"" + versions.get("2") + "). This test will accept String instead of int, but the API specifies it should be int.");
            o = versions.get("2");
        }
        assertNotNull(o, "geni_api_versions for value 2 is null (tried with both int 2 and string \"2\").");
        assertTrue(o instanceof String, "value for 2 is not a String but a " + o.getClass().getName());

        //test that no url's are correct and none have localhost as hostname
        for (Object key : versions.keySet()) {
            assertTrue(key instanceof Integer || key instanceof String, "geni_api_versions keys should be Integer or String, not " + key.getClass().getName());
            int versionNr;
            if (key instanceof Integer)
                versionNr = (Integer) key;
            else {
                warn("geni_api_versions contains String key \"" + key + "\". This test will accept String instead of int, but the API specifies it should be int.");
                versionNr = Integer.parseInt((String) key);
            }
            Object val = versions.get(key);
            assertTrue(val instanceof String, "geni_api_versions values should be String, not " + val.getClass().getName());
            String urlS = (String) val;
            //check URL
            URL url = new URL(urlS);
            String host = url.getHost();
            assertFalse(host.equals("localhost"), "Illegal host in URL: " + url + " (host in URL should not be the non-global \"" + host + "\")");
            assertFalse(host.equals("127.0.0.1"), "Illegal host in URL: " + url + " (host in URL should not be the non-global \"" + host + "\")");
        }

        Object urn = value.get("urn");
        if (urn != null) {
            setErrorsNotFatal();
            assertInstanceOf(urn, String.class, "if URN is defined, it should be a String, not a "+urn.getClass().getName());
            if (urn instanceof String) {
                String urnString = (String) urn;
                String testUrnString = testContext.getTestedAuthority().getUrn().getValue();
                if (!urnString.equals(testUrnString))
                    warn("URN in GetVersion ("+urnString+") does not match the URN used to start this test ("+testUrnString+
                            "). This could either be a problem on the server, a bad URN in GetVersion, or it could be that " +
                            "the jFed has wrong info about this authority. This failure could result in a failure to allocate " +
                            "resources (as the component_manager urn used will not match this server).");
            }
            setErrorsNotFatal();
        } else {
            note("GetVersion does not specify \"urn\" (which contains the component manager urn). This is not mandatory, but it is useful to include.");
        }
    }
    @Test(hardDepends = { "testGetVersionResultCorrectness" }, softDepends = {"testGetVersionResultApiVersionsCorrectness"})
    public void testGetVersionResultNoDuplicates() throws JFedException {
        //Check if RSpecs are unique
        List<AggregateManager2.VersionInfo.RspecVersion> adRspecVersions = new ArrayList<AggregateManager2.VersionInfo.RspecVersion>();
        for (AggregateManager2.VersionInfo.RspecVersion rspecVer : versionInfo.getAdRspecVersions()) {
            for (AggregateManager2.VersionInfo.RspecVersion other : adRspecVersions)
                assertFalse(other.equalTypeAndVersion(rspecVer), "VersionInfo Result invalid: Duplicate Rspec type/version pair in supported Advertisement RSpec:" +
                        "type=" + other.getType() + " version=" + other.getVersion() + " VS " +
                        "type=" + rspecVer.getType() + " version=" + rspecVer.getVersion() + " ");
            adRspecVersions.add(rspecVer);
        }

        List<AggregateManager2.VersionInfo.RspecVersion> reqRspecVersions = new ArrayList<AggregateManager2.VersionInfo.RspecVersion>();
        for (AggregateManager2.VersionInfo.RspecVersion rspecVer : versionInfo.getRequestRspecVersions()) {
            for (AggregateManager2.VersionInfo.RspecVersion other : reqRspecVersions)
                assertFalse(other.equalTypeAndVersion(rspecVer), "VersionInfo Result invalid: Duplicate Rspec type/version pair in supported Request RSpec" +
                        "type=" + other.getType() + " version=" + other.getVersion() + " VS " +
                        "type=" + rspecVer.getType() + " version=" + rspecVer.getVersion() + " ");
            reqRspecVersions.add(rspecVer);
        }
    }

    @Test(hardDepends = {"testGetVersionXmlRpcCorrectness"}, softDepends = {"testGetVersionResultNoDuplicates"})
    public void testListResourcesBadCredential() throws JFedException {
        //Test without credentials. Should fail.
        AggregateManager2.AggregateManagerReply<String> reply = am2.listResources(
                getAM2Connection(),
                new ArrayList<AnyCredential>(),
                "geni",
                "3",
                true,
                true,
                null,
                null);

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        assertFalse(reply.getGeniResponseCode().isSuccess());
    }

    @Test(hardDepends = {"testGetVersionXmlRpcCorrectness"}, softDepends = {"testGetVersionResultNoDuplicates"})
    public void testSliverStatusBadSlice() throws JFedException {
        String badSliceUrn = "urn:publicid:IDN+"+testContext.getUserAuthority().getNameForUrn()+"+slice+NonExisting";

        AggregateManager2.AggregateManagerReply<AggregateManager2.SliverStatus> reply =
                am2.sliverStatus(getAM2Connection(), getUserCredentialList(), badSliceUrn, null);

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        assertFalse(reply.getGeniResponseCode().isSuccess(), "SliverStatus reply GeniResponse code is SUCCESS (0) when given a non existing slice \"" + badSliceUrn + "\"");
    }

    private CommonAMTest.SliceInfo sliceNoSliver;
    @Test(hardDepends = {"testGetVersionXmlRpcCorrectness"}, softDepends = {"testGetVersionResultNoDuplicates"})
    public void testCreateSliceNoSliver() throws JFedException {
        //create a slice to use in AM tests

        sliceNoSliver = commonAMTest.createSlice("n");
        assert sliceNoSliver != null;
        assert sliceNoSliver.urn != null : "sliceNoSliver.urn is null";
        assert sliceNoSliver.urn.getValue().startsWith("urn:publicid:IDN+");
        assert sliceNoSliver.credential != null : "sliceNoSliver.credential is null";
    }

    @Test(hardDepends = {"testCreateSliceNoSliver"} )
    public void testSliverStatusNoSliverSlice() throws JFedException {
        assert sliceNoSliver != null;

        //then check if SliverStatus reports not found as it should
        AggregateManager2.AggregateManagerReply<AggregateManager2.SliverStatus> reply =
                am2.sliverStatus(getAM2Connection(), toCredentialList(sliceNoSliver.credential), sliceNoSliver.urn.getValue(), null);

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        assertFalse(reply.getGeniResponseCode().isSuccess(),
                "SliverStatus reply GeniResponse code is SUCCESS (0) when given a slice \"" + sliceNoSliver.urn + "\" that has no sliver. (should fail because no sliver found for the slice)");

        assertNotNull(reply.getRawResult());
        Object rawValueResult = reply.getRawResult().get("value");
        if (rawValueResult != null) {
            //it does not need to have a result, but when it does, it should be a valid one.
            warnIfNot(rawValueResult instanceof Hashtable, "SliverStatus result is not null, which is allowed on failure,"+
                    " but in that case it is expected to be a valid response, which would be a struct. However, it is a "+
                    rawValueResult.getClass().getSimpleName()+" -> value=\""+rawValueResult.toString()+"\"");
        }
        warnIfNot((rawValueResult != null) == (reply.getValue() != null),
                "Mismatch: SliverStatus processed result value is "+
                        (reply.getValue() != null ? "not null" : "null")+" but RAW SliverStatus result value is "+
                        (rawValueResult != null ? "not null" : "null"));
    }



    //helpers for finding a fixed node in the list
    private String fixedNodeUrn = null;
    private String fixedNodeSliverType = null;
    @Test(hardDepends = {"testGetVersionXmlRpcCorrectness"}, softDepends = {"testGetVersionResultNoDuplicates"}, groups = {"listavailableresources", "nodelogin"})
    public void testListResourcesAvailableNoSlice() throws JFedException {
        String rspec = testListResourcesAvailableNoSlice_internal("geni", "3", true);

        String testUrnString = testContext.getTestedAuthority().getUrn().getValue();

        //check if it contains any nodes component_manager_urn matching the testUrnString
        int nodecount = 0;
        int matchingNodecount = 0;
        Set<String> componentManagerIds = new HashSet<String>();

        //helpers for finding a fixed node in the list
        String fixedNodeUrn = null;
        String fixedNodeSliverType = null;

        try {
            Class docClass = be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents.class;
            String packageName = docClass.getPackage().getName();
            JAXBContext jc = JAXBContext.newInstance(packageName);
            Unmarshaller u = jc.createUnmarshaller();
            JAXBElement<RSpecContents> doc =
                    (JAXBElement<be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents>) u.unmarshal( new StringReader(rspec));
            be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents c = doc.getValue();

            String typ = c.getType();
            assertNotNull(typ, "Received advertisement RSpec does not specify a type: " + rspec);
            assertEquals(typ, "advertisement", "Received advertisement RSpec is not a advertisement, it is a: \"" + typ + "\"");

            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    if (el.getValue() instanceof be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.NodeContents) {
                        be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.NodeContents node = (be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.NodeContents) el.getValue();

                        nodecount++;

                        String componentManagerId = node.getComponentManagerId();
                        String nodeId = node.getComponentId();
                        componentManagerIds.add(componentManagerId);

                        if (componentManagerId.equals(testUrnString))
                            matchingNodecount++;

                        List<String> sliverTypeNames = new ArrayList<String>();
                        for (Object nodeElO : node.getAnyOrRelationOrLocation()) {
                            if (nodeElO instanceof JAXBElement) {
                                JAXBElement nodeEl = (JAXBElement) nodeElO;
                                if (nodeEl.getValue() instanceof NodeContents.SliverType) {
                                    NodeContents.SliverType st = (NodeContents.SliverType) nodeEl.getValue();
                                    String sliverTypeName = st.getName();
                                    sliverTypeNames.add(sliverTypeName);

                                    if (componentManagerId.equals(testUrnString)) {
                                        if (fixedNodeUrn == null ||
                                                CommonAMTest.preferSliverType(sliverTypeName, fixedNodeSliverType)) {
                                            fixedNodeUrn = nodeId;
                                            fixedNodeSliverType = sliverTypeName;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (JAXBException e) {
            throw new RuntimeException("Exception parsing advertisement RSpec Xml: "+e.getMessage(), e);
        }

        if (matchingNodecount == 0) {
            if (componentManagerIds.isEmpty())
                warn("Could not find a single node for this component_managers_id ("+testUrnString+") in the advertisement. No nodes of other component_managers_id's found either.");
            else
                warn("Could not find a single node for this component_managers_id ("+testUrnString+") in the advertisement. Did find nodes for the following component_managers_id's: "+componentManagerIds);
            warn("There are probably no free nodes left");
        } else {
            note("Found nodes for the following component_managers_id's: "+ componentManagerIds);
        }

        if (fixedNodeUrn == null)
            warn("Could not find a suitable fixed node in the advertisement request");
        else
            note("Found potential fixed node: " + fixedNodeUrn);
        note("Best sliver type found: "+fixedNodeSliverType);
    }

    @Test(hardDepends = {"testGetVersionXmlRpcCorrectness"}, softDepends = {"testGetVersionResultNoDuplicates", "testListResourcesAvailableNoSlice"}, groups = {"listavailableresources"})
    public void testListResourcesAvailableNoSliceUpperCase() throws JFedException {
        note("This tests if uppercase rspec type also works. The AMv2 API says: \"type and version are case-insensitive strings, matching those in geni_ad_rspec_versions as returned by GetVersion at this aggregate.\"");
        testListResourcesAvailableNoSlice_internal("GENI", "3", true);
    }

    public String testListResourcesAvailableNoSlice_internal(String rspecType, String rspecVersion, boolean available) throws JFedException {
        assert userCredential != null;

        //check if SliverStatus reports not found as it should
        //check without available option
        AggregateManager2.AggregateManagerReply<String> reply =
                am2.listResources(getAM2Connection(), toCredentialList(userCredential), rspecType, rspecVersion, available/*available*/, true/*compressed*/, null, null);

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "ListResources reply GeniResponse code is not SUCCESS (0) when given no slice urn and available="+available);

        String rspec = reply.getValue();
        assertNotNull(rspec, "ListResources reply is completely empty when given no slice urn and available="+available);

        int nodeCount = CommonAMTest.testValidGeni3AdvertisementRspec(this, rspec);
        note("The received RSpec has a length of "+rspec.length()+" characters, and lists "+nodeCount+" nodes.");

        return rspec;
    }

    @Test(hardDepends = {"testCreateSliceNoSliver"})
    public void testListResourcesNoSliverSlice() throws JFedException {
        assert sliceNoSliver != null : "sliceNoSliver is null";

        //check if SliverStatus reports not found as it should
        //check without available option
        AggregateManager2.AggregateManagerReply<String> reply =
                am2.listResources(getAM2Connection(), toCredentialList(sliceNoSliver.credential), "geni", "3", null/*available*/, true/*compressed*/, sliceNoSliver.urn.getValue(), null);

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        String specsText = "ListResources returns an RSpec in GENI standard schema. \n" +
                "When a valid geni_slice_urn option is supplied, the returned RSpec will be a Manifest RSpec of the type corresponding to geni_rspec_version, but in manifest format. \n" +
                "If no resources are allocated to the indicated slice by this aggregate, an empty RSpec should be returned -- aggregates should NOT return an error.";

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "ListResources reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=unspecified). (according to the specs:\"" + specsText + "\")");

        String rspec = reply.getValue();
        assertNotNull(rspec,
                "ListResources reply is completely empty when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=unspecified). (according to the specs:\"" + specsText + "\")");

        assertEquals(CommonAMTest.testValidGeni3ManifestRspec(this, rspec), 0,
                "ListResources reply when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=unspecified) is not an valid RSpec (according to the specs:\"" + specsText + "\"): " + rspec);

        assertTrue(CommonAMTest.isEmptyRspec(this, rspec),
                "ListResources reply when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=unspecified) is not an empty RSpec (according to the specs:\"" + specsText + "\"): " + rspec);

        //TODO check if it is a manifest and not a request or advertisement RSpec
    }

    /* same as testListResourcesNoSliverSlice but with available option added. should make no difference. */
    @Test(hardDepends = {"testCreateSliceNoSliver"})
    public void testListResourcesNoSliverSliceAvailable() throws JFedException {
        assert sliceNoSliver != null : "sliceNoSliver is null";

        String specsText = "ListResources returns an RSpec in GENI standard schema. \n" +
                "When a valid geni_slice_urn option is supplied, the returned RSpec will be a Manifest RSpec of the type corresponding to geni_rspec_version, but in manifest format. \n" +
                "If no resources are allocated to the indicated slice by this aggregate, an empty RSpec should be returned -- aggregates should NOT return an error.";

        //Test with available TRUE
        AggregateManager2.AggregateManagerReply<String> reply =
                am2.listResources(getAM2Connection(), toCredentialList(sliceNoSliver.credential), "geni", "3", true/*available*/, true/*compressed*/, sliceNoSliver.urn.getValue(), null);

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "ListResources reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=true). (according to the specs:\"" + specsText + "\")");

        String rspec = reply.getValue();
        assertNotNull(rspec,
                "ListResources reply is completely empty when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=unspecified). (according to the specs:\"" + specsText + "\")");

        assertEquals(CommonAMTest.testValidGeni3ManifestRspec(this, rspec), 0,
                "ListResources reply  when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=true) is not an valid RSpec (according to the specs:\"" + specsText + "\"): " + rspec);

        assertTrue(CommonAMTest.isEmptyRspec(this, rspec),
                "ListResources reply  when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=true) is not an empty RSpec (according to the specs:\"" + specsText + "\"): " + rspec);


        //Test with available FALSE
        reply = am2.listResources(getAM2Connection(), toCredentialList(sliceNoSliver.credential), "geni", "3", false/*available*/, true/*compressed*/, sliceNoSliver.urn.getValue(), null);

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "ListResources reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=false). (according to the specs:\"" + specsText + "\")");

        rspec = reply.getValue();
        assertNotNull(rspec,
                "ListResources reply is completely empty when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=unspecified). (according to the specs:\"" + specsText + "\")");

        assertEquals(CommonAMTest.testValidGeni3ManifestRspec(this, rspec), 0,
                "ListResources reply  when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=false) is not an valid RSpec (according to the specs:\"" + specsText + "\"): " + rspec);

        assertTrue(CommonAMTest.isEmptyRspec(this, rspec),
                "ListResources reply  when given a slice \"" + sliceNoSliver.urn + "\" that has" +
                        " no sliver (available=false) is not an empty RSpec (according to the specs:\"" + specsText + "\"): " + rspec);
    }






    private CommonAMTest.SliceInfo sliceSliver;
    @Test(softDepends = {"testGetVersionResultApiVersionsCorrectness", "testGetVersionResultNoDuplicates"}, hardDepends = {"testGetVersionXmlRpcCorrectness"} )
    public void testCreateSliceSliver() throws JFedException {
        //create a slice to use in AM tests
        sliceSliver = commonAMTest.createSlice("s");
        assert sliceSliver != null;
        assert sliceSliver.urn != null : "sliceSliver.urn is null";
        assert sliceSliver.urn.getValue().startsWith("urn:publicid:IDN+");
        assert sliceSliver.credential != null : "sliceSliver.credential is null";
    }

    private String createSliverManifestRspec = null;
    @Test(hardDepends = {"testCreateSliceSliver"}, softDepends = {"testListResourcesAvailableNoSlice"} )
    public void testCreateSliver() throws JFedException, NoSuchAlgorithmException {
        assert sliceSliver != null : "sliceSliver is null";

        assert nodeLoginTester == null;
        String fixedSshPublicKeyFile = getTestConfig().getProperty("fixed_ssh_public_key_file");
        String fixedSshPrivateKeyFile = getTestConfig().getProperty("fixed_ssh_private_key_file");
        String fixedSshPrivateKeyPassword = getTestConfig().getProperty("fixed_ssh_private_key_password");
        nodeLoginTester = new NodeLoginTester(this, fixedSshPublicKeyFile, fixedSshPrivateKeyFile, fixedSshPrivateKeyPassword);

        String requestRspec = CommonAMTest.getOneNodeRequestRSpec(testContext.getTestedAuthority());
        if (requestRspec == null) skip("testCreateSliver skipped, because no RSpec example known for type=\""+testContext.getTestedAuthority().getType()+"\"");  


        //TODO: use these to check generated request
        //fixedNodeUrn
        //fixedNodeSliverType


        //CreateSliver needs to generate it's own SSH keypair and use the public key.
        String sshKey = "todo";
        Vector<String> sshKeys = new Vector<String>();
        sshKeys.add(nodeLoginTester.getSshKeyHelper().getSshPublicKeyString());
        UserSpec user = new UserSpec(testContext.getGeniUser().getUserUrnString(), sshKeys);
        List<UserSpec> users = new ArrayList<UserSpec>();
        users.add(user);
        AggregateManager2.AggregateManagerReply<String> reply = am2.createSliver(getAM2Connection(), toCredentialList(sliceSliver.credential), sliceSliver.urn.getValue(), requestRspec, users, null);

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS, "CreateSliver did not succeed");

        createSliverManifestRspec = reply.getValue();
        assertEquals(CommonAMTest.testValidGeni3ManifestRspec(this, createSliverManifestRspec), 1,
                "CreateSliver did not return a valid RSpec" + createSliverManifestRspec);

        assertNotNull(nodeLoginTester);
        assertFalse(nodeLoginTester.hasParsed());
        nodeLoginTester.parseSshInfoFromGeni3ManifestRspec(createSliverManifestRspec);

        assertFalse(CommonAMTest.isEmptyRspec(this, createSliverManifestRspec),
                "CreateSliver returned and empty RSpec: " + createSliverManifestRspec);

        System.out.println("Created sliver for \"" + sliceSliver.urn.getValue() + "\" manifestRspec=" + createSliverManifestRspec);
    }

    public void validSuccesStatus(AggregateManager2.AggregateManagerReply<AggregateManager2.SliverStatus> reply) {
        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "SliverStatus reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceSliver.urn.getValue() + "\" that has a sliver.");

        assertEquals(reply.getRawResult().get("value").getClass(), Hashtable.class,
                "SliverStatus value should be a Hashtable. Not: " + reply.getRawResult().get("value"));

        Hashtable rawValue = (Hashtable) reply.getRawResult().get("value");
        String geniUrn = assertHashTableContainsNonemptyString(rawValue, "geni_urn");
        assertValidUrn(geniUrn, null); //type slice or sliver allowed
        String urntype = GeniUrn.parse(geniUrn).getResourceType();
        if (!urntype.equals("sliver")) {
            if (urntype.equals("slice"))
                warn("URN type in SliverStatus is \"slice\", but expecting \"sliver\". This is not in compliance with API.");
            else
                throw new RuntimeException("urntype is "+urntype+" in "+geniUrn+" but expecting \"sliver\"");
        }
        String geniStatus = assertHashTableContainsNonemptyString(rawValue, "geni_status");
        assertValidStatus(geniStatus);
        Vector geniResources = assertHashTableContainsVector(rawValue, "geni_resources");

        for (Object geniResource : geniResources) {
            assertNotNull(geniResource);
            assertEquals(geniResource.getClass(), Hashtable.class, "one of the geni_resources is not a Hashtable but a " + geniResource.getClass().getName());
            Hashtable ht = (Hashtable) geniResource;
            String resourceUrn = assertHashTableContainsNonemptyString(ht, "geni_urn");
            assertValidUrn(resourceUrn, null);
            String resourceStatus = assertHashTableContainsNonemptyString(ht, "geni_status");
            assertValidStatus(resourceStatus);
            assertHashTableContainsString(ht, "geni_error");
        }
    }

    @Test(hardDepends = {"testCreateSliver"} )
    public void testSliverStatusExistingSliver() throws JFedException {
        //Test SliverStatus with created sliver
        assert sliceSliver != null : "sliceSliver is null";

        AggregateManager2.AggregateManagerReply<AggregateManager2.SliverStatus> reply =
                am2.sliverStatus(getAM2Connection(), toCredentialList(sliceSliver.credential), sliceSliver.urn.getValue(), null);

        validSuccesStatus(reply);
    }

    @Test(hardDepends = {"testCreateSliver"} )
    public void testListResourcesExistingSliver() throws JFedException {
        //Test ListResources on created sliver
        assert sliceSliver != null : "sliceSliver is null";

        AggregateManager2.AggregateManagerReply<String> reply =
                am2.listResources(getAM2Connection(), toCredentialList(sliceSliver.credential), "geni", "3", null/*available*/, true/*compressed*/, sliceSliver.urn.getValue(), null);

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "ListResources reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceSliver.urn.getValue() + "\" that has a sliver.");

        String rspec = reply.getValue();
        assertEquals(CommonAMTest.testValidGeni3ManifestRspec(this, rspec), 1,
                "ListResources reply  when given a slice \"" + sliceSliver.urn.getValue() + "\" that has" +
                        " a sliver is not an valid RSpec: " + rspec);

        assertFalse(CommonAMTest.isEmptyRspec(this, rspec),
                "ListResources reply  when given a slice \"" + sliceSliver.urn.getValue() + "\" that has" +
                        " a sliver is an empty RSpec: " + rspec);
    }

    @Test(hardDepends = { "testCreateSliver" }, softDepends = { "testSliverStatusExistingSliver", "testListResourcesExistingSliver" }, groups = {"createsliver"} )
    public void testCreatedSliverBecomesReady() throws JFedException {
        //Test if the sliver ever becomes ready. We wait for maximum 20 minutes.
        assert sliceSliver != null : "sliceSliver is null";

        long now = System.currentTimeMillis();
        long deadline = now + (20*60*1000);
        while (now < deadline) {
            AggregateManager2.AggregateManagerReply<AggregateManager2.SliverStatus> reply =
                    am2.sliverStatus(getAM2Connection(), toCredentialList(sliceSliver.credential), sliceSliver.urn.getValue(), null);

            validSuccesStatus(reply);
            Hashtable rawValue = (Hashtable) reply.getRawResult().get("value");
            String geniStatus = assertHashTableContainsNonemptyString(rawValue, "geni_status");
            if (geniStatus.equals("ready")) {
                System.out.println("testCreatedSliverBecomesReady -> sliver ready: "+rawValue);
                return;
            }

            System.out.println("testCreatedSliverBecomesReady -> sliver not ready: "+geniStatus+".  Trying again in 30 seconds...");
            try {
                Thread.sleep(30000 /*ms*/);
            } catch (InterruptedException e) { /* Ignore*/ }
            now = System.currentTimeMillis();
        }
        throw new RuntimeException("Sliver did not become ready within 20 minutes!");
    }

    @Test(hardDepends = {"testCreatedSliverBecomesReady"})
    public void checkManifestOnceSliverIsReady() throws JFedException, IOException {
        //fetch manifest once sliver is ready, and compare it. Warn if differs.
        //it might have SSH info now that it did not have before!

        AggregateManager2.AggregateManagerReply<String> reply =
                am2.listResources(getAM2Connection(), toCredentialList(sliceSliver.credential), "geni", "3", null/*available*/, true/*compressed*/, sliceSliver.urn.getValue(), null);

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "ListResources reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceSliver.urn.getValue() + "\" that has a sliver.");

        String rspec = reply.getValue();
        assertEquals(CommonAMTest.testValidGeni3ManifestRspec(this, rspec), 1,
                "ListResources reply  when given a slice \"" + sliceSliver.urn.getValue() + "\" that has" +
                        " a sliver is not an valid RSpec: " + rspec);

        assertFalse(CommonAMTest.isEmptyRspec(this, rspec),
                "ListResources reply  when given a slice \"" + sliceSliver.urn.getValue() + "\" that has" +
                        " a sliver is an empty RSpec: " + rspec);

        String manifestRspec = reply.getValue();

        if (!manifestRspec.equals(createSliverManifestRspec)) {
            note("Manifest RSpec returned by ListResources after Sliver becomes ready differs from manifest RSpec returned by CreateSliver");
            note("Manifest RSpec returned by CreateSliver "+
                    (createSliverManifestRspec.contains("ssh-keys")?"contains":"DOES NOT contain")+" 'ssh-keys'."+
                    " length="+createSliverManifestRspec.length()+" chars. ");
            note("Manifest RSpec returned by ListResources after Sliver becomes ready "+
                    (manifestRspec.contains("ssh-keys")?"contains":"DOES NOT contain")+" 'ssh-keys'." +
                    " length="+manifestRspec.length()+" chars.");
            nodeLoginTester.parseSshInfoFromGeni3ManifestRspec(manifestRspec);
        }
    }


    @Test(hardDepends = {"checkManifestOnceSliverIsReady"}, groups = {"nodelogin"} )
    public void testNodeLogin() throws JFedException, IOException {
        assert nodeLoginTester != null;
        assert nodeLoginTester.hasParsed();

        nodeLoginTester.testNodeLogin();
    }

    @Test(hardDepends = {"testCreatedSliverBecomesReady"}, softDepends = {"testNodeLogin"} )
    public void testRenewSliver() throws JFedException {
        assert sliceSliver != null : "sliceSliver is null";

        //Test Renew Sliver. Renew so it expires in 5 minutes
        Date expirationTime = new Date(System.currentTimeMillis() + (5 * 60 * 1000));
        AggregateManager2.AggregateManagerReply<Boolean> reply = am2.renewSliver(getAM2Connection(), toCredentialList(sliceSliver.credential), sliceSliver.urn.getValue(), expirationTime, null);

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "RenewSliver reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceSliver.urn.getValue() + "\" that has a sliver.");

        assertTrue(reply.getValue(),
                "RenewSliver reply's value (which means success) is not true when given a slice \"" + sliceSliver.urn.getValue() + "\" that has a sliver.");

    }

    /* Test must run after tests that use sliver. Will always run, to cleanup any created sliver. */
    @Test(softDepends = {"testNodeLogin", "testRenewSliver", "testCreatedSliverBecomesReady", "checkManifestOnceSliverIsReady"}, groups = {"createsliver","nodelogin"})
    public void testDeleteSliver() throws JFedException {
        if (sliceSliver == null) skip("DEBUG: Skipped because other test created nothing to delete");

        assert sliceSliver != null : "sliceSliver is null";

        System.out.println("DeleteSliver for slice " + sliceSliver.urn.getValue());

        //Test Delete Sliver
        AggregateManager2.AggregateManagerReply<Boolean> reply = am2.deleteSliver(getAM2Connection(), toCredentialList(sliceSliver.credential), sliceSliver.urn.getValue(), null);

        testAM2CorrectnessXmlRpcResult(reply.getRawResult());

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "DeleteSliver reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceSliver.urn.getValue() + "\" that has a sliver.");

        assertTrue(reply.getValue(),
                "DeleteSliver reply's value (which means success) is not true when given a slice \"" + sliceSliver.urn.getValue() + "\" that has a sliver.");
    }

    //TODO we could also test if DeleteSliver worked
}
