package be.iminds.ilabt.jfed.lowlevel.api.test;

import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.UserAndSliceApiWrapper;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl.AutomaticUserAndSliceApiWrapper;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents;
import be.iminds.ilabt.jfed.testing.base.ApiTest;
import be.iminds.ilabt.jfed.util.CommandExecutionContext;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.StringReader;
import java.util.*;

/**
 * CommonAMTest:
 *
 *   methods for common tests in AM's
 */
public class CommonAMTest {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    public static String getComponentManagerIdForSite(SfaAuthority auth) {
        if (auth.getType() != null && auth.getType().equals("emulab"))
            return auth.getUrnString();
        if (auth.getType() != null && auth.getType().equals("instageni"))
            return auth.getUrnString();
        if (auth.getType() != null && auth.getType().equals("planetlab"))
            return auth.getUrnString();
        if (auth.getType() != null && (auth.getType().equals("orca") || auth.getType().equals("exogeni"))) {
            //see https://geni-orca.renci.org/trac/wiki/orca-and-rspec
            String sitename = null;
            if (auth.getUrnString().equals("urn:publicid:IDN+geni.renci.org+authority+cm")) //"ties resources from all"
                sitename = "exogeni.net"; //just a guess, perhaps this is ANY?
            // Note: There is a way to select any, but I do not know the urn: see https://wiki.exogeni.net/doku.php?id=public:experimenters:start#selecting_which_orca_actor_to_request_resources_from
            if (auth.getUrnString().equals("urn:publicid:IDN+bbn-hn.exogeni.net+authority+cm"))
                sitename = "exogeni.net:bbnvmsite";
            if (auth.getUrnString().equals("urn:publicid:IDN+dbc1-16.nicl.cs.duke.edu+authority+cm"))
                sitename = "exogeni.net:dukevmsite";
            if (auth.getUrnString().equals("urn:publicid:IDN+fiu-hn.exogeni.net+authority+cm"))
                sitename = "exogeni.net:fiuvmsite";
            if (auth.getUrnString().equals("urn:publicid:IDN+nicta-hn.exogeni.net+authority+cm"))
                sitename = "exogeni.net:nictavmsite";
            if (auth.getUrnString().equals("urn:publicid:IDN+rci-hn.exogeni.net+authority+cm"))
                sitename = "exogeni.net:rcivmsite";
            if (auth.getUrnString().equals("urn:publicid:IDN+uh-hn.exogeni.net+authority+cm"))
                sitename = "exogeni.net:uhvmsite";
            if (auth.getUrnString().equals("urn:publicid:IDN+uva-nl-hn.exogeni.net+authority+cm"))
                sitename = "exogeni.net:uvanlvmsite";
            if (auth.getUrnString().equals("urn:publicid:IDN+ufl-hn.exogeni.net+authority+cm"))
                sitename = "exogeni.net:uflvmsite";
            if (auth.getUrnString().equals("urn:publicid:IDN+osf-hn.exogeni.net+authority+cm"))
                sitename = "exogeni.net:osfvmsite";
            //note, there is also uncvmsite: University NC (but URN and URL not known)


            if (sitename != null)
                return "urn:publicid:IDN+"+sitename+"+authority+cm";
        }
        return auth.getUrnString();
    }

    public static boolean getExclusiveForSite(SfaAuthority auth) {
        String sliverType = getSliverTypeForSite(auth);
        if (sliverType.equals("raw-pc"))
            return true;
        else
            return false;
    }

    public static String getSliverTypeForSite(SfaAuthority auth) {
        if (auth.getType() != null && auth.getType().equals("emulab"))
            return "raw-pc";
        if (auth.getType() != null && auth.getType().equals("instageni"))
            return "emulab-openvz";
        if (auth.getType() != null && auth.getType().equals("planetlab"))
            return "plab-vserver";
        if (auth.getType() != null && (auth.getType().equals("orca") || auth.getType().equals("exogeni")))
            return "xo.small";
        if (auth.getNameForUrn().contains("exogeni") || auth.getNameForUrn().contains("vmsite") || auth.getNameForUrn().contains("orca"))
            return "xo.small";

        return null;
    }

    /** returns an RSpec for one node, for the given authority. */
    public static String getOneNodeRequestRSpec(SfaAuthority auth) {
        if (auth.getType() != null && auth.getType().equals("emulab")) {
            return "<rspec type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
                    "  <node client_id=\"PC\" component_manager_id=\""+auth.getUrnString()+"\" exclusive=\"true\">\n" +
                    "    <sliver_type name=\"raw-pc\"/>\n" +
                    "  </node>\n" +
                    "</rspec>\n";
        }
        if (auth.getUrn().equals(GeniUrn.parse("urn:publicid:IDN+fiteagle+authority+am"))) {
            Random rand = new Random(System.currentTimeMillis());
            return "<rspec type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/ad.xsd http://fiteagle.org/rspec/ext/1 http://fiteagle.org/rspec/ext/1\" xmlns:ns2=\"http://fiteagle.org/rspec/ext/1\" xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:ns3=\"http://fiteagle.org/rspec/ext/1/openstackVMResource\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                    "<ns3:openstackResource resourceId=\"42ad1e74-c9cd-4fe0-9d18-522b7f8bede1\">\n" +
                    "<ns3:vmToInstantiate imageId=\"d6521c1b-4407-454a-981f-b5d4d4d5fcae\" flavorId=\"3\" vmName=\"randomName"+rand.nextInt()+"\" keyPairName=\"randomKeyPair"+rand.nextInt()+"\"/>\n" +
                    "</ns3:openstackResource>\n" +
                    "</rspec>";
        }
        if (auth.getType() != null && auth.getType().equals("instageni")) {
            return "<rspec type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
                    "  <node client_id=\"PC\" component_manager_id=\""+auth.getUrnString()+"\" exclusive=\"false\">\n" +
                    "    <sliver_type name=\"emulab-openvz\"/>\n" +
//                    "    <sliver_type name=\"emulab-xen\"/>\n" +
                    "  </node>\n" +
                    "</rspec>\n";
        }
        if (auth.getType() != null && auth.getType().equals("planetlab")) {
            return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
                    "   <rspec type=\"request\" " +
                    " xmlns=\"http://www.geni.net/resources/rspec/3\" >\n" +
                    "       <node client_id=\"node0\" " +
                    " component_id=\"urn:publicid:IDN+ple:unistra+node+planetlab1.u-strasbg.fr\" " +
                    " component_manager_id=\"urn:publicid:IDN+ple:ibbtple+authority+cm\" " +
                    " component_name=\"planetlab1.u-strasbg.fr\" " +
                    " exclusive=\"false\">\n" +
                    "           <sliver/>\n" +
                    "           <sliver_type name=\"plab-vserver\"/>\n" +
                    "           <location country=\"unknown\" longitude=\"7.73833\" latitude=\"48.5237\"/>\n" +
                    "           <hardware_type name=\"plab-pc\"/>\n" +
                    "           <hardware_type name=\"pc\"/>\n" +
                    "       </node>\n" +
                    "   </rspec>";
            //OLD
//            return "<rspec type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
//                    "    <node component_id=\"urn:publicid:IDN+ple:unistra+node+planetlab1.u-strasbg.fr\" component_manager_id=\"urn:publicid:IDN+ple+authority+cm\" component_name=\"planetlab1.u-strasbg.fr\" exclusive=\"false\">\n" +
//                    "           <hardware_type name=\"plab-pc\"/>\n" +
//                    "           <hardware_type name=\"pc\"/>\n" +
//                    "           <location country=\"unknown\" latitude=\"48.5237\" longitude=\"7.73833\"/>\n" +
//                    "           <sliver_type name=\"plab-vserver\">\n" +
//                    "           </sliver_type>\n" +
//                    "       </node>\n" +
//                    "   </rspec>";
        }
        if (auth.getType() != null && (auth.getType().equals("orca") || auth.getType().equals("exogeni"))) {
            //see https://geni-orca.renci.org/trac/wiki/orca-and-rspec
            String componentManagerId = getComponentManagerIdForSite(auth);

            return "<rspec type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
                    //                    "  <node client_id=\"PC\" component_manager_id=\""+auth.getUrnString()+"\" exclusive=\"false\">\n" +
                    "  <node client_id=\"PC\" component_manager_id=\""+componentManagerId+"\" exclusive=\"false\">\n" +
                    //                    "    <sliver_type name=\"ExoGENI-M4\"/>\n" + //bare metal node
                    "    <sliver_type name=\"xo.small\"/>\n" +   //1 core node (smallest available)
                    "  </node>\n" +
                    "</rspec>\n";
        }

        //otherwise, request a non exclusive node without specifying sliver type
        return "<rspec type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
                "  <node client_id=\"PC\" component_manager_id=\""+auth.getUrnString()+"\" exclusive=\"false\">\n" +
                "  </node>\n" +
                "</rspec>\n";
    }

    public static boolean isEmptyRspec(ApiTest test, String rspec) {
        if (rspec == null || rspec.trim().isEmpty())
            return true;

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(rspec));
            Document doc = db.parse(is);

            Element rootEl = doc.getDocumentElement();

            String rootElName = rootEl.getTagName();
            if (!rootElName.equalsIgnoreCase("rspec")) {
                throw new RuntimeException("Not an rspec (root element tag name="+rootElName+"): "+rspec);
            }

            NodeList childNodeList = rootEl.getChildNodes();
            for (int i = 0; i < childNodeList.getLength(); i++) {
                Node n = childNodeList.item(i);

                if (n instanceof Element) {
                    Element e = (Element) n;
                    String childName = e.getTagName();
                    if (childName.equalsIgnoreCase("node"))
                        return false;
                    if (childName.equalsIgnoreCase("link"))
                        return false;

                    //hack for PLE
                    if (childName.equalsIgnoreCase("network"))
                        return false;
                }
            }
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("ParserConfigurationException while testing if rspec is empty: "+e.getMessage(), e);
        } catch (SAXException e) {
            throw new RuntimeException("SAXException while testing if rspec is empty: "+e.getMessage(), e);
        } catch (IOException e) {
            throw new RuntimeException("IOException while testing if rspec is empty: "+e.getMessage(), e);
        }
        return true;
    }

    /**
     * returns nodecount
     * */
    public static int testValidGeni3ManifestRspec(ApiTest test, String rspec) {
        if (rspec == null) return -1;
        test.assertNotNull(rspec, "Rspec is null");

        int nodeCount = 0;

        //quick HACK to allow the planetlab Europe rspec manifest
        // FEDIBBTDEV-113, bvermeul, copied this nice stuff from suite/rspec-edit/src/main/java/be/iminds/ilabt/jfed/ui/rspeceditor/model/Rspec.java
        if (rspec.contains("<RSpec")) {
            test.note("We received an SFA RSpec instead of a GENI RSpec v3, but we'll try to work around.");
            //logger.debug("HACK: rewriting received planetlab manifest XML to make it parsable xml");
            rspec = rspec.replace("<RSpec type=\"SFA\"", "<rspec xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" type=\"manifest\"");
            rspec = rspec.replace("<RSpec ", "<rspec xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" type=\"manifest\"");
            rspec = rspec.replace("</RSpec>", "</rspec>");
            rspec = rspec.replace("<network name=\"ple\">", "");
            rspec = rspec.replace("</network>", "");
            //logger.debug("HACK: rewriten xml: "+rspec);
        }



        //parse the RSpec XML
        try {
            Class docClass = be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents.class;
            String packageName = docClass.getPackage().getName();
            JAXBContext jc = JAXBContext.newInstance(packageName);
            Unmarshaller u = jc.createUnmarshaller();
            JAXBElement<RSpecContents> doc = (JAXBElement<be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents>) u.unmarshal( new StringReader(rspec));
            be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents c = doc.getValue();

            be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RspecTypeContents typ = c.getType();
            test.assertNotNull(typ, "Received manifest RSpec does not specify a type: " + rspec);
            test.assertEquals(typ.value(), "manifest", "Received manifest RSpec is not a manifest: " + rspec);

            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    if (el.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents) {
                        be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents node = (be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents) el.getValue();

                        String nodeName = node.getClientId();
                        nodeCount++;

                        for (Object nodeElO : node.getAnyOrRelationOrLocation()) {
                            if (nodeElO instanceof JAXBElement) {
                                JAXBElement nodeEl = (JAXBElement) nodeElO;
                                //                                if (nodeEl.getValue() instanceof InterfaceContents) {
                                //                                    InterfaceContents ic = (InterfaceContents) nodeEl.getValue();
                                //                                    String interfaceName = ic.getClientId();
                                //                                }
                            }
                        }
                    }
                    //                    if (el.getValue() instanceof LinkContents) {
                    //                        LinkContents link = (LinkContents) el.getValue();
                    //
                    //                        String linkname = link.getClientId();
                    //
                    //                        for (Object linkElO : link.getAnyOrPropertyOrLinkType()) {
                    //                            if (linkElO instanceof JAXBElement) {
                    //                                JAXBElement linkEl = (JAXBElement) linkElO;
                    //                                if (linkEl.getValue() instanceof InterfaceRefContents) {
                    //                                    InterfaceRefContents ic = (InterfaceRefContents) linkEl.getValue();
                    //                                    String interfaceName = ic.getClientId();
                    //                                }
                    //                            }
                    //                        }
                    //                    }
                }
            }
        } catch (JAXBException e) {
            throw new RuntimeException("Exception parsing manifest RSpec Xml: "+e.getMessage(), e);
        }

        //        assertTrue(nodeCount > 0, "No nodes found in manifest rspec: "+rspec);

        return nodeCount;
    }
    /**
     * returns nodecount
     * */
    public static int testValidGeni3AdvertisementRspec(ApiTest test, String rspec) {
        if (rspec == null) return -1;
        test.assertNotNull(rspec, "Rspec is null");

        int nodeCount = 0;

        //parse the RSpec XML
        try {
            Class docClass = be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents.class;
            String packageName = docClass.getPackage().getName();
            JAXBContext jc = JAXBContext.newInstance(packageName);
            Unmarshaller u = jc.createUnmarshaller();
            JAXBElement<be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents> doc =
                    (JAXBElement<be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents>) u.unmarshal( new StringReader(rspec));
            be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents c = doc.getValue();

            String typ = c.getType();
            test.assertNotNull(typ, "Received advertisement RSpec does not specify a type: " + rspec);
            test.assertEquals(typ, "advertisement", "Received advertisement RSpec is not a advertisement, it is a: \"" + typ+"\"");

            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    if (el.getValue() instanceof be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.NodeContents) {
                        be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.NodeContents node = (be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.NodeContents) el.getValue();

                        nodeCount++;

                        for (Object nodeElO : node.getAnyOrRelationOrLocation()) {
                            if (nodeElO instanceof JAXBElement) {
                                JAXBElement nodeEl = (JAXBElement) nodeElO;
                                //                                if (nodeEl.getValue() instanceof InterfaceContents) {
                                //                                    InterfaceContents ic = (InterfaceContents) nodeEl.getValue();
                                //                                    String interfaceName = ic.getClientId();
                                //                                }
                            }
                        }
                    }
                    //                    if (el.getValue() instanceof LinkContents) {
                    //                        LinkContents link = (LinkContents) el.getValue();
                    //
                    //                        String linkname = link.getClientId();
                    //
                    //                        for (Object linkElO : link.getAnyOrPropertyOrLinkType()) {
                    //                            if (linkElO instanceof JAXBElement) {
                    //                                JAXBElement linkEl = (JAXBElement) linkElO;
                    //                                if (linkEl.getValue() instanceof InterfaceRefContents) {
                    //                                    InterfaceRefContents ic = (InterfaceRefContents) linkEl.getValue();
                    //                                    String interfaceName = ic.getClientId();
                    //                                }
                    //                            }
                    //                        }
                    //                    }
                }
            }
        } catch (JAXBException e) {
            throw new RuntimeException("Exception parsing advertisement RSpec Xml: "+e.getMessage(), e);
        }

        //        assertTrue(nodeCount > 0, "No nodes found in advertisement rspec: "+rspec);

        return nodeCount;
    }



    public static String createSliceName(ApiTest test, SfaAuthority userAuthority, String prefix) {
        int maxSliceNameLength = 19; //Geni max length

        //planetlab sfa max length
        int authLen = userAuthority.getNameForUrn().replaceAll("\\.", "").length();
        int planetlab_l = 32 - authLen;
        // protogeni max length of FQDN = 64 characters (unix limit): PC.st1383985554.wall2-ilabt-iminds-be.instageni.rnet.missouri.edu
        // .instageni.rnet.missouri.edu = 28 chars
        // .wall2-ilabt-iminds-be = userAuthority.getNameForUrn().length()+1
        // we use 3 for hostnames (pc1,pc2 in stitching) (and 1 for the .)
        int protogeni_l = 64 - 28 - userAuthority.getNameForUrn().length() - 1 - 3 - 1;
        int l = 0;
        if (protogeni_l < planetlab_l) {
            l = protogeni_l;
        } else {
            l = planetlab_l;
        }
        if (l < maxSliceNameLength) {
            maxSliceNameLength = l;
            test.note("For "+userAuthority.getNameForUrn()+" ("+authLen+" non-dot chars), the maximum slice name length (taking into account planetlab and protogeni limits) is "+maxSliceNameLength);
        }
        else
            test.note("Slice name length is "+maxSliceNameLength);

        long uniqueNumber = System.currentTimeMillis()/1000; //unique each second
        // uniqueNumber /= 10; //unique each 10 seconds
        String uniqueNumberString = uniqueNumber+"";
        int uniqueNumberMaxLen = maxSliceNameLength - prefix.length();
        if (uniqueNumberString.length() > uniqueNumberMaxLen) {
            //drop from front of string, not from back
            uniqueNumberString = uniqueNumberString.substring(uniqueNumberString.length() - uniqueNumberMaxLen);
            test.assertEquals(uniqueNumberString.length(), uniqueNumberMaxLen, "bug in test: uniqueNumberString.length()="+uniqueNumberString.length()+" !=  uniqueNumberMaxLen="+uniqueNumberMaxLen);

            test.note("Slice unique number is "+uniqueNumber+" after making it shorter it, it is "+uniqueNumberString);
        }
        String longSliceName = prefix+uniqueNumberString;
        return longSliceName;
    }


    private CommandExecutionContext testContext;
    private ApiTest test;
    private SfaAuthority userAuthority;
    private AnyCredential userCredential;
    //    private ProtogeniSliceAuthority sa;  //not used directly, use userAndSliceApiWrapperUser1
    private UserAndSliceApiWrapper userAndSliceApiWrapperUser1;
    private UserAndSliceApiWrapper userAndSliceApiWrapperUser2;

    public CommonAMTest(ApiTest test, CommandExecutionContext testContext) {
        this(test, testContext, testContext.getUserAuthority());
    }
    public CommonAMTest(ApiTest test, CommandExecutionContext testContext, SfaAuthority userAuthority) {
        this.test = test;
        this.testContext = testContext;
        this.userAuthority = userAuthority;

        assert this.test != null;
        assert this.testContext != null;
        assert this.userAuthority != null;

//        sa = new ProtogeniSliceAuthority(testContext.getLogger());

        userAndSliceApiWrapperUser1 = new AutomaticUserAndSliceApiWrapper(testContext.getLogger(), testContext.getGeniUser(), testContext.getConnectionProvider());
    }

    private AnyCredential user2Credential;
    public AnyCredential getUser2Credential() {
        assert test != null;
        assert secondUserContext != null;

        if (user2Credential != null)
            return user2Credential;

        try {
            user2Credential = userAndSliceApiWrapperUser2.getUserCredentials(GeniUrn.parse(secondUserContext.getGeniUser().getUserUrnString()));
        } catch (JFedException e) {
            throw new RuntimeException(e);
        }
        assert user2Credential != null;
        return user2Credential;
    }
    public AnyCredential getUserCredential() {
        assert test != null;
        assert testContext != null;
        assert userAuthority != null;

        if (userCredential != null)
            return userCredential;

        try {
            userCredential = userAndSliceApiWrapperUser1.getUserCredentials(GeniUrn.parse(testContext.getGeniUser().getUserUrnString()));
        } catch (JFedException e) {
            throw new RuntimeException(e);
        }
        assert userCredential != null;
        return userCredential;
    }
    public static List<AnyCredential> toCredentialList(AnyCredential c) {
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(c);
        return res;
    }
    public List<AnyCredential> getUserCredentialList() {
        if (testCredentialType == TestCredentialType.REGULAR)
            return toCredentialList(getUserCredential());

        if (testCredentialType == TestCredentialType.DELEGATION)
            return toCredentialList(getDelegatedUserCredential());

        assert testCredentialType == TestCredentialType.SPEAKSFOR;
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(getUser2Credential());
        res.add(getSpeaksForUserCredential());
        return res;
    }
    public List<AnyCredential> getSliceCredentialList(SliceInfo sliceInfo) {
        if (testCredentialType == TestCredentialType.REGULAR)
            return toCredentialList(sliceInfo.credential);

        if (testCredentialType == TestCredentialType.DELEGATION)
            return toCredentialList(sliceInfo.getDelegatedCredential(testContext, secondUserContext));

        assert testCredentialType == TestCredentialType.SPEAKSFOR;
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(sliceInfo.credential);
        res.add(getSpeaksForUserCredential());
        return res;
    }

    /**
     * add speaksfor option if needed
     *
     * @param extraOptions does not change original extraOptions, makes a copy. allowed to be null.
     * */
    public Hashtable addCredentialExtraOptions(Hashtable extraOptions) {
        if (testCredentialType != TestCredentialType.SPEAKSFOR)
            return extraOptions;

        assert secondUserContext != null;

        Hashtable res = new Hashtable();
        if (extraOptions != null) res.putAll(extraOptions);
        res.put("geni_experimenter_urn", secondUserContext.getGeniUser().getUserUrnString());
        return res;
    }

    private static enum TestCredentialType { REGULAR, SPEAKSFOR, DELEGATION };
    private TestCredentialType testCredentialType = TestCredentialType.REGULAR;
    private CommandExecutionContext secondUserContext;
    public void selectRegularTestCredentialType(ApiTest test) {
        testCredentialType = TestCredentialType.REGULAR;
        this.secondUserContext = null;
        delegatedUserCredential = null;
        speaksForUserCredential = null;
        user2Credential = null;
        for (SliceInfo sliceInfo : allSliceInfo)
            sliceInfo.delegatedCredential = null;

        userAndSliceApiWrapperUser2 = null;
    }

    /** user 1 is speaking for user 2 */
    public void selectSpeaksForTestCredentialType(ApiTest test, CommandExecutionContext secondUserContext) {
        testCredentialType = TestCredentialType.SPEAKSFOR;
        this.secondUserContext = secondUserContext;
        delegatedUserCredential = null;
        speaksForUserCredential = null;
        user2Credential = null;
        for (SliceInfo sliceInfo : allSliceInfo)
            sliceInfo.delegatedCredential = null;

        userAndSliceApiWrapperUser2 = new AutomaticUserAndSliceApiWrapper(testContext.getLogger(), secondUserContext.getGeniUser(), secondUserContext.getConnectionProvider());

        test.note("User 2="+secondUserContext.getGeniUser().getUserUrnString()+" delegates rights to user 1="+testContext.getGeniUser().getUserUrnString()+"");
    }

    /** user 1 uses delegated credential from user 2 (so user 2's rights) */
    public void selectDelegationTestCredentialType(ApiTest test, CommandExecutionContext secondUserContext) {
        testCredentialType = TestCredentialType.DELEGATION;
        this.secondUserContext = secondUserContext;
        delegatedUserCredential = null;
        speaksForUserCredential = null;
        user2Credential = null;
        for (SliceInfo sliceInfo : allSliceInfo)
            sliceInfo.delegatedCredential = null;

        userAndSliceApiWrapperUser2 = new AutomaticUserAndSliceApiWrapper(testContext.getLogger(), secondUserContext.getGeniUser(), secondUserContext.getConnectionProvider());

        test.note("User 1="+testContext.getGeniUser().getUserUrnString()+" speaks for user 2="+secondUserContext.getGeniUser().getUserUrnString()+"");
    }

    private SfaCredential delegatedUserCredential;
    public SfaCredential getDelegatedUserCredential() {
        if (delegatedUserCredential != null) return delegatedUserCredential;
//        if (userCredential == null) getUserCredential();
//        if (userCredential == null) throw new RuntimeException("User credential is null");
        if (user2Credential == null) getUser2Credential();
        if (user2Credential == null) throw new RuntimeException("User credential is null");

        GeniUser user1 = testContext.getGeniUser();
        GeniUser user2 = secondUserContext.getGeniUser();

        SfaCredential sfaUser2Credential = (SfaCredential) user2Credential;
        try {
            delegatedUserCredential = sfaUser2Credential.delegate(
                    user1.getUserUrnString()/*newOwnerUrn*/,
                    user1.getClientCertificateChain().get(0)/*newOwnerCert*/,
                    user2.getPrivateKey()/*originalOwnerPrivateKey*/,
                    new Date(System.currentTimeMillis()+24*60*60*1000)/*expireDate*/,
                    "*"/*delegatedRights*/,
                    false/*canDelegate*/);
        } catch (CredentialException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        assert delegatedUserCredential != null;
        return delegatedUserCredential;
    }

    private SfaCredential speaksForUserCredential;
    public SfaCredential getSpeaksForUserCredential() {
        if (speaksForUserCredential != null) return speaksForUserCredential;
//        if (user2Credential == null) getUser2Credential();
//        if (user2Credential == null) throw new RuntimeException("User credential is null");

        GeniUser user1 = testContext.getGeniUser();
        GeniUser user2 = secondUserContext.getGeniUser();

        try {
            speaksForUserCredential = SfaCredential.createSpeaksFor(
                    user2.getUserUrnString()/*spokenForUrn*/,
                    user1.getUserUrnString()/*speakerUrn*/,
                    user2.getClientCertificateChain().get(0)/*spokenForCert*/,
                    user1.getClientCertificateChain().get(0)/*speakerCert*/,
                    user2.getPrivateKey()/*spokenForPrivateKey*/,
                    new Date(System.currentTimeMillis()+24*60*60*1000)/*expireDate*/,
                    "*"/*privilegeName*/,
                    false/*canDelegate*/);
        } catch (CredentialException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        assert speaksForUserCredential != null;
        return speaksForUserCredential;
    }

    public static class SliceInfo {
        String name;
        GeniUrn urn;
        AnyCredential credential;
        SfaCredential delegatedCredential;
        String urnString;

        public SfaCredential getDelegatedCredential(CommandExecutionContext receiverContext, CommandExecutionContext granterContext)  {
            if (delegatedCredential != null) return delegatedCredential;
            if (credential == null) return null;
            SfaCredential sfaCredential = (SfaCredential) credential;
            try {
                delegatedCredential = sfaCredential.delegate(
                        receiverContext.getGeniUser().getUserUrnString()/*newOwnerUrn*/,
                        receiverContext.getGeniUser().getClientCertificateChain().get(0)/*newOwnerCert*/,
                        granterContext.getGeniUser().getPrivateKey()/*originalOwnerPrivateKey*/,
                        new Date(System.currentTimeMillis()+24*60*60*1000)/*expireDate*/,
                        "*"/*delegatedRights*/,
                        false/*canDelegate*/);
            } catch (CredentialException e) {
                throw new RuntimeException(e.getMessage(), e);
            }
            return delegatedCredential;
        }
    }

    private static int MAX_CREATE_SLICE_TRIES = 3;
    private List<SliceInfo> allSliceInfo = new ArrayList<SliceInfo>();
    public SliceInfo createSlice(String prefix) throws JFedException {
        boolean callAsUser1 = testCredentialType.equals(TestCredentialType.REGULAR);
        assert callAsUser1 != testCredentialType.equals(TestCredentialType.SPEAKSFOR) || testCredentialType.equals(TestCredentialType.DELEGATION);

        SliceInfo res = new SliceInfo();
        int tries = 0;
        boolean success = false;
        while (!success) {
            res.name = CommonAMTest.createSliceName(test, userAuthority, prefix);
            res.urn = new GeniUrn(userAuthority.getNameForUrn(), "slice", res.name);  //not always correct, but overwritten below
            res.urnString = res.urn.toString();

            try {
                if (callAsUser1) {
                    UserAndSliceApiWrapper.SliceInfo sliceInfo = userAndSliceApiWrapperUser1.createSlice(getUserCredential(), res.name);
                    res.credential = sliceInfo.getCredential();
                    res.urn = sliceInfo.getUrn();
                    res.urnString = res.urn.toString();
                }
                else {
                    UserAndSliceApiWrapper.SliceInfo sliceInfo = userAndSliceApiWrapperUser2.createSlice(getUser2Credential(), res.name);
                    res.credential = sliceInfo.getCredential();
                    res.urn = sliceInfo.getUrn();
                    res.urnString = res.urn.toString();
                }
                success = true;
            } catch (Exception e) {
                //ignore
                LOG.warn("Exception creating slice, will ignore for now", e);
                success = false;
            }

            if (!success) {
                //maybe name is taken

                tries++;
                test.assertTrue(tries <= MAX_CREATE_SLICE_TRIES, "tried "+tries+" times. Maximum tries is "+MAX_CREATE_SLICE_TRIES+". -> Giving up!");
                if (tries > MAX_CREATE_SLICE_TRIES) {
                    res.credential = null;
                    break;
                }

                //wait before trying again
                try { Thread.sleep(1200 /*ms*/); } catch (InterruptedException e) { }
            }
        }
        test.assertNotNull(res.credential);

        //old version without UserAndSliceApiWrapper
//        ProtogeniSliceAuthority.SliceAuthorityReply<AnyCredential> registerRes = null;
//
//        int tries = 0;
//        boolean success = false;
//        while (!success) {
//            res.name = CommonAMTest.createSliceName(test, userAuthority, prefix);
//            res.urn = new GeniUrn(userAuthority.getNameForUrn(), "slice", res.name);
//            res.urnString = res.urn.toString();
//
//            if (callAsUser1)
//                registerRes = sa.register(getSAConnection(), getUserCredential(), res.urn);
//            else
//                registerRes = sa.register(getSAUser2Connection(), getUser2Credential(), res.urn);
//            TestSliceAuthority.testSACorrectnessXmlRpcResult(registerRes.getRawResult());
//            success = registerRes.getGeniResponseCode().isSuccess();
//
//            if (!success) {
//                //maybe name is taken
//                test.note("Could not create slice \"" + res.urnString + "\": " + registerRes.getGeniResponseCode() + " output: " + registerRes.getOutput());
//
//                tries++;
//                test.assertTrue(tries <= MAX_CREATE_SLICE_TRIES, "tried "+tries+" times. Maximum tries is "+MAX_CREATE_SLICE_TRIES+". -> Giving up!");
//                if (tries > MAX_CREATE_SLICE_TRIES)
//                    break;
//
//                //wait before trying again
//                try { Thread.sleep(1200 /*ms*/); } catch (InterruptedException e) { }
//            }
//        }
//
//        test.assertNotNull(registerRes);
//        test.assertTrue(registerRes.getGeniResponseCode().isSuccess(),"Register call was not successful in creating \""+res.urn.getValue()+"\": "+registerRes.getGeniResponseCode()+" output="+registerRes.getOutput());
//        res.credential = registerRes.getValue();
//        test.assertNotNull(res.credential);
//        test.assertNotNull(res.credential.getCredentialXml());
//        test.assertTrue(res.credential.getCredentialXml().length() > 10, "credential too short "+ res.credential.getCredentialXml());

        test.assertNotNull(res.credential);

        allSliceInfo.add(res);

        return res;
    }

    public SliceInfo renewSlice(SliceInfo sliceInfo, Date newExpirationtime) throws JFedException {
        //this just changes the actual sliceInfo in place

        boolean callAsUser1 = testCredentialType.equals(TestCredentialType.REGULAR);
        assert callAsUser1 != testCredentialType.equals(TestCredentialType.SPEAKSFOR) || testCredentialType.equals(TestCredentialType.DELEGATION);

        if (callAsUser1) {
            sliceInfo.credential = userAndSliceApiWrapperUser1.renewSlice(sliceInfo.credential, newExpirationtime);
        }
        else {
            sliceInfo.credential = userAndSliceApiWrapperUser2.renewSlice(sliceInfo.credential, newExpirationtime);
        }

        test.assertNotNull(sliceInfo.credential);

        return sliceInfo;
    }

    /**
     * returns true if A is preferred over B
     * */
    public static boolean preferSliverType(String sliverTypeNameA, String sliverTypeNameB) {
        if (sliverTypeNameB == null) return true;
        int scoreA = getSliverTypeNameScore(sliverTypeNameA);
        int scoreB = getSliverTypeNameScore(sliverTypeNameB);
        return scoreA > scoreB;
    }

    /**
     * returns a score for the sliver type name. Higher scores are preferred.
     * */
    public static int getSliverTypeNameScore(String sliverTypeName) {
        if (sliverTypeName == null) return 0;
        if (sliverTypeName.equalsIgnoreCase("emulab-openvz")) return 100;
        if (sliverTypeName.equalsIgnoreCase("emulab-xen")) return 98;
        if (sliverTypeName.equalsIgnoreCase("plab-vserver")) return 99;

        if (sliverTypeName.equalsIgnoreCase("raw-pc")) return 90;

        //exogeni
        if (sliverTypeName.equalsIgnoreCase("xo.small")) return 80;
        if (sliverTypeName.equalsIgnoreCase("xo.tiny")) return 81;
        if (sliverTypeName.startsWith("xo.")) return 79;

        //various
        if (sliverTypeName.contains("xen")) return 63;
        if (sliverTypeName.contains("openvz")) return 62;
        if (sliverTypeName.contains("virt")) return 61;
        if (sliverTypeName.contains("vz")) return 60;

        if (sliverTypeName.contains("raw")) return 11;
        if (sliverTypeName.contains("pc")) return 10;

        return 1;
    }
}
