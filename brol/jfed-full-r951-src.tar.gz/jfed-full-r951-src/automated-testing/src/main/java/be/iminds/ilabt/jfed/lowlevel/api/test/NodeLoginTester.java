package be.iminds.ilabt.jfed.lowlevel.api.test;

import be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents;
import be.iminds.ilabt.jfed.testing.base.ApiTest;
import be.iminds.ilabt.jfed.util.IOUtils;
import be.iminds.ilabt.jfed.util.KeyUtil;
import be.iminds.ilabt.jfed.util.SSHKeyHelper;
import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;
import org.apache.logging.log4j.LogManager;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.*;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

/**
 * NodeLoginTester: helper class that specifically tests node login.
 */
public class NodeLoginTester {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    private ApiTest test;

    private SSHKeyHelper sshKeyHelper;
    private String sshUsername;
    private String sshHostname;
    private int sshPort;

    public NodeLoginTester(ApiTest test, String fixedSshPublicKeyFile, String fixedSshPrivateKeyFile, String pass) throws NoSuchAlgorithmException {
        this.test = test;

        if ((fixedSshPrivateKeyFile == null) != (fixedSshPrivateKeyFile == null))
            throw  new RuntimeException("fixedSshPublicKeyFile and fixedSshPrivateKeyFile must either both be null, or both differ from null");

        if (fixedSshPrivateKeyFile != null) {
            assert fixedSshPublicKeyFile != null;
            try {
                String privatePem = IOUtils.fileToString(fixedSshPrivateKeyFile);
                String publicFileContent = IOUtils.fileToString(fixedSshPublicKeyFile);

                boolean isCertificate = KeyUtil.hasX509Certificate(publicFileContent);
                boolean isOpenSsl = KeyUtil.isOpenSshRsaKey(publicFileContent);

                PublicKey publicKey = null;
                if (isOpenSsl)
                    publicKey = KeyUtil.openSshAuthorizedKeysFormatRsaPublicKey(publicFileContent);
                if (isCertificate)
                    publicKey = KeyUtil.pemToX509Certificate(publicFileContent).getPublicKey();
                assert publicKey != null;

                RSAPrivateKey privateKey = KeyUtil.pemToRsaPrivateKey(privatePem, pass == null ? null : pass.toCharArray());
                this.sshKeyHelper = new SSHKeyHelper(publicKey, privateKey);
            } catch (Exception e) {
                logger.error("Exception while reading key: "+e.getMessage(), e);
                throw new RuntimeException("Exception while reading key: "+e.getMessage(), e);
            }
        }
        else
            this.sshKeyHelper = new SSHKeyHelper(); //random
    }

    private boolean parsed = false;

    public boolean hasParsed() {
        return parsed;
    }
    public boolean parseSshInfoFromGeni3ManifestRspec(String rspec) {
        if (rspec == null) return false;
        test.assertNotNull(rspec, "Rspec is null");

        parsed = true;

        String hostname = null;
        int port = 22;
        String username = null;

        int nodeCount = 0;
        int loginCount = 0;

        //quick HACK to allow the planetlab Europe rspec manifest
        // FEDIBBTDEV-113, bvermeul, copied this nice stuff from suite/rspec-edit/src/main/java/be/iminds/ilabt/jfed/ui/rspeceditor/model/Rspec.java
        if (rspec.contains("<RSpec")) {
            test.note("We received an SFA RSpec instead of a GENI RSpec v3, but we'll try to work around.");
            //logger.debug("HACK: rewriting received planetlab manifest XML to make it parsable xml");
            rspec = rspec.replace("<RSpec type=\"SFA\"", "<rspec xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" type=\"manifest\"");
            rspec = rspec.replace("<RSpec ", "<rspec xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" type=\"manifest\"");
            rspec = rspec.replace("</RSpec>", "</rspec>");
            rspec = rspec.replace("<network name=\"ple\">", "");
            rspec = rspec.replace("</network>", "");
            //logger.debug("HACK: rewriten xml: "+rspec);
        }


        //parse the RSpec XML
        try {
            Class docClass = be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents.class;
            String packageName = docClass.getPackage().getName();
            JAXBContext jc = JAXBContext.newInstance(packageName);
            Unmarshaller u = jc.createUnmarshaller();
            JAXBElement<RSpecContents> doc = (JAXBElement<be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents>) u.unmarshal( new StringReader(rspec));
            be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents c = doc.getValue();

            be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RspecTypeContents typ = c.getType();

            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    if (el.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents) {
                        be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents node = (be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents) el.getValue();

                        String nodeName = node.getClientId();
                        nodeCount++;

                        for (Object nodeElO : node.getAnyOrRelationOrLocation()) {
                            if (nodeElO instanceof JAXBElement) {
                                JAXBElement nodeEl = (JAXBElement) nodeElO;
                                if (nodeEl.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.ServiceContents) {
                                    be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.ServiceContents serviceC = (be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.ServiceContents) nodeEl.getValue();
                                    for (Object serviceElO : serviceC.getAnyOrLoginOrInstall()) {
                                        if (serviceElO instanceof JAXBElement) {
                                            JAXBElement serviceEl = (JAXBElement) serviceElO;
                                            if (serviceEl.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.LoginServiceContents) {
                                                be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.LoginServiceContents loginSC = (be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.LoginServiceContents) serviceEl.getValue();

                                                String auth = loginSC.getAuthentication();

                                                String aHostname = loginSC.getHostname();
                                                int aPort = 0;
                                                if (loginSC.getPort() != null)
                                                    aPort = Integer.parseInt(loginSC.getPort());
                                                String aUsername = loginSC.getUsername();

                                                if (auth.equals("ssh-keys")) {
                                                    test.assertEquals("ssh-keys", auth, "service login authentication must be ssh-keys for node " + nodeName);
                                                    test.assertNotNull(aHostname, "no hostname in service login for node " + nodeName);
                                                    test.assertNotNull(aUsername, "no username in service login for node " + nodeName);
                                                    //TODO add support for missing username?

                                                    hostname = aHostname;
                                                    port = aPort;
                                                    username = aUsername;

                                                    loginCount++;
                                                } else {
                                                    test.note("Unsupported auth in manifest RSpec service login: " + auth);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (JAXBException e) {
            throw new RuntimeException("Exception parsing manifest RSpec Xml: "+e.getMessage(), e);
        }

        if (loginCount > 0)
        {
            test.assertTrue(loginCount > 0, "no service login found (" + loginCount + " service logins for " + nodeCount + " nodes)");
            test.assertNotNull(hostname);
            test.assertNotNull(username);

            if (loginCount > 1)
                test.note("Found multiple node logins in manifest rspec (" + loginCount + " service logins for " + nodeCount + " nodes), using last one.");

            sshUsername = username;
            sshHostname= hostname;
            sshPort = port;
        } else {
            test.note("Found no node service login in manifest RSpec.");
        }

        return true;
    }



    public void testNodeLogin() throws IOException {
        assert parsed : "No RSpec was parsed for node login info";
        if (!parsed)
            test.skip("No manifest RSpec parsed yet, so SSH login cannot be tested.");

        if (sshHostname == null)
            test.skip("No node / service / login in manifest RSpec, so SSH login cannot be tested.");

        // bvermeul, wait max 20 minutes till ssh login works (as PLE says that sliver is ready while it is not)
        // FEDIBBTDEV-113
        long now = System.currentTimeMillis();
        long start = now;
        long deadline = now + (20*60*1000);
        boolean isAuthenticated = false;
        Connection conn = null;
        String remainingMethods = "";
        while ( now < deadline ) {


            //Test node login using SSH private key

            conn = new Connection(sshHostname, sshPort);
            conn.connect();
            String privateKeyToPrint = new String(sshKeyHelper.getPEMAnyPrivateKey());
            if (privateKeyToPrint.length() > 75) privateKeyToPrint = privateKeyToPrint.substring(0, 75) + " ...";
            test.note("Trying to log in with PEM private key:\n" + privateKeyToPrint);
            isAuthenticated = conn.authenticateWithPublicKey(sshUsername, sshKeyHelper.getPEMRsaPrivateKey(), "nopass"); //needs RSA PRIVATE KEY   does not work with PRIVATE KEY
            remainingMethods = null;
            if (isAuthenticated)
                break;

            String[] remainingMethodsArray = conn.getRemainingAuthMethods(sshUsername);
            remainingMethods = "";
            for (String remainingMethod : remainingMethodsArray)
                remainingMethods += " "+remainingMethod;
            if (remainingMethodsArray.length == 0)
                remainingMethods = "   no other authentication methods returned by server.";
            else
                remainingMethods = "   Remaining authentication methods:"+remainingMethods+"  (these will not be tried by this test)";



            test.warn("SSH connection not successful (should be available from the moment that status is 'ready').  Trying again in 30 seconds...");
            try {
                Thread.sleep(30000 /*ms*/);
            } catch (InterruptedException e) { /* Ignore*/ }
            now = System.currentTimeMillis();
        }


        test.assertTrue(isAuthenticated, "Could not login to host: authentication with private key failed. " +
                sshUsername + "@" + sshHostname + ":" + sshPort+
                remainingMethods);

        test.note("SSH connection authenticated successfully after " + (long)(System.currentTimeMillis() - start) + " milliseconds, will open session.");
        Session session = conn.openSession();
        test.assertTrue(session != null);

        test.note("SSH session opened successfully, will send command.");
        BufferedReader sout = new BufferedReader(new InputStreamReader(session.getStdout()));
        BufferedReader serr = new BufferedReader(new InputStreamReader(session.getStderr()));
        //session.execCommand("/usr/bin/who");
        session.execCommand("ls / && uname -a");
        String result = "";
        String err = "";
        String line = sout.readLine();
        while (line != null) {
            result += line;
            line = sout.readLine();
        }
        line = serr.readLine();
        while (line != null) {
            err += line;
            line = serr.readLine();
        }
        //        note("\"who\" command on "+sshHostname+"@"+sshHostname+":"+sshPort+" result: \""+result.trim()+"\". (stderr is: \"" + err + "\")");
        //        assertTrue(result.contains(sshUsername), "I executed \"/usr/bin/who\" on the remote host, and expected a return containing my username (\"" + sshUsername + "\"). Instead I got: \"" + result.trim() + "\". (stderr is: \"" + err + "\")");

        test.note("\"ls && uname /\" command on " + sshUsername + "@" + sshHostname + ":" + sshPort + " result: \"" + result.trim() + "\". (stderr is: \"" + err + "\")");
        test.assertTrue(result.length() > 5, "I executed \"ls /\" on the remote host, and expected some reply. Instead I got: \"" + result.trim() + "\". (stderr is: \"" + err + "\")");

        session.close();

        conn.close();
    }

    public SSHKeyHelper getSshKeyHelper() {
        return sshKeyHelper;
    }

    public String getSshUsername() {
        return sshUsername;
    }

    public String getSshHostname() {
        return sshHostname;
    }

    public int getSshPort() {
        return sshPort;
    }
}
