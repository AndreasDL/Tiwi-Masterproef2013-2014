package be.iminds.ilabt.jfed.lowlevel.api.test;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.ServerType;
import be.iminds.ilabt.jfed.lowlevel.api.*;
import be.iminds.ilabt.jfed.lowlevel.api.FederationRegistryApi2;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.CommandExecutionContext;
import be.iminds.ilabt.jfed.util.GeniUrn;

import java.net.URL;
import java.util.*;

/**
 * TestFederationMemberAuthority2
 */
public class TestFederationRegistry2 extends AbstractFederationApi2Test {
    public String getTestDescription() {
        return "Test Federation API Federation Registry version 2";
    }

    private FederationRegistryApi2 fr;
    private CommandExecutionContext testContext;

    private GeniUrn testUserUrn;

    public SfaConnection getConnection() throws JFedException {
        return (SfaConnection) testContext.getConnectionProvider().getConnectionByAuthority(testContext.getGeniUser(), testContext.getTestedAuthority(),
                new ServerType(ServerType.GeniServerRole.GENI_CH, 2));
    }

    List<String> serviceDefaultFieldNames = new ArrayList<String>();
    List<AbstractFederationApi2.GetVersionResult.FieldInfo> serviceDefaultFields = new ArrayList<AbstractFederationApi2.GetVersionResult.FieldInfo>();



    protected void checkLookupServiceCorrectness(AbstractFederationApi2.FederationApiReply reply, Vector<String> filter) {
        setErrorsFatal();
        Object rawReplyValue = reply.getRawValue();
        assertInstanceOf(rawReplyValue, Vector.class, "Lookup service result should be an array (=Vector), but is of type " + rawReplyValue.getClass().getName());
        Vector rawReplyValueV = (Vector) rawReplyValue;
        setErrorsNotFatal();
        for (Object o: rawReplyValueV) {
            assertInstanceOf(o, Hashtable.class, "Lookup service array should contain dictionaries (=Hashtable) of string to object . But at least one value is not dict but " +
                    o.getClass().getName());
            Hashtable ht = (Hashtable) o;

            if (filter == null) {
                //these are required by the API if no filter is specified. (more fields are allowed)
                assertHashTableContainsNonemptyString(ht, "SERVICE_TYPE");
                assertHashTableContainsNonemptyString(ht, "SERVICE_URN");
                assertHashTableContainsNonemptyString(ht, "SERVICE_URL");
                assertHashTableContainsNonemptyString(ht, "SERVICE_NAME");

                //TODO: check for the fields specified in the get_version reply
            } else {
                for (String requiredField : filter) {
                    assertHashTableContainsNonemptyString(ht, requiredField);
                }
            }
        }
        setErrorsFatal();
    }



    public void setUp(CommandExecutionContext testContext) {
        this.testContext = testContext;
        fr = new FederationRegistryApi2(testContext.getLogger());
        fr.setHandleMalformedReplies(false); //throw exceptions instead of trying to recover from malformed replies

        testUserUrn = GeniUrn.parse(testContext.getGeniUser().getUserUrnString());
        assertNotNull(testUserUrn, "Error in test user urn: "+testContext.getGeniUser().getUserUrnString());

        serviceDefaultFields = fr.getMinimumFields("SERVICE");
        for (AbstractFederationApi2.GetVersionResult.FieldInfo fi : serviceDefaultFields)
            serviceDefaultFieldNames.add(fi.getName());
    }

    @Test
    public void getVersion() throws JFedException {
        AbstractFederationApi2.FederationApiReply<AbstractFederationApi2.GetVersionResult> reply = fr.getVersion(getConnection());
        checkGetVersion(reply, fr, false);
    }


    private AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails> amDetails;
    @Test()
    public void lookupAggregatesNoFilter() throws JFedException {
        Hashtable<String, String> match = null;//new Hashtable<String, String>();
        Vector<String> filter = null;// new Vector<String>();

        AbstractFederationApi2.FederationApiReply<AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails>> reply =
                fr.lookupAM(getConnection(), filter, match, null);
        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        checkLookupServiceCorrectness(reply, filter);
        amDetails = reply.getValue();
        assertNotNull(amDetails, "lookup_aggregates returned null reply");
        for (FederationRegistryApi2.ServiceDetails sd : amDetails.getConvertedList())
            note("lookup_aggregates returned aggregate: "+sd.getUrl());
    }

    private AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails> maDetails;
    @Test()
    public void lookupMemberAuthoritiesNoFilter() throws JFedException {
        Hashtable<String, String> match = null;//new Hashtable<String, String>();
        Vector<String> filter = null;// new Vector<String>();

        AbstractFederationApi2.FederationApiReply<AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails>> reply =
                fr.lookupMA(getConnection(), filter, match, null);
        assertTrue(reply.getGeniResponseCode().isSuccess());

        checkLookupServiceCorrectness(reply, filter);
        maDetails = reply.getValue();
        assertNotNull(maDetails);
        for (FederationRegistryApi2.ServiceDetails sd : maDetails.getConvertedList())
            note("lookup_member_authorities returned aggregate: "+sd.getUrl());
    }

    private AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails> saDetails;
    @Test()
    public void lookupSliceAuthoritiesNoFilter() throws JFedException {
        Hashtable<String, String> match = null;//new Hashtable<String, String>();
        Vector<String> filter = null;// new Vector<String>();

        AbstractFederationApi2.FederationApiReply<AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails>> reply =
                fr.lookupSA(getConnection(), filter, match, null);
        assertTrue(reply.getGeniResponseCode().isSuccess());

        checkLookupServiceCorrectness(reply, filter);
        saDetails = reply.getValue();
        assertNotNull(saDetails);
        for (FederationRegistryApi2.ServiceDetails sd : saDetails.getConvertedList())
            note("lookup_slice_authorities returned: "+sd.getUrl());
    }

    /////////////////////////// lookup with match ////////////////////////////////////////////

    private boolean hasTestedMulti = false;
    @Test(hardDepends = {"lookupAggregatesNoFilter"})
    public void lookupAggregatesWithMatchNoFilter() throws JFedException {
        if (amDetails.isEmpty()) skip("cannot test match if there are no AM");

        List<FederationRegistryApi2.ServiceDetails> toMatch = new ArrayList<FederationRegistryApi2.ServiceDetails>();
        Vector<String> urnToMatch = new Vector<String>();
        Vector<String> urlToMatch = new Vector<String>();
        if (!hasTestedMulti && amDetails.size() > 3) {
            note("Testing list of scalars, indicating an OR, as value in the match dictionary");
            toMatch.add(amDetails.getConverted(1));
            toMatch.add(amDetails.getConverted(2));
            hasTestedMulti = true;
        } else {
            toMatch.add(amDetails.getConverted(0));
        }
        for (FederationRegistryApi2.ServiceDetails amDetail : toMatch) {
            assertNotNull(amDetail.getUrn(), "A service in a previous test call did not specify an URN");
            assertNotNull(amDetail.getUrl(), "A service in a previous test call did not specify an URL");
            urnToMatch.add(amDetail.getUrn().getValue());
            urlToMatch.add(amDetail.getUrl().toExternalForm());
        }

        note("Testing match by URL");
        Hashtable<String, Object> match = new Hashtable<String, Object>();
        Vector<String> filter = null;// new Vector<String>();
        if (urlToMatch.size() > 1)
            match.put("SERVICE_URL", urlToMatch);
        else
            match.put("SERVICE_URL", urlToMatch.get(0));

        AbstractFederationApi2.FederationApiReply<AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails>> reply =
                fr.lookupAM(getConnection(), filter, match, null);
        assertTrue(reply.getGeniResponseCode().isSuccess());

        checkLookupServiceCorrectness(reply, filter);
        amDetails = reply.getValue();
        assertNotNull(amDetails);
        assertEquals(amDetails.size(), toMatch.size(), "The search returned a different number of results than expected.");
        for (FederationRegistryApi2.ServiceDetails sd : amDetails.getConvertedList()) {
            assertTrue(urnToMatch.remove(sd.getUrn().getValue()), "returned a service that should not have been matched: "+sd.getUrn());
        }
        assertEmpty(urnToMatch, "Some services where not matched as expected: "+urnToMatch);
    }
    @Test(hardDepends = {"lookupMemberAuthoritiesNoFilter"})
    public void lookupMemberAuthoritiesWithMatchNoFilter() throws JFedException {
        if (maDetails.isEmpty()) skip("cannot test match if there are no MA");

        List<FederationRegistryApi2.ServiceDetails> toMatch = new ArrayList<FederationRegistryApi2.ServiceDetails>();
        Vector<String> urnToMatch = new Vector<String>();
        Vector<String> nameToMatch = new Vector<String>();
        if (!hasTestedMulti && maDetails.size() > 3) {
            note("Testing list of scalars, indicating an OR, as value in the match dictionary");
            toMatch.add(maDetails.getConverted(1));
            toMatch.add(maDetails.getConverted(2));
            hasTestedMulti = true;
        } else {
            toMatch.add(maDetails.getConverted(0));
        }
        for (FederationRegistryApi2.ServiceDetails maDetail : toMatch) {
            assertNotNull(maDetail.getUrn(), "A service in a previous test call did not specify an URN");
            assertNotNull(maDetail.getName(), "A service in a previous test call did not specify an name");
            urnToMatch.add(maDetail.getUrn().getValue());
            nameToMatch.add(maDetail.getName());
        }

        note("Testing match by NAME");
        Hashtable<String, Object> match = new Hashtable<String, Object>();
        Vector<String> filter = null;// new Vector<String>();
        if (nameToMatch.size() > 1)
            match.put("SERVICE_NAME", nameToMatch);
        else
            match.put("SERVICE_NAME", nameToMatch.get(0));

        AbstractFederationApi2.FederationApiReply<AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails>> reply =
                fr.lookupMA(getConnection(), filter, match, null);
        assertTrue(reply.getGeniResponseCode().isSuccess());

        checkLookupServiceCorrectness(reply, filter);
        maDetails = reply.getValue();
        assertNotNull(maDetails);
        assertEquals(maDetails.size(), toMatch.size(), "The search returned a different number of results than expected.");
        for (FederationRegistryApi2.ServiceDetails sd : maDetails.getConvertedList()) {
            assertTrue(urnToMatch.remove(sd.getUrn().getValue()), "returned a service that should not have been matched: "+sd.getUrn());
        }
        assertEmpty(urnToMatch, "Some services where not matched as expected: "+urnToMatch);
    }
    @Test(hardDepends = {"lookupSliceAuthoritiesNoFilter"})
    public void lookupSliceAuthoritiesWithMatchNoFilter() throws JFedException {
        if (saDetails.isEmpty()) skip("cannot test match if there are no SA");

        List<FederationRegistryApi2.ServiceDetails> toMatch = new ArrayList<FederationRegistryApi2.ServiceDetails>();
        Vector<String> urnToMatch = new Vector<String>();
        if (!hasTestedMulti && saDetails.size() > 3) {
            note("Testing list of scalars, indicating an OR, as value in the match dictionary");
            toMatch.add(saDetails.getConverted(1));
            toMatch.add(saDetails.getConverted(2));
            hasTestedMulti = true;
        } else {
            toMatch.add(saDetails.getConverted(0));
        }
        for (FederationRegistryApi2.ServiceDetails saDetail : toMatch) {
            assertNotNull(saDetail.getUrn(), "A service in a previous test call did not specify an URN");
            urnToMatch.add(saDetail.getUrn().getValue());
        }

        note("Testing match by URN");
        Hashtable<String, Object> match = new Hashtable<String, Object>();
        Vector<String> filter = null;// new Vector<String>();
        if (urnToMatch.size() > 1)
            match.put("SERVICE_URN", urnToMatch);
        else
            match.put("SERVICE_URN", urnToMatch.get(0));

        AbstractFederationApi2.FederationApiReply<AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails>> reply =
                fr.lookupSA(getConnection(), filter, match, null);
        assertTrue(reply.getGeniResponseCode().isSuccess());

        checkLookupServiceCorrectness(reply, filter);
        saDetails = reply.getValue();
        assertNotNull(saDetails);
        assertEquals(saDetails.size(), toMatch.size(), "The search returned a different number of results than expected.");
        for (FederationRegistryApi2.ServiceDetails sd : saDetails.getConvertedList()) {
            assertTrue(urnToMatch.remove(sd.getUrn().getValue()), "returned a service that should not have been matched: "+sd.getUrn());
        }
        assertEmpty(urnToMatch, "Some services where not matched as expected: "+urnToMatch);
    }


    /////////////////////////// lookup with filter ////////////////////////////////////////////


    private void checkRawLookupResult(Vector<Hashtable<String, String>> rawLookupResult, List<String> expectedFieldNames, List<String> excludedFieldNames) {
        assertNotNull(rawLookupResult);

        for (Hashtable<String, String> serviceInfo : rawLookupResult) {
            for (String fieldName : expectedFieldNames) {
                if (!serviceInfo.containsKey(fieldName))
                    errorNonFatal("returned result does not contain field: \""+ fieldName+"\"");
            }
            for (String fieldName : excludedFieldNames) {
                if (serviceInfo.containsKey(fieldName))
                    errorNonFatal("returned result contains unexpected field: \""+ fieldName+"\"");
            }
        }
    }
    @Test(softDepends = {"lookupAggregatesWithMatchNoFilter"})
    public void lookupAggregatesWithFilter() throws JFedException {
        Hashtable<String, String> match = null;//new Hashtable<String, String>();
        Vector<String> filter = new Vector<String>();
        filter.add("SERVICE_URL");
        filter.add("SERVICE_CERT");
        filter.add("SERVICE_DESCRIPTION");

        AbstractFederationApi2.FederationApiReply<AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails>> reply =
                fr.lookupAM(getConnection(), filter, match, null);
        assertTrue(reply.getGeniResponseCode().isSuccess());

        checkLookupServiceCorrectness(reply, filter); //was commented, but does not need to be

        Vector<Hashtable<String, String>> rawResult = (Vector<Hashtable<String, String>>) reply.getRawValue();
        assertNotNull(rawResult);
        List<String> expectedFieldNames = new ArrayList<String>(filter);
        List<String> excludedFieldNames = new ArrayList<String>(serviceDefaultFieldNames);
        excludedFieldNames.removeAll(expectedFieldNames);
        checkRawLookupResult(rawResult, expectedFieldNames, excludedFieldNames);
    }
    @Test(softDepends = {"lookupMemberAuthoritiesWithMatchNoFilter"})
    public void lookupMemberAuthoritiesWithFilter() throws JFedException {
        Hashtable<String, String> match = null;//new Hashtable<String, String>();
        Vector<String> filter = new Vector<String>();
        filter.add("SERVICE_NAME");

        AbstractFederationApi2.FederationApiReply<AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails>> reply =
                fr.lookupMA(getConnection(), filter, match, null);
        assertTrue(reply.getGeniResponseCode().isSuccess());

        checkLookupServiceCorrectness(reply, filter); //was commented, but does not need to be

        Vector<Hashtable<String, String>> rawResult = (Vector<Hashtable<String, String>>) reply.getRawValue();
        assertNotNull(rawResult);
        List<String> expectedFieldNames = new ArrayList<String>(filter);
        List<String> excludedFieldNames = new ArrayList<String>(serviceDefaultFieldNames);
        excludedFieldNames.removeAll(expectedFieldNames);
        checkRawLookupResult(rawResult, expectedFieldNames, excludedFieldNames);
    }
    @Test(softDepends = {"lookupSliceAuthoritiesWithMatchNoFilter"})
    public void lookupSliceAuthoritiesWithFilter() throws JFedException {
        Hashtable<String, String> match = null;//new Hashtable<String, String>();
        Vector<String> filter = new Vector<String>();
        filter.add("SERVICE_URN");
        filter.add("SERVICE_CERT");
        filter.add("SERVICE_DESCRIPTION");

        AbstractFederationApi2.FederationApiReply<AbstractFederationApi.LookupResult<FederationRegistryApi2.ServiceDetails>> reply =
                fr.lookupSA(getConnection(), filter, match, null);
        assertTrue(reply.getGeniResponseCode().isSuccess());

        checkLookupServiceCorrectness(reply, filter); //was commented, but does not need to be

        Vector<Hashtable<String, String>> rawResult = (Vector<Hashtable<String, String>>) reply.getRawValue();
        assertNotNull(rawResult);
        List<String> expectedFieldNames = new ArrayList<String>(filter);
        List<String> excludedFieldNames = new ArrayList<String>(serviceDefaultFieldNames);
        excludedFieldNames.removeAll(expectedFieldNames);
        checkRawLookupResult(rawResult, expectedFieldNames, excludedFieldNames);
    }


    @Test(hardDepends = {"lookupAggregatesNoFilter"})
    public void lookupAMForUrns() throws JFedException {
        assertNotNull(amDetails);

        {
            //test URNs of (fake) objects on the authorities
            Vector<GeniUrn> urns = new Vector<GeniUrn>();
            for (FederationRegistryApi2.ServiceDetails amDetail : amDetails.getConvertedList()) {
                assertNotNull(amDetail.getUrn(), "A service in a previous test call did not specify an URN");
                urns.add(new GeniUrn(amDetail.getUrn().getTopLevelAuthority(), "sliver", "fakesliver"));
            }
            note("Looking up "+urns.size()+" AM urns: "+urns);
            try {
                AbstractFederationApi2.FederationApiReply<Map<GeniUrn, URL>> reply =
                        fr.lookupAuthoritiesForUrns(getConnection(), urns);
                assertTrue(reply.getGeniResponseCode().isSuccess());

                Map<GeniUrn, URL> mapping = reply.getValue();
                assertNotNull(mapping);

                setErrorsNotFatal();
                assertEquals(mapping.size(), urns.size(), "Size of returned hashtable differs from number of requested urns. returned hashtable="+mapping);
                for (FederationRegistryApi2.ServiceDetails amDetail : amDetails.getConvertedList()) {
                    URL returnedUrl = mapping.get(new GeniUrn(amDetail.getUrn().getTopLevelAuthority(), "sliver", "fakesliver"));
                    assertNotNull(returnedUrl, "lookup_authorities_for_urns did not return an entry for "+amDetail.getUrn());
                    if (returnedUrl != null) {
                        assertEquals(returnedUrl, amDetail.getUrl(), "lookup_authorities_for_urns did not return the same URL for "+amDetail.getUrn());
                    }
                }
                note("first test done.");
            } catch (JFedException e) {
                errorNonFatal("Error calling lookup_authorities_for_urns: probably malformed URN or URL in reply. error message:"+e.getMessage());
            }
            setErrorsFatal();
        }



        //test URNs of the authorities themself
        {
            Vector<GeniUrn> urns = new Vector<GeniUrn>();
            for (FederationRegistryApi2.ServiceDetails amDetail : amDetails.getConvertedList()) {
                assertNotNull(amDetail.getUrn(), "A service in a previous test call did not specify an URN");
                urns.add(amDetail.getUrn());
            }
            note("Looking up "+urns.size()+" AM urns: "+urns);

            try {
                AbstractFederationApi2.FederationApiReply<Map<GeniUrn, URL>> reply =
                        fr.lookupAuthoritiesForUrns(getConnection(), urns);
                assertTrue(reply.getGeniResponseCode().isSuccess());

                Map<GeniUrn, URL> mapping = reply.getValue();
                assertNotNull(mapping);

                setErrorsNotFatal();
                assertEquals(mapping.size(), urns.size(), "Size of returned hashtable differs from number of requested urns. returned hashtable="+mapping);
                for (FederationRegistryApi2.ServiceDetails amDetail : amDetails.getConvertedList()) {
                    URL returnedUrl = mapping.get(amDetail.getUrn());
                    assertNotNull(returnedUrl, "lookup_authorities_for_urns did not return an entry for "+amDetail.getUrn());
                    if (returnedUrl != null) {
                        assertEquals(returnedUrl, amDetail.getUrl(), "lookup_authorities_for_urns did not return the same URL for "+amDetail.getUrn());
                    }
                }

            } catch (JFedException e) {
                errorNonFatal("Error calling lookup_authorities_for_urns: probably malformed URN or URL in reply. error message:"+e.getMessage());
            }
            setErrorsFatal();
        }
    }

    @Test(hardDepends = {"lookupSliceAuthoritiesNoFilter"})
    public void lookupSAForUrns() throws JFedException {

        assertNotNull(saDetails);
        Random r = new Random(System.currentTimeMillis());

        {
            Vector<GeniUrn> urns = new Vector<GeniUrn>();
            Map<GeniUrn, URL> requestUrnToExpectedUrl = new HashMap<GeniUrn, URL>();
            for (FederationRegistryApi2.ServiceDetails saDetail : saDetails.getConvertedList()) {
                assertNotNull(saDetail.getUrn(), "A service in a previous test call did not specify an URN");
                String type;
                switch (r.nextInt(2)) {
                    case 0: { type = "slice"; break; }
                    default: { type = "project"; break; }
                }
                GeniUrn urn = new GeniUrn(saDetail.getUrn().getTopLevelAuthority(), type, "fake"+type);
                requestUrnToExpectedUrl.put(urn, saDetail.getUrl());
                urns.add(urn);
            }
            note("Looking up "+urns.size()+" SA urns: "+urns);

            try {
                AbstractFederationApi2.FederationApiReply<Map<GeniUrn, URL>> reply =
                        fr.lookupAuthoritiesForUrns(getConnection(), urns);
                assertTrue(reply.getGeniResponseCode().isSuccess());

                Map<GeniUrn, URL> mapping = reply.getValue();
                assertNotNull(mapping);

                setErrorsNotFatal();
                assertEquals(mapping.size(), urns.size(), "Size of returned hashtable differs from number of requested urns. returned hashtable=" + mapping);
                for (Map.Entry<GeniUrn, URL> e: requestUrnToExpectedUrl.entrySet()) {
                    URL returnedUrl = mapping.get(e.getKey());
                    URL expectedURL = e.getValue();

                    assertNotNull(returnedUrl, "lookup_authorities_for_urns did not return an entry for "+e.getKey());
                    if (returnedUrl != null) {
                        assertEquals(returnedUrl, expectedURL, "lookup_authorities_for_urns did not return the same URL for "+e.getKey());
                    }
                }

                note("first test done.");
            } catch (JFedException e) {
                errorNonFatal("Error calling lookup_authorities_for_urns: probably malformed URN or URL in reply. error message:"+e.getMessage());
            }
            setErrorsFatal();
        }


        {
            Vector<GeniUrn> urns = new Vector<GeniUrn>();

            for (FederationRegistryApi2.ServiceDetails saDetail : saDetails.getConvertedList()) {
                assertNotNull(saDetail.getUrn(), "A service in a previous test call did not specify an URN");
                urns.add(saDetail.getUrn());
            }
            note("Looking up "+urns.size()+" SA urns: "+urns);
            try {
                AbstractFederationApi2.FederationApiReply<Map<GeniUrn, URL>> reply =
                        fr.lookupAuthoritiesForUrns(getConnection(), urns);
                assertTrue(reply.getGeniResponseCode().isSuccess());

                Map<GeniUrn, URL> mapping = reply.getValue();
                assertNotNull(mapping);

                setErrorsNotFatal();
                assertEquals(mapping.size(), urns.size(), "Size of returned hashtable differs from number of requested urns. returned hashtable=" + mapping);
                for (FederationRegistryApi2.ServiceDetails saDetail : saDetails.getConvertedList()) {
                    URL returnedUrl = mapping.get(saDetail.getUrn());

                    assertNotNull(returnedUrl, "lookup_authorities_for_urns did not return an entry for "+saDetail.getUrn());
                    if (returnedUrl != null) {
                        assertEquals(returnedUrl, saDetail.getUrl(), "lookup_authorities_for_urns did not return the same URL for "+saDetail.getUrn());
                    }
                }

            } catch (JFedException e) {
                errorNonFatal("Error calling lookup_authorities_for_urns: probably malformed URN or URL in reply. error message:"+e.getMessage());
            }
            setErrorsFatal();
        }
    }

    @Test(hardDepends = {"lookupMemberAuthoritiesNoFilter"})
    public void lookupMAForUrns() throws JFedException {
        assertNotNull(maDetails);

        Random r = new Random(System.currentTimeMillis());

        {
            Vector<GeniUrn> urns = new Vector<GeniUrn>();
            Map<GeniUrn, URL> requestUrnToExpectedUrl = new HashMap<GeniUrn, URL>();
            for (FederationRegistryApi2.ServiceDetails maDetail : maDetails.getConvertedList()) {
                assertNotNull(maDetail.getUrn(), "A service in a previous test call did not specify an URN");
                String type;
                switch (r.nextInt(2)) {
                    case 0: { type = "member"; break; }
                    default: { type = "key"; break; }
                }
                GeniUrn urn = new GeniUrn(maDetail.getUrn().getTopLevelAuthority(), type, "fake"+type);
                requestUrnToExpectedUrl.put(urn, maDetail.getUrl());
                urns.add(urn);
            }
            note("Looking up "+urns.size()+" MA urns: "+urns);

            try {
                AbstractFederationApi2.FederationApiReply<Map<GeniUrn, URL>> reply =
                        fr.lookupAuthoritiesForUrns(getConnection(), urns);
                assertTrue(reply.getGeniResponseCode().isSuccess());

                Map<GeniUrn, URL> mapping = reply.getValue();
                assertNotNull(mapping);

                setErrorsNotFatal();
                assertEquals(mapping.size(), urns.size(), "Size of returned hashtable differs from number of requested urns. returned hashtable=" + mapping);
                for (Map.Entry<GeniUrn, URL> e: requestUrnToExpectedUrl.entrySet()) {
                    URL returnedUrl = mapping.get(e.getKey());
                    URL expectedURL = e.getValue();

                    assertNotNull(returnedUrl, "lookup_authorities_for_urns did not return an entry for "+e.getKey());
                    if (returnedUrl != null) {
                        assertEquals(returnedUrl, expectedURL, "lookup_authorities_for_urns did not return the same URL for "+e.getKey());
                    }
                }

                note("first test done.");
            } catch (JFedException e) {
                errorNonFatal("Error calling lookup_authorities_for_urns: probably malformed URN or URL in reply. error message:"+e.getMessage());
            }
            setErrorsFatal();
        }

        {
            Vector<GeniUrn> urns = new Vector<GeniUrn>();
            for (FederationRegistryApi2.ServiceDetails maDetail : maDetails.getConvertedList()) {
                assertNotNull(maDetail.getUrn(), "A service in a previous test call did not specify an URN");
                urns.add(maDetail.getUrn());
            }
            note("Looking up "+urns.size()+" MA urns: "+urns);

            try {
                AbstractFederationApi2.FederationApiReply<Map<GeniUrn, URL>> reply =
                        fr.lookupAuthoritiesForUrns(getConnection(), urns);
                assertTrue(reply.getGeniResponseCode().isSuccess());

                Map<GeniUrn, URL> mapping = reply.getValue();
                assertNotNull(mapping);

                setErrorsNotFatal();
                assertEquals(mapping.size(), urns.size(), "Size of returned hashtable differs from number of requested urns. returned hashtable=" + mapping);
                for (FederationRegistryApi2.ServiceDetails maDetail : maDetails.getConvertedList()) {
                    URL returnedUrl = mapping.get(maDetail.getUrn());

                    assertNotNull(returnedUrl, "lookup_authorities_for_urns did not return an entry for "+maDetail.getUrn());
                    if (returnedUrl != null) {
                        assertEquals(returnedUrl, maDetail.getUrl(), "lookup_authorities_for_urns did not return the same URL for "+maDetail.getUrn());
                    }
                }
            } catch (JFedException e) {
                errorNonFatal("Error calling lookup_authorities_for_urns: probably malformed URN or URL in reply. error message:"+e.getMessage());
            }
            setErrorsFatal();
        }
    }



    @Test()
    public void lookupTrustRoots() throws JFedException {
        AbstractFederationApi2.FederationApiReply<List<String>> reply =
                fr.getTrustRoots(getConnection());
        assertTrue(reply.getGeniResponseCode().isSuccess());

        List<String> trustRoots = reply.getValue();
        assertNotNull(trustRoots);
        for (String trustRoot : trustRoots) {
            String tr = trustRoot;
            if (tr.length() > 30) tr = trustRoot.substring(0, 30) + "...";
            note("get_trust_roots returned (showing maximum of 30 chars): "+tr);
        }
    }
}
