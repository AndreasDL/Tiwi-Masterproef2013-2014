package be.iminds.ilabt.jfed.lowlevel.api.test;

import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api.AggregateManager3;
import be.iminds.ilabt.jfed.lowlevel.api.UserSpec;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.lowlevel.resourceid.ResourceUrn;
import be.iminds.ilabt.jfed.testing.base.ApiTest;
import be.iminds.ilabt.jfed.util.CommandExecutionContext;
import be.iminds.ilabt.jfed.util.RFC3339Util;
import be.iminds.ilabt.jfed.util.TextUtil;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.*;

/**
 * TestAggregateManager3
 */
public class TestAggregateManager3 extends ApiTest {
    public String getTestDescription() {
        return "Many Aggregate Manager (Geni AM API v3) Tests. 2 slices and a sliver will be created during the tests. "+
                "The sliver will be deleted. This will not test ListResources.";
    }
    @Override
    public List<String> getOptionalConfigKeys() {
        List<String> res = new ArrayList<String>();
        /* fixed_ssh_private_key_file and fixed_ssh_public_key_file option:
              There are 3 cases:
                  option not specified: use randomly generated key that is different each time
                  option specified, with private key file specified: use public and private key from files (public key can be read from PEM certificate)
                  option specified, with private key file specified, AND this file is the same file for both and is a user login file (key+cert file): use public and private key from file. Note that some site might only use this ssh key anyhow (such as perhaps fuseco?)

         */
        res.add("fixed_ssh_public_key_file"); //needed if fixed_ssh_private_key_file is specified (file containing PEM x509certificate is also allowed)
        res.add("fixed_ssh_private_key_file"); //needed if fixed_ssh_public_key_file is specified
        res.add("fixed_ssh_private_key_password"); //may be null,even if fixed_ssh_private_key_file is not (in case no password is needed)

        res.add("credentialType"); //regular, speaksFor or delegation
        res.add("passwordFilename2");
        res.add("userUrn2");
        res.add("pemKeyAndCertFilename2");
        res.add("userAuthorityUrn2");


        res.add("be_less_strict"); //turns some failures into warnings

        return res;
    }



    private CommonAMTest commonAMTest;
    private AggregateManager3 am3;
    private CommandExecutionContext testContext;

    public SfaConnection getAM3Connection() throws JFedException {
        return (SfaConnection) testContext.getConnectionProvider().getConnectionByAuthority(testContext.getGeniUser(), testContext.getTestedAuthority(), new ServerType(ServerType.GeniServerRole.AM, 3));
    }

    /**
     * Check for correctness of a AM3 XmlRpc result. Should be tested for each reply received.
     * */
    public void testAM3CorrectnessXmlRpcResult(Hashtable res) {
        Object code = res.get("code");
        Object value = res.get("value");
        Object output = res.get("output");
        assertNotNull(code, "testAM3CorrectnessXmlRpcResult code == null in "+res);
        assertNotNull(value, "testAM3CorrectnessXmlRpcResult value == null in "+res);
        assertEquals(code.getClass(), Hashtable.class, "testAM3CorrectnessXmlRpcResult code is not Hashtable in "+res);
        Hashtable codeHt = (Hashtable) code;
        Object genicode = codeHt.get("geni_code");
        assertNotNull(genicode, "testAM3CorrectnessXmlRpcResult code does not contain \"geni_code\" in "+res);
        assertEquals(genicode.getClass(), Integer.class, "testAM3CorrectnessXmlRpcResult code.geni_code is not int in "+res);

        int genicodevalue = (Integer) genicode;
        //output should be present if code is not 0
        if (genicodevalue != 0) {
            assertNotNull(output, "testAM3CorrectnessXmlRpcResult: while geni_code is non success ("+genicodevalue+"), output == null in "+res);
            assertEquals(output.getClass(), String.class, "testAM3CorrectnessXmlRpcResult: while geni_code is non success ("+genicodevalue+"), output is not String (it is "+output.getClass().getName()+" with value \""+output.toString()+"\") in \"+res+\"");
        }
        else {
            if (output == null)
                note("testAM3CorrectnessXmlRpcResult: while geni_code is success ("+genicodevalue+"), output is ommited. This is allowed by the API.");
            if (output != null && !(output instanceof String))
                warn("testAM3CorrectnessXmlRpcResult: while geni_code is success ("+genicodevalue+"), output is not String (it is "+output.getClass().getName()+" with value \""+output.toString()+"\"). This is allowed but not recommended by jFed.");
        }
    }

    private boolean beLessStrict = false; //turn some failures into warnings
    public void setUp(CommandExecutionContext testContext) {
        this.testContext = testContext;
        assertNotNull(testContext);
        assertNotNull(testContext.getGeniUser());
        assertNotNull(testContext.getUserAuthority());

        commonAMTest = new CommonAMTest(this, testContext);
        am3 = new AggregateManager3(testContext.getLogger());

        if (getTestConfig().get("be_less_strict") != null) {
            Object v = getTestConfig().get("be_less_strict");
            if (v instanceof Boolean)
                beLessStrict = (Boolean) v;
            else
                beLessStrict = TextUtil.stringToBoolean(v+"");
            note("be_less_strict option specified: "+v);
            if (beLessStrict)
                note(" be_less_strict activated: turning some failures into warnings");
            else
                note(" be_less_strict is NOT activated");
        }

        if (getTestConfig().get("credentialType") != null) {
            String credentialTypeParameter = (String) getTestConfig().get("credentialType");

            boolean known = false;
            boolean normal = credentialTypeParameter.trim().equalsIgnoreCase("normal") || credentialTypeParameter.trim().equalsIgnoreCase("regular");
            boolean sf = credentialTypeParameter.trim().equalsIgnoreCase("speaksFor");
            boolean dele = credentialTypeParameter.trim().equalsIgnoreCase("delegation") || credentialTypeParameter.trim().equalsIgnoreCase("delegated") || credentialTypeParameter.trim().equalsIgnoreCase("delegate");

            if (normal)
                note("All tests will test regular credentials");
            if (sf)
                note("All tests will test speaks-for credentials");
            if (dele)
                note("All tests will test delegated credentials");

            if (!sf && !dele && !normal)
                throw new RuntimeException("credentialType parameter has unrecognized value \""+credentialTypeParameter+"\". Possible values: regular speaksFor delegation");

            if (sf || dele) {
                note("Getting info for 2nd user in \""+credentialTypeParameter+"\" credentials");
                CommandExecutionContext secondUserContext = CommandExecutionContext.loadFromProperties(getTestConfig(), true, false, "2", " in test config");
                assertNotNull(secondUserContext);
                assertNotNull(secondUserContext.getGeniUser());
                assertNotNull(secondUserContext.getUserAuthority());

                if (sf)
                    commonAMTest.selectSpeaksForTestCredentialType(this, secondUserContext);
                if (dele)
                    commonAMTest.selectDelegationTestCredentialType(this, secondUserContext);
            } else {
                assert normal;
                commonAMTest.selectRegularTestCredentialType(this);
            }
        } else {
            note("All tests will test regular credentials");
            commonAMTest.selectRegularTestCredentialType(this);
        }
    }


    private static List<String> toStringList(String s) {
        List<String> res = new ArrayList<String>();
        res.add(s);
        return res;
    }
    private static List<String> toStringList(String s1, String s2) {
        List<String> res = new ArrayList<String>();
        res.add(s1);
        res.add(s2);
        return res;
    }
    private static List<String> toStringList(String s1, String s2, String s3) {
        List<String> res = new ArrayList<String>();
        res.add(s1);
        res.add(s2);
        res.add(s3);
        return res;
    }




    private Hashtable versionRawResult = null;
    private AggregateManager3.VersionInfo versionInfo = null;
    @Test(groups = {"getversion"})
    public void testGetVersionXmlRpcCorrectness() throws JFedException {
        AggregateManager3.AggregateManagerReply<AggregateManager3.VersionInfo> reply = am3.getVersion(getAM3Connection());

        testAM3CorrectnessXmlRpcResult(reply.getRawResult());

        //GetVersion is the only method where we have to check for something extra in the raw XMLRPC result
        versionRawResult = reply.getRawResult();
        assertNotNull(versionRawResult);

        Object ver = versionRawResult.get("geni_api"); //this is here for backward compatibility with v1. GetVersion returns this on all versions.
        assertNotNull(ver);
        assertTrue(ver instanceof Integer);
        int v = ((Integer) ver).intValue();
        assertEquals(v, 3, "AM (backward compatibility \"geni_api\" field) is not version 3");


        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS, "GeniResponse code is not SUCCESS (0)");

        versionInfo = reply.getValue();
        assertNotNull(versionInfo);
        assertEquals(versionInfo.getApi(), 3, "AM is not version 3");
    }

    @Test(hardDepends = { "testGetVersionXmlRpcCorrectness" }, groups = {"getversion"})
    public void testGetVersionResultCorrectness() throws JFedException {
        note("This test does not call GetVersion again, it uses the result received by \"testGetVersionXmlRpcCorrectness\"");
        Hashtable value = (Hashtable) versionRawResult.get("value");

        //check if all required fields are present
        assertEquals(value.get("geni_api"), new Integer(3));

        assertNotNull(value.get("geni_api_versions"), "geni_api_versions not in version result");
        assertTrue(value.get("geni_api_versions") instanceof Hashtable, "geni_api_versions is not a Hashtable but a "+value.get("geni_api_versions").getClass().getName());

        String [] rspecVersionListnames = { "geni_request_rspec_versions", "geni_ad_rspec_versions" };
        for (String name : rspecVersionListnames) {
            assertNotNull(value.get(name), name+" not in GetVersion result");
            assertTrue(value.get(name) instanceof Vector, name+" is not a Vector but a "+value.get(name).getClass().getName());

            Vector v = (Vector) value.get(name);
            assertTrue(v.size() > 0, name+" array is empty");
            for (Object o : v) {
                assertTrue(o instanceof Hashtable, name+" array should contain only Hashtable not a "+o.getClass().getName());
                Hashtable t = (Hashtable) o;
                assertHashTableContainsNonemptyString(t, "type");
                assertHashTableContainsNonemptyString(t, "version");
                assertHashTableContainsString(t, "schema");
                assertHashTableContainsString(t, "namespace");
                Object extensionsO = t.get("extensions");
                assertNotNull(extensionsO);
                assertTrue(extensionsO instanceof Vector, "value for extensions of "+name+" is not a String but a " + extensionsO.getClass().getName());
                Vector extensions = (Vector) extensionsO;
                for (Object e : extensions)
                    assertTrue(e instanceof String, "an extension of \"+name+\" is not a string but a "+e.getClass().getName());
            }
        }
        String [] credentialTypeListnames = { "geni_credential_types" };
        for (String name : credentialTypeListnames) {
            assertNotNull(value.get(name), name+" not in GetVersion result");
            assertTrue(value.get(name) instanceof Vector, name+" is not a Vector but a "+value.get(name).getClass().getName());

            Vector v = (Vector) value.get(name);
            assertTrue(v.size() > 0, name+" array is empty");
            for (Object o : v) {
                assertTrue(o instanceof Hashtable, name+" array should contain only Hashtable not a "+o.getClass().getName());
                Hashtable t = (Hashtable) o;
                String typ = assertHashTableContainsNonemptyString(t, "geni_type");
                //version 3 actually requires a String! But that string should contain an integer.
                //TODO support actual integer as well, but with warning
//                int ver = assertContainsInteger(t, "geni_version", "WARNING: GetVersion result - \"geni_credential_types\" - \"geni_version\" is a String, "+
//                        "but it should have been an Integer. (will parse String to Integer and continue)");
                String ver = assertHashTableContainsNonemptyString(t, "geni_version");
            }
        }

        Object urn = value.get("urn");
        if (urn != null) {
            setErrorsNotFatal();
            assertInstanceOf(urn, String.class, "if URN is defined, it should be a String, not a "+urn.getClass().getName());
            if (urn instanceof String) {
                String urnString = (String) urn;
                String testUrnString = testContext.getTestedAuthority().getUrn().getValue();
                if (!urnString.equals(testUrnString))
                    warn("URN in GetVersion ("+urnString+") does not match the URN used to start this test ("+testUrnString+
                            "). This could either be a problem on the server, a bad URN in GetVersion, or it could be that " +
                            "the jFed has wrong info about this authority. This failure could result in a failure to allocate " +
                            "resources (as the component_manager urn used will not match this server).");
            }
            setErrorsFatal();
        } else {
            note("GetVersion does not specify \"urn\" (which contains the component manager urn). This is not mandatory, but it is useful to include.");
        }
    }
    @Test(hardDepends = { "testGetVersionXmlRpcCorrectness" }, softDepends = {"testGetVersionResultCorrectness"}, groups = {"getversion"})
    public void testGetVersionResultApiVersionsCorrectness() throws JFedException, MalformedURLException {
        note("This test does not call GetVersion again, it uses the result received by \"testGetVersionXmlRpcCorrectness\"");
        Hashtable value = (Hashtable) versionRawResult.get("value");
        Hashtable versions = (Hashtable) value.get("geni_api_versions");

        //test if contains self reference
        Object o = versions.get(/*new Integer(3)*/"3");
        if (o == null) {
            o = versions.get(new Integer(3));
            if (o != null)
                warn("geni_api_versions for key=\"3\" (Integer value in String) is null. (Note that for key=3 (Integer) it is \"" + o + "). " +
                        "This test will accept Integer instead of String, but the API specifies it should be a String.");
        }
        assertNotNull(o, "geni_api_versions for key=3 is null (tried with both int 3 and string \"3\").");
        assertTrue(o instanceof String, "value for key=\"3\" is not a String but a " + o.getClass().getName());

        //test that no url's are incorrect and none have localhost as hostname
        for (Object key : versions.keySet()) {
            assertTrue(key instanceof Integer || key instanceof String, "geni_api_versions keys should be Integer (or String), not "+key.getClass().getName());
            int versionNr;
            if (key instanceof Integer) {
                warn("geni_api_versions contains a key of type Integer with value "+key+". " +
                        "This test will accept keys of type Integer instead of String, but the API specifies it should be String.");
                versionNr = (Integer) key;
            }
            else {
                versionNr = Integer.parseInt((String) key);
            }
            Object val = versions.get(key);
            assertTrue(val instanceof String, "geni_api_versions values should be String, not "+val.getClass().getName());
            String urlS = (String) val;
            //check URL
            URL url = new URL(urlS);
            String host = url.getHost();
            assertFalse(host.equals("localhost"), "Illegal host in URL: "+url+" (host in URL should not be the non-global \""+host+"\")");
            assertFalse(host.equals("127.0.0.1"), "Illegal host in URL: "+url+" (host in URL should not be the non-global \""+host+"\")");

        }
    }

    @Test(hardDepends = { "testGetVersionXmlRpcCorrectness" }, softDepends= { "testGetVersionResultApiVersionsCorrectness", "testGetVersionResultCorrectness" }, groups = {"getversion"})
    public void testGetVersionResultNoDuplicates() throws JFedException {
        note("This test does not call GetVersion again, it uses the result received by \"testGetVersionXmlRpcCorrectness\"");
        //Check if RSpecs are unique
        List<AggregateManager3.VersionInfo.RspecVersion> adRspecVersions = new ArrayList<AggregateManager3.VersionInfo.RspecVersion>();
        for (AggregateManager3.VersionInfo.RspecVersion rspecVer : versionInfo.getAdRspecVersions()) {
            for (AggregateManager3.VersionInfo.RspecVersion other : adRspecVersions)
                assertFalse(other.equalTypeAndVersion(rspecVer), "VersionInfo Result invalid: Duplicate Rspec type/version pair in supported Advertisement RSpec:"+
                        "type="+other.getType()+" version="+other.getVersion()+" VS "+
                        "type="+rspecVer.getType()+" version="+rspecVer.getVersion()+" ");
            adRspecVersions.add(rspecVer);
        }

        List<AggregateManager3.VersionInfo.RspecVersion> reqRspecVersions = new ArrayList<AggregateManager3.VersionInfo.RspecVersion>();
        for (AggregateManager3.VersionInfo.RspecVersion rspecVer : versionInfo.getRequestRspecVersions()) {
            for (AggregateManager3.VersionInfo.RspecVersion other : reqRspecVersions)
                assertFalse(other.equalTypeAndVersion(rspecVer), "VersionInfo Result invalid: Duplicate Rspec type/version pair in supported Request RSpec"+
                        "type="+other.getType()+" version="+other.getVersion()+" VS "+
                        "type="+rspecVer.getType()+" version="+rspecVer.getVersion()+" ");
            reqRspecVersions.add(rspecVer);
        }

        List<AggregateManager3.VersionInfo.CredentialType> credentialTypes = new ArrayList<AggregateManager3.VersionInfo.CredentialType>();
        for (AggregateManager3.VersionInfo.CredentialType credentialType : versionInfo.getCredentialTypes()) {
            for (AggregateManager3.VersionInfo.CredentialType other : credentialTypes)
                assertFalse(other.equals(credentialType), "VersionInfo Result invalid: Duplicate CredentialType type/version pair in supported Request RSpec"+
                        "type="+other.getType()+" version="+other.getVersion()+" VS "+
                        "type="+credentialType.getType()+" version="+credentialType.getVersion()+" ");
            credentialTypes.add(credentialType);
        }
    }





    @Test(hardDepends = { "testGetVersionXmlRpcCorrectness" }, softDepends= {"testGetVersionResultNoDuplicates"},
            description = "This test calls ListResources without any credentials. That should fail.")
    public void testListResourcesBadCredential() throws JFedException {
        //Test without credentials. Should fail.
        AggregateManager3.AggregateManagerReply<String> reply = am3.listResources(
                getAM3Connection(),
                new ArrayList<AnyCredential>(), //no credential
                "geni",
                "3",
                true,
                true,
                null);

        testAM3CorrectnessXmlRpcResult(reply.getRawResult());

        assertFalse(reply.getGeniResponseCode().isSuccess(), "The ListResources call should fail when given no credentials. Instead, it returned success!");

        //only warning if somewhat acceptable error code
        if (reply.getGeniResponseCode().equals(GeniAMResponseCode.GENIRESPONSE_FORBIDDEN) || reply.getGeniResponseCode().equals(GeniAMResponseCode.GENIRESPONSE_ERROR))
            warn("The ListResources call should fail with error code 1 \"Bad Arguments: malformed arguments\" when given no credentials. Instead, it returned "+reply.getGeniResponseCode()+"  "+reply.getGeniResponseCode().getDescription());
        else
            assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_BADARGS, "The ListResources call should fail with error code 1 \"Bad Arguments: malformed arguments\" when given no credentials. Instead, it returned "+reply.getGeniResponseCode()+"  "+reply.getGeniResponseCode().getDescription());
    }

    @Test(hardDepends = { "testGetVersionXmlRpcCorrectness" }, softDepends= {"testGetVersionResultNoDuplicates"})
    public void testListAvailableResources() throws JFedException {
        AggregateManager3.AggregateManagerReply<String> reply = am3.listResources(
                getAM3Connection(),
                commonAMTest.getUserCredentialList(),
                "geni",
                "3",
                true,
                true,
                commonAMTest.addCredentialExtraOptions(null)/*extraoptions*/);

        testAM3CorrectnessXmlRpcResult(reply.getRawResult());

        assertTrue(reply.getGeniResponseCode().isSuccess(), "The ListResources call did not return success but "+reply.getGeniResponseCode());
    }

    @Test(hardDepends = { "testGetVersionXmlRpcCorrectness" }, softDepends= {"testGetVersionResultNoDuplicates"},
            description = "This test calls Status with user credentials, and the urn of a non exisiting slice. That should fail.")
    public void testStatusBadSlice() throws JFedException {
        String badSliceUrn = "urn:publicid:IDN+"+testContext.getUserAuthority().getNameForUrn()+"+slice+NonExisting";

        List<String> urns = new ArrayList<String>();
        urns.add(badSliceUrn);

        AggregateManager3.AggregateManagerReply<AggregateManager3.StatusInfo> reply =
                am3.status(getAM3Connection(), urns, commonAMTest.getUserCredentialList(), false/*besteffort*/, commonAMTest.addCredentialExtraOptions(null)/*extraoptions*/);

        testAM3CorrectnessXmlRpcResult(reply.getRawResult());

        assertFalse(reply.getGeniResponseCode().isSuccess(), "SliverStatus reply GeniResponse code is SUCCESS (0) when given a non existing slice \"" + badSliceUrn + "\"");
    }

    /*
    *
    * For testing:
    *   - slice0  is a slice that will have no sliver on the AM
    *   - sliceS  is a slice that will have a sliver on the AM
    *
    * */

    /* Create the slices needed in the next tests. Uses SA, but not AM */
    private CommonAMTest.SliceInfo slice0;
    private CommonAMTest.SliceInfo sliceS;
    @Test(hardDepends = { "testGetVersionXmlRpcCorrectness" }, softDepends= {"testGetVersionResultNoDuplicates"},
            description = "Create the slices used in the next tests")
    public void createTestSlices() throws JFedException {
        //create slices to use in AM tests
        slice0 = commonAMTest.createSlice("n");
        sliceS = commonAMTest.createSlice("s");

        assertNotNull(slice0.urnString, "slice0.urnString may not be null");
        assertTrue( slice0.urnString.startsWith("urn:publicid:IDN+"));
        assertNotNull(slice0.credential != null, "slice0.credential may not be null");
        assertValidUrn(slice0.urnString, "slice");

        assertNotNull(sliceS.urnString, "sliceS.urnString may not be null");
        assertTrue(sliceS.urnString.startsWith("urn:publicid:IDN+"));
        assertNotNull(sliceS.credential, "sliceS.credential may not be null");
        assertValidUrn(sliceS.urnString, "slice");
    }

    @Test(hardDepends = {"createTestSlices"}, description = "Call Status on a slice without slivers. It is expected an error such as 12 \"Search Failed (eg for slice)\" is returned.")
    public void testStatusNoSliverSlice() throws JFedException {
        //then check if SliverStatus reports not found as it should
        AggregateManager3.AggregateManagerReply<AggregateManager3.StatusInfo> reply =
                am3.status(getAM3Connection(), toStringList(slice0.urnString), commonAMTest.getSliceCredentialList(slice0), false/*besteffort*/, commonAMTest.addCredentialExtraOptions(null));

        testAM3CorrectnessXmlRpcResult(reply.getRawResult());

        /*
        * Calling Status() on an unknown, deleted or expired sliver (by explicit URN) shall result in an error
        * (e.g. SEARCHFAILED, EXPIRED or ERROR)
        *
        * (unless geni_best_effort is true, in which case the method may succeed,
         * but return a geni_error for each sliver that failed).
          *
          * Attempting to get Status() for a slice (no slivers identified) with no current slivers at this aggregate
          * may return an empty list for geni_slivers, may return a list of previous slivers that have since been
          * deleted, or may even return an error (e.g. SEARCHFAILED or EXPIRED).
          * Note therefore that geni_slivers may be an empty list.
        * */

        String spec = "Attempting to get Status() for a slice (no slivers identified) with no current slivers at this aggregate\n" +
                " may return an empty list for geni_slivers, may return a list of previous slivers that have since been\n" +
                " deleted, or may even return an error (e.g. SEARCHFAILED or EXPIRED).\n" +
                " Note therefore that geni_slivers may be an empty list.";
        note("AMV3 spec says: \""+spec+"\"");

        boolean isSuccess = reply.getGeniResponseCode().isSuccess();
        boolean emptySliverList = isSuccess && reply.getValue().getSliverInfo().isEmpty();

        boolean isSearchFailed = reply.getGeniResponseCode().equals(GeniAMResponseCode.GENIRESPONSE_SEARCHFAILED);
        boolean isExpired = reply.getGeniResponseCode().equals(GeniAMResponseCode.GENIRESPONSE_EXPIRED);

        if (isSuccess) {
            assertTrue(emptySliverList,
                    "The reply to the Status call has response code SUCCESS (0) when given a slice \""+ slice0.urnString +
                            "\" that has no sliver. However, the sliver list is not empty, as would be expected " +
                            "(because there are no previous slivers in this slice)");
        } else {
            if (!isSearchFailed && !isExpired)
                warn("The reply to the Status call has response code "+reply.getGeniResponseCode()+" when given a slice \""+
                        slice0.urnString +"\" that has no sliver. This is acceptable behaviour. However, there are more " +
                        "fitting errors to return, such as code 12 \"Search Failed (eg for slice)\" or code 15 \"Expired\"");
        }
    }

    public void verifyDescribeReplyNoSliver(String urn, AggregateManager3.AggregateManagerReply<AggregateManager3.ManifestInfo> reply) {
        testAM3CorrectnessXmlRpcResult(reply.getRawResult());

        String specsText = "If a slice urn is supplied and there are no slivers in the given slice at this aggregate, " +
                "then geni_rspec shall be a valid manifest RSpec, containing zero (0) node or link elements - that is, specifying no resources. " +
                "geni_slivers may be an empty array, or may be an array of previous slivers that have since been deleted or expired. " +
                "Calling Describe on one or more sliver URNs that are unknown, deleted or expired shall result in an error (e.g. SEARCHFAILED, EXPIRED or ERROR geni_code). ";

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "Describe reply GeniResponse code is not SUCCESS (0) when given a slice \"" + urn + "\" that has" +
                        " no sliver (available=unspecified). (according to the specs:\""+specsText+"\")");

        AggregateManager3.ManifestInfo manifestInfo = reply.getValue();
        assertNotNull(manifestInfo,
                "Describe reply is completely empty when given a slice \"" + urn + "\" that has" +
                        " no sliver (available=unspecified). (according to the specs:\""+specsText+"\")");
        String rspec = manifestInfo.getManifestRspec();

        assertEquals(CommonAMTest.testValidGeni3ManifestRspec(this, rspec), 0,
                "Describe reply when given a slice \"" + urn + "\" that has" +
                        " no sliver (available=unspecified) is not an valid RSpec (according to the specs:\"" + specsText + "\"): " + rspec);

        assertTrue(CommonAMTest.isEmptyRspec(this, rspec),
                "Describe reply when given a slice \""+ urn +"\" that has"+
                        " no sliver (available=unspecified) is not an empty RSpec (according to the specs:\""+specsText+"\"): "+rspec);
    }

    @Test(hardDepends = {"createTestSlices"} )
    public void testDescribeNoSliverSlice() throws JFedException {
        assertNotNull(slice0);

        //check if SliverStatus reports not found as it should
        AggregateManager3.AggregateManagerReply<AggregateManager3.ManifestInfo> reply =
                am3.describe(getAM3Connection(), toStringList(slice0.urnString), commonAMTest.getSliceCredentialList(slice0), "geni", "3", true/*compressed*/, commonAMTest.addCredentialExtraOptions(null));

        verifyDescribeReplyNoSliver(slice0.urnString, reply);

        //check if SliverStatus reports not found as it should
        reply = am3.describe(getAM3Connection(), toStringList(slice0.urnString), commonAMTest.getSliceCredentialList(slice0), "geni", "3", false/*compressed*/, commonAMTest.addCredentialExtraOptions(null));

        verifyDescribeReplyNoSliver(slice0.urnString, reply);
    }


    private String sliverSUrnStr;
    private ResourceUrn sliverSUrn;
    @Test(hardDepends = {"createTestSlices"} )
    public void testAllocate() throws JFedException, NoSuchAlgorithmException, ParseException {
        assertNotNull(sliceS);

        //TODO: make sure geni 3 is advertised in GetVersion. If not, use another RSpec request format!
        String requestRspec = CommonAMTest.getOneNodeRequestRSpec(testContext.getTestedAuthority());
        if (requestRspec == null) skip("Allocate skipped, because no RSpec example known for type=\""+testContext.getTestedAuthority().getType()+"\"");

        AggregateManager3.AggregateManagerReply<AggregateManager3.AllocateAndProvisionInfo> reply =
                am3.allocate(getAM3Connection(), commonAMTest.getSliceCredentialList(sliceS), sliceS.urnString, requestRspec, null/*endTime*/, commonAMTest.addCredentialExtraOptions(null));

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS, "Allocate did not succeed");

        AggregateManager3.AllocateAndProvisionInfo allocateAndProvisionInfo = reply.getValue();
        String replyRequestRspec = allocateAndProvisionInfo.getRspec();
        assertNotNull(replyRequestRspec, "Allocate should return a request RSpec"+replyRequestRspec);
        //TODO check if it is a request rspec

        //TODO API question: Allocate returns a request RSpec, why? (also, in the specification, the return struct mentions a manifest rspec)

        List<AggregateManager3.SliverInfo> sliverInfos = allocateAndProvisionInfo.getSliverInfo();
        assertEquals(sliverInfos.size(), 1, "should be exactly 1 sliver allocated");
        AggregateManager3.SliverInfo sliverInfo = sliverInfos.get(0);
        sliverSUrnStr = sliverInfo.getSliverUrn();
        assertNotNull(sliverSUrnStr);
        assertValidUrn(sliverSUrnStr, "sliver");
        sliverSUrn = new ResourceUrn(sliverSUrnStr);
        assertEquals(sliverInfo.getAllocationStatus(), "geni_allocated", "Allocated sliver should be in geni_allocated state");

        try {
            Date expireDate = sliverInfo.getExpiresDate();
            Date now = new Date();
            if (!now.before(expireDate))
                warn("newly allocated sliver does not expire in the future! now="+now+" expireDate=\""+expireDate+"\"");
//           assertTrue(now.before(expireDate), "allocated sliver does not expire in the future! now="+now+" expireDate="+expireDate);
        } catch (ParseException e) {
            warn("geni_expire data is NOT a valid RFC3339 date: \""+sliverInfo.getExpires()+"\"");
        }

        System.out.println("Allocated sliver for \"" + sliceS.urnString + "\" replyRequestRspec=" + replyRequestRspec);
    }

    NodeLoginTester nodeLoginTester;

    @Test(hardDepends = {"testAllocate"} )
    public void testProvision() throws JFedException, NoSuchAlgorithmException, ParseException {
        assertNotNull(sliceS);
        assertNotNull(sliverSUrnStr);
        assertValidUrn(sliverSUrnStr, "sliver");

        //check GetVersion geni_single_allocation  if it is true, we may only give a slice URN, no sliver URN(s)
        List<String> urns = toStringList(sliverSUrnStr);
        if (versionInfo.isSingleSliceAllocation()) {
            urns = toStringList(sliceS.urnString);
        }

        //Note: currently Utah Emulab's current AM3 doesn't work without this optional option
        //      TODO we should also test without users to replicate this problem!

        assert nodeLoginTester == null;
        String fixedSshPublicKeyFile = getTestConfig().getProperty("fixed_ssh_public_key_file");
        String fixedSshPrivateKeyFile = getTestConfig().getProperty("fixed_ssh_private_key_file");
        String fixedSshPrivateKeyPassword = getTestConfig().getProperty("fixed_ssh_private_key_password");
        nodeLoginTester = new NodeLoginTester(this, fixedSshPublicKeyFile, fixedSshPrivateKeyFile, fixedSshPrivateKeyPassword);

        Vector<String> sshKeys = new Vector<String>();
        sshKeys.add(nodeLoginTester.getSshKeyHelper().getSshPublicKeyString());
        UserSpec userSpec = new UserSpec(testContext.getGeniUser().getUserUrnString(), sshKeys);
        List<UserSpec> users = new ArrayList<UserSpec>();
        users.add(userSpec);

        //TODO: make sure geni 3 is advertised in GetVersion. If not, use another RSpec manifest format!

        AggregateManager3.AggregateManagerReply<AggregateManager3.AllocateAndProvisionInfo> reply =
                am3.provision(getAM3Connection(), urns, commonAMTest.getSliceCredentialList(sliceS),
                        "geni", "3", null/*bestEffort*/, null/*endtime*/, users/*users*/, commonAMTest.addCredentialExtraOptions(null) /*extraoptions*/);

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS, "Provision did not succeed");

        AggregateManager3.AllocateAndProvisionInfo allocateAndProvisionInfo = reply.getValue();
        String manifestRspec = allocateAndProvisionInfo.getRspec();
        assertNotNull(manifestRspec, "Provision should return a manifest RSpec");
        assertEquals(CommonAMTest.testValidGeni3ManifestRspec(this, manifestRspec), 1,
                "Provision did not return a valid RSpec" + manifestRspec);
        assertFalse(CommonAMTest.isEmptyRspec(this, manifestRspec),
                "Provision returned and empty RSpec: " + manifestRspec);

        assert ! nodeLoginTester.hasParsed();
        nodeLoginTester.parseSshInfoFromGeni3ManifestRspec(manifestRspec);

        List<AggregateManager3.SliverInfo> sliverInfos = allocateAndProvisionInfo.getSliverInfo();
        assertEquals(sliverInfos.size(), 1, "should be exactly 1 sliver provisioned");
        AggregateManager3.SliverInfo sliverInfo = sliverInfos.get(0);
        String resSliverSUrnStr = sliverInfo.getSliverUrn();
        assertNotNull(resSliverSUrnStr);
        assertValidUrn(resSliverSUrnStr, "sliver");
        assertEquals(resSliverSUrnStr, sliverSUrnStr, "Provisioned result has different URN than request");

//Note: State 3, geni_provisioned, is the state of the sliver allocation after the aggregate begins to instantiate the sliver.
        assertEquals(sliverInfo.getAllocationStatus(), "geni_provisioned", "according to specification, sliver should immediately be in geni_provisioned state after the Provision call");

        try {
            Date expireDate = sliverInfo.getExpiresDate();
            Date now = new Date();
            assertTrue(now.before(expireDate), "provisioned sliver does not expire in the future! now="+now+" expireDate="+expireDate);
        } catch (ParseException e) {
            warn("geni_expire data is NOT a valid RFC3339 date: \""+sliverInfo.getExpires()+"\"");
        }

        //TODO check if manifest rspec is valid

        //TODO check if users are in manifest rspec

        System.out.println("Provisioned sliver for \"" + sliceS.urnString + "\" manifestRspec=" + manifestRspec);
    }

    @Test(hardDepends = {"testProvision"} )
    public void testSliverBecomesProvisioned() throws JFedException, ParseException {
        //Test if the sliver ever becomes provisioned. We wait for maximum 20 minutes.
        assertNotNull(sliceS);

        long now = System.currentTimeMillis();
        long deadline = now + (20*60*1000);
        while (now < deadline) {
            AggregateManager3.AggregateManagerReply<AggregateManager3.StatusInfo> reply =
                    am3.status(getAM3Connection(), toStringList(sliceS.urnString),
                            commonAMTest.getSliceCredentialList(sliceS), null/*best effort*/, commonAMTest.addCredentialExtraOptions(null));

            validSuccesStatus(reply);

            AggregateManager3.StatusInfo statusInfo = reply.getValue();
            List<AggregateManager3.SliverInfo> sliverInfos = statusInfo.getSliverInfo();
            AggregateManager3.SliverInfo sliverInfo = sliverInfos.get(0);

//Note: State 3, geni_provisioned, is the state of the sliver allocation after the aggregate begins to instantiate the sliver.
            assertNotEquals(sliverInfo.getAllocationStatus(), "geni_unallocated", "sliver became geni_unallocated while waiting for it to be provisioned.");
            assertNotEquals(sliverInfo.getAllocationStatus(), "geni_allocated", "sliver became geni_allocated while waiting for it to be provisioned.");
            assertEquals(sliverInfo.getAllocationStatus(), "geni_provisioned", "sliver is not in geni_provisioned while waiting for it to be provisioned.");

            //geni_failed is a state which will will see a a failure to become ready
            assertNotEquals(sliverInfo.getOperationalStatus(), "geni_failed", "sliver operational state became \"geni_failed\" while waiting for it to be provisioned. We assume this is a failure.");

            //When waiting for "geni_provisioned" to be completed, the sliver is always in state
            //      geni_pending_allocation
            //   typically, when the sliver is "geni_provisioned" it will become
            //      geni_notready   after which it can be started. (but other states are possible)
            //CONCLUSION: if the sliver is not in "geni_pending_allocation", it is ready
            if (!sliverInfo.getOperationalStatus().equals("geni_pending_allocation"))  {
                System.out.println("testSliverBecomesReady -> sliver is now fully provisioned: operational_state="+sliverInfo.getOperationalStatus());
                return;
            }

            System.out.println("testCreatedSliverBecomesReady -> sliver not fully provisioned: operational_state="+sliverInfo.getOperationalStatus()+".  Trying again in 30 seconds...");
            try {
                Thread.sleep(30000 /*ms*/);
            } catch (InterruptedException e) { /* Ignore*/ }
            now = System.currentTimeMillis();
        }
        throw new RuntimeException("Sliver did not become ready within 20 minutes!");
    }

    @Test(hardDepends = {"testSliverBecomesProvisioned"} )
    public void testPerformOperationalAction() throws JFedException, NoSuchAlgorithmException, ParseException {
        assertNotNull(sliceS);
        assertNotNull(sliverSUrnStr);
        assertValidUrn(sliverSUrnStr, "sliver");

        //check GetVersion geni_single_allocation  if it is true, we may only give a slice URN, no sliver URN
        List<String> urns = toStringList(sliverSUrnStr);
        if (versionInfo.isSingleSliceAllocation()) {
            urns = toStringList(sliceS.urnString);
        }

        String action = "geni_start";

        AggregateManager3.AggregateManagerReply<List<AggregateManager3.SliverInfo>> reply;
        try {
            reply = am3.performOperationalAction(getAM3Connection(), urns, commonAMTest.getSliceCredentialList(sliceS),
                            action,
                            null/*bestEffort*/, commonAMTest.addCredentialExtraOptions(null) /*extraoptions*/);
        } catch (JFedException e) {
            if (beLessStrict) {
                warn("Exception while executing performOperationalAction. Due to be_less_strict, this will be ignored. Message: " + e.getMessage());
                return;
            }
            throw e;
        }

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS, "PerformOperationalAction did not succeed");

        //special check, this really is an error, but we will make it a warning so dependant tests can continue.
        if (!(reply.getRawResult().get("value") instanceof Vector)) {
            warn("ERROR: Invalid reply to PerformOperationalAction. The \"value\" of a successful call should be a Vector (API specifies: \"list of struct\"), but it was: "+reply.getRawResult().get("value").getClass()+". "+
                    "\nNote: This ERROR has been converted to a warning so that dependent tests can run.");
            return;
        }
        if (reply.getValue() == null) {
            warn("ERROR: Invalid reply to PerformOperationalAction."+
                    "\nNote: This ERROR has been converted to a warning so that dependent tests can run.");
            return;
        }

        List<AggregateManager3.SliverInfo> sliverInfos = reply.getValue();
        assertNotNull(sliverInfos, "jFed failed to process the PerformOperationalAction reply correctly. (this is either an invalid reply to PerformOperationalAction or a jFed bug)");
        assertEquals(sliverInfos.size(), 1, "should be exactly 1 sliver returned for PerformOperationalAction");
        AggregateManager3.SliverInfo sliverInfo = sliverInfos.get(0);
        String resSliverSUrnStr = sliverInfo.getSliverUrn();
        assertNotNull(resSliverSUrnStr);
        assertValidUrn(resSliverSUrnStr, "sliver");
        assertEquals(resSliverSUrnStr, sliverSUrnStr, "PerformOperationalAction result has different URN than request");
        sliverSUrn = new ResourceUrn(sliverSUrnStr);
//        assertEquals(sliverInfo.getAllocationStatus(), "geni_allocated", "Provisioned sliver should be in geni_allocated state");

        try {
            Date expireDate = sliverInfo.getExpiresDate();
            Date now = new Date();
            assertTrue(now.before(expireDate), "started sliver does not expire in the future! now="+now+" expireDate="+expireDate);
        } catch (ParseException e) {
            warn("geni_expire data is NOT a valid RFC3339 date: \""+sliverInfo.getExpires()+"\"");
        }

        System.out.println("PerformOperationalAction for \"" + sliceS.urnString + "\" action=" + action);
    }

    public void validSuccesStatus(AggregateManager3.AggregateManagerReply<AggregateManager3.StatusInfo> reply) throws ParseException {
        testAM3CorrectnessXmlRpcResult(reply.getRawResult());

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "SliverStatus reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceS.urnString + "\" that has a sliver.");

        assertEquals(reply.getRawResult().get("value").getClass(), Hashtable.class,
                "SliverStatus value should be a Hashtable. Not: "+reply.getRawResult().get("value"));

        AggregateManager3.StatusInfo statusInfo = reply.getValue();
        assertNotNull(statusInfo);

        String resSliceUrn = statusInfo.getSliceUrn();
        assertNotNull(resSliceUrn);
        assertValidUrn(resSliceUrn, "slice");
        assertEquals(resSliceUrn, sliceS.urnString, "Status slice urn is not correct slice");

        List<AggregateManager3.SliverInfo> sliverInfos = statusInfo.getSliverInfo();
        assertEquals(sliverInfos.size(), 1, "should be exactly 1 sliver status");
        AggregateManager3.SliverInfo sliverInfo = sliverInfos.get(0);
        String resSliverSUrnStr = sliverInfo.getSliverUrn();
        assertNotNull(resSliverSUrnStr);
        assertValidUrn(resSliverSUrnStr, "sliver");
        assertEquals(resSliverSUrnStr, sliverSUrnStr, "Provisioned result has different URN than request");
        sliverSUrn = new ResourceUrn(sliverSUrnStr);

        //TODO check if allocation states are allowed values (note that RSpec can describe additional allowed states)
        assertNotNull(sliverInfo.getAllocationStatus());

        //TODO check if operational states are allowed values (note that RSpec can describe additional allowed states)
        assertNotNull(sliverInfo.getOperationalStatus());

        try {
            Date expireDate = sliverInfo.getExpiresDate();
            Date now = new Date();
            assertTrue(now.before(expireDate), "sliver does not expire in the future! now="+now+" expireDate="+expireDate);
        } catch (ParseException e) {
            warn("geni_expire data is NOT a valid RFC3339 date: \""+sliverInfo.getExpires()+"\"");
        }

        assertNotNull(sliverInfo.getExpires());
    }

    @Test(hardDepends = {"testPerformOperationalAction"} )
    public void testStatusExistingSliver() throws JFedException, ParseException {
        assertNotNull(sliceS);
        assertNotNull(sliverSUrnStr);
        assertValidUrn(sliverSUrnStr, "sliver");


        AggregateManager3.AggregateManagerReply<AggregateManager3.StatusInfo> reply =
                am3.status(getAM3Connection(), toStringList(sliceS.urnString),
                        commonAMTest.getSliceCredentialList(sliceS), null/*best effort*/, commonAMTest.addCredentialExtraOptions(null));
        validSuccesStatus(reply);
    }

    public void checkDescribeExistingSliver(AggregateManager3.AggregateManagerReply<AggregateManager3.ManifestInfo> reply, String sliceUrn, String sliverUrn) {
        testAM3CorrectnessXmlRpcResult(reply.getRawResult());

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "Describe reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceS.urnString + "\" that has a sliver.");

        AggregateManager3.ManifestInfo manifestInfo = reply.getValue();
        assertNotNull(manifestInfo,
                "Describe reply is completely empty when given a provisioned sliver \"" + sliverUrn + "\"");

        assertEquals(manifestInfo.getSliceUrn(), sliceUrn, "Describe reply is for another slice URN than requested");

        String rspec = manifestInfo.getManifestRspec();
        assertEquals(CommonAMTest.testValidGeni3ManifestRspec(this, rspec), 1,
                "Describe reply rspec when given a provisioned sliver \"" + sliverUrn + "\" is not an valid RSpec");

        List<AggregateManager3.SliverInfo> sliverInfos = manifestInfo.getSliverInfos();
        assertEquals(sliverInfos.size(), 1, "should be exactly 1 sliver status");
        AggregateManager3.SliverInfo sliverInfo = sliverInfos.get(0);
        String resSliverSUrnStr = sliverInfo.getSliverUrn();
        assertNotNull(resSliverSUrnStr);
        assertValidUrn(resSliverSUrnStr, "sliver");
        assertEquals(resSliverSUrnStr, sliverSUrnStr, "Describe reply sliver info has different sliver URN than request");
        sliverSUrn = new ResourceUrn(sliverSUrnStr);
        //TODO check if allocation states are allowed values (note that RSpec can describe additional allowed states)
        assertNotNull(sliverInfo.getAllocationStatus());
        //TODO check if operational states are allowed values (note that RSpec can describe additional allowed states)
        assertNotNull(sliverInfo.getOperationalStatus());
        //TODO check if expires is correct date according to RFC
        assertNotNull(sliverInfo.getExpires());
    }

    @Test(hardDepends = {"testPerformOperationalAction"} )
    public void testDescribeExistingSliver() throws JFedException {
        assertNotNull(sliceS);
        assertNotNull(sliverSUrnStr);
        assertValidUrn(sliverSUrnStr, "sliver");

        AggregateManager3.AggregateManagerReply<AggregateManager3.ManifestInfo> reply =
                am3.describe(getAM3Connection(), toStringList(sliverSUrnStr), commonAMTest.getSliceCredentialList(sliceS),
                        "geni", "3", true/*compressed*/, commonAMTest.addCredentialExtraOptions(null));

        assertNotNull(versionInfo);
        if (versionInfo.isSingleSliceAllocation()) {
            String apiText = "    geni_single_allocation: <XML-RPC boolean 1/0, default 0>: When true (not default), and " +
                    "performing one of (Describe, Allocate, Renew, Provision, Delete), such an AM requires you to include " +
                    "either the slice urn or the urn of all the slivers in the same state. If you attempt to run one of " +
                    "those operations on just some slivers in a given state, such an AM will return an error. \n\n" +
                    "   For example, at an AM where geni_single_allocation is true you must Provision all geni_allocated " +
                    "slivers at once. If you supply a list of sliver URNs to Provision that is only 'some' of the " +
                    "geni_allocated slivers for this slice at this AM, then the AM will return an error. Similarly, " +
                    "such an aggregate would return an error from Describe if you request a set of sliver URNs that is " +
                    "only some of the geni_provisioned slivers.";
            note("The server reported geni_single_allocation to be true in the GetVersion reply. This will call Describe" +
                    " with the urn of the single sliver in this slice. According to the API this is valid: \n\n"+apiText);
        }

        //TODO need to test if geni_compressed is correctly handled by server.
        warn("Unimplemented test: need to test if geni_compressed is correctly handled by server.");

        checkDescribeExistingSliver(reply, sliceS.urnString, sliverSUrnStr);
    }

    @Test(hardDepends = { "testPerformOperationalAction" }, softDepends = { "testStatusExistingSliver", "testDescribeExistingSliver" }, groups = {"createsliver"} )
    public void testSliverBecomesStarted() throws JFedException, ParseException {
        //Test if the sliver ever becomes ready. We wait for maximum 20 minutes.
        assertNotNull(sliceS);

        long now = System.currentTimeMillis();
        long deadline = now + (20*60*1000);
        while (now < deadline) {
            AggregateManager3.AggregateManagerReply<AggregateManager3.StatusInfo> reply =
                    am3.status(getAM3Connection(), toStringList(sliceS.urnString),
                            commonAMTest.getSliceCredentialList(sliceS), null/*best effort*/, commonAMTest.addCredentialExtraOptions(null));

            validSuccesStatus(reply);

            AggregateManager3.StatusInfo statusInfo = reply.getValue();
            List<AggregateManager3.SliverInfo> sliverInfos = statusInfo.getSliverInfo();
            AggregateManager3.SliverInfo sliverInfo = sliverInfos.get(0);

            assertNotEquals(sliverInfo.getAllocationStatus(), "geni_unallocated", "sliver became geni_unallocated while waiting for it to start.");
            assertNotEquals(sliverInfo.getAllocationStatus(), "geni_allocated", "sliver became geni_allocated while waiting for it to start.");
            assertEquals(sliverInfo.getAllocationStatus(), "geni_provisioned", "sliver is not in geni_provisioned while waiting for it to start.");

            //geni_failed is a state which will will see a a failure to become ready
            assertNotEquals(sliverInfo.getOperationalStatus(), "geni_failed", "sliver operational state became \"geni_failed\" while waiting for it to start.");

            //Note: this is not generic: not all AM's will support this state
            if (sliverInfo.getOperationalStatus().equals("geni_ready"))  {
                System.out.println("testSliverBecomesReady -> sliver ready: "+sliverInfo.getOperationalStatus());
                return;
            }

            System.out.println("testCreatedSliverBecomesReady -> sliver not ready: "+sliverInfo.getOperationalStatus()+".  Trying again in 30 seconds...");
            try {
                Thread.sleep(30000 /*ms*/);
            } catch (InterruptedException e) { /* Ignore*/ }
            now = System.currentTimeMillis();
        }
        throw new RuntimeException("Sliver did not become ready within 20 minutes!");
    }

    @Test(hardDepends = {"testSliverBecomesStarted"}, groups = {"nodelogin"} )
    public void testNodeLogin() throws JFedException, IOException {
        assert nodeLoginTester != null;

        nodeLoginTester.testNodeLogin();
    }

    @Test(hardDepends = {"testSliverBecomesStarted"}, softDepends = {"testNodeLogin"} )
    public void testRenewSliver() throws JFedException, ParseException {
        assertNotNull(sliceS);



        //Get current expiration time
        AggregateManager3.AggregateManagerReply<AggregateManager3.StatusInfo> replyStatus1 =
                am3.status(getAM3Connection(), toStringList(sliceS.urnString),
                        commonAMTest.getSliceCredentialList(sliceS), null/*best effort*/, commonAMTest.addCredentialExtraOptions(null));
        validSuccesStatus(replyStatus1);
        assertEquals(replyStatus1.getValue().getSliceUrn(), sliceS.urnString);
        assertEquals(replyStatus1.getValue().getSliverInfo().size(), 1);
        String startExpirationTimeString = replyStatus1.getValue().getSliverInfo().get(0).getExpires();
        Date startExpirationTime;
        try {
            startExpirationTime = RFC3339Util.iso8601StringToDate(startExpirationTimeString);
        } catch (ParseException e) {
            throw new RuntimeException("geni_expire data is NOT a valid RFC3339 date: \""+startExpirationTimeString+"\"", e);
        }

        if (sliceS.credential instanceof SfaCredential) {
            SfaCredential sliceCred = (SfaCredential) sliceS.credential;
            if (!sliceCred.getExpiresDate().after(startExpirationTime)) {
                note("Sliver expires at same time as slice. Will renew slice first, so sliver can be then be renewed");
                Date newSliceExpirationTime = new Date(startExpirationTime.getTime() + (10 * 60 * 1000));
                sliceS = commonAMTest.renewSlice(sliceS, newSliceExpirationTime);
            }
        }

        //Test Renew Sliver. Renew so it expires 5 minutes later then before
        Date newSliverExpirationTime = new Date(startExpirationTime.getTime() + (5 * 60 * 1000));
//        Date expirationTime = new Date(System.currentTimeMillis() + (5 * 60 * 1000));
        String newSliverExpirationTimeString = RFC3339Util.dateToRFC3339String(newSliverExpirationTime, true, true, true);
        AggregateManager3.AggregateManagerReply<List<AggregateManager3.SliverInfo>> replyRenew = am3.renew(
                getAM3Connection(),
                toStringList(sliceS.urnString),
                commonAMTest.getSliceCredentialList(sliceS),
                newSliverExpirationTimeString,
                null/*bestEffort*/,
                commonAMTest.addCredentialExtraOptions(null));

        testAM3CorrectnessXmlRpcResult(replyRenew.getRawResult());

        assertEquals(replyRenew.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "RenewSliver reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceS.urnString + "\" that has a sliver.");


        assertEquals(replyRenew.getValue().size(), 1);
        String renewResSliverExpirationTimeString = replyRenew.getValue().get(0).getExpires();
        Date renewResSliverExpirationTime = RFC3339Util.rfc3339StringToDate(renewResSliverExpirationTimeString);
        assertEquals(renewResSliverExpirationTime.getTime(), newSliverExpirationTime.getTime(),
                "Sliver expiration time has not been set to the data asked in Renew reply: str: requested=\""+
                        newSliverExpirationTimeString+"\" set=\""+renewResSliverExpirationTimeString+
                        "\"  date: requested=\""+newSliverExpirationTime+"\" set=\""+renewResSliverExpirationTime+"\"");


        //Get status and check if expiration time is indeed set
        AggregateManager3.AggregateManagerReply<AggregateManager3.StatusInfo> replyStatus2 =
                am3.status(getAM3Connection(), toStringList(sliceS.urnString),
                        commonAMTest.getSliceCredentialList(sliceS), null/*best effort*/, commonAMTest.addCredentialExtraOptions(null));
        validSuccesStatus(replyStatus2);
        assertEquals(replyStatus2.getValue().getSliceUrn(), sliceS.urnString);
        assertEquals(replyStatus2.getValue().getSliverInfo().size(), 1);
        String statusResSliverExpirationTimeString = replyStatus2.getValue().getSliverInfo().get(0).getExpires();
        Date statusResSliverExpirationTime = RFC3339Util.rfc3339StringToDate(statusResSliverExpirationTimeString);
        assertEquals(statusResSliverExpirationTime.getTime(), newSliverExpirationTime.getTime(),
                "Sliver expiration time has not been set to the data asked in Status reply: str: requested=\""+
                        newSliverExpirationTimeString+"\" set=\""+statusResSliverExpirationTimeString+
                        "\"  date: requested=\""+newSliverExpirationTime+"\" set=\""+statusResSliverExpirationTime+"\"");
    }

    /* Test must run after tests that use sliver. Will always run, to cleanup any created sliver. */
    @Test(softDepends = {"testNodeLogin", "testRenewSliver", "testSliverBecomesStarted"}, groups = {"createsliver","nodelogin"} )
    public void testDeleteSliver() throws JFedException {
        if (sliceS.urnString == null) skip("DEBUG: Skipped because other test created nothing to delete");

        assertNotNull(sliceS);

        System.out.println("DeleteSliver for slice " + sliceS.urnString);

//        //Test Delete Sliver by sliver URN
//        assert sliverSUrnStr != null : "sliverSUrnStr is null";
//        assertValidUrn(sliverSUrnStr, "sliver");
//        AggregateManager3.AggregateManagerReply<List<AggregateManager3.SliverInfo>> reply1 =
//                am3.delete(getAM3Connection(), toStringList(sliverSUrnStr), commonAMTest.getSliceCredentialList(sliceS), null/*best effort*/, null);

        //Test Delete Sliver by slice URN
        AggregateManager3.AggregateManagerReply<List<AggregateManager3.SliverInfo>> reply2 =
                am3.delete(getAM3Connection(), toStringList(sliceS.urnString), commonAMTest.getSliceCredentialList(sliceS), null/*best effort*/, commonAMTest.addCredentialExtraOptions(null));

//        testAM3CorrectnessXmlRpcResult(reply1.getRawResult());
        testAM3CorrectnessXmlRpcResult(reply2.getRawResult());

        assertEquals(reply2.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS,
                "DeleteSliver reply GeniResponse code is not SUCCESS (0) when given a slice \"" + sliceS.urnString + "\" that has a sliver.");

        List<AggregateManager3.SliverInfo> sliverInfos = reply2.getValue();
        assertEquals(sliverInfos.size(), 1, "should be exactly 1 sliver status");
        AggregateManager3.SliverInfo sliverInfo = sliverInfos.get(0);
        String resSliverSUrnStr = sliverInfo.getSliverUrn();
        assertNotNull(resSliverSUrnStr);
        assertValidUrn(resSliverSUrnStr, "sliver");
        assertEquals(resSliverSUrnStr, sliverSUrnStr, "Delete reply sliver info has different sliver URN than request");
        sliverSUrn = new ResourceUrn(sliverSUrnStr);

        // Note that this method should return a struct for each deleted sliver, with the URN of the deleted sliver,
        // the allocation state geni_unallocated, and the time when the sliver was previously set to expire.
        // This method may also return an empty list, if no slivers are at this aggregate in the specified slice.

        //TODO check if allocation state is as expected after delete
        assertNotNull(sliverInfo.getAllocationStatus());
        assertEquals(sliverInfo.getAllocationStatus(), "geni_unallocated");

        //might not be present, so no check:
//        //TODO check if operational state is as expected after delete
//        assertNotNull(sliverInfo.getOperationalStatus());




        //test if DeleteSliver worked

        // Calling Status() on an unknown, deleted or expired sliver (by explicit URN) shall result in an error (e.g.
        // SEARCHFAILED, EXPIRED or ERROR) (unless geni_best_effort is true, in which case the method may succeed, but
        // return a geni_error for each sliver that failed).

        //TODO assert that calling status for the status sliver URN fails


        // Attempting to get Status() for a slice (no slivers identified) with no current slivers at this aggregate may
        // return an empty list for geni_slivers, may return a list of previous slivers that have since been deleted,
        // or may even return an error (e.g. SEARCHFAILED or EXPIRED). Note therefore that geni_slivers may be an empty
        // list.
        AggregateManager3.AggregateManagerReply<AggregateManager3.StatusInfo> replyStatus =
                am3.status(getAM3Connection(), toStringList(sliceS.urnString),
                        commonAMTest.getSliceCredentialList(sliceS), null/*best effort*/, commonAMTest.addCredentialExtraOptions(null));
        testAM3CorrectnessXmlRpcResult(replyStatus.getRawResult());

        if (replyStatus.getGeniResponseCode().isSuccess()) {
            //list empty or with deleted slivers (geni_unallocated)

            assertEquals(replyStatus.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS);
            assertEquals(replyStatus.getRawResult().get("value").getClass(), Hashtable.class,
                    "SliverStatus value should be a Hashtable. Not: "+replyStatus.getRawResult().get("value"));
            AggregateManager3.StatusInfo statusInfo = replyStatus.getValue();
            assertNotNull(statusInfo);

            String resSliceUrn = statusInfo.getSliceUrn();
            assertNotNull(resSliceUrn);
            assertValidUrn(resSliceUrn, "slice");
            assertEquals(resSliceUrn, sliceS.urnString, "Status slice urn is not correct slice");

            List<AggregateManager3.SliverInfo> sliverInfosStatus = statusInfo.getSliverInfo();

            if (sliverInfosStatus.isEmpty()) {
                //Ok, it has been deleted
                return;
            }

            //all slivers in this slice should be unallocated
            for (AggregateManager3.SliverInfo si : sliverInfosStatus) {
                String siSliverUrnStr = si.getSliverUrn();
                assertNotNull(siSliverUrnStr);
                assertValidUrn(siSliverUrnStr, "sliver");
                assertEquals(si.getAllocationStatus(), "geni_unallocated");
            }
            //Ok, it has been deleted
            return;
        } else {
            //not success
            //Ok, it has been deleted
            return;
        }

    }

}
