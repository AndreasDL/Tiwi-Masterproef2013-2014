package be.iminds.ilabt.jfed.lowlevel.api.test;

import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.api.AbstractFederationApi;
import be.iminds.ilabt.jfed.lowlevel.api.AbstractFederationApi1;
import be.iminds.ilabt.jfed.testing.base.ApiTest;
import org.apache.logging.log4j.LogManager;

import java.util.*;

/**
 * AbstractFederationApi2Test
 */
public abstract class AbstractFederationApi2Test extends ApiTest {
    private static org.apache.logging.log4j.Logger l4jLogger = LogManager.getLogger();


    /**
     * Check for correctness of a XmlRpc result. Should be tested for each reply received.
     * */
    public void checkCorrectnessXmlRpcResult(AbstractFederationApi1.FederationApiReply res) {
        Hashtable raw = res.getRawResult();
        Object code = raw.get("code");
        Object value = raw.get("value");
        Object output = raw.get("output");
        assertNotNull(code);
        assertNotNull(value);
        assertNotNull(output);
        assertTrue(code instanceof Integer);
        assertTrue(output instanceof String);
    }

    protected AbstractFederationApi1.GetVersionResult getVersionResult;
    protected void checkGetVersion(
            AbstractFederationApi1.FederationApiReply<? extends AbstractFederationApi1.GetVersionResult> reply,
            AbstractFederationApi api,
            boolean isAuthority) throws JFedException {
        checkCorrectnessXmlRpcResult(reply);
        assertTrue(reply.getGeniResponseCode().isSuccess());

        getVersionResult = reply.getValue();
        assertTrue(getVersionResult.getFields() != null);

        //work with raw object below
        Object raw = reply.getRawResult().get("value");
        assertNotNull(raw, "get_version return value not found");
        assertInstanceOf(raw, Hashtable.class);
        Hashtable<String, Object> htRes = (Hashtable<String, Object>) raw;
        setErrorsNotFatal();

        String version = assertHashTableContainsNonemptyString(htRes, "VERSION");

//        Hashtable fields = assertHashTableContainsHashtable(htRes, "FIELDS"); //not mandatory
        Object fieldsObj = htRes.get("FIELDS");
        Hashtable fields = null;
        if (fieldsObj != null) {
            if (fieldsObj instanceof Hashtable)
                fields = (Hashtable) fieldsObj;
            else
                errorNonFatal("get_version FIELDS should be a dictionary (Hashtable), but it is a "+fieldsObj.getClass().getName());
        }

        if (!isAuthority) {
            //registry: no ROLE or CREDENTIAL_TYPES
            assertFalse(htRes.containsKey("ROLES"), "Registry should not have ROLES field in get_version");
            assertFalse(htRes.containsKey("CREDENTIAL_TYPES"), "Registry should not have CREDENTIAL_TYPES field in get_version");
        } else {
            //MemberAuthority or SliceAuthority: require SERVICES and CREDENTIAL_TYPES
            Vector credentialTypes = assertHashTableContainsVector(htRes, "CREDENTIAL_TYPES");
            assertNotEmpty(credentialTypes);

            Vector services = assertHashTableContainsVector(htRes, "SERVICES");
            if (services != null) {
                note("SERVICES advertised in get_version: "+services);
                for (String requiredService : api.getRequiredApiServices())
                    assertTrue(services.contains(requiredService), "The required service "+requiredService+" is not specified in the get_version SERVICES");
                List<String> knownServices = new ArrayList<String>(api.getRequiredApiServices());
                knownServices.addAll(api.getOptionalApiServices());
                List<String> unknownServices = new ArrayList<String>(services);
                unknownServices.removeAll(knownServices);
                assertEmpty(unknownServices, "Some services advertised in get_version SERVICES are unknown: "+unknownServices+"   (note: all known services: "+knownServices+")");
            }

            //Vector roles = assertHashTableContainsVector(htRes, "ROLES"); //optional
        }

        setErrorsFatal();

        List<String> knownFieldValueKeys = new ArrayList<String>();
        knownFieldValueKeys.add("OBJECT");
        knownFieldValueKeys.add("TYPE");
        knownFieldValueKeys.add("CREATE");
        knownFieldValueKeys.add("MATCH");
        knownFieldValueKeys.add("UPDATE");
        knownFieldValueKeys.add("PROTECT"); //only for MemberAuthority
        if (fields != null) {
            note("FIELDS advertised in get_version: "+fields.keySet());
            for (Object entryO : fields.entrySet()) {
                Map.Entry entry = (Map.Entry) entryO;
                assertInstanceOf(entry.getKey(), String.class, "FIELDS contains entry with non-String key: "+entry.getKey().getClass().getName());
                assertInstanceOf(entry.getValue(), Hashtable.class, "FIELDS contains entry with non-Hashtable value: "+entry.getValue().getClass().getName());
                String key = (String) entry.getKey();
                Hashtable<String, Object> value = (Hashtable<String, Object>) entry.getValue();

                setErrorsNotFatal();
                assertTrue(key.startsWith("_"), "supplementary FIELDS should start with and underscore: "+key);

                if (isAuthority) assertTrue(value.containsKey("OBJECT"), "FIELD definition for field \""+key+"\" should contain OBJECT key");

                assertTrue(value.containsKey("TYPE"), "FIELD definition for field \""+key+"\" should contain TYPE key");

                //Not mandatory:
//                if (isAuthority) assertTrue(value.containsKey("CREATE"), "FIELD definition for field \""+key+"\" should contain CREATE key");
//                                 assertTrue(value.containsKey("MATCH"), "FIELD definition for field \""+key+"\" should contain MATCH key");
//                if (isAuthority) assertTrue(value.containsKey("UPDATE"), "FIELD definition for field \""+key+"\" should contain UPDATE key");

                if (value.containsKey("OBJECT") || !isAuthority) {
                    String objectName = (String) value.get("OBJECT");
                    if (objectName == null && !isAuthority)
                        objectName = "SERVICE";
                    List<String> requiredFields = new ArrayList<String>(api.getMinimumFieldNames(objectName));
//                    note("DEBUG: requiredFields="+requiredFields+"  for OBJECT="+objectName+"  at FIELD="+key);
                    assertFalse(requiredFields.contains(key), "The FIELD \""+key+"\" is a required field. Only supplementary fields should be listed in FIELDS");

                    //PROTECT has a default, so it is not mandatory
//                    if (objectName.equals("MEMBER"))
//                        assertTrue(value.containsKey("PROTECT"), "FIELD definition for field \""+key+"\" should contain PROTECT key for OBJECT=MEMBER");
//                    else
                    if (!objectName.equals("MEMBER"))
                        assertFalse(value.containsKey("PROTECT"), "FIELD definition for field \"" + key + "\" should NOT contain PROTECT key for OBJECT != MEMBER");
                }
                for (String vk : value.keySet()) {
                    Object vv = value.get(vk);
                    warnIfNot(knownFieldValueKeys.contains(vk), "Unknown field key " + vk + " for entry " + key);

                    if (vk.equals("OBJECT")) {
                        //                        assertTrue(services.contains(vv), "The supported SERVICES specified in get_version do not support the OBJECT "+vv+" for FIELD "+key);
                        warnIfNot(api.getApiObjects().contains(vv), "Unknown OBJECT " + vv + " for FIELD " + key);
                    }

                    if (vk.equals("TYPE")) {
                        try {
                            Enum e = AbstractFederationApi1.GetVersionResult.FieldInfo.FieldType.valueOf(vv+"");
                        } catch (IllegalArgumentException e) {
                            errorNonFatal("Unknown TYPE "+vv+" for FIELD "+key);
                        }
                    }

                    if (vk.equals("PROTECT")) {
                        try {
                            Enum e = AbstractFederationApi1.GetVersionResult.FieldInfo.Protect.valueOf(vv+"");
                        } catch (IllegalArgumentException e) {
                            errorNonFatal("Unknown PROTECT value "+vv+" for FIELD "+key);
                        }
                    }

                    if (vk.equals("CREATE")) {
                        try {
                            Enum e = AbstractFederationApi1.GetVersionResult.FieldInfo.CreationAllowed.valueOf(vv+"");
                        } catch (IllegalArgumentException e) {
                            errorNonFatal("Unknown CREATE value "+vv+" for FIELD "+key);
                        }
                    }
                }

                if (getVersionResult.getFields() != null)
                    assertTrue(getVersionResult.getFields().containsKey(key), "Bug in jFed: GetVersionResult does not contain failed that is defined in get_version: \""+key+"\". All fields in GetVersionResult="+getVersionResult.getFields().keySet());

                setErrorsFatal();
            }
        }
    }

    protected void addRequiredSupplementaryFieldsToCreate(Hashtable<String, String> fields, String objectName) {
        if (getVersionResult != null) {
            Map<String, AbstractFederationApi1.GetVersionResult.FieldInfo> projectSupplementaryFields =
                    getVersionResult.getFieldsForObject(objectName);
            if (projectSupplementaryFields.size() > 0) {
                for (Map.Entry<String, AbstractFederationApi1.GetVersionResult.FieldInfo> e : projectSupplementaryFields.entrySet()) {
                    String fieldName = e.getKey();
                    AbstractFederationApi1.GetVersionResult.FieldInfo fieldInfo = e.getValue();
                    if (!fields.containsKey(fieldName) && fieldInfo.getCreationAllowed().equals(AbstractFederationApi1.GetVersionResult.FieldInfo.CreationAllowed.REQUIRED)) {
                        List<AbstractFederationApi1.GetVersionResult.FieldInfo.FieldType> fakeableTypes =
                                new ArrayList<AbstractFederationApi1.GetVersionResult.FieldInfo.FieldType>();
                        fakeableTypes.add(AbstractFederationApi1.GetVersionResult.FieldInfo.FieldType.URN);
                        fakeableTypes.add(AbstractFederationApi1.GetVersionResult.FieldInfo.FieldType.URL); //TODO add better dummy values for URN, URL, EMAIL?
                        fakeableTypes.add(AbstractFederationApi1.GetVersionResult.FieldInfo.FieldType.UID);
                        fakeableTypes.add(AbstractFederationApi1.GetVersionResult.FieldInfo.FieldType.STRING);
                        fakeableTypes.add(AbstractFederationApi1.GetVersionResult.FieldInfo.FieldType.EMAIL);
                        fakeableTypes.add(AbstractFederationApi1.GetVersionResult.FieldInfo.FieldType.KEY);
                        if (fakeableTypes.contains(fieldInfo.getType()))
                            fields.put(fieldName, "dummy");
                        else
                            warn("Do not know how to add supplementary field '"+fieldName+"' which has CREATION=REQUIRED and is of TYPE="+fieldInfo.getType());
                    }
                }
            }
        }
    }

    protected void checkLookupCorrectness(AbstractFederationApi1.FederationApiReply reply) {
        setErrorsFatal();
        Object rawReplyValue = reply.getRawValue();
        assertInstanceOf(rawReplyValue, Hashtable.class, "Lookup result should be a dictionary (=Hashtable), but is of type " + rawReplyValue.getClass().getName());
        Hashtable<Object, Object> rawReplyValueHt = (Hashtable<Object, Object>) rawReplyValue;
        setErrorsNotFatal();
        for (Map.Entry e: rawReplyValueHt.entrySet()) {
            Object rawKey = e.getKey();
            Object rawVal = e.getValue();
            assertInstanceOf(rawKey, String.class, "Lookup dictionary should contain dictionaries string (URN) to dictionary. But at least one key is not String but " +
                    rawKey.getClass().getName());
            assertInstanceOf(rawVal, Hashtable.class, "Lookup dictionary should contain dictionaries string to dictionary (=Hashtable). But at least one value is not dict but " +
                    rawVal.getClass().getName());
        }
        setErrorsFatal();
    }
}
