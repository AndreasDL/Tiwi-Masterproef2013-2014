package be.iminds.ilabt.jfed.lowlevel.api.test;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api.*;
import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.JFedAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaPlainConnection;
import be.iminds.ilabt.jfed.lowlevel.connection.HttpsClientWithUserAuthenticationFactory;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaSslConnection;
import be.iminds.ilabt.jfed.lowlevel.stitching.StitchingDirector;
import be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents;
import be.iminds.ilabt.jfed.rspec.request.geni_rspec_3.*;
import be.iminds.ilabt.jfed.testing.base.ApiTest;
import be.iminds.ilabt.jfed.util.*;
import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;
import org.apache.logging.log4j.LogManager;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * StitchingTest:
 *   - create a stitched RSpec, contact SCS and do all needed CreateSlivers.
 *   - Then test login on node and connectivity using ping.
 *   - finally, Delete everything
 */
public class StitchingTest extends ApiTest {
    private static org.apache.logging.log4j.Logger l4jLogger = LogManager.getLogger();

    @Override
    public List<String> getRequiredConfigKeys() {
        List<String> res = new ArrayList<String>();
        res.add("stitchedAuthorityUrns"); //space seperated list
        return res;
    }

    @Override
    public List<String> getOptionalConfigKeys() {
        List<String> res = new ArrayList<String>();
        res.add("topology");
        res.add("rspecfile");
        return res;
    }

    @Override
    public String getTestDescription() {
        return "Test Stitching between multiple authorities, including node login and ping test between nodes";
    }

    String scsUrl;
    String scsUrn;
    List<String> stitchedAuthorityUrns;
    @Override
    public void setUp(CommandExecutionContext testContext) {
        stitchedAuthorityUrns = getStitchedAuthorityUrns();

        commonAMTest = new CommonAMTest(this, testContext);
        am2 = new AggregateManager2(testContext.getLogger());

        //TODO get these from config if specified
        scsUrl = "http://oingo.dragon.maxgigapop.net:8081/geni/xmlrpc";
        scsUrn = "urn:publicid:IDN+oingo.dragon.maxgigapop.net+auth+am";

        logger = getTestContext().getLogger();
        authorityListModel = JFedAuthorityList.getAuthorityListModel();
        assert authorityListModel != null;

        String topologyType = getTestConfig().getProperty("topology");
        String rspecFile = getTestConfig().getProperty("rspecfile");
        if (topologyType == null || topologyType.isEmpty() || topologyType.equals("ring") || topologyType.equals("line") || topologyType.equals("snake")) {
            //supported topology type
        } else
            errorFatal("Unknown topology of type \""+topologyType+"\"");

        if (rspecFile != null && !rspecFile.isEmpty())
            note("Will use user specified Rspec file (\""+rspecFile+"\") instead of automatically generating rspec.");
//            errorFatal("support for rspecfile parameter not yet implemented. \""+rspecFile+"\"");
    }

    public List<String> getStitchedAuthorityUrns() {
        List<String> res = new ArrayList<String>();
        String urnList = getTestConfig().getProperty("stitchedAuthorityUrns");
        if (urnList == null) throw new RuntimeException("StitchingTest required config key stitchedAuthorityUrns is not present.");
        String[] urnsArray = urnList.split(" ");
        for (String urn : urnsArray)
            res.add(urn);
        if (res.isEmpty()) throw new RuntimeException("StitchingTest required config key stitchedAuthorityUrns (space seperated list) does not contain urns: "+urnList);
        if (res.size() == 1) throw new RuntimeException("StitchingTest required config key stitchedAuthorityUrns (space seperated list) contains only 1 urn: "+urnList);
        return res;
    }

    private CommonAMTest commonAMTest;
    private AggregateManager2 am2;

    private List<AnyCredential> getUserCredentialList() {
        assert userCredential != null;
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(userCredential);
        return res;
    }
    private static List<AnyCredential> toCredentialList(AnyCredential c) {
        assert c != null;
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(c);
        return res;
    }

    public SfaConnection getSAConnection() throws JFedException {
        return (SfaConnection) getTestContext().getConnectionProvider().getConnectionByAuthority(getTestContext().getGeniUser(), getTestContext().getUserAuthority(), new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1));
    }
//    public GeniConnection getAM2Connection() throws GeniException {
//        return getTestContext().getConnectionProvider().getConnectionByAuthority(getTestContext().getGeniUser(), getTestContext().getTestedAuthority(), new ServerType(ServerType.GeniServerRole.AM, 2));
//    }


    private class SshInfo {
        String sshUsername;
        String sshHostname;
        int sshPort;

        @Override
        public String toString() {
            return "SshInfo{" +
                    "sshUsername='" + sshUsername + '\'' +
                    ", sshHostname='" + sshHostname + '\'' +
                    ", sshPort=" + sshPort +
                    '}';
        }
    }
    private Map<SfaAuthority, SshInfo> sshInfos = new HashMap<SfaAuthority, SshInfo>();
    private boolean extractSshInfo(SfaAuthority authority, String rspec) {
        if (rspec == null) return false;
        assertNotNull(rspec, "Rspec is null");

        String hostname = null;
        int port = 22;
        String username = null;

        int nodeCount = 0;
        int loginCount = 0;

        //parse the RSpec XML
        try {
            Class docClass = be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents.class;
            String packageName = docClass.getPackage().getName();
            JAXBContext jc = JAXBContext.newInstance(packageName);
            Unmarshaller u = jc.createUnmarshaller();
            JAXBElement<RSpecContents> doc = (JAXBElement<be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents>) u.unmarshal( new StringReader(rspec));
            be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents c = doc.getValue();

            be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RspecTypeContents typ = c.getType();
            assertNotNull(typ, "Received manifest RSpec does not specify a type: " + rspec);
            assertEquals(typ.value(), "manifest", "Received manifest RSpec is not a manifest: " + rspec);

            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    if (el.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents) {
                        be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents node = (be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents) el.getValue();

                        String nodeName = node.getClientId();
                        nodeCount++;

                        for (Object nodeElO : node.getAnyOrRelationOrLocation()) {
                            if (nodeElO instanceof JAXBElement) {
                                JAXBElement nodeEl = (JAXBElement) nodeElO;
//                                if (nodeEl.getValue() instanceof InterfaceContents) {
//                                    InterfaceContents ic = (InterfaceContents) nodeEl.getValue();
//                                    String interfaceName = ic.getClientId();
//                                }
                                if (nodeEl.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.ServiceContents) {
                                    be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.ServiceContents serviceC = (be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.ServiceContents) nodeEl.getValue();
                                    for (Object serviceElO : serviceC.getAnyOrLoginOrInstall()) {
                                        if (serviceElO instanceof JAXBElement) {
                                            JAXBElement serviceEl = (JAXBElement) serviceElO;
                                            if (serviceEl.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.LoginServiceContents) {
                                                be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.LoginServiceContents loginSC = (be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.LoginServiceContents) serviceEl.getValue();

                                                String auth = loginSC.getAuthentication();

                                                String aHostname = loginSC.getHostname();
                                                int aPort = 0;
                                                if (loginSC.getPort() != null)
                                                    aPort = Integer.parseInt(loginSC.getPort());
                                                String aUsername = loginSC.getUsername();

                                                if (auth.equals("ssh-keys")) {
                                                    assertEquals("ssh-keys", auth, "service login authentication must be ssh-keys for node " + nodeName);
                                                    assertNotNull(aHostname, "no hostname in service login for node " + nodeName);
                                                    assertNotNull(aUsername, "no username in service login for node " + nodeName);
                                                    //TODO add support for missing username? (a fallback username can be derived from user urn)

                                                    hostname = aHostname;
                                                    port = aPort;
                                                    username = aUsername;

                                                    loginCount++;
                                                } else {
                                                    note("Unsupported auth in manifest RSpec service login: " + auth);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (JAXBException e) {
            throw new RuntimeException("Exception parsing manifest RSpec Xml: "+e.getMessage(), e);
        }

        if (loginCount > 0)
        {
            assertTrue(loginCount > 0, "no service login found (" + loginCount + " service logins for " + nodeCount + " nodes)");
            assertNotNull(hostname);
            assertNotNull(username);

            if (loginCount > 1)
                note("Found multiple node logins in manifest rspec (" + loginCount + " service logins for " + nodeCount + " nodes), using last one.");

            SshInfo sshInfo = new SshInfo();
            sshInfo.sshUsername = username;
            sshInfo.sshHostname= hostname;
            sshInfo.sshPort = port;
            sshInfos.put(authority, sshInfo);
            return true;
        } else {
            note("Found no node service login in manifest RSpec.");
            return false;
        }
    }







    //Note on dependencies: you can do SCS call and init without actually creating the slice.
    //                      Only the sliceName is needed for these calls
    //                      CreateSlivers does require that the slice is really created




    private AnyCredential userCredential;
    @Test()
    public void getUserCredential() throws JFedException {
        userCredential = commonAMTest.getUserCredential();
    }

    private CommonAMTest.SliceInfo slice;
    @Test(hardDepends = {"getUserCredential"}, groups = {"createslice"})
    public void createSlice() throws JFedException {
        slice = commonAMTest.createSlice("t");

        assertNotNull(slice);
        assertNotNull(slice.urn);
        assertNotNull(slice.name);
        assertNotNull(slice.urnString);
        assertNotNull(slice.credential);
        assertNotNull(slice.credential.getCredentialXml());
        assertTrue(slice.credential.getCredentialXml().length() > 10 , "credential too short "+ slice.credential.getCredentialXml());
    }

    private String rspecXmlStr;
    private List<String> allIps() {
        List<String> res = new ArrayList<String>();
        for (Node node : nodes)
            for (Iface iface : node.ifaces)
                res.add(iface.ip);
        return res;
    }
    private List<String> localIps(SfaAuthority auth) {
        List<String> res = new ArrayList<String>();
        for (Node node : nodes)
            if (node.authUrn.equals(auth.getUrnString()))
                for (Iface iface : node.ifaces)
                    res.add(iface.ip);
        return res;
    }
    private List<String> pingTargetsForAuth(SfaAuthority auth) {
        List<String> res = new ArrayList<String>();
        for (Node node : nodes)
            if (node.authUrn.equals(auth.getUrnString()))
                for (Iface iface : node.ifaces)
                    for (Iface otherSideIface : iface.link.otherIfaces(iface))
                        res.add(otherSideIface.ip);
        return res;
    }
    /** returns true if the authority is one of the authorities with nodes, and not just one of the stitching link auths */
    private boolean isNodeAuth(SfaAuthority auth) {
        return stitchedAuthorityUrns.contains(auth.getUrnString());
    }
    private class Node {
        private final String name;
        private final String authUrn;
        private List<Iface> ifaces = new ArrayList<Iface>();
        private Node(String authUrn) {
            this.name = "PC"+nodes.size();
            this.authUrn = authUrn;
            nodes.add(this);
        }
        private Node(String name, String authUrn) {
            this.name = name;
            this.authUrn = authUrn;
            nodes.add(this);
        }
    }
    private class Iface {
        private final Node node;
        private final Link link;
        private String ip;
        private Iface(Node node, Link link) {
            this.node = node;
            this.link = link;
            this.node.ifaces.add(this);
            this.link.ifaces.add(this);
            this.ip = link.subnet+"."+(link.ifaces.indexOf(this)+1);
        }
        private String getName() {
            return node.name+":if"+node.ifaces.indexOf(this);
        }
    }
    private class Link {
        private final String name;
        private List<Iface> ifaces = new ArrayList<Iface>();
        private final String subnet;
        private Link() {
            this.name = "link"+links.size();
            this.subnet = "192.168."+(4+links.size());
            links.add(this);
        }
        private Link(Node a, Node b) {
            this();
            new Iface(a, this);
            new Iface(b, this);
        }
        private List<String> componentManagerUrns() {
            List<String> res = new ArrayList<String>();
            for (Iface i : ifaces) {
                Node n = i.node;
                res.add(n.authUrn);
            }
            return res;
        }
        private List<Iface> otherIfaces(Iface iface) {
            List<Iface> res = new ArrayList<Iface>();
            for (Iface i : ifaces)
                if (i != iface)
                    res.add(i);
            return res;
        }
    }

    private boolean isSiteNodeExclusive(String authUrn) {
//        SfaAuthority auth = authorityListModel.getByUrn(authUrn);
//        assert auth != null;
//        boolean isExclusive = CommonAMTest.getExclusiveForSite(auth);

        if (authUrn.startsWith("urn:publicid:IDN+wall2.ilabt.iminds.be+authority+"))
            return true;
        return false;
    }
    private String getSiteComponentManagerId(String authUrn) {
        SfaAuthority auth = authorityListModel.getByUrn(authUrn);
        assert auth != null;
        return CommonAMTest.getComponentManagerIdForSite(auth);
    }
    private String getSiteNodeSliverType(String authUrn) {
        SfaAuthority auth = authorityListModel.getByUrn(authUrn);
        assert auth != null;
        String sliverType = CommonAMTest.getSliverTypeForSite(auth);

        if (authUrn.startsWith("urn:publicid:IDN+wall2.ilabt.iminds.be+authority+"))
            return "raw-pc";
        if (sliverType != null && sliverType.equals("raw-pc"))
            return "emulab-openvz";

        if (sliverType == null) //fallback. will probably fail
            return "emulab-openvz";

        return sliverType;
    }


    private void readRspec(String inputRspec) {
        rspecXmlStr = inputRspec;
        try {
            JAXBContext jc = JAXBContext.newInstance(be.iminds.ilabt.jfed.rspec.request.geni_rspec_3.RSpecContents.class);
            Unmarshaller u = jc.createUnmarshaller();
            //            JAXBElement<RSpecContents> doc = (JAXBElement<RSpecContents>) u.unmarshal( new FileInputStream(rspecFile));
            JAXBElement<be.iminds.ilabt.jfed.rspec.request.geni_rspec_3.RSpecContents> doc =
                    (JAXBElement<be.iminds.ilabt.jfed.rspec.request.geni_rspec_3.RSpecContents>) u.unmarshal( new StringReader(inputRspec));
            be.iminds.ilabt.jfed.rspec.request.geni_rspec_3.RSpecContents c = doc.getValue();

            assert c != null;

            //Note: getType() will return null if the type is specified but not "request".
            //      This is because the xsd specifies type as a choice from a list containing only "request".
            if (c != null &&
                    c.getType() != null &&
                    c.getType().value() != null) {
                if (!c.getType().value().equals("request"))
                    l4jLogger.warn("Parsing an RSpec "+c.getType().value()+" as an RSpec request!");
            } else {
                l4jLogger.warn("Parsed RSpec has no type (note: this also occurs if the type is not \"request\"): "+inputRspec);
            }

            Map<String, Iface> nameToIface = new HashMap<String, Iface>();
            Map<String, Node> ifaceNameToRspecNode = new HashMap<String, Node>();

            //first nodes
            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    if (el.getValue() instanceof NodeContents) {
                        NodeContents node = (NodeContents) el.getValue();

                        String compManagerId = node.getComponentManagerId();
                        String id = node.getClientId();
                        //in an advertisement, client ID is typically empty, but component name and ID are set
                        if (id == null) id = node.getComponentName();
                        if (id == null) id = node.getComponentId();

                        assert id != null : "Rspec has a node without any ID: "+el;
                        Node resNode = new Node(id, compManagerId);
                        nodes.add(resNode);

                        for (Object nodeElO : node.getAnyOrRelationOrLocation()) {
                            if (nodeElO instanceof JAXBElement) {
                                JAXBElement nodeEl = (JAXBElement) nodeElO;
                                if (nodeEl.getValue() instanceof InterfaceContents) {
                                    InterfaceContents ic = (InterfaceContents) nodeEl.getValue();
                                    assert ic != null;

                                    //for a request, this is mandatory, but we use the same code to parse the advertisement
                                    //assert ic.getClientId() != null : "InterfaceContents has no clientId: "+ic;
                                    if (ic.getClientId() != null) {
                                        //check if iface with same name is not already added
                                        for (String existingIfaceName : ifaceNameToRspecNode.keySet())
                                            if (ic.getClientId().equals(existingIfaceName))
                                                throw new RuntimeException("Duplicate interfaces in XML Rspec: id=\""+existingIfaceName+"\"");

                                        ifaceNameToRspecNode.put(ic.getClientId(), resNode);
                                    } else {
                                        l4jLogger.warn("ignoring that InterfaceContents has no clientId");
                                    }
                                }
                            }
                        }
                    }
                }
            }

            //then the rest
            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    boolean handled = false;
                    if (el.getValue() instanceof NodeContents)
                        handled = true;
                    if (el.getValue() instanceof LinkContents) {
                        handled = true;
                        LinkContents link = (LinkContents) el.getValue();

                        String id = link.getClientId();
                        //in an advertisement, client ID is typically empty, but component name and ID are set
                        if (id == null) id = link.getOtherAttributes().get("component_name");
                        if (id == null) id = link.getOtherAttributes().get("component_id");

                        assert id != null : "Rspec has a link without any ID: "+el;

                        List<String> linkComponentManagerUrns = new ArrayList<String>();
                        for (Object oo : link.getAnyOrPropertyOrLinkType()) {
                            //sometimes, it's wrapped in a JAXBElement
                            Object value = oo;
                            if (o instanceof JAXBElement)
                                value = ((JAXBElement) oo).getValue();

                            if (value instanceof ComponentManager) {
                                ComponentManager cm = (ComponentManager) value;
                                linkComponentManagerUrns.add(cm.getName());
                            }
                        }

                        if (linkComponentManagerUrns.size() < 2) {
                            //link without stitching
                            continue;
                        }

                        Link resLink = new Link(); //iface creation will add links
                        links.add(resLink);

                        //check if all interfaces of link are known. We will ignore the link if they are not.
                        for (Object linkElO : link.getAnyOrPropertyOrLinkType()) {
                            if (linkElO instanceof JAXBElement) {
                                JAXBElement linkEl = (JAXBElement) linkElO;
                                if (linkEl.getValue() instanceof InterfaceRefContents) {
                                    InterfaceRefContents ic = (InterfaceRefContents) linkEl.getValue();

                                    Iface iface = nameToIface.get(ic.getClientId());
                                    if (iface == null) {
                                        Node rspecNode = ifaceNameToRspecNode.get(ic.getClientId());

                                        if (rspecNode == null) {
                                            l4jLogger.warn("Interface has not been defined in a <node>, but is referred to in a <link>: "+ic.getClientId());
                                        } else
                                            iface = new Iface(rspecNode, resLink); //constructor links Node and Link automatically
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Throwable e) {
            l4jLogger.warn("Error reading Rspec XML (ping test will not be possible due to this): "+e.getMessage(), e);
            nodes.clear();
            links.clear();
        }
    }


    private List<Node> nodes = new ArrayList<Node>();
    private List<Link> links = new ArrayList<Link>();
    @Test(groups = {"init"})
    public void generateRspec() throws JFedException, IOException {
        String topologyType = getTestConfig().getProperty("topology");
        String rspecFile = getTestConfig().getProperty("rspecfile");

        if (rspecFile != null && !rspecFile.isEmpty()) {
//            errorFatal("support for rspecfile parameter not yet implemented. \""+rspecFile+"\"");
//            return;

            readRspec(IOUtils.fileToString(rspecFile));

            Set<String> authUrns = new HashSet<String>();
            for (Node node : nodes)
                authUrns.add(node.authUrn);

            note("Parsed Rspec file. node count="+nodes.size()+"   stitching link count="+links.size());

            note("  Authority URNs="+authUrns);
            stitchedAuthorityUrns = new ArrayList<String>(authUrns);

            note("  Stitching IPs="+allIps());

            return;
        }


        assert authorityListModel != null;
        assert stitchedAuthorityUrns != null;
        assert stitchedAuthorityUrns.size() > 1;

        //create nodes
        for (String authUrn : stitchedAuthorityUrns) {
            Node n = new Node(authUrn);
        }

        //create link(s)
        assert nodes.size() > 1;
        if (topologyType == null || topologyType.isEmpty() || topologyType.equals("ring")) {
            if (nodes.size() == 2) {
                //create link if there are only 2 nodes
                new Link(nodes.get(0), nodes.get(1));
            } else {
                //create links (ring topo)
                Node firstNode = nodes.get(0);
                Node lastNode = nodes.get(nodes.size()-1);
                Node prevNode = lastNode;
                for (Node n : nodes) {
                    new Link(n, prevNode);
                    prevNode = n;
                }
            }
        } else {
            if (topologyType.equals("line") || topologyType.equals("snake")) {
                if (nodes.size() == 2) {
                    //create link if there are only 2 nodes
                    new Link(nodes.get(0), nodes.get(1));
                } else {
                    //create links
                    Node prevNode = null;
                    for (Node n : nodes) {
                        if (prevNode != null)
                            new Link(n, prevNode);
                        prevNode = n;
                    }
                }
            } else {
                errorFatal("Unknown topology of type \""+topologyType+"\"");
            }
        }

        //create Rspec
        String nodesXml = "";
        String linksXml = "";
        for (Node node : nodes) {
            String nodeXml = "  <node client_id=\""+node.name+"\" component_manager_id=\""+getSiteComponentManagerId(node.authUrn)+"\" exclusive=\"" + (isSiteNodeExclusive(node.authUrn) ? "true" : "false") + "\">\n"+
                    "    <sliver_type name=\""+getSiteNodeSliverType((node.authUrn))+"\"/>\n";
//                    "    <sliver_type name=\"emulab-openvz\"/>\n";

            for (Iface iface : node.ifaces)
                nodeXml +=   "    <interface client_id=\""+iface.getName()+"\">\n" +
                        "      <ip address=\""+iface.ip+"\" netmask=\"255.255.255.0\" type=\"ipv4\"/>\n" +
                        "    </interface>\n";

            nodeXml +=      "  </node>\n";
            nodesXml += nodeXml;
        }

        for (Link link : links) {
            String linkXml = "  <link client_id=\""+link.name+"\">\n";
            for (String urn : link.componentManagerUrns())
                linkXml += "    <component_manager name=\""+getSiteComponentManagerId(urn)+"\"/>\n";
            for (Iface iface : link.ifaces)
                linkXml += "    <interface_ref client_id=\""+iface.getName()+"\"/>\n";


            for (int ifaceIndex1 = 0; ifaceIndex1 < link.ifaces.size(); ifaceIndex1++)
                for (int ifaceIndex2 = ifaceIndex1+1; ifaceIndex2 < link.ifaces.size(); ifaceIndex2++) {
                    Iface iface1 = link.ifaces.get(ifaceIndex1);
                    Iface iface2 = link.ifaces.get(ifaceIndex2);
                    //capacity is in demo rspec, and is probably needed:
                    //    I got an error with text "*** ERROR: vtopgen: Cannot mix trivial_ok|emulated with * bw" on emulab.net when not using it
                    //       (but that could also have other cause)
                    linkXml += "    <property source_id=\""+iface1.getName()+"\" dest_id=\""+iface2.getName()+"\" capacity=\"100000\"/>\n" +
                            "    <property source_id=\""+iface2.getName()+"\" dest_id=\""+iface1.getName()+"\" capacity=\"100000\"/>\n";
//                    linkXml += "    <property source_id=\""+iface1.getName()+"\" dest_id=\""+iface2.getName()+"\"/>\n" +
//                               "    <property source_id=\""+iface2.getName()+"\" dest_id=\""+iface1.getName()+"\"/>\n";
                }
            linkXml += "  </link>\n";

            linksXml += linkXml;
        }

        rspecXmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<rspec type=\"request\" \n" +
                "    xmlns=\"http://www.geni.net/resources/rspec/3\" \n" +
                "    xmlns:planetlab=\"http://www.planet-lab.org/resources/sfa/ext/planetlab/1\" \n" +
                "    xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" \n" +
                "       xmlns:stitch=\"http://hpn.east.isi.edu/rspec/ext/stitch/0.1/\" \n" +
                "    xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 \n" +
                "    http://www.geni.net/resources/rspec/3/request.xsd\">  \n" +
                nodesXml+
                linksXml+
                "</rspec>";

        l4jLogger.info("Generated Rspec: " + rspecXmlStr);
        note("Generated Rspec: "+rspecXmlStr);
    }

    private Logger logger;
    private AuthorityListModel authorityListModel;
    private StitchingDirector director;
    private SSHKeyHelper sshKeyHelper;
    private List<UserSpec> users;
    SfaAuthority scsAuth;
    @Test(hardDepends = {"createSlice", "generateRspec"}, groups = {"init"})
    public void initStitching() throws JFedException, NoSuchAlgorithmException, MalformedURLException {
        director = new StitchingDirector(authorityListModel);

        sshKeyHelper = new SSHKeyHelper();

        users = new ArrayList<UserSpec>();
        UserSpec userSpec = new UserSpec(getTestContext().getGeniUser().getUserUrnString(), sshKeyHelper.getSshPublicKeyString());
        users.add(userSpec);

        //create stitching auth if doesn't exist
        scsAuth = null;
        if (authorityListModel.getByUrn(scsUrn) == null) {
            Map< ServerType, URL> urlMap = new HashMap< ServerType, URL>();
            urlMap.put(new ServerType(ServerType.GeniServerRole.SCS, 1), new URL(scsUrl));
            scsAuth = new SfaAuthority(scsUrn, "Stitching Test SCS", urlMap, null/*proxies*/, null, "scs");
            authorityListModel.addAuthority(scsAuth);
            authorityListModel.fireChange();

            assert authorityListModel.getByUrn(scsUrn) != null;
        } else
            scsAuth = authorityListModel.getByUrn(scsUrn);
    }


    @Test(hardDepends = {"initStitching"}, groups = {"scs"})
    public void callSCS() throws JFedException {
        assertNotNull(slice);
        assert rspecXmlStr != null;

        //contact stitcher
        StitchingComputationService scs = new StitchingComputationService(logger);
        SfaConnection con = new SfaPlainConnection(scsAuth, scsAuth.getUrl(ServerType.GeniServerRole.SCS, 1).toExternalForm(), null/*proxyInfo*/, false/*debug*/);

        StitchingComputationService.SCSReply<StitchingComputationService.ComputePathResult> scsReply =
                scs.computePath(con, slice.urnString, rspecXmlStr, null);

        assertNotNull(scsReply);
        assertEquals(scsReply.getCode(), 0, "SCS call Result code is not 0 but "+scsReply.getCode());
        assertNotNull(scsReply.getValue());

        StitchingComputationService.ComputePathResult computePathResult = scsReply.getValue();

        director.setComputePathResult(computePathResult);

        assertTrue(director.getAllAuthorities().size() > 0);
        assertTrue(director.getHopsLeft().size() > 0);
        assertTrue(director.getReadyHops().size() > 0);
        assertEquals(director.getHopsLeft().size(), director.getAllAuthorities().size(),
                "director getHopsLeft().size() != getAllAuthorities().size()  -> "+
               director.getHopsLeft().size()+" != "+director.getAllAuthorities().size());
    }

    private SfaConnection getAm2Connection(SfaAuthority auth) throws URISyntaxException, JFedException {
        GeniUser user = getTestContext().getGeniUser();
        String url = auth.getUrl(ServerType.GeniServerRole.AM, 2).toURI().toString();
        SfaConnection con = null;
        if (url.startsWith("http://")) {
            note("WARNING: Connection URL is http instead of https! " +
                    "This is unsecure, so this connection protocol will never used. " +
                    "Will try using https instead, maybe that works.");
            url = url.replaceFirst("http", "https");
        }
        if (url.startsWith("https://"))
            con = new SfaSslConnection(auth,
                    url,
                    user.getClientCertificateChain(),
                    user.getPrivateKey(),
                    null/*proxyInfo*/,
                    false/*debug*/,
                    handleUntrustedCallback);
        if (url.startsWith("http://"))
            con = new SfaPlainConnection(auth,
                    url,
                    null/*proxyInfo*/,
                    false/*debug*/);
        assert con != null : "URL has unsupported protocol: "+url;
        return con;
    }


    private HttpsClientWithUserAuthenticationFactory.HandleUntrustedCallback handleUntrustedCallback = null;
    public void setInsecure() {
        handleUntrustedCallback = new HttpsClientWithUserAuthenticationFactory.INSECURE_TRUSTALL_HandleUntrustedCallback();
    }
    @Test(hardDepends = {"callSCS", "createSlice"}, groups = {"createsliver"})
    public void callCreateSlivers() throws JFedException, URISyntaxException {
        assertNotNull(slice.credential);

        setInsecure();

        List<StitchingDirector.ReadyAuthorityDetails> readyHops = director.getReadyHops();
        while (!readyHops.isEmpty()) {
            String readyHopString = "";
            for (StitchingDirector.ReadyAuthorityDetails hop : readyHops)
                readyHopString+=" "+hop.getAuthority().getUrnString();
            note("Hops ready: " + readyHops.size()+": "+readyHopString);
            l4jLogger.info("Hops ready: " + readyHops.size()+": "+readyHopString);
            l4jLogger.trace("Hops ready: " + readyHops);

            //Either use loop or call getReadyHops each time
//            for (StitchingDirector.ReadyHopDetails hop : readyHops) {
            StitchingDirector.ReadyAuthorityDetails hop = readyHops.get(0); {

                SfaAuthority auth = hop.getAuthority();
                String requestRspec = hop.getRequestRspec();

                note("   CreateSliver call for " + auth.getUrnString());
                l4jLogger.info("   CreateSliver call for hop=" + hop);
                l4jLogger.info("   CreateSliver call for auth=" + auth.getUrnString());

                SfaConnection con = getAm2Connection(auth);

//                AbstractGeniAggregateManager.AggregateManagerReply<String> reply = am2.listResources(
//                        con, toCredentialList(sliceCredential), "geni_sfa", "3",
//                        true/*available*/, true/*compressed*/, sliceUrnStr,
//                        null);   //DEBUGREUSEPREVTEST this is for specifc debugging only, replace by commented lines below
                AbstractGeniAggregateManager.AggregateManagerReply<String> reply = am2.createSliver(
                        con, toCredentialList(slice.credential), slice.urnString, requestRspec, users,
                        null);

                l4jLogger.trace("   Processing result of CreateSliver call for " + auth.getUrnString());
                boolean failure = director.processCreateSliverResult(hop, reply);
                assertFalse(failure, "Stitching director reported failure for call with reply code="+reply.getGeniResponseCode()+" output="+reply.getOutput());

                if (reply.getGeniResponseCode().isSuccess()) {
                    String manifestRspec = reply.getValue();
                    assert manifestRspec != null;
                    extractSshInfo(auth, manifestRspec);
                }
//                assertTrue(reply.getGeniResponseCode().isSuccess(), "Call not successful: "+reply.getGeniResponseCode());
//
//                String manifestRspec = reply.getValue();
//                assert manifestRspec != null;
//
//                director.processManifest(hop, manifestRspec);
//
//                extractSshInfo(auth, manifestRspec);
            }

            readyHops = director.getReadyHops();
        }
    }

    @Test(hardDepends = {"callCreateSlivers"}, groups = {"createsliver"})
    public void waitForAllReady() throws JFedException, URISyntaxException {
        List<SfaAuthority> sliverAuths = director.getActivelyInvolvedAuthorities();

        long now = System.currentTimeMillis();
        long deadline = now + (20*60*1000);

        assertTrue(sliverAuths.size() > 0, "There are no actively involved Authorities.");

        //Test if the slivers ever becomes ready. We wait for maximum 20 minutes.
        while (now < deadline) {
            List<SfaAuthority> sliverAuthsToCheck = new ArrayList<SfaAuthority>(sliverAuths);
            assertTrue(sliverAuthsToCheck.size() > 0);

            for (SfaAuthority auth : sliverAuthsToCheck) {
                SfaConnection con = getAm2Connection(auth);

                now = System.currentTimeMillis();
                l4jLogger.info("   Calling SliverStatus on " + auth.getUrnString() + ". Deadline in: " + (deadline - now) + " ms");

                AggregateManager2.AggregateManagerReply<AggregateManager2.SliverStatus> reply =
                        am2.sliverStatus(con, toCredentialList(slice.credential), slice.urnString, null);

                Hashtable rawValue = (Hashtable) reply.getRawResult().get("value");
                String geniStatus = assertHashTableContainsNonemptyString(rawValue, "geni_status");
                //Possible values are: configuring, ready, failed, and unknown         (in practice "changing" is included as well)
                if (geniStatus.equals("ready")) {
                    note("testCreatedSliverBecomesReady -> sliver ready: "+geniStatus+" @ "+auth.getUrn());
                    sliverAuths.remove(auth);
                    if (sliverAuths.isEmpty()) {
                        note("testCreatedSliverBecomesReady -> all slivers ready");
                        return;
                    }
                    continue;
                } else {
                    if (geniStatus.equals("failed")) {
                        errorNonFatal("testCreatedSliverBecomesReady -> sliver failed instead of becoming ready: "+geniStatus+""+" @ "+auth.getUrn());
                        if (rawValue.get("geni_resources") != null &&
                                rawValue.get("geni_resources") instanceof Vector)
                            for (Object o : ((Vector)rawValue.get("geni_resources"))) {
                                if (o instanceof Hashtable) {
                                    Hashtable ht = (Hashtable) o;
                                    String geni_urn = ht.get("geni_urn")+"";
                                    String geni_status = ht.get("geni_status")+"";
                                    String geni_error = ht.get("geni_error")+"";
                                    note("resource: geni_urn="+geni_urn);
                                    note("          geni_status="+geni_status);
                                    note("          geni_error="+geni_error);
                                }
                            }

                        errorFatal("sliver failed");
                    } else {
                        note("testCreatedSliverBecomesReady -> sliver not ready: "+geniStatus+""+" @ "+auth.getUrn());
                        l4jLogger.info("      Sliver not ready: \"" + geniStatus + "\". Deadline in: " + (deadline - now) + " ms");
                    }
                }
            }

            now = System.currentTimeMillis();
            note("testCreatedSliverBecomesReady -> At least one sliver still not ready.  Trying again in 30 seconds...");
            l4jLogger.info("   At least one sliver still not ready. Sleeping for 30 seconds. Deadline in: " + (deadline - now) + " ms");

            try {
                Thread.sleep(30000 /*ms*/);
            } catch (InterruptedException e) { /* Ignore*/ }

            now = System.currentTimeMillis();
        }
        errorFatal("Some slivers did not become ready within 20 minutes: " + sliverAuths);
    }

    @Test(hardDepends = {"waitForAllReady"}, groups = {"nodelogin"})
    public void loginAndPing() throws JFedException, IOException {
        List<SfaAuthority> sliverAuths = director.getActivelyInvolvedAuthorities();

        boolean allLoginOk = true;

        //only try login on authorities with nodes.
        List<SfaAuthority> authsWithNode = new ArrayList<SfaAuthority>();
        for (SfaAuthority auth : sliverAuths)
            if (isNodeAuth(auth))
                authsWithNode.add(auth);

        assertTrue(authsWithNode.size() > 1, "Too few authorities with nodes ("+authsWithNode.size()+"): authsWithNode="+authsWithNode+"   stitchedAuthorityUrns="+stitchedAuthorityUrns);

        for (SfaAuthority auth : authsWithNode) {
            SshInfo sshInfo = sshInfos.get(auth);
            if (sshInfo == null) {
                errorNonFatal("No SSH login info was extracted for " + auth.getUrnString());
                allLoginOk = false;
                continue;
            }
            l4jLogger.info("Login to " + auth.getUrnString() + "  " + sshInfo);
            note("Login to "+auth.getUrnString()+"  "+sshInfo);

            if (sshInfo.sshHostname == null) {
                errorNonFatal("No node / service / login in manifest RSpec, so SSH login cannot be tested for " + auth.getUrnString());
                allLoginOk = false;
                continue;
            }

            //Test node login using SSH private key

            Connection conn = new Connection(sshInfo.sshHostname, sshInfo.sshPort);
            try {
                conn.connect();
            } catch (IOException e) {
                errorNonFatal("Could not connect to node \""+sshInfo.sshHostname+"\" at port "+sshInfo.sshPort);
                allLoginOk = false;
                continue;
            }
            String privateKeyToPrint = new String(sshKeyHelper.getPEMPrivateKey());
            if (privateKeyToPrint.length() > 50) privateKeyToPrint = privateKeyToPrint.substring(0, 50);
            note("Trying to log in with PEM private key:\n" + privateKeyToPrint);
            boolean isAuthenticated = conn.authenticateWithPublicKey(sshInfo.sshUsername, sshKeyHelper.getPEMRsaPrivateKey(), "nopass");
            setErrorsNotFatal();
            assertTrue(isAuthenticated, "Could not login to host. " + sshInfo.sshHostname + "@" + sshInfo.sshHostname + ":" + sshInfo.sshPort);
            setErrorsFatal();

            if (!isAuthenticated)
                continue;

            Session session = conn.openSession();
            BufferedReader sout = new BufferedReader(new InputStreamReader(session.getStdout()));
            BufferedReader serr = new BufferedReader(new InputStreamReader(session.getStderr()));

            List<String> pingTargets = pingTargetsForAuth(auth);
            for (String targetIP : pingTargets) {
                note("Trying to ping "+targetIP);
                /*
                Ping options on linux:
                       -c count
                              Stop after sending count ECHO_REQUEST packets. With deadline option, ping waits for count ECHO_REPLY packets, until the timeout expires.
                       -n     Numeric output only.  No attempt will be made to lookup symbolic names for host addresses.
                       -w deadline
                              Specify a timeout, in seconds, before ping exits regardless of how many packets have been sent or received. In this case ping does not stop after count packet are sent, it
                              waits either for deadline expire or until count probes are answered or for some error notification from network.
                       -W timeout
                              Time to wait for a response, in seconds. The option affects only timeout in absense of any responses, otherwise ping waits for two RTTs.
                * */

                String command = "ping -c 5 -n -w 30 "+targetIP;
                session.execCommand(command);
                String result = "";
                String err = "";
                String line = sout.readLine();
                while (line != null) {
                    result += line;
                    line = sout.readLine();
                }
                line = serr.readLine();
                while (line != null) {
                    err += line;
                    line = serr.readLine();
                }
                note("\""+"ping -c 5 -n -w 30 "+targetIP+"\" command on " + sshInfo.sshHostname + "@" + sshInfo.sshHostname + ":" + sshInfo.sshPort + " result: \"" + result.trim() + "\". (stderr is: \"" + err + "\")");
                setErrorsNotFatal();
                assertTrue(result.length() > 5, "I executed \"ping\" on the remote host, and expected some reply. Instead I got: \"" + result.trim() + "\". (stderr is: \"" + err + "\")");

                if (result.length() > 5) {
                    //example reply:
                    //   5 packets transmitted, 3 received
                    Pattern patternTrans = Pattern.compile("([0-9]*) packets transmitted");
                    Matcher matcherTrans = patternTrans.matcher(result);
                    assertTrue (matcherTrans.find(), "Did not find \"[0-9]* packets transmitted\" in result");
                    String sent = matcherTrans.group(1);

                    Pattern patternRecv = Pattern.compile("([0-9]*) received");
                    Matcher matcherRecv = patternRecv.matcher(result);
                    assertTrue (matcherRecv.find(), "Did not find \"[0-9]* received\" in result");
                    String recv = matcherRecv.group(1);

                    assertEquals("5", sent, "Packets sent count is not 5: sent=\""+sent+"\"  (recv=\""+recv+"\")");
                    assertEquals("5", recv, "Packets recveived count is not 5: \""+recv+"\"");
                }
                setErrorsFatal();
            }

            session.close();

            conn.close();
        }

        assertTrue(allLoginOk);
    }


    //DEBUGREUSEPREVTEST comment  callDelete() to reuse previous test. uncomment for normal test
    @Test(softDepends = {"loginAndPing", "callCreateSlivers", "waitForAllReady"}, hardDepends = {"createSlice"}, groups = {"createsliver","nodelogin"})
    public void callDeletes() throws JFedException {
        GeniUser user = getTestContext().getGeniUser();

        List<SfaAuthority> allAuths = director.getActivelyInvolvedAuthorities();

        if (allAuths.size() == 0) {
            warn("Something went wrong: got empty list of involved authorities! This might be correct, but it could be a bug. Will instead Delete on all authorities to be sure everything is cleaned up.");
            allAuths = director.getAllAuthorities();
        }

        for (SfaAuthority authorityInfo: allAuths) {
            //do delete call
            try {
                //TODO handle errors
                String url = authorityInfo.getUrl(ServerType.GeniServerRole.AM, 2).toURI().toString();
                SfaConnection con = null;
                if (url.startsWith("http://")) {
                    note("WARNING: Connection URL is http instead of https! This is unsecure, so connection will not be tried. I will try using https instead, maybe that works.");
                    url = url.replaceFirst("http", "https");
                }
                if (url.startsWith("https://"))
                    con = new SfaSslConnection(authorityInfo,
                            url,
                            user.getClientCertificateChain(),
                            user.getPrivateKey(),
                            null/*proxyInfo*/,
                            false/*debug*/,
                            handleUntrustedCallback);
                if (url.startsWith("http://"))
                    con = new SfaPlainConnection(authorityInfo,
                            url,
                            null/*proxyInfo*/,
                            false/*debug*/);
                assert con != null : "URL has unsupported protocol: "+url;

                AbstractGeniAggregateManager.AggregateManagerReply<Boolean> reply =
                        am2.deleteSliver(con,  toCredentialList(slice.credential), slice.urnString, null);

                note("Called delete on " + authorityInfo.getUrnString() + " results: " + reply.getValue());
            } catch (JFedException e) {
                e.printStackTrace();
            } catch (URISyntaxException e) {
                e.printStackTrace();
            }
        }
    }
}
