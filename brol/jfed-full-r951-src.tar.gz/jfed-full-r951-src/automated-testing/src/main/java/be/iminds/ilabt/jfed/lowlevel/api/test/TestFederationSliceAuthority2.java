package be.iminds.ilabt.jfed.lowlevel.api.test;

import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.ServerType;
import be.iminds.ilabt.jfed.lowlevel.api.*;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.util.CommandExecutionContext;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.RFC3339Util;

import java.util.*;

/**
 * TestFederationSliceAuthority2
 */
public class TestFederationSliceAuthority2 extends AbstractFederationApi2Test {
    public String getTestDescription() {
        return "Test Federation API Slice Authority version 2";
    }

    private FederationSliceAuthorityApi2 sa;
    private FederationMemberAuthorityApi2 ma;
    private CommandExecutionContext testContext;

    public SfaConnection getSAConnection() throws JFedException {
        return (SfaConnection) testContext.getConnectionProvider().getConnectionByAuthority(testContext.getGeniUser(), testContext.getTestedAuthority(),
                new ServerType(ServerType.GeniServerRole.GENI_CH_SA, 2));
    }
    public SfaConnection getMAConnection() throws JFedException {
        return (SfaConnection) testContext.getConnectionProvider().getConnectionByAuthority(testContext.getGeniUser(), testContext.getTestedAuthority(),
                new ServerType(ServerType.GeniServerRole.GENI_CH_MA, 2));
    }

    List<String> sliceDefaultFieldNames = new ArrayList<String>();
    List<AbstractFederationApi2.GetVersionResult.FieldInfo> sliceDefaultFields = new ArrayList<AbstractFederationApi2.GetVersionResult.FieldInfo>();
    List<String> projectDefaultFieldNames = new ArrayList<String>();
    List<AbstractFederationApi2.GetVersionResult.FieldInfo> projectDefaultFields = new ArrayList<AbstractFederationApi2.GetVersionResult.FieldInfo>();
    public void setUp(CommandExecutionContext testContext) {
        this.testContext = testContext;
        sa = new FederationSliceAuthorityApi2(testContext.getLogger());
        ma = new FederationMemberAuthorityApi2(testContext.getLogger());
        sa.setHandleMalformedReplies(false); //throw exceptions instead of trying to recover from malformed replies
        ma.setHandleMalformedReplies(false); //throw exceptions instead of trying to recover from malformed replies

        sliceDefaultFields = sa.getMinimumFields("SLICE");
        projectDefaultFields = sa.getMinimumFields("PROJECT");
        for (AbstractFederationApi2.GetVersionResult.FieldInfo fi : sliceDefaultFields)
            sliceDefaultFieldNames.add(fi.getName());
        for (AbstractFederationApi2.GetVersionResult.FieldInfo fi : projectDefaultFields)
            projectDefaultFieldNames.add(fi.getName());
    }


    private boolean hasSliceMemberService = false;
    private boolean hasSliverInfoService = false;
    private boolean hasProjectService = false;
    private boolean hasProjectMemberService = false;

    private List<String> allRoles;
    @Test
    public void getVersion() throws JFedException {
        AbstractFederationApi2.FederationApiReply<FederationSliceAuthorityApi2.GetVersionSAResult> reply = sa.getVersion(getSAConnection());
        checkGetVersion(reply, sa, true);

        Hashtable<String, Object> htRes = (Hashtable<String, Object>) reply.getRawValue();
        Vector services = assertHashTableContainsVector(htRes, "SERVICES");

        if (services != null) {
            hasSliceMemberService = services.contains("SLICE_MEMBER");
            hasSliverInfoService = services.contains("SLIVER_INFO");
            hasProjectService = services.contains("PROJECT");
            hasProjectMemberService = services.contains("PROJECT_MEMBER");
        }

        allRoles = reply.getValue().getRoles();

        warnIfNot(allRoles.size() > 0, "No roles are defined in get_version");
    }



    AnyCredential maTestUserCredential;
    List<AnyCredential> maTestUserCredentialList;
    @Test(softDepends = {"getVersion"})
    public void getTestUserCredential() throws JFedException {
        GeniUrn testUserUrn = GeniUrn.parse(testContext.getGeniUser().getUserUrnString());
        assertNotNull(testUserUrn, "Error in test user urn: "+testContext.getGeniUser().getUserUrnString());

        AbstractFederationApi2.FederationApiReply<List<AnyCredential>> reply =
                ma.getCredentials(getMAConnection(), new ArrayList<AnyCredential>(), testUserUrn, null);
        checkCorrectnessXmlRpcResult(reply);
        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        List<AnyCredential> testUserCreds = reply.getValue();
        assertNotNull(testUserCreds, "no credential returned");
        assertNotEmpty(testUserCreds,
                "empty list of credentials returned. Expecting a list with credentials, but got  "+(reply.getRawValue() == null ?
                        "null" :
                        (reply.getRawValue() instanceof Vector ?
                                ("a list: "+reply.getRawValue()) :
                                ("something of class:"+reply.getRawValue().getClass().getName())
                        )
                ));
        maTestUserCredentialList = new ArrayList<AnyCredential>(testUserCreds);
        maTestUserCredential = testUserCreds.get(0);
    }

    HashMap<String, Object> testUserInfo;
    @Test(softDepends = {"getTestUserCredential"}, description = "Some methods might require user info, so we try to fetch all user info here. Any failure here is not a failure of the SA, but a failure in the MA.")
    public void getTestUserInfo() throws JFedException {
        GeniUrn testUserUrn = GeniUrn.parse(testContext.getGeniUser().getUserUrnString());
        assertNotNull(testUserUrn, "Error in test user urn: "+testContext.getGeniUser().getUserUrnString());

        Map<String, String> match = new HashMap();
        match.put("MEMBER_URN", testUserUrn.getValue());

        testUserInfo = new HashMap<String, Object>();

        setErrorsNotFatal();

        AbstractFederationApi2.FederationApiReply<AbstractFederationApi2.LookupResult> reply =
                ma.lookupMember(getMAConnection(), maTestUserCredentialList, match, null, null);
        checkCorrectnessXmlRpcResult(reply);
        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        if (reply.getValue() != null) {
            Hashtable<String, Object> replyUserInfo = reply.getValue().get(testUserUrn.getValue());
            if (replyUserInfo != null)
                testUserInfo.putAll(replyUserInfo);
        }

        note("Retrieved user info fields: " + testUserInfo.keySet());

        setErrorsFatal();
    }

    AnyCredential testUserCredential;
    List<AnyCredential> testUserCredentialList;
    @Test(softDepends = {"getTestUserCredential"}, description="Get A Credential for the test user. If the MA get_credential call did not work, this will try to fall back to the old PROTOGENI_SA API.")
    public void retrieveCredentialSomehow() throws JFedException {
        if (maTestUserCredentialList != null && maTestUserCredential != null) {
            testUserCredential = maTestUserCredential;
            testUserCredentialList = maTestUserCredentialList;
        } else {
            if (testContext.getUserAuthority().getUrl(new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1)) == null) {
                errorFatal("The Uniform Federation API Member Authority get_credential call failed to provide a credential. additionally, the test user authority does not have a PROTOGENI_SA available as fallback. => Cannot retrieve a credential for the test user.");
            } else {
                note("The Uniform Federation API Member Authority get_credential call failed to provide a credential: Falling back to the PROTOGENI_SA API to retrieve a credential for the remaining tests.");
                SfaConnection protogeniSaCon = (SfaConnection) testContext.getConnectionProvider().getConnectionByAuthority(testContext.getGeniUser(),
                        testContext.getUserAuthority(), new ServerType(ServerType.GeniServerRole.PROTOGENI_SA, 1));
                ProtogeniSliceAuthority protogeniSa = new ProtogeniSliceAuthority(testContext.getLogger());

                ProtogeniSliceAuthority.SliceAuthorityReply<AnyCredential> pgSaReply = protogeniSa.getCredential(protogeniSaCon);
                assertTrue(pgSaReply.getGeniResponseCode().isSuccess());
                AnyCredential pgCred = pgSaReply.getValue();

                assertNotNull(pgCred, "no credential returned by protogeni SA");
                testUserCredentialList = new ArrayList<AnyCredential>();
                testUserCredentialList.add(pgCred);
                testUserCredential = pgCred;
            }
        }
    }


    private String sliceName;
    private GeniUrn sliceUrn;
    private Hashtable<String, Object> sliceCreationDetails;
    private static String initialSliceDescription = "test slice used in automated testing";
    @Test(hardDepends = {"retrieveCredentialSomehow"}, softDepends = {"getVersion", "createProject", "getTestUserInfo"})
    public void createSlice() throws JFedException {
        sliceName = CommonAMTest.createSliceName(this, getTestContext().getUserAuthority(), "S");

        Hashtable<String, String> fields = new Hashtable<String, String>();
        fields.put("SLICE_EXPIRATION", RFC3339Util.dateToRFC3339String(new Date(System.currentTimeMillis() + 2 * 60 * 60 * 1000), true, true, true));
        fields.put("SLICE_DESCRIPTION", initialSliceDescription);

        //if PROJECT SERVICE is available, we NEED to add SLICE_PROJECT_URN to the keys
        if (hasProjectService) {
            fields.put("SLICE_PROJECT_URN", projectUrn.getValue());
        }
        if (getVersionResult != null && getVersionResult.getFieldsForObject("PROJECT").containsKey("_GENI_SLICE_EMAIL")) {
            if (testUserInfo != null && testUserInfo.containsKey("MEMBER_EMAIL"))
                fields.put("_GENI_SLICE_EMAIL", testUserInfo.get("MEMBER_EMAIL")+"");
            else {
                warn("create_slice requires the field _GENI_SLICE_EMAIL, but the current user's EMAIL is unknown. (the value 'dummy@example.com' will be used, but will likely cause problems)");
                fields.put("_GENI_SLICE_EMAIL", "dummy@example.com");
            }
        }
        addRequiredSupplementaryFieldsToCreate(fields, "SLICE");

        AbstractFederationApi2.FederationApiReply<Hashtable<String, Object>> reply =
                sa.createSlice(getSAConnection(), testUserCredentialList, sliceName, fields, null);
        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        sliceCreationDetails = reply.getValue();
        assertNotNull(sliceCreationDetails);
        note("slice details contains the following fields: " + sliceCreationDetails.keySet());

        setErrorsNotFatal();
        assertHashTableContainsString(sliceCreationDetails, "SLICE_URN");
        String replySliceUrn = (String) sliceCreationDetails.get("SLICE_URN");
        note("SLICE_URN of created slice: \""+replySliceUrn+"\"");
        sliceUrn = GeniUrn.parse(replySliceUrn);
        assertNotNull(sliceUrn, "SLICE_URN value \""+replySliceUrn+"\" is not a valid urn");
        assertEquals(sliceUrn.getResourceType(), "slice", "SLICE_URN is not a slice urn, but is of type "+sliceUrn.getResourceType());
        assertEquals(sliceUrn.getResourceName(), sliceName, "SLICE_URN does not have the requested name \""+sliceName+"\", but has name "+sliceUrn.getResourceName());
        warnIfNot(sliceUrn.getTopLevelAuthority().startsWith(testContext.getTestedAuthority().getNameForUrn()), "SLICE_URN top level authority is unexpected (expected \""+testContext.getTestedAuthority().getNameForUrn()+"\" or subauthority): "+sliceUrn.getTopLevelAuthority());

//        sliceUrn = new GeniUrn(testContext.getTestedAuthority().getNameForUrn(), "slice", sliceName);

//        assertHashTableContainsString(sliceCreationDetails, "SLICE_UID");
//        assertHashTableContainsString(sliceCreationDetails, "SLICE_EXPIRATION"); //XmlRpc might store Data object!
        Object expirationObject = sliceCreationDetails.get("SLICE_EXPIRATION");
        assertNotNull(expirationObject, "slice creation result hashtable does not contain key \"SLICE_EXPIRATION\"");
        if ((!(expirationObject instanceof Date)) && (!(expirationObject instanceof String)))
            errorNonFatal("slice creation result hashtable value for \"SLICE_EXPIRATION\" is not a Date or String but a " + expirationObject.getClass().getName());
        setErrorsFatal();

        //not mandatory
        Object creationSliceCredentialString = sliceCreationDetails.get("SLICE_CREDENTIAL");
        if (creationSliceCredentialString != null) {
            warn("Creating the slice returned a SLICE_CREDENTIAL. This field name is not prefixed with an underscore and is not in the API yet. If it is added, it should probably be of type CREDENTIAL (a list of dictionaries) and not a STRING. Otherwise, the type of credential is not known.");
//            creationSliceCredential = AnyCredential.create("Slice Creation Credential", creationSliceCredentialString, "sfa" , "3"); //assume SFA 3 type...
        }
    }

    private List<AnyCredential> sliceCredentials;
    @Test(hardDepends = {"createSlice"})
    public void getSliceCredentials() throws JFedException {
        AbstractFederationApi2.FederationApiReply<List<AnyCredential>> reply =
                sa.getCredentials(getSAConnection(), testUserCredentialList, sliceUrn, null);
        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        sliceCredentials = reply.getValue();
        assertNotNull(sliceCredentials);
        assertNotEmpty(sliceCredentials);
    }




    private void checkSliceLookupResult(AbstractFederationApi2.FederationApiReply<AbstractFederationApi2.LookupResult> reply, List<String> expectedFieldNames, List<String> excludedFieldNames) {
        AbstractFederationApi2.LookupResult lookupRes = reply.getValue();
        checkCorrectnessXmlRpcResult(reply);
        checkLookupCorrectness(reply);
        assertNotNull(lookupRes);

        assertTrue(lookupRes.size() > 0, "Lookup result is empty for slice urn: "+sliceUrn.getValue());

        Hashtable<String, Hashtable<String, Object>> raw = lookupRes.getRaw();
        errorNonFatalIfNot(raw.size() == 1, "lookup must return one slice, but it returned "+raw.size());

        Hashtable<String, Object> rawUser = raw.get(sliceUrn.getValue());
        errorNonFatalIfNot(rawUser != null, "lookup must return requested slice ("+sliceUrn.getValue()+") but returned null.");

        String rawUrn = (String) rawUser.get("SLICE_URN"); //check that if this slice has a slice urn, it matches.
        if (rawUrn != null && !sliceUrn.getValue().equals(rawUrn))
            errorNonFatal("lookup must return requested slice ("+sliceUrn.getValue()+"), and it did, however its returned SLICE_URN entry is not matching: "+rawUrn);

        for (int i = 0; i < lookupRes.size(); i++) {
            Hashtable<String, Object> sliceInfo = lookupRes.get(i);
            for (String fieldName : expectedFieldNames) {
                if (!sliceInfo.containsKey(fieldName))
                    errorNonFatal("returned result does not contain field: \""+ fieldName+"\"");
            }
            for (String fieldName : excludedFieldNames) {
                if (sliceInfo.containsKey(fieldName))
                    errorNonFatal("returned result contains unexpected field: \""+ fieldName+"\"");
            }
        }
    }

    @Test(hardDepends = {"getSliceCredentials"})
    public void lookupSlicesNoFilter() throws JFedException {
        Hashtable<String, String> match = new Hashtable<String, String>();
        Vector<String> filter = null;//new Vector<String>();

        match.put("SLICE_URN", sliceUrn.getValue());

        note("looking up slice by SLICE_URN: " + sliceUrn.getValue());
        AbstractFederationApi2.FederationApiReply<AbstractFederationApi2.LookupResult> reply =
                sa.lookupSlice(getSAConnection(), sliceCredentials, match, filter, null);
        checkCorrectnessXmlRpcResult(reply);

        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());


        List<String> expectedFieldNames = new ArrayList<String>();
        List<String> excludedFieldNames = new ArrayList<String>();
        for (AbstractFederationApi2.GetVersionResult.FieldInfo fi : sliceDefaultFields)
            if (hasProjectService || !fi.getName().equals("SLICE_PROJECT_URN"))   //special field! only present when project service is supported
                expectedFieldNames.add(fi.getName());
        note("No filter provided, so expecting all fields to be returned: "+expectedFieldNames);
        checkSliceLookupResult(reply, expectedFieldNames, excludedFieldNames);

        String desc = (String) reply.getValue().get(sliceUrn).get("SLICE_DESCRIPTION");
        assertNotNull(desc);
        assertEquals(desc, initialSliceDescription);
    }

    private static String updatedSliceDescription = "test slice used in automated testing with updated description";
    @Test(hardDepends = {"getSliceCredentials"}, softDepends = {"lookupSlicesNoFilter"})
    public void updateSlice() throws JFedException {
        Hashtable<String, String> fields = new Hashtable<String, String>();
        fields.put("SLICE_DESCRIPTION", updatedSliceDescription);

        AbstractFederationApi2.FederationApiReply<String> reply =
                sa.updateSlice(getSAConnection(), sliceCredentials, sliceUrn, fields, null);
        checkCorrectnessXmlRpcResult(reply);

        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());
    }

    @Test(hardDepends = {"updateSlice"})
    public void lookupSlicesNoFilterAfterUpdate() throws JFedException {
        Hashtable<String, String> match = new Hashtable<String, String>();
        Vector<String> filter = null;// new Vector<String>();

        match.put("SLICE_URN", sliceUrn.getValue());

        note("looking up slice by SLICE_URN: " + sliceUrn.getValue());
        AbstractFederationApi2.FederationApiReply<AbstractFederationApi2.LookupResult> reply =
                sa.lookupSlice(getSAConnection(), sliceCredentials, match, filter, null);
        checkCorrectnessXmlRpcResult(reply);

        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        List<String> expectedFieldNames = new ArrayList<String>();
        List<String> excludedFieldNames = new ArrayList<String>();
        for (AbstractFederationApi2.GetVersionResult.FieldInfo fi : sliceDefaultFields)
            if (hasProjectService || !fi.getName().equals("SLICE_PROJECT_URN"))   //special field! only present when project service is supported
                expectedFieldNames.add(fi.getName());
        note("No filter provided, so expecting all fields to be returned: "+expectedFieldNames);
        checkSliceLookupResult(reply, expectedFieldNames, excludedFieldNames);

        String desc = (String) reply.getValue().get(sliceUrn).get("SLICE_DESCRIPTION");
        assertNotNull(desc);
        assertEquals(desc, updatedSliceDescription);
    }



    ////////////////////////////////////////////////// SLICE_MEMBER methods //////////////////////////////////////////////////

    private String lookupSliceMembersRole;
    @Test(hardDepends = {"createSlice", "getSliceCredentials"}, softDepends = {"lookupSlicesNoFilterAfterUpdate"})
    public void lookupSliceMembers() throws JFedException {
        if (!hasSliceMemberService) skip("No SLICE_MEMBER service advertised in get_version");

        AbstractFederationApi2.FederationApiReply<List<FederationSliceAuthorityApi2.UrnRoleTuple>> reply =
                sa.lookupMembers(getSAConnection(), "SLICE", sliceUrn, sliceCredentials, null);
        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        List<FederationSliceAuthorityApi2.UrnRoleTuple> memberTuples = reply.getValue();
        assertNotNull(memberTuples);
        assertNotEmpty(memberTuples);
        assertTrue(memberTuples.size() == 1, "More than 1 member in slice: "+memberTuples);

        FederationSliceAuthorityApi2.UrnRoleTuple memberTuple = memberTuples.get(0);
        assertEquals(memberTuple.urn.getValue(), testContext.getGeniUser().getUserUrnString(), "Expected slice member to be "+testContext.getGeniUser().getUserUrnString()+" but it was "+memberTuple.urn.getValue());
        note("test user role in slice is: "+memberTuple.role);
        assertNotNull(memberTuple.role, "member role is null in slice");
        lookupSliceMembersRole = memberTuple.role;
    }

    @Test(hardDepends = {"createSlice"}, softDepends = {"lookupSliceMembers"})
    public void lookupSlicesForMember() throws JFedException {
        if (!hasSliceMemberService) skip("No SLICE_MEMBER service advertised in get_version");

        GeniUrn memberUrn = GeniUrn.parse(testContext.getGeniUser().getUserUrnString());
        assertNotNull(memberUrn);

        AbstractFederationApi2.FederationApiReply<List<FederationSliceAuthorityApi2.UrnRoleTuple>> reply =
                sa.lookupForMember(getSAConnection(), "SLICE", memberUrn, testUserCredentialList, null);
        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        List<FederationSliceAuthorityApi2.UrnRoleTuple> value = reply.getValue();

        assertNotNull(value);
        assertNotEmpty(value);
        assertTrue(value.size() >= 1, "should have been at least 1 slice for " + memberUrn);
        note("Slice urns for member "+memberUrn+": "+value);

        String role = null;
        for (FederationSliceAuthorityApi2.UrnRoleTuple tuple : value) {
//            note("comparing \""+tuple.getUrn()+"\" with \""+sliceUrn+"\" -> "+tuple.getUrn().equals(sliceUrn));
            if (tuple.getUrn().getTopLevelAuthority().startsWith(sliceUrn.getTopLevelAuthority())
                    && tuple.getUrn().getResourceName().equals(sliceUrn.getResourceName())
                    && tuple.getUrn().getResourceType().equals("slice"))
                role = tuple.getRole();
            assertEquals(tuple.getUrn().getResourceType(), "slice", "The returned URN is not a slice urn but is of type: \""+tuple.getUrn().getResourceType()+"\"");
        }

        assertNotNull(role, "slice \""+sliceUrn+"\" was not listed as slice for member \""+memberUrn+"\". Full result: "+value);
        if (lookupSliceMembersRole != null)
            assertEquals(role, lookupSliceMembersRole, "A different role was returned for \""+memberUrn+"\" in "+sliceUrn+" for the lookup_slices_for_members and lookup_slice_members calls");
    }

    @Test(hardDepends = {"getVersion", "createSlice", "lookupSliceMembers"}, softDepends = {"lookupSlicesForMember"})
    public void modifyMembership() throws JFedException {
        assertNotNull(allRoles, "get_version test did not set allRoles");
        assertNotNull(lookupSliceMembersRole, "lookupSliceMembersRole not set in lookupSliceMembers");

        if (!hasSliceMemberService) skip("No SLICE_MEMBER service advertised in get_version");

        List<FederationSliceAuthorityApi2.UrnRoleTuple> membersToAdd = new ArrayList<FederationSliceAuthorityApi2.UrnRoleTuple>();
        List<GeniUrn> membersToRemove = new ArrayList<GeniUrn>();
        List<FederationSliceAuthorityApi2.UrnRoleTuple> membersToChange = new ArrayList<FederationSliceAuthorityApi2.UrnRoleTuple>();

        if (allRoles.size() <= 1) {
            skip("server does not have multiple roles: cannot test modify_slice_membership");
        }

        String newRole = allRoles.get(0);
        String oldRole = lookupSliceMembersRole;

        if (allRoles.contains("USER") && !oldRole.equals("USER")) newRole = "USER";
        if (allRoles.contains("MEMBER") && !oldRole.equals("MEMBER")) newRole = "MEMBER";

        for (int i = 1; newRole.equals(oldRole) && i < allRoles.size(); i++)
            newRole = allRoles.get(i);
        assertNotEquals(newRole, oldRole, "roles defined in get_version do not differ: oldRole="+oldRole+" allRoles="+allRoles);

        membersToChange.add(new FederationSliceAuthorityApi2.UrnRoleTuple("SLICE", testContext.getGeniUser().getUserUrnString(), newRole));
        note("Wil ltry to change role of member \""+testContext.getGeniUser().getUserUrnString()+"\" in slice \""+sliceUrn+"\" from \""+oldRole+"\" to \""+newRole+"\"");

        AbstractFederationApi2.FederationApiReply<String> reply1 =
                sa.modifyMembership(getSAConnection(), "SLICE", sliceUrn, membersToAdd, membersToRemove, membersToChange, testUserCredentialList, null);
        checkCorrectnessXmlRpcResult(reply1);

        assertTrue(reply1.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply1.getGeniResponseCode());




        //lookup and check if changed correctly
        AbstractFederationApi2.FederationApiReply<List<FederationSliceAuthorityApi2.UrnRoleTuple>> reply2 =
                sa.lookupMembers(getSAConnection(), "SLICE", sliceUrn, testUserCredentialList, null);
        assertTrue(reply2.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply2.getGeniResponseCode());

        List<FederationSliceAuthorityApi2.UrnRoleTuple> memberTuples = reply2.getValue();
        assertNotNull(memberTuples);
        assertNotEmpty(memberTuples);
        assertTrue(memberTuples.size() == 1, "Expected exactly 1 member in slice: "+memberTuples);

        FederationSliceAuthorityApi2.UrnRoleTuple memberTuple = memberTuples.get(0);
        assertEquals(memberTuple.urn.getValue(), testContext.getGeniUser().getUserUrnString(), "Expected slice member to be "+testContext.getGeniUser().getUserUrnString()+" but it was "+memberTuple.urn.getValue());
        note("test user role in slice is: "+memberTuple.role);
        assertNotNull(memberTuple.role, "member role is null in slice");
        assertEquals(memberTuple.role,  newRole, "member role differs from newly assigned role");
        lookupSliceMembersRole = memberTuple.role;
    }


    ////////////////////////////////////////////////// SLIVER_INFO methods //////////////////////////////////////////////////

    @Test(hardDepends = {"retrieveCredentialSomehow", "createSlice"},
            softDepends = {"lookupSlicesNoFilterAfterUpdate", "lookupSlicesForMember", "lookupSliceMembers", "modifyMembership"})
    public void lookupSliverInfoNoFilter() throws JFedException {
        if (!hasSliverInfoService) skip("No SLIVER_INFO service advertised in get_version");

        Hashtable<String, String> match = new Hashtable<String, String>();
        Vector<String> filter = null;// new Vector<String>();

        AbstractFederationApi2.FederationApiReply<AbstractFederationApi2.LookupResult> reply =
                sa.lookupSliverInfo(getSAConnection(), testUserCredentialList, sliceUrn, match, filter, null);
        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        checkLookupCorrectness(reply);
        AbstractFederationApi2.LookupResult lookupRes = reply.getValue();
        assertNotNull(lookupRes);
        assertTrue(lookupRes.size() == 0);

        note("This test just checks that there are no slivers in the created slice. Nothing else is currently tested for SLIVER_INFO");
    }



    ////////////////////////////////////////////////// PROJECT methods //////////////////////////////////////////////////

    private String projectName;
    private GeniUrn projectUrn;
    private Hashtable<String, Object> projectCreationDetails;
    private static String initialProjectDescription = "test project used in automated testing";
    @Test(hardDepends = {"retrieveCredentialSomehow"}, softDepends = {"getVersion", "getTestUserInfo"})
    public void createProject() throws JFedException {
        if (!hasProjectService) skip("No PROJECT service advertised in get_version");

        projectName = "P"+System.currentTimeMillis();
        projectUrn = new GeniUrn(testContext.getTestedAuthority().getNameForUrn(), "project", projectName);

        Hashtable<String, String> fields = new Hashtable<String, String>();
        fields.put("PROJECT_DESCRIPTION", initialProjectDescription);
        fields.put("PROJECT_EXPIRATION", RFC3339Util.dateToRFC3339String(new Date(System.currentTimeMillis() + 3 * 60 * 60 * 1000), true, true, true));

        if (getVersionResult == null)
            warn("get_version result is unknown to this test method. Cannot add any required supplemental fields.");
        else {
            if (getVersionResult.getFields() == null)
                warn("getVersionResult fieldInfos map is null. Bug in jFed?");
            else {
                note("All Required supplemental fields: "+getVersionResult.getFields().keySet());
            }
            if (getVersionResult.getFieldsForObject("PROJECT") == null)
                warn("getVersionResult fieldInfos map is null when called with getFieldsForObject(\"PROJECT\"). Bug in jFed?");
            else {
                note("Required supplemental fields for PROJECT are: "+getVersionResult.getFieldsForObject("PROJECT").keySet());
            }
        }
        if (getVersionResult != null &&  getVersionResult.getFieldsForObject("PROJECT") != null) {
            if (getVersionResult.getFieldsForObject("PROJECT").containsKey("_GENI_PROJECT_EMAIL")) {
                note("get_version contains supplementary field _GENI_PROJECT_EMAIL. Will fill in user email.");
                if (testUserInfo != null && testUserInfo.containsKey("MEMBER_EMAIL"))
                    fields.put("_GENI_PROJECT_EMAIL", testUserInfo.get("MEMBER_EMAIL")+"");
                else {
                    warn("create_project requires the field _GENI_PROJECT_EMAIL, but the current users EMAIL is unknown. (the value 'dummy@example.com' will be used, but will likely cause problems)");
                    fields.put("_GENI_PROJECT_EMAIL", "dummy@example.com");
                }
            }
            if (getVersionResult.getFieldsForObject("PROJECT").containsKey("_GENI_PROJECT_OWNER")) { //type UID
                note("get_version contains supplementary field _GENI_PROJECT_OWNER. Will fill in user UID");
                if (testUserInfo != null && testUserInfo.containsKey("MEMBER_UID"))
                    fields.put("_GENI_PROJECT_OWNER", testUserInfo.get("MEMBER_UID")+"");
                else {
                    warn("create_project requires the field _GENI_PROJECT_OWNER, but the current users UID is unknown. (the value 'unknown' will be used, but will likely cause problems)");
                    fields.put("_GENI_PROJECT_OWNER", "unknown");
                }

            }
        }
        addRequiredSupplementaryFieldsToCreate(fields, "PROJECT");

        AbstractFederationApi2.FederationApiReply<Hashtable<String, Object>> reply =
                sa.createProject(getSAConnection(), testUserCredentialList, projectName, fields, null);
        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        projectCreationDetails = reply.getValue();
        assertNotNull(projectCreationDetails);
        note("project details contains the following fields: " + projectCreationDetails.keySet());

        setErrorsNotFatal();
        assertHashTableContainsString(projectCreationDetails, "PROJECT_URN");
        setErrorsFatal();

        //TODO: try to set a short expiration time here or in update
    }


    private void checkProjectLookupResult(AbstractFederationApi2.FederationApiReply<AbstractFederationApi2.LookupResult> reply, List<String> expectedFieldNames, List<String> excludedFieldNames) {
        AbstractFederationApi2.LookupResult lookupRes = reply.getValue();
        checkCorrectnessXmlRpcResult(reply);
        checkLookupCorrectness(reply);
        assertNotNull(lookupRes);

        assertTrue(lookupRes.size() > 0, "Lookup result is empty for project urn: "+projectUrn.getValue());

        Hashtable<String, Hashtable<String, Object>> raw = lookupRes.getRaw();
        errorNonFatalIfNot(raw.size() == 1, "lookup must return one project, but it returned "+raw.size());

        Hashtable<String, Object> rawUser = raw.get(projectUrn.getValue());
        errorNonFatalIfNot(rawUser != null, "lookup must return requested project ("+projectUrn.getValue()+") but returned null.");

        String rawUrn = (String) rawUser.get("PROJECT_URN"); //check that if this project has a project urn, it matches.
        if (rawUrn != null && !projectUrn.getValue().equals(rawUrn))
            errorNonFatal("lookup must return requested project ("+projectUrn.getValue()+"), and it did, however its returned PROJECT_URN entry is not matching: "+rawUrn);

        String rawName = (String) rawUser.get("PROJECT_NAME"); //check that if this project has a project name, it matches.
        if (rawName != null && !projectName.equals(rawName))
            errorNonFatal("lookup must return requested project (urn="+projectUrn.getValue()+" name="+projectName+"), and it did, however its returned PROJECT_Name entry is not matching: "+rawName);

        for (int i = 0; i < lookupRes.size(); i++) {
            Hashtable<String, Object> projectInfo = lookupRes.get(i);
            for (String fieldName : expectedFieldNames) {
                if (!projectInfo.containsKey(fieldName))
                    errorNonFatal("returned result does not contain field: \""+ fieldName+"\"");
            }
            for (String fieldName : excludedFieldNames) {
                if (projectInfo.containsKey(fieldName))
                    errorNonFatal("returned result contains unexpected field: \""+ fieldName+"\"");
            }
        }
    }

    @Test(hardDepends = {"createProject"})
    public void lookupProjectsByUrnNoFilter() throws JFedException {
        if (!hasProjectService) skip("No PROJECT service advertised in get_version");

        Hashtable<String, String> match = new Hashtable<String, String>();
        Vector<String> filter = null;//new Vector<String>();

        match.put("PROJECT_URN", projectUrn.getValue());

        note("looking up project by PROJECT_URN: " + projectUrn.getValue());
        AbstractFederationApi2.FederationApiReply<AbstractFederationApi2.LookupResult> reply =
                sa.lookupProject(getSAConnection(), testUserCredentialList, match, filter, null);
        checkCorrectnessXmlRpcResult(reply);

        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        List<String> expectedFieldNames = new ArrayList<String>();
        List<String> excludedFieldNames = new ArrayList<String>();
        for (AbstractFederationApi2.GetVersionResult.FieldInfo fi : projectDefaultFields)
            expectedFieldNames.add(fi.getName());
        note("No filter provided, so expecting all fields to be returned: "+expectedFieldNames);
        checkProjectLookupResult(reply, expectedFieldNames, excludedFieldNames);

        String desc = (String) reply.getValue().get(projectUrn).get("PROJECT_DESCRIPTION");
        assertNotNull(desc);
        assertEquals(desc, initialProjectDescription);
    }

    @Test(hardDepends = {"createProject"})
    public void lookupProjectsByNameNoFilter() throws JFedException {
        if (!hasProjectService) skip("No PROJECT service advertised in get_version");

        Hashtable<String, String> match = new Hashtable<String, String>();
        Vector<String> filter = null;//new Vector<String>();

        match.put("PROJECT_NAME", projectName);

        note("looking up project by PROJECT_URN: " + projectUrn.getValue());
        AbstractFederationApi2.FederationApiReply<AbstractFederationApi2.LookupResult> reply =
                sa.lookupProject(getSAConnection(), testUserCredentialList, match, filter, null);
        checkCorrectnessXmlRpcResult(reply);

        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        List<String> expectedFieldNames = new ArrayList<String>();
        List<String> excludedFieldNames = new ArrayList<String>();
        for (AbstractFederationApi2.GetVersionResult.FieldInfo fi : projectDefaultFields)
            expectedFieldNames.add(fi.getName());
        note("No filter provided, so expecting all fields to be returned: "+expectedFieldNames);
        checkProjectLookupResult(reply, expectedFieldNames, excludedFieldNames);

        String desc = (String) reply.getValue().get(projectUrn).get("PROJECT_DESCRIPTION");
        assertNotNull(desc);
        assertEquals(desc, initialProjectDescription);
    }

    private static String updatedProjectDescription = "test project used in automated testing with updated description";
    @Test(hardDepends = {"createProject"}, softDepends = {"lookupProjectsByUrnNoFilter", "lookupProjectsByNameNoFilter"})
    public void updateProject() throws JFedException {
        if (!hasProjectService) skip("No PROJECT service advertised in get_version");

        Hashtable<String, String> fields = new Hashtable<String, String>();
        fields.put("PROJECT_DESCRIPTION", updatedProjectDescription);

        AbstractFederationApi2.FederationApiReply<String> reply =
                sa.updateProject(getSAConnection(), testUserCredentialList, projectUrn, fields, null);
        checkCorrectnessXmlRpcResult(reply);

        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());
    }

    @Test(hardDepends = {"updateProject"})
    public void lookupProjectsNoFilterAfterUpdate() throws JFedException {
        if (!hasProjectService) skip("No PROJECT service advertised in get_version");

        Hashtable<String, String> match = new Hashtable<String, String>();
        Vector<String> filter = null;// new Vector<String>();

        match.put("PROJECT_URN", projectUrn.getValue());

        note("looking up project by PROJECT_URN: " + projectUrn.getValue());
        AbstractFederationApi2.FederationApiReply<AbstractFederationApi2.LookupResult> reply =
                sa.lookupProject(getSAConnection(), testUserCredentialList, match, filter, null);
        checkCorrectnessXmlRpcResult(reply);

        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        List<String> expectedFieldNames = new ArrayList<String>();
        List<String> excludedFieldNames = new ArrayList<String>();
        for (AbstractFederationApi2.GetVersionResult.FieldInfo fi : projectDefaultFields)
            expectedFieldNames.add(fi.getName());
        note("No filter provided, so expecting all fields to be returned: "+expectedFieldNames);
        checkProjectLookupResult(reply, expectedFieldNames, excludedFieldNames);

        String desc = (String) reply.getValue().get(projectUrn).get("PROJECT_DESCRIPTION");
        assertNotNull(desc);
        assertEquals(desc, updatedProjectDescription);
    }

    ////////////////////////////////////////////////// PROJECT_MEMBER methods //////////////////////////////////////////////////

    private String lookupProjectMembersRole;
    @Test(hardDepends = {"retrieveCredentialSomehow", "createProject"}, softDepends = {"lookupProjectsNoFilterAfterUpdate"})
    public void lookupProjectMembers() throws JFedException {
        if (!hasProjectMemberService) skip("No PROJECT_MEMBER service advertised in get_version");

        AbstractFederationApi2.FederationApiReply<List<FederationSliceAuthorityApi2.UrnRoleTuple>> reply =
                sa.lookupMembers(getSAConnection(), "PROJECT", projectUrn, testUserCredentialList, null);
        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        List<FederationSliceAuthorityApi2.UrnRoleTuple> memberTuples = reply.getValue();
        assertNotNull(memberTuples);
        assertNotEmpty(memberTuples);
        assertTrue(memberTuples.size() == 1, "Expected exactly 1 member in project: "+memberTuples);

        FederationSliceAuthorityApi2.UrnRoleTuple memberTuple = memberTuples.get(0);
        assertEquals(memberTuple.urn.getValue(), testContext.getGeniUser().getUserUrnString(), "Expected project member to be "+testContext.getGeniUser().getUserUrnString()+" but it was "+memberTuple.urn.getValue());
        note("test user role in project is: "+memberTuple.role);
        assertNotNull(memberTuple.role, "member role is null in project");
        lookupProjectMembersRole = memberTuple.role;
    }

    @Test(hardDepends = {"createProject"}, softDepends = {"lookupProjectMembers"})
    public void lookupProjectsForMember() throws JFedException {
        if (!hasProjectMemberService) skip("No PROJECT_MEMBER service advertised in get_version");

        GeniUrn memberUrn = GeniUrn.parse(testContext.getGeniUser().getUserUrnString());
        assertNotNull(memberUrn);

        AbstractFederationApi2.FederationApiReply<List<FederationSliceAuthorityApi2.UrnRoleTuple>> reply =
                sa.lookupForMember(getSAConnection(), "PROJECT", memberUrn, testUserCredentialList, null);
        assertTrue(reply.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply.getGeniResponseCode());

        List<FederationSliceAuthorityApi2.UrnRoleTuple> value = reply.getValue();

        assertNotNull(value);
        assertNotEmpty(value);
        assertTrue(value.size() >= 1, "should have been at least 1 project for " + memberUrn);
        note("Project urns for member "+memberUrn+": "+value);

        String role = null;
        for (FederationSliceAuthorityApi2.UrnRoleTuple tuple : value) {
            if (tuple.getUrn().equals(projectUrn))
                role = tuple.getRole();
            assertEquals(tuple.getUrn().getResourceType(), "project", "The returned URN is not a project urn but is of type: \""+tuple.getUrn().getResourceType()+"\"");
        }

        assertNotNull(role, "project "+projectUrn+" was not listed as project for member "+memberUrn+". All: "+value);
        if (lookupProjectMembersRole != null)
            assertEquals(role, lookupProjectMembersRole, "A different role was returned for "+memberUrn+" in "+projectUrn+" for the lookup_projects_for_members and lookup_project_members calls");
    }

    @Test(hardDepends = {"getVersion", "createProject", "lookupProjectMembers"}, softDepends = {"lookupProjectsForMember"})
    public void modifyProjectMembership() throws JFedException {
        assertNotNull(allRoles, "get_version test did not set allRoles");
        assertNotNull(lookupProjectMembersRole, "lookupProjectMembersRole not set in lookupProjectMembers");

        if (!hasProjectMemberService) skip("No PROJECT_MEMBER service advertised in get_version");

        List<FederationSliceAuthorityApi2.UrnRoleTuple> membersToAdd = new ArrayList<FederationSliceAuthorityApi2.UrnRoleTuple>();
        List<GeniUrn> membersToRemove = new ArrayList<GeniUrn>();
        List<FederationSliceAuthorityApi2.UrnRoleTuple> membersToChange = new ArrayList<FederationSliceAuthorityApi2.UrnRoleTuple>();

        if (allRoles.size() <= 1) {
            skip("server does not have multiple roles: cannot test modify_project_membership");
        }

        String newRole = allRoles.get(0);
        String oldRole = lookupProjectMembersRole;

        if (allRoles.contains("USER") && !oldRole.equals("USER")) newRole = "USER";
        if (allRoles.contains("MEMBER") && !oldRole.equals("MEMBER")) newRole = "MEMBER";

        for (int i = 1; newRole.equals(oldRole) && i < allRoles.size(); i++)
            newRole = allRoles.get(i);
        assertNotEquals(newRole, oldRole, "roles defined in get_version do not differ: oldRole="+oldRole+" allRoles="+allRoles);

        membersToChange.add(new FederationSliceAuthorityApi2.UrnRoleTuple("PROJECT", testContext.getGeniUser().getUserUrnString(), newRole));
        note("Wil ltry to change role of member \""+testContext.getGeniUser().getUserUrnString()+"\" in project \""+projectUrn+"\" from \""+oldRole+"\" to \""+newRole+"\"");

        AbstractFederationApi2.FederationApiReply<String> reply1 =
                sa.modifyMembership(getSAConnection(), "PROJECT", projectUrn, membersToAdd, membersToRemove, membersToChange, testUserCredentialList, null);
        checkCorrectnessXmlRpcResult(reply1);

        assertTrue(reply1.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply1.getGeniResponseCode());




        //lookup and check if changed correctly
        AbstractFederationApi2.FederationApiReply<List<FederationSliceAuthorityApi2.UrnRoleTuple>> reply2 =
                sa.lookupMembers(getSAConnection(), "PROJECT", projectUrn, testUserCredentialList, null);
        assertTrue(reply2.getGeniResponseCode().isSuccess(), "The tested call did not return code 0 (success), instead it returned "+reply2.getGeniResponseCode());

        List<FederationSliceAuthorityApi2.UrnRoleTuple> memberTuples = reply2.getValue();
        assertNotNull(memberTuples);
        assertNotEmpty(memberTuples);
        assertTrue(memberTuples.size() == 1, "Expected exactly 1 member in project: "+memberTuples);

        FederationSliceAuthorityApi2.UrnRoleTuple memberTuple = memberTuples.get(0);
        assertEquals(memberTuple.urn.getValue(), testContext.getGeniUser().getUserUrnString(), "Expected project member to be "+testContext.getGeniUser().getUserUrnString()+" but it was "+memberTuple.urn.getValue());
        note("test user role in project is: "+memberTuple.role);
        assertNotNull(memberTuple.role, "member role is null in project");
        assertEquals(memberTuple.role,  newRole, "member role differs from newly assigned role");
        lookupProjectMembersRole = memberTuple.role;
    }

}
