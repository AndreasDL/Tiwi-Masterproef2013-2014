package be.iminds.ilabt.jfed.testing.base;

import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.util.CommandExecutionContext;
import be.iminds.ilabt.jfed.util.GeniUrn;

import java.util.*;

/**
 * ApiTest:
 *
 *   for a test class you need:
 *     - user info
 *     - SA info if applicable
 *     - tested API info
 *     - connection (auto)
 *     - logger (auto)
 *
 *  per test meta data
 *     - name (default: auto from method name)
 *     - dependencies and preferred grouping (name or methodName)
 *        - hard dependency (skip if other failed or skipped)
 *        - soft dependency (always run after other (no matter if it succeeds, skips or fails))
 *        - group (a name that can be the same for a number of tests. These will be kept together, unless the other dependencies are used)
 *
 *  for each test log:
 *     - commands and replies
 *     - details, notes, warnings, errors and fatal errors (+ skips: the test can start to run and then decide it needs to be skipped)
 *     - info on the test
 *         - description of what it does
 *         - description of what is expected
 */
public abstract class ApiTest {
    private CommandExecutionContext testContext;
    public CommandExecutionContext getTestContext() {
        return testContext;
    }
    void setTestContext(CommandExecutionContext testContext) {
        this.testContext = testContext;
    }

    private Properties testConfig;
    public Properties getTestConfig() {
        return testConfig;
    }
    void setTestConfig(Properties testConfig) {
        this.testConfig = testConfig;
    }

    /** Overwrite to specify required config keys */
    public List<String> getRequiredConfigKeys() {
        return new ArrayList<String>();
    }
    /** Overwrite to specify optional config keys */
    public List<String> getOptionalConfigKeys() {
        return new ArrayList<String>();
    }

    public Logger getLogger() {
        return testContext.getLogger();
    }

    public abstract String getTestDescription();
    public abstract void setUp(CommandExecutionContext testContext) throws Exception;

    private ApiTestResult.ApiTestMethodResult currentTestResult;
    void setCurrentTestResult(ApiTestResult.ApiTestMethodResult currentTestResult) {
        this.currentTestResult = currentTestResult;
    }

    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
    @java.lang.annotation.Target({java.lang.annotation.ElementType.METHOD})
    public @interface Test {
        java.lang.String description() default "";
        java.lang.String[] groups() default {};

        java.lang.String[] hardDepends() default {};
        java.lang.String[] softDepends() default {};

        String dataProvider() default ""; //TODO implement

        //this concept (isReturnValue annotation) is under revision
//        /**
//         * If true, only the success of this test will be used as return value for the entire test run
//         * If there are no tests with this option, the success of all tests is used.
//         * If there are multiple tests in a class with this option, the result is unspecified!
//         * */
//        boolean ignoreForReturnValue() default false;
    }
    public @interface DataProvider { //TODO implement
        String name() default "";
    }


    public void note(String val) {
        currentTestResult.addLogLine(ApiTestResult.MethodLogLineType.NOTE, val);
    }

    public void skip(String reason) {
        currentTestResult.state = ApiTestResult.TestResultState.SKIPPED;
//        currentTestResult.addLogLine(ApiTestResult.MethodLogLineType.NOTE, "Test skipped: "+reason);
        throw new RunTests.SkipTestException(reason);
    }

    private boolean errorsFatal = true;
    /** errors will no longer be fatal, until setErrorsFatal() is called, or the current annotated test is done (so next test methods wil have fatal errors again). */
    protected void setErrorsNotFatal() {
        errorsFatal = false;
    }
    protected void setErrorsFatal() {
        errorsFatal = true;
    }


    public void errorNonFatal(String val) {
        currentTestResult.state = ApiTestResult.TestResultState.FAILED;
        currentTestResult.addLogLine(ApiTestResult.MethodLogLineType.ERROR, val);
    }

    public void errorFatal(String val) {
        fatalError(val);
    }
    public void fatalError(String val) {
        if (errorsFatal) {
//        currentTestResult.addLogLine(ApiTestResult.MethodLogLineType.FATAL_ERROR, val);
            currentTestResult.state = ApiTestResult.TestResultState.FAILED;
            throw new AssertionError(val);
        } else {
            errorNonFatal(val);
        }
    }

    public void warn(String val) {
        currentTestResult.addLogLine(ApiTestResult.MethodLogLineType.WARN, val);
        if (currentTestResult.state == ApiTestResult.TestResultState.SUCCESS)
            currentTestResult.state = ApiTestResult.TestResultState.WARN;
    }

    public void warnIfNot(boolean v) {
        warnIfNot(v, "warnIfNot failed");
    }
    public void warnIfNot(boolean v, String failText) {
        if (!v)
            warn(failText);
    }

    public void errorNonFatalIfNot(boolean v) {
        errorNonFatalIfNot(v, "warnIfNot failed");
    }
    public void errorNonFatalIfNot(boolean v, String failText) {
        if (!v)
            errorNonFatal(failText);
    }

    public void assertTrue(boolean v) {
        assertTrue(v, "assertTrue failed");
    }
    public void assertTrue(boolean v, String failText) {
        if (!v)
            fatalError(failText);
    }


    public void assertFalse(boolean v) {
        assertFalse(v, "assertFalse failed");
    }
    public void assertFalse(boolean v, String failText) {
        if (v)
            fatalError(failText);
    }


    public void assertNotNull(Object o) {
        assertNotNull(o, "object is null");
    }
    public void assertNotNull(Object o, String failText) {
        if (o == null)
            fatalError(failText);
    }


    public void assertNotEmpty(Collection c) {
        assertNotEmpty(c, "list is empty");
    }
    public void assertEmpty(Collection c) {
        assertEmpty(c, "list is not empty");
    }
    public void assertNotEmpty(Collection c, String failText) {
        if (c.isEmpty())
            fatalError(failText);
    }
    public void assertEmpty(Collection c, String failText) {
        if (!c.isEmpty())
            fatalError(failText);
    }


    public void assertNull(Object o) {
        assertNotNull(o, "object is null");
    }
    public void assertNull(Object o, String failText) {
        if (o != null)
            fatalError(failText);
    }

    public void assertEquals(Object a, Object b, String failText) {
        if (!a.equals(b))
            fatalError(failText+" -> "+(a instanceof String ? "object are not equal: a=\""+a.toString()+"\" b=\""+
                    b.toString()+"\"": "object are not equal: a="+a.toString() +"b="+b.toString()));
    }
    public void assertEquals(Object a, Object b) {
        assertEquals(a, b, a instanceof String ? "object are not equal: a=\""+a.toString()+"\" b=\""
                +b.toString()+"\"": "object are not equal: a="+a.toString() +"b="+b.toString());
    }


    public void assertNotEquals(Object a, Object b, String failText) {
        if (a.equals(b))
            fatalError(failText+" -> object are equal: a=b="+a.toString());
    }
    public void assertNotEquals(Object a, Object b) {
        assertNotEquals(a, b, "object are equal: a=b="+a.toString());
    }

    public void assertInstanceOf(Object o, Class<?> c) {
        assertInstanceOf(o, c, "object is not an instance of class \""+c.getName()+"\". (It is instance of class "+c.getName().toString()+")");
    }
    public void assertInstanceOf(Object o, Class<?> c, String failText) {
        if (!c.isInstance(o))
            fatalError(failText+" -> object is not an instance of class \""+c.getName()+"\". (It is instance of class "+c.getName().toString()+")");
    }



    public Vector assertHashTableContainsVector(Hashtable t, String key) {
        Object o = t.get(key);
        assertNotNull(o, "Hashtable does not contain key \""+key+"\"");
        if (o == null) return null;
        assertEquals(o.getClass(), Vector.class, "value for " + key + " is not a Vector but a " + o.getClass().getName());
        if (!o.getClass().equals(Vector.class)) return null;
        return (Vector) o;
    }
    public Hashtable assertHashTableContainsHashtable(Hashtable t, String key) {
        Object o = t.get(key);
        assertNotNull(o, "Hashtable does not contain key \""+key+"\"");
        if (o == null) return null;
        assertEquals(o.getClass(), Hashtable.class, "value for " + key + " is not a Hashtable but a " + o.getClass().getName());
        if (!o.getClass().equals(Hashtable.class)) return null;
        return (Hashtable) o;
    }
    public String assertHashTableContainsString(Hashtable t, String key) {
        Object o = t.get(key);
        assertNotNull(o, "Hashtable does not contain key \""+key+"\"");
        if (o == null) return null;
        assertEquals(o.getClass(), String.class, "value for " + key + " is not a String but a " + o.getClass().getName());
        if (!o.getClass().equals(String.class)) return null;
        return (String) o;
    }
    public Object assertHashTableContainsObject(Hashtable t, String key) {
        Object o = t.get(key);
        assertNotNull(o, "Hashtable does not contain key \""+key+"\"");
        return o;
    }
    public String assertHashTableContainsNonemptyString(Hashtable t, String key) {
        Object o = t.get(key);
        assertNotNull(o, "Hashtable does not contain key \""+key+"\"");
        if (o == null) return null;
        assertEquals(o.getClass(), String.class, "value for " + key + " is not a String but a " + o.getClass().getName());
        if (!o.getClass().equals(String.class)) return null;
        String s = (String) o;
        assertTrue(s.length() > 0, "value for " + key + " is an empty string");
        return s;
    }



    /** @param type is allowed to be null if no type to test */
    public void assertValidUrn(String urn, String type) {
        GeniUrn geniUrn = GeniUrn.parse(urn);
        assertTrue(geniUrn != null, "Urn is not valid: \"" + urn + "\"");
        if (geniUrn == null) return;
        if (type != null) assertEquals(geniUrn.getResourceType(), type, "Urn type is not correct in urn=\"" + urn + "\"");
        assertFalse(geniUrn.getTopLevelAuthority().isEmpty(), "Urn authority is empty in urn=\"" + urn + "\"");
        assertFalse(geniUrn.getResourceName().isEmpty(), "Urn resource name is empty in urn=\"" + urn + "\"");
    }

}

