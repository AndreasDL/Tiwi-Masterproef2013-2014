package be.iminds.ilabt.jfed.lowlevel.api.test;

import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api.AggregateManager2;
import be.iminds.ilabt.jfed.lowlevel.api.AggregateManager3;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import be.iminds.ilabt.jfed.testing.base.ApiTest;
import be.iminds.ilabt.jfed.util.CommandExecutionContext;
import be.iminds.ilabt.jfed.util.TextUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

/**
 * TestDelegationAggregateManager2. Create a delegated credential, and test it on an AMv2
 *
 * This needs 2 users: extra options:
 *    username2 = ...
 *    passwordFilename2 = ...
 *    pemKeyAndCertFilename2 = ...
 *    userAuthorityUrn2 = ...
 *
 * User 2 will delegate to user 1
 * Then user 1 will call the AM with the delegated credential of user 2
 */
public class TestDelegationOnAggregateManager extends ApiTest {
    public String getTestDescription() {
        return "Delegation or speaksfor credential generation and usage test. This test generates a delegated or speaksfor credentials, and uses it to call ListResources on an AM.";
    }

    private AggregateManager2 am2;
    private AggregateManager3 am3;
    private CommonAMTest commonAMTestUser1;
    private CommonAMTest commonAMTestUser2;

    private CommandExecutionContext testContext;
    private CommandExecutionContext secondUserContext;

    public SfaConnection getAMConnectionUser1() throws JFedException {
        return (SfaConnection) testContext.getConnectionProvider().getConnectionByAuthority(
                testContext.getGeniUser(),
                testContext.getTestedAuthority(),
                new ServerType(ServerType.GeniServerRole.AM, amVersion));
    }
    public SfaConnection getAMConnectionUser2() throws JFedException {
        return (SfaConnection) testContext.getConnectionProvider().getConnectionByAuthority(
                secondUserContext.getGeniUser(),
                testContext.getTestedAuthority(),
                new ServerType(ServerType.GeniServerRole.AM, amVersion));
    }

    @Override
    public List<String> getOptionalConfigKeys() {
        List<String> res = new ArrayList<String>();
        res.add("useSpeaksFor"); //any boolean string   (default no: use delegation)
        res.add("passwordFilename2");
        res.add("amVersion");
        return res;
    }

    @Override
    public List<String> getRequiredConfigKeys() {
        List<String> res = new ArrayList<String>();
        res.add("userUrn2");
        res.add("pemKeyAndCertFilename2");
        res.add("userAuthorityUrn2");
        return res;
    }


    private SfaCredential userCredential1;
    private List<AnyCredential> getUser1CredentialList() {
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(userCredential1);
        return res;
    }
    private SfaCredential userCredential2;
    private List<AnyCredential> getUser2CredentialList() {
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(userCredential2);
        return res;
    }
    private SfaCredential userCredential2DelegatedToUser1;
    private List<AnyCredential> getUser2DelegatedToUser1CredentialList() {
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(userCredential2DelegatedToUser1);
        return res;
    }
    private static List<AnyCredential> toCredentialList(AnyCredential c) {
        List<AnyCredential> res = new ArrayList<AnyCredential>();
        res.add(c);
        return res;
    }

    private boolean delegation;
    private int amVersion = 2;
    public void setUp(CommandExecutionContext testContext) throws CredentialException {
        Boolean delegationConfigParameter = TextUtil.objectToBoolean(getTestConfig().get("useSpeaksFor"));
        if (delegationConfigParameter != null) {
            delegation = !delegationConfigParameter;
            if (delegation)
                note("This test will test delegation");
            else
                note("This test will test speaks-for");
        } else {
            delegation = true;
            note("This test will test delegation");
        }

        if (getTestConfig().get("amVersion") != null) {
            amVersion = Integer.parseInt(getTestConfig().get("amVersion")+"");
            assertTrue(amVersion >= 2 && amVersion <= 3, "Unsupported AM version: "+amVersion);
        }

        note("Getting info for 2nd user");
        secondUserContext = CommandExecutionContext.loadFromProperties(getTestConfig(), true, false, "2", " in test config");
        assertNotNull(secondUserContext);
        assertNotNull(secondUserContext.getGeniUser());
        assertNotNull(secondUserContext.getUserAuthority());

        this.testContext = testContext;
        assertNotNull(testContext);
        assertNotNull(testContext.getGeniUser());
        assertNotNull(testContext.getUserAuthority());

        am2 = new AggregateManager2(testContext.getLogger());
        am3 = new AggregateManager3(testContext.getLogger());

        commonAMTestUser1 = new CommonAMTest(this, testContext);
        commonAMTestUser2 = new CommonAMTest(this, secondUserContext);

    }

    @Test(description = "Fetching User 1 Credential.")
    public void getUser1Credential() throws JFedException, CredentialException {
        GeniUser user1 = testContext.getGeniUser();
        userCredential1 = (SfaCredential) commonAMTestUser1.getUserCredential();

        assertNotNull(userCredential1);

        note("Credential owner urn:  \""+userCredential1.getOwnerUrn()+"\"");
        note("Credential target urn: \""+userCredential1.getTargetUrn()+"\"");
        note("Credential type:       \""+userCredential1.getType()+"\"");
        note("Credential expires:    \"" + userCredential1.getExpires() + "\"");
        note("Credential expires (parsed):    \"" + userCredential1.getExpiresDate() + "\"");

        assertTrue(userCredential1.check());
        note("Credential for "+user1.getUserUrnString()+" passed check");
    }

    @Test(description = "Fetching User 2 Credential.")
    public void getUser2Credential() throws JFedException, CredentialException {
        GeniUser user2 = secondUserContext.getGeniUser();
        userCredential2 = (SfaCredential) commonAMTestUser2.getUserCredential();

        assertNotNull(userCredential2);

        note("Credential owner urn:  \""+userCredential2.getOwnerUrn()+"\"");
        note("Credential target urn: \""+userCredential2.getTargetUrn()+"\"");
        note("Credential type:       \""+userCredential2.getType()+"\"");
        note("Credential expires:    \"" + userCredential2.getExpires() + "\"");
        note("Credential expires (parsed):    \"" + userCredential2.getExpiresDate() + "\"");

        assertTrue(userCredential2.check());
        note("Credential for "+user2.getUserUrnString()+" passed check");
    }


    @Test(description = "Create delegated or speaksfor credential", hardDepends = {"getUser2Credential"})
    public void createDelegatedOrSpeaksForCredential() throws JFedException, CredentialException {
        createDelegatedOrSpeaksForCredentialInternal();
    }
    public void createDelegatedOrSpeaksForCredentialInternal() throws JFedException, CredentialException {
        GeniUser user1 = testContext.getGeniUser();
        GeniUser user2 = secondUserContext.getGeniUser();

        assertNotNull(userCredential2);

        Date expires = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        if (userCredential2.getExpiresDate() != null && expires.after(userCredential2.getExpiresDate())) {
            note("original credential expires in less than 24 hours (at "+userCredential2.getExpires()+" == "+userCredential2.getExpiresDate()+"), so using that expire time for the "+ (delegation?"delegated":"speaksfor")+ " credential");
            expires = userCredential2.getExpiresDate();
        }
        if (userCredential2.getExpiresDate() == null) {
            note("original credential expires is invalid date. Will create credential that expires in 1 hour");
            expires = new Date(System.currentTimeMillis() + 1 * 60 * 60 * 1000);
        }

        if (delegation) {
            note("Configured to create delegated credential");

            userCredential2DelegatedToUser1 = userCredential2.delegate(
                    user1.getUserUrnString()/*newOwnerUrn*/,
                    user1.getClientCertificateChain().get(0)/*newOwnerCert*/,
                    user2.getPrivateKey()/*originalOwnerPrivateKey*/,
                    expires/*expireDate*/,
                    "*"/*delegatedRights*/,
                    false/*canDelegate*/);
        }
        else {
            note("Configured to create speaks-for credential");

            userCredential2DelegatedToUser1 = SfaCredential.createSpeaksFor(
                    user2.getUserUrnString()/*spokenForUrn*/,
                    user1.getUserUrnString()/*speakerUrn*/,
                    user2.getClientCertificateChain().get(0)/*spokenForCert*/,
                    user1.getClientCertificateChain().get(0)/*speakerCert*/,
                    user2.getPrivateKey()/*spokenForPrivateKey*/,
                    expires/*expireDate*/,
                    "*"/*privilegeName*/,
                    false/*canDelegate*/);
        }

        assertNotNull(userCredential2DelegatedToUser1);

        note("Credential owner urn:  \""+userCredential2DelegatedToUser1.getOwnerUrn()+"\"");
        note("Credential target urn: \""+userCredential2DelegatedToUser1.getTargetUrn()+"\"");
        note("Credential type:       \""+userCredential2DelegatedToUser1.getType()+"\"");
        note("Credential expires:    \""+userCredential2DelegatedToUser1.getExpires()+"\"");

        assertTrue(userCredential2DelegatedToUser1.check());
        note("Generated "+ (delegation?"delegated":"speaksfor")+ " credential passed check");
    }

    private Hashtable versionRawResult = null;
    private AggregateManager2.VersionInfo versionInfo = null;
    @Test(description = "Testing GetVersion as user 1. This call requires no credential.", hardDepends = {"createDelegatedOrSpeaksForCredential"})
    public void getVersionUser1() throws JFedException {
        //ignore AM version here (because it's GetVersion)
        AggregateManager2.AggregateManagerReply<AggregateManager2.VersionInfo> reply = am2.getVersion(getAMConnectionUser1());

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS, "GeniResponse code is not SUCCESS (0)");

        versionInfo = reply.getValue();
        assertNotNull(versionInfo);
    }

    @Test(description = "Testing ListResources as user 2. The (non-delegated and non-speaks-for) user 2 credential is used.", hardDepends = {"getVersionUser1"})
    public void listResourcesUser2() throws JFedException {
        ApiCallReply<String> reply = null;
        if (amVersion == 2) {
            AggregateManager2.AggregateManagerReply<String> am2reply = am2.listResources(
                    getAMConnectionUser2(),
                    getUser2CredentialList()/*credentialList*/,
                    "geni"/*rspecType*/,
                    "3"/*rspecVersion*/,
                    true/*available*/,
                    true/*compressed*/,
                    null/*sliceUrn*/,
                    null/*extraOptions*/);
            reply = am2reply;
        }
        if (amVersion == 3) {
            AggregateManager3.AggregateManagerReply<String> am3reply = am3.listResources(
                    getAMConnectionUser2(),
                    getUser2CredentialList()/*credentialList*/,
                    "geni"/*rspecType*/,
                    "3"/*rspecVersion*/,
                    true/*available*/,
                    true/*compressed*/,
                    null/*extraOptions*/);
            reply = am3reply;
        }

        assertNotNull(reply);

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS, "GeniResponse code is not SUCCESS (0)");

        String rspec = reply.getValue();
        assertNotNull(rspec);
    }

    @Test(description = "Testing ListResources as user 1 with user 2 delegated or speaksfor credential.", hardDepends = {"listResourcesUser2"/*, "getUser1Credential"*/})
    public void listResourcesDelegatedOrSpeaksFor() throws JFedException {
        listResourcesDelegatedOrSpeaksForInternal();
    }
    public void listResourcesDelegatedOrSpeaksForInternal() throws JFedException {
        ApiCallReply<String> reply = null;
        if (delegation) {
            note("Calling ListResource with delegated credential");
            if (amVersion == 2) {
                AggregateManager2.AggregateManagerReply<String> am2reply = am2.listResources(
                        getAMConnectionUser1(),
                        getUser2DelegatedToUser1CredentialList()/*credentialList*/,
                        "geni"/*rspecType*/,
                        "3"/*rspecVersion*/,
                        true/*available*/,
                        true/*compressed*/,
                        null/*sliceUrn*/,
                        null/*extraOptions*/);
                reply = am2reply;
            }
            if (amVersion == 3) {
                AggregateManager3.AggregateManagerReply<String> am3reply = am3.listResources(
                        getAMConnectionUser1(),
                        getUser2DelegatedToUser1CredentialList()/*credentialList*/,
                        "geni"/*rspecType*/,
                        "3"/*rspecVersion*/,
                        true/*available*/,
                        true/*compressed*/,
                        null/*extraOptions*/);
                reply = am3reply;
            }
        }
        else {
            note("Calling ListResource with speaks-for credential");
            GeniUser user2 = secondUserContext.getGeniUser();
            Hashtable<String, Object> extraOptions = new Hashtable<String, Object>();
            extraOptions.put("geni_experimenter_urn", user2.getUserUrnString());
            List<AnyCredential> credList = getUser2DelegatedToUser1CredentialList();
            assertNotNull(userCredential2);
            credList.add(userCredential2);

            if (amVersion == 2) {
                AggregateManager2.AggregateManagerReply<String> am2reply = am2.listResources(
                        getAMConnectionUser1(),
                        credList/*credentialList*/,
                        "geni"/*rspecType*/,
                        "3"/*rspecVersion*/,
                        true/*available*/,
                        true/*compressed*/,
                        null/*sliceUrn*/,
                        extraOptions/*extraOptions*/);
                reply = am2reply;
            }
            if (amVersion == 3) {
                AggregateManager3.AggregateManagerReply<String> am3reply = am3.listResources(
                        getAMConnectionUser1(),
                        credList/*credentialList*/,
                        "geni"/*rspecType*/,
                        "3"/*rspecVersion*/,
                        true/*available*/,
                        true/*compressed*/,
                        extraOptions/*extraOptions*/);
                reply = am3reply;
            }
        }
        assertNotNull(reply);

        assertEquals(reply.getGeniResponseCode(), GeniAMResponseCode.GENIRESPONSE_SUCCESS, "GeniResponse code is not SUCCESS (0)");

        String rspec = reply.getValue();
        assertNotNull(rspec);
    }

    @Test(description = "Testing ListResources as user 1 with user 2 delegated or speaksfor credential. Test with different valid expire date formats",
            hardDepends = {"listResourcesUser2"/*, "getUser1Credential"*/},
            softDepends = {"listResourcesDelegatedOrSpeaksFor"})
    public void listResourcesDelegatedOrSpeaksForVariousExpireDatesDormats() throws JFedException, CredentialException {
        note("All dates used in the credential expires field of this test are normally valid RFC3339");

        SfaCredential.debug_expiredate_forceZinsteadOfZero = false;
        SfaCredential.debug_expiredate_forcezulu = true;
        SfaCredential.debug_expiredate_discardsubsecond = true;
        SfaCredential.debug_expiredate_smalltz = false;
        note("Testing with +00:00 instead of Z and SfaCredential.forceZuluTimezone="+SfaCredential.debug_expiredate_forcezulu +
                " discardMilliSeconds="+SfaCredential.debug_expiredate_discardsubsecond+
                " lowerCase="+SfaCredential.debug_expiredate_smalltz);
        createDelegatedOrSpeaksForCredentialInternal();
        listResourcesDelegatedOrSpeaksForInternal();

        SfaCredential.debug_expiredate_forcezulu = false;
        SfaCredential.debug_expiredate_discardsubsecond = false;
        SfaCredential.debug_expiredate_smalltz = true;
        note("Testing with SfaCredential.forceZuluTimezone="+SfaCredential.debug_expiredate_forcezulu +
                " discardMilliSeconds="+SfaCredential.debug_expiredate_discardsubsecond+
                " lowerCase="+SfaCredential.debug_expiredate_smalltz);
        createDelegatedOrSpeaksForCredentialInternal();
        listResourcesDelegatedOrSpeaksForInternal();

        SfaCredential.debug_expiredate_forcezulu = false;
        SfaCredential.debug_expiredate_discardsubsecond = true;
        SfaCredential.debug_expiredate_smalltz = false;
        note("Testing with SfaCredential.forceZuluTimezone="+SfaCredential.debug_expiredate_forcezulu +
                " discardMilliSeconds="+SfaCredential.debug_expiredate_discardsubsecond+
                " lowerCase="+SfaCredential.debug_expiredate_smalltz);
        createDelegatedOrSpeaksForCredentialInternal();
        listResourcesDelegatedOrSpeaksForInternal();

        SfaCredential.debug_expiredate_forcezulu = true;
        SfaCredential.debug_expiredate_discardsubsecond = false;
        SfaCredential.debug_expiredate_smalltz = false;
        note("Testing with SfaCredential.forceZuluTimezone="+SfaCredential.debug_expiredate_forcezulu +
                " discardMilliSeconds="+SfaCredential.debug_expiredate_discardsubsecond+
                " lowerCase="+SfaCredential.debug_expiredate_smalltz);
        createDelegatedOrSpeaksForCredentialInternal();
        listResourcesDelegatedOrSpeaksForInternal();

        SfaCredential.debug_expiredate_forcezulu = true;
        SfaCredential.debug_expiredate_discardsubsecond = true;
        SfaCredential.debug_expiredate_smalltz = true;
        note("Testing with SfaCredential.forceZuluTimezone="+SfaCredential.debug_expiredate_forcezulu +
                " discardMilliSeconds="+SfaCredential.debug_expiredate_discardsubsecond+
                " lowerCase="+SfaCredential.debug_expiredate_smalltz);
        createDelegatedOrSpeaksForCredentialInternal();
        listResourcesDelegatedOrSpeaksForInternal();

        SfaCredential.debug_expiredate_forcezulu = true;
        SfaCredential.debug_expiredate_discardsubsecond = false;
        SfaCredential.debug_expiredate_smalltz = true;
        note("Testing with SfaCredential.forceZuluTimezone="+SfaCredential.debug_expiredate_forcezulu +
                " discardMilliSeconds="+SfaCredential.debug_expiredate_discardsubsecond+
                " lowerCase="+SfaCredential.debug_expiredate_smalltz);
        createDelegatedOrSpeaksForCredentialInternal();
        listResourcesDelegatedOrSpeaksForInternal();

        SfaCredential.debug_expiredate_forcezulu = false;
        SfaCredential.debug_expiredate_discardsubsecond = true;
        SfaCredential.debug_expiredate_smalltz = true;
        note("Testing with SfaCredential.forceZuluTimezone="+SfaCredential.debug_expiredate_forcezulu +
                " discardMilliSeconds="+SfaCredential.debug_expiredate_discardsubsecond+
                " lowerCase="+SfaCredential.debug_expiredate_smalltz);
        createDelegatedOrSpeaksForCredentialInternal();
        listResourcesDelegatedOrSpeaksForInternal();

        SfaCredential.debug_expiredate_forcezulu = false;
        SfaCredential.debug_expiredate_discardsubsecond = false;
        SfaCredential.debug_expiredate_smalltz = false;
        note("Testing with SfaCredential.forceZuluTimezone="+SfaCredential.debug_expiredate_forcezulu +
                " discardMilliSeconds="+SfaCredential.debug_expiredate_discardsubsecond+
                " lowerCase="+SfaCredential.debug_expiredate_smalltz);
        createDelegatedOrSpeaksForCredentialInternal();
        listResourcesDelegatedOrSpeaksForInternal();

        //set back to defaults to be safe
        SfaCredential.debug_expiredate_forceZinsteadOfZero = true;
        SfaCredential.debug_expiredate_forcezulu = true;
        SfaCredential.debug_expiredate_discardsubsecond = true;
        SfaCredential.debug_expiredate_smalltz = false;
    }
}
