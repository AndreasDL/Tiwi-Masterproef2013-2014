package be.iminds.ilabt.jfed.ui.rspeceditor.editor;

import java.net.URL;
import java.util.ResourceBundle;

import be.iminds.ilabt.jfed.ui.javafx.util.ObjectPropertyBindHelper;
import be.iminds.ilabt.jfed.ui.javafx.util.SelectedObjectPropertyBinder;
import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;

public class RspecNodeShowPanel implements Initializable {
    private SelectedObjectPropertyBinder selectedObjectPropertyBinder = new SelectedObjectPropertyBinder(false);
    
    @FXML private Label idLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        assert idLabel != null;
        assert selectedObjectPropertyBinder != null;
        assert selectedObjectPropertyBinder.getBinders() != null;
        selectedObjectPropertyBinder.getBinders().add(new ObjectPropertyBindHelper<RspecNode>(idLabel.textProperty()) {
            @Override public Property objectProperty(RspecNode t) { return t.idProperty(); }
        });
    }
    
    public void setSelection(RspecSelection rspecSelection) {
        selectedObjectPropertyBinder.setSelectedObjectProperty(rspecSelection.selectedRspecNodeProperty());
    }
}
