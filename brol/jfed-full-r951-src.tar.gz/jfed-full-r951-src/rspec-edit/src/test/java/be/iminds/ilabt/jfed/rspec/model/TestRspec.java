package be.iminds.ilabt.jfed.rspec.model;

import junit.framework.Assert;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.Test;

/**
 * TestRspec
 */
public class TestRspec {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    private ModelRspec testRspec;
    @Test()
    public void generateTestRspec() {
        testRspec = new ModelRspec();
        RspecNode n1 = new RspecNode(testRspec.nextNodeName());
        testRspec.getNodes().add(n1);
        RspecNode n2 = new RspecNode(testRspec.nextNodeName());
        testRspec.getNodes().add(n2);
        RspecNode n3 = new RspecNode(testRspec.nextNodeName());
        testRspec.getNodes().add(n3);
        RspecNode n4 = new RspecNode(testRspec.nextNodeName());
        testRspec.getNodes().add(n4);
        n1.setOsImage("DUMMY");
        n2.setOsImage("DUMMY");
        n3.setOsImage("DUMMY");
        n4.setOsImage("DUMMY");

        n1.setEditorX(10);
        n1.setEditorY(10);

        n2.setEditorX(300);
        n2.setEditorY(10);

        n3.setEditorX(10);
        n3.setEditorY(300);

        n4.setEditorX(300);
        n4.setEditorY(300);

        RspecLink l1 = new RspecLink(testRspec, testRspec.nextLinkName());
        RspecInterface i1 = new RspecInterface(n1, l1, testRspec.nextIfaceName(n1));
        RspecInterface i2 = new RspecInterface(n2, l1, testRspec.nextIfaceName(n2));
        RspecInterface i3 = new RspecInterface(n3, l1, testRspec.nextIfaceName(n3));
        i1.setId("if1");
        i2.setId("if2");
        i3.setId("if3");

        testRspec.getLinks().add(l1);

        RspecLink l2 = new RspecLink(testRspec, testRspec.nextLinkName());
        RspecInterface i4 = new RspecInterface(n1, l2, testRspec.nextIfaceName(n1));
        RspecInterface i5 = new RspecInterface(n4, l2, testRspec.nextIfaceName(n4));
        l2.setId("gigalink2");
        testRspec.getLinks().add(l2);
    }


    @Test(dependsOnMethods={"generateTestRspec"})
    public void testGenerateGeneralRspec() {
        String rspecXmlString = testRspec.toGeni3RequestRspec();

        LOG.debug("Test Rspec XML: "+rspecXmlString);

        Assert.assertTrue(rspecXmlString.length() > 100);

        Assert.assertTrue(rspecXmlString.contains("type=\"request\""));
        Assert.assertTrue(rspecXmlString.contains("xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd\" "));
        Assert.assertTrue(rspecXmlString.contains("xmlns=\"http://www.geni.net/resources/rspec/3\" "));
        Assert.assertTrue(rspecXmlString.contains("xmlns:jFed=\"http://jfed.iminds.be/rspec/ext/jfed/1\" "));
        Assert.assertTrue(rspecXmlString.contains("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""));
    }

//    @Test(dependsOnMethods={"generateTestRspec"})
//    public void testGeneratePleRspec() {
//
//    }
//
//    @Test(dependsOnMethods={"generateTestRspec"})
//    public void testGenerateNitosRspec() {
//
//    }
}
