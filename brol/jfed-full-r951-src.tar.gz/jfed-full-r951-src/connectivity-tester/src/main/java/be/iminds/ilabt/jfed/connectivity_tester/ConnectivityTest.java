package be.iminds.ilabt.jfed.connectivity_tester;

import javax.xml.bind.annotation.XmlElement;
import java.util.concurrent.Callable;

/**
 * User: twalcari
 * Date: 12/19/13
 * Time: 4:24 PM
 */
public interface ConnectivityTest extends Callable<ConnectivityTest.Status> {

    @XmlElement(name = "exception")
    String getExceptionString();

    public String getName();

    public static enum Status { SUCCEEDED, WARNING, FAILED, SKIPPED }

    public  Status getStatus();
    public String getMessage();
    public ConnectivityException getException();

}
