package be.iminds.ilabt.jfed.connectivity_tester;

/**
 * User: twalcari
 * Date: 12/19/13
 * Time: 4:26 PM
 */
public class Ping6Test extends AbstractConnectivityTest {
    private static final String DEFAULT_IPV6_ADDRESS = "flsmonitor.fed4fire.eu";

    private final String address;
    public Ping6Test(){
        this(DEFAULT_IPV6_ADDRESS);
    }

    public Ping6Test(String address){
        super("Ping to IPv6-host");
        this.address = address;
    }

    @Override
    public Status runTest() throws ConnectivityException {
        if (PingUtils.isReachableByPing6(address)) {
            setMessage("Successfully connected to " + address);
            return Status.SUCCEEDED;
        } else {

            setMessage("Unable to reach " + address);
            return Status.FAILED;
        }

    }
}
