package be.iminds.ilabt.jfed.connectivity_tester;

/**
 * User: twalcari
 * Date: 12/19/13
 * Time: 4:26 PM
 */
public class Ping4Test extends AbstractConnectivityTest {
    private static final String DEFAULT_IPV4_ADDRESS = "flsmonitor.fed4fire.eu";

    private final String address;
    public Ping4Test(){
        this(DEFAULT_IPV4_ADDRESS);
    }

    public Ping4Test(String address){
        super("Ping to IPv4-host");
        this.address = address;
    }


    @Override
    public Status runTest() throws ConnectivityException {
        if (PingUtils.isReachableByPing(address)) {
            setMessage("Successfully connected to " + address);
            return Status.SUCCEEDED;
        } else {

            setMessage("Unable to reach " + address);
            return Status.FAILED;
        }

    }
}
