package be.iminds.ilabt.jfed.connectivity_tester;

/**
 * User: twalcari
 * Date: 12/19/13
 * Time: 4:25 PM
 */
public class ConnectivityException extends Exception {
    public ConnectivityException() {
    }

    public ConnectivityException(String message) {
        super(message);
    }

    public ConnectivityException(String message, Throwable cause) {
        super(message, cause);
    }

    public ConnectivityException(Throwable cause) {
        super(cause);
    }

    public ConnectivityException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
