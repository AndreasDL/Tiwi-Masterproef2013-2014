package be.iminds.ilabt.jfed.connectivity_tester;

import java.net.*;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/**
 * User: twalcari
 * Date: 12/19/13
 * Time: 4:26 PM
 */
public class HasIPv4AddressTest extends AbstractConnectivityTest {

    public HasIPv4AddressTest() {
        super("Check for IPv4-address");
    }

    @Override
    public Status runTest() throws ConnectivityException {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface interf = interfaces.nextElement();
                if (interf.isUp() && !interf.isLoopback()) {
                    List<InterfaceAddress> adrs = interf.getInterfaceAddresses();
                    for (Iterator<InterfaceAddress> iter = adrs.iterator(); iter.hasNext(); ) {
                        InterfaceAddress adr = iter.next();
                        InetAddress inadr = adr.getAddress();
                        if (inadr instanceof Inet4Address){
                            setMessage("Found network-address " + inadr.getHostAddress()+ " on interface " + interf.getDisplayName());
                            return Status.SUCCEEDED;
                        }
                    }
                }
            }
        } catch (SocketException e) {
            throw new ConnectivityException(e);
        }
        throw new ConnectivityException("Could not find non-loopback IPv4-address for this computer");
    }
}
