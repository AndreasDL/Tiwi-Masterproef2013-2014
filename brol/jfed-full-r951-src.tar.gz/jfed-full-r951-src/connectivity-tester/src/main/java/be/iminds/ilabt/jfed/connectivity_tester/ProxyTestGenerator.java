package be.iminds.ilabt.jfed.connectivity_tester;

import be.iminds.ilabt.jfed.lowlevel.authority.JFedAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.stitching.VlanRangeHelper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * User: twalcari
 * Date: 1/7/14
 * Time: 2:28 PM
 */
public class ProxyTestGenerator implements TestsGenerator {
    @Override
    public Collection<ConnectivityTest> generateTests() {

        List<ConnectivityTest> tests = new ArrayList<>();

        List<SfaAuthority> authorities = JFedAuthorityList.getAuthorityListModel().getAuthorities();

        for (SfaAuthority auth : authorities) {
            for (SfaAuthority.ProxyInfo proxyInfo : auth.getProxies()) {
                VlanRangeHelper portRange = new VlanRangeHelper(proxyInfo.getPortRange());
                Integer port = portRange.getCurrent();

                //test maximum 10 ports for the same proxy
                while (port != null) {
                    tests.add(new HostAndPortTest(proxyInfo.getHostname(), port,
                            "Proxy " + proxyInfo.getHostname() + ":" + port, "Proxy"));
                    port = portRange.getNext();
                }

            }
        }
        return tests;
    }

}
