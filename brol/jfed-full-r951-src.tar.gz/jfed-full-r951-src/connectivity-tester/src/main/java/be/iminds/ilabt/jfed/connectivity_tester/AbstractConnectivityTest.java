package be.iminds.ilabt.jfed.connectivity_tester;

import javax.xml.bind.annotation.XmlElement;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * User: twalcari
 * Date: 12/19/13
 * Time: 4:54 PM
 */
public abstract class AbstractConnectivityTest implements ConnectivityTest {

    private final String name;
    private ConnectivityException exception;
    private String message = null;
    private Status status = null;

    /**
     * DO NOT USE THIS CONSTRUCTOR
     * <p/>
     * This constructor is provided for JAXB, and should not be used for any other purpose.
     */
    private AbstractConnectivityTest() {
        this.name = "Unknown";
    }

    public AbstractConnectivityTest(String name) {
        this.name = name;
    }

    @Override
    @XmlElement(name = "message")
    public String getMessage() {
        return message;
    }

    protected void setMessage(String message) {
        this.message = message;
    }

    @Override
    public ConnectivityException getException() {
        return exception;
    }

    @Override
    @XmlElement(name = "exception")
    public String getExceptionString() {
        if (exception == null)
            return null;

        StringWriter sw = new StringWriter();
        exception.printStackTrace(new PrintWriter(sw));
        return sw.toString();

    }

    @Override
    public Status call() {
        try {
            status = runTest();
        } catch (ConnectivityException e) {
            this.exception = e;
            status = Status.FAILED;
        } catch (RuntimeException e) {
            this.exception = new ConnectivityException("Caught runtime-exception: " + e.getMessage());
            status = Status.FAILED;
        }
        return status;
    }

    @XmlElement(name = "name")
    public String getName() {
        return name;
    }

    public abstract Status runTest() throws ConnectivityException;

    @XmlElement(name = "result")
    public Status getStatus() {
        return status;
    }
}
