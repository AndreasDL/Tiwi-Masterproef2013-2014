package be.iminds.ilabt.jfed.connectivity_tester;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.HierarchicalConfiguration;
import org.apache.commons.configuration.XMLConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * User: twalcari
 * Date: 1/6/14
 * Time: 10:20 AM
 */
public class ConnectivityTestSuite {
    private static final Logger LOG = LoggerFactory.getLogger(ConnectivityTestSuite.class);
    private static final String TYPE_STRING = "string", TYPE_INT = "int";
    private final List<ConnectivityTest> tests;

    public ConnectivityTestSuite() {
        tests = new ArrayList<>();

        try {
            XMLConfiguration config = new XMLConfiguration(DoTests.class.getResource("/tests.xml"));

            for (HierarchicalConfiguration testConf : config.configurationsAt("test")) {
                try {
                    Class<ConnectivityTest> testClass =
                            (Class<ConnectivityTest>) Class.forName(testConf.getString("className"));

                    //find our constructor args
                    List<HierarchicalConfiguration> argList = testConf.configurationsAt("constructorArgs.arg");
                    Object[] testArgs = new Object[argList.size()];
                    Class[] argClasses = new Class[argList.size()];

                    for (int i = 0; i < argList.size(); i++) {
                        String type = argList.get(i).getString("[@type]", TYPE_STRING);

                        if (TYPE_INT.equals(type)) {
                            testArgs[i] = Integer.parseInt((String) argList.get(i).getRoot().getValue());
                            argClasses[i] = Integer.TYPE;

                        } else {
                            testArgs[i] = argList.get(i).getRoot().getValue();
                            argClasses[i] = testArgs[i].getClass();
                        }
                    }

                    Constructor<ConnectivityTest> testConstructor = testClass.getConstructor(argClasses);
                    ConnectivityTest test = testConstructor.newInstance(testArgs);
                    tests.add(test);

                } catch (ClassNotFoundException | NoSuchMethodException
                        | InstantiationException | IllegalAccessException
                        | InvocationTargetException e) {
                    LOG.error("Error while instantiating test " + testConf.getString("@id") + ". Skipping.", e);
                }
            }

            for (HierarchicalConfiguration testConf : config.configurationsAt("tests-generator")) {
                try {
                    Class<TestsGenerator> testsGenClass =
                            (Class<TestsGenerator>) Class.forName(testConf.getString("className"));

                    //find our constructor args
                    List<HierarchicalConfiguration> argList = testConf.configurationsAt("constructorArgs.arg");
                    Object[] testArgs = new Object[argList.size()];
                    Class[] argClasses = new Class[argList.size()];

                    for (int i = 0; i < argList.size(); i++) {
                        String type = argList.get(i).getString("[@type]", TYPE_STRING);

                        if (TYPE_INT.equals(type)) {
                            testArgs[i] = Integer.parseInt((String) argList.get(i).getRoot().getValue());
                            argClasses[i] = Integer.TYPE;

                        } else {
                            testArgs[i] = argList.get(i).getRoot().getValue();
                            argClasses[i] = testArgs[i].getClass();
                        }
                    }

                    Constructor<TestsGenerator> testsGeneratorConstructor = testsGenClass.getConstructor(argClasses);
                    TestsGenerator testsGenerator = testsGeneratorConstructor.newInstance(testArgs);
                    tests.addAll(testsGenerator.generateTests());

                } catch (ClassNotFoundException | NoSuchMethodException
                        | InstantiationException | IllegalAccessException
                        | InvocationTargetException e) {
                    LOG.error("Error while instantiating test " + testConf.getString("@id") + ". Skipping.", e);
                }
            }

        } catch (ConfigurationException e) {
            e.printStackTrace();
        }
    }

    public List<ConnectivityTest> getTests() {
        return Collections.unmodifiableList(tests);
    }

}
