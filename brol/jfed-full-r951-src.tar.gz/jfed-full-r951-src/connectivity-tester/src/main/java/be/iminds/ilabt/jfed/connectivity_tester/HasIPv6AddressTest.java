package be.iminds.ilabt.jfed.connectivity_tester;

import java.net.*;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/**
 * User: twalcari
 * Date: 12/19/13
 * Time: 4:26 PM
 */
public class HasIPv6AddressTest extends AbstractConnectivityTest {

    public HasIPv6AddressTest() {
        super("Check for IPv6-address");
    }
    @Override
    public Status runTest() throws ConnectivityException {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface interf = interfaces.nextElement();
                if (interf.isUp() && !interf.isLoopback()) {
                    List<InterfaceAddress> adrs = interf.getInterfaceAddresses();
                    for (Iterator<InterfaceAddress> iter = adrs.iterator(); iter.hasNext(); ) {
                        InterfaceAddress adr = iter.next();
                        InetAddress inadr = adr.getAddress();
                        if (inadr instanceof Inet6Address && !inadr.isLinkLocalAddress()) {
                            setMessage("Found network-address " + inadr.getHostAddress() + " on interface " + interf.getDisplayName());
                            return Status.SUCCEEDED;
                        }
                    }
                }
            }
        } catch (SocketException e) {
            throw new ConnectivityException(e);
        }
        throw new ConnectivityException("Could not find a public IPv6-address for this computer");
    }
}
