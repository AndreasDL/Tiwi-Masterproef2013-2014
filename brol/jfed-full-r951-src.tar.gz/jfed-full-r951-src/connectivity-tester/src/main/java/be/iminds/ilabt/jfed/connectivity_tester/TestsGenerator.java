package be.iminds.ilabt.jfed.connectivity_tester;

import java.util.Collection;

/**
 * User: twalcari
 * Date: 1/7/14
 * Time: 3:00 PM
 */
public interface TestsGenerator {

    public Collection<? extends ConnectivityTest> generateTests();
}
