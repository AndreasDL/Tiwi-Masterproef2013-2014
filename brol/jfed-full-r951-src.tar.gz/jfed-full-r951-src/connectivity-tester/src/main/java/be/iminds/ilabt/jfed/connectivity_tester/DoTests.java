package be.iminds.ilabt.jfed.connectivity_tester;

import java.util.List;

/**
 * User: twalcari
 * Date: 1/3/14
 * Time: 11:04 AM
 */
public class DoTests {

    public static void main(String[] args) {
        List<ConnectivityTest> tests = new ConnectivityTestSuite().getTests();

        for(ConnectivityTest test : tests){
            try {
                ConnectivityTest.Status result = test.call();
                System.out.println(test.getName() + " status: " + result.name());
                if (test.getMessage() != null)
                    System.out.println(test.getName() + " message: " + test.getMessage());
                if (test.getException() != null)
                    System.out.println(test.getName() + " exception: " + test.getException());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
