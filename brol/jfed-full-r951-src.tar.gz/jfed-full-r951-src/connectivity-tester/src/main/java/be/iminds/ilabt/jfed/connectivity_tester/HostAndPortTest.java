package be.iminds.ilabt.jfed.connectivity_tester;

import java.io.IOException;
import java.net.*;

/**
 * User: twalcari
 * Date: 12/23/13
 * Time: 10:20 AM
 */
public class HostAndPortTest extends AbstractConnectivityTest {

    private static final int TIMEOUT = 5000; //5 seconds
    private final String hostname;
    private final int port;

    public HostAndPortTest(String hostname, int port, String description, String category) {
        super(String.format("[%s] %s", category, description));
        this.hostname = hostname;
        this.port = port;
    }

    public HostAndPortTest(URL url, String description, String category){


        this(url.getHost(), url.getPort() != -1 ? url.getPort() : url.getDefaultPort(),
                description, category);
    }


    @Override
    public Status runTest() throws ConnectivityException {
        SocketAddress socketAddress = new InetSocketAddress(hostname, port);
        Socket socket = new Socket();
        try {
            //try to connect
            socket.connect(socketAddress, TIMEOUT);

            if (socket.isConnected()) {
                setMessage("Successfully opened socket to " + hostname + ":" + port );
                return Status.SUCCEEDED;
            } else {
                setMessage("Socket isn't connected to " + hostname + ":" + port );
                return Status.FAILED;
            }
        } catch (SocketTimeoutException e) {
            throw new ConnectivityException("Connection to " + hostname + ":" + port + " timed out", e);
        } catch (IOException e) {
            throw new ConnectivityException("Could not open a socket to " + hostname + ":" + port, e);
        } finally {
            try {
                socket.close();
            } catch (IOException ex) {
            }

        }
    }
}
