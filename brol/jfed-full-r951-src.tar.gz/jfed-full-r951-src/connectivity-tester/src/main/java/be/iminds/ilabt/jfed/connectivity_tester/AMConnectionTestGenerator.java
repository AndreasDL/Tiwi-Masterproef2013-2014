package be.iminds.ilabt.jfed.connectivity_tester;

import be.iminds.ilabt.jfed.lowlevel.ServerType;
import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.JFedAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * User: twalcari
 * Date: 1/7/14
 * Time: 2:28 PM
 */
public class AMConnectionTestGenerator implements TestsGenerator {
    @Override
    public Collection<ConnectivityTest> generateTests() {

        List<ConnectivityTest> tests = new ArrayList<>();

        AuthorityListModel authorityListModel = JFedAuthorityList.getAuthorityListModel();

        for (SfaAuthority auth : authorityListModel.getAuthorities()) {
            for (Map.Entry<ServerType, URL> e : auth.getUrls().entrySet()) {
                tests.add(new HostAndPortTest(e.getValue(), auth.getNameForUrn() + " "
                        + e.getKey().getRole() + " v" + e.getKey().getVersion(), "AM"));
            }
        }

        return tests;

    }

}
