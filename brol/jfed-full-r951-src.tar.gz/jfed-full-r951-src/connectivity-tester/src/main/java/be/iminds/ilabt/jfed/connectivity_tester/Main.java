package be.iminds.ilabt.jfed.connectivity_tester;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * User: twalcari
 * Date: 12/19/13
 * Time: 5:16 PM
 */
public class Main {

    private static final int POS_HOSTNAME = 0;
    private static final int POS_PORT = 1;
    private static final int POS_DESCRIPTION = 2;
    private static final int POS_CATEGORY = 3;

    public static void main(String[] args) {


        List<ConnectivityTest> tests = new ArrayList<ConnectivityTest>();
        tests.add(new HasIPv4AddressTest());
        tests.add(new HasIPv6AddressTest());
        tests.add(new Ping6Test());

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(Main.class.getResourceAsStream("/ports.csv")))) {

            //ignore first line
            String line = reader.readLine();
            assert (line != null);

            while ((line = reader.readLine()) != null) {

                String[] parts = line.split(";");
                tests.add(new HostAndPortTest(parts[POS_HOSTNAME], Integer.parseInt(parts[POS_PORT]), parts[POS_DESCRIPTION], parts[POS_CATEGORY]));

            }


        } catch (IOException e) {
            e.printStackTrace();
        }

        for (ConnectivityTest test : tests) {
            try {
                ConnectivityTest.Status result = test.call();
                System.out.println(test.getName() + " status: " + result.name());
                if (test.getMessage() != null)
                    System.out.println(test.getName() + " message: " + test.getMessage());
                if (test.getException() != null)
                    System.out.println(test.getName() + " exception: " + test.getException());
            } catch (Exception e) {

            }
        }


    }

}
