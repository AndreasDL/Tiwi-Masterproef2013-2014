<?php

$ref = 1;

$filename = "reports/bugreport-" . $ref . ".xml";
while(file_exists($filename)){
	$ref++;
	$filename = "reports/bugreport-" . $ref . ".xml";
}

$report = urldecode($_POST["report"]);

file_put_contents($filename, $report);

//load the contents of the bugreport, and fetch the description
$xml = new SimpleXMLElement($report);
$call_count = $xml->calls->call->count();
//send mail to admins

$message = <<<EOD
  Received a new jFed bug report  
==================================
Description: $xml->description

Version: $xml->version
# included calls: $call_count

Reporter Mail: $xml->mail
Reporter Credentials: $xml->reporterCredential

Full report: New bugreport https://flsmonitor.fed4fire.eu/jfedexperimenter/$filename

EOD;
$to      = 'thijs.walcarius@intec.ugent.be, brecht.vermeulen@ugent.be, wim.vandemeerssche@intec.ugent.be';
$subject = 'jFed bug report #' . $ref ;
$headers = 'From: jfed-bugreports@atlantis.ugent.be' . "\r\n" .
    'Reply-To: brecht.vermeulen@ugent.be' . "\r\n";

mail($to, $subject, $message, $headers);

//send mail to user

$user_message = <<<EOD
Dear,

Your bugreport was submitted under reference #$ref. Please include this reference in any future communications regarding this bug report.

A jFed developer will update you on this bug report as soon as possible.

Your bug report contains following information:

* Description: $xml->description

* Version: $xml->version
* # included calls: $call_count

Kind regards,

The jFed-team

EOD;


mail($xml->mail, $subject, $user_message, $headers);



echo "Filed bugreport under reference #$ref";

?>
