package be.iminds.ilabt.jfed.experimenter_gui.bugreporting;

/**
 * User: twalcari
 * Date: 2/5/14
 * Time: 4:29 PM
 */
public class LogLine {


    private long time;
    private String className;
    private String level;
    private String message;
    private String throwable;
    private String threadName;

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getThrowable() {
        return throwable;
    }

    public void setThrowable(String throwable) {
        this.throwable = throwable;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getThreadName() {
        return threadName;
    }

    public void setThreadName(String threadName) {
        this.threadName = threadName;
    }
}
