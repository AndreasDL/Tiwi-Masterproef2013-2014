package be.iminds.ilabt.jfed.experimenter_gui.util;

import be.iminds.ilabt.jfed.experimenter_gui.canvas.impl.RspecCanvasNode;
import be.iminds.ilabt.jfed.experimenter_gui.editor.bo.NodeDescription;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;
import be.iminds.ilabt.jfed.ui.rspeceditor.editor.ComponentManagerInfo;
import javafx.scene.image.Image;

/**
 * User: twalcari
 * Date: 11/8/13
 * Time: 2:40 PM
 */
public class ImageUtil {

    private ImageUtil() {
    }

    public static Image getRspecNodeImage(RspecNode node) {
        return new Image(RspecCanvasNode.class.getResource("/images/vm.png").toString());
    }

    public static Image getComponentManagerInfoImage(ComponentManagerInfo componentManagerInfo) {
        return new Image(RspecCanvasNode.class.getResource("/images/computer.png").toString());
    }

    public static Image getNodeTypeImage(NodeDescription.NodeType type) {
        String loc = null;
        switch (type) {
            case COMPUTER:
                loc = "/images/computer.png";
                break;
            case VM:
                loc = "/images/vm.png";
                break;
            case WIRELESS:
                loc = "/images/wireless.png";
                break;
            case SERVER:
                loc = "/images/computer-mainframe.png";
                break;
        }

        return new Image(ImageUtil.class.getResource(loc).toExternalForm());

    }


}
