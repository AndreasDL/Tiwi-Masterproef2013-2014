package be.iminds.ilabt.jfed.experimenter_gui.call_gui;

import be.iminds.ilabt.jfed.highlevel.controller.JavaFXTaskThread;
import be.iminds.ilabt.jfed.highlevel.controller.SingleTask;
import com.cathive.fonts.fontawesome.FontAwesomeIcon;
import com.cathive.fonts.fontawesome.FontAwesomeIconView;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.HBox;

/**
 * TaskLabel
 */
public class TaskLabel extends HBox {
    private final Label id;
    private final Label name;
    //private final Label state;
    private ObjectProperty<JavaFXTaskThread.SingleTask> task = new SimpleObjectProperty<>(null);
    private ChangeListener<? super SingleTask.TaskState> stateChangeListener;

    public TaskLabel() {
        id = new Label("");
        id.getStyleClass().add("task-label-id");
        name = new Label("");
        name.getStyleClass().add("task-label-name");
        //state = new Label("");

        getStylesheets().add(TaskLabel.class.getResource("calls.css").toExternalForm());
        getStyleClass().add("task-label");

        getChildren().addAll(id, name);//, state);

        stateChangeListener = new ChangeListener<SingleTask.TaskState>() {
            @Override
            public void changed(ObservableValue<? extends SingleTask.TaskState> observableValue,
                                SingleTask.TaskState oldTaskState,
                                SingleTask.TaskState newTaskState) {
                changeState(oldTaskState, newTaskState);
            }
        };

        task.addListener(new ChangeListener<JavaFXTaskThread.SingleTask>() {
            @Override
            public void changed(ObservableValue<? extends JavaFXTaskThread.SingleTask> observableValue,
                                JavaFXTaskThread.SingleTask oldSingleTask,
                                JavaFXTaskThread.SingleTask newSingleTask) {
                SingleTask.TaskState oldTaskState = null;
                if (oldSingleTask != null) {
                    //state.textProperty().unbind();
                    oldTaskState = oldSingleTask.getState();
                    oldSingleTask.stateProperty().removeListener(stateChangeListener);
                }
                if (newSingleTask != null) {
                    name.setText(newSingleTask.getName());
                    id.setText(newSingleTask.getId());
                    //state.textProperty().bind(Bindings.convert(newSingleTask.stateProperty()));
                    newSingleTask.stateProperty().addListener(stateChangeListener);
                    changeState(oldTaskState, newSingleTask.getState());
                }
            }
        });


    }

    private static String taskStateToStyleClass(SingleTask.TaskState state) {
        switch (state) {
            case UNSUBMITTED: {
                return "taskstate-unsubmitted";
            }
            case BLOCKED: {
                return "taskstate-blocked";
            }
            case QUEUED: {
                return "taskstate-queued";
            }
            case RUNNING: {
                return "taskstate-running";
            }
            case FAILED: {
                return "taskstate-failed";
            }
            case SUCCESS: {
                return "taskstate-success";
            }
            default:
                throw new RuntimeException("Unexpected state");
        }
    }

    private static FontAwesomeIcon taskStateToIcon(SingleTask.TaskState state) {
        switch (state) {
            case UNSUBMITTED: {
                return FontAwesomeIcon.ICON_ASTERISK;
            }
            case BLOCKED: {
                return FontAwesomeIcon.ICON_PAUSE;
            }
            case QUEUED: {
                return FontAwesomeIcon.ICON_REORDER; //bars
            }
            case RUNNING: {
                return FontAwesomeIcon.ICON_PLAY;
            }
            case FAILED: {
                return FontAwesomeIcon.ICON_EXCLAMATION_SIGN;
            }
            case SUCCESS: {
                return FontAwesomeIcon.ICON_CHECK_SIGN;
            }
            default:
                throw new RuntimeException("Unexpected state");
        }
    }

    private void changeState(SingleTask.TaskState oldTaskState, SingleTask.TaskState newTaskState) {

        if (oldTaskState != null) {
            getStyleClass().remove(taskStateToStyleClass(oldTaskState));
        }

        if (newTaskState != null) {
            getStyleClass().add(taskStateToStyleClass(newTaskState));

            FontAwesomeIconView newIcon = new FontAwesomeIconView(taskStateToIcon(newTaskState));
            newIcon.setTooltip(new Tooltip(newTaskState.name()));

            id.setGraphic(newIcon);
        } else {
            id.setGraphic(null);
            id.setText("");
            name.setText("");
        }
    }

    public void setTask(JavaFXTaskThread.SingleTask t) {
        task.set(t);
    }

    public ObjectProperty<JavaFXTaskThread.SingleTask> taskProperty() {
        return task;
    }
}
