package be.iminds.ilabt.jfed.experimenter_gui.preferences;

import be.iminds.ilabt.jfed.experimenter_gui.util.ui.TextFieldWithStatus;
import be.iminds.ilabt.jfed.util.OSDetector;
import be.iminds.ilabt.jfed.util.PreferencesUtil;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import be.iminds.ilabt.jfed.util.KeyUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.FileChooser;
import javafx.stage.FileChooserBuilder;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * User: twalcari
 * Date: 12/6/13
 * Time: 2:26 PM
 */
public class LinuxPreferencesDialog extends PreferencesDialog {
    private static final Logger LOG = LoggerFactory.getLogger(LinuxPreferencesDialog.class);
    private static final String LINUX_PREFERENCES_FXML = "LinuxPreferences.fxml";
    @FXML
    protected TextFieldWithStatus pubKeyFileTextField;
    @FXML
    protected Button pubKeyBrowseButton;
    @FXML
    protected TextArea terminalCommandTextArea;
    @FXML
    private Label terminalCommandLabel;
    @FXML
    private CheckBox sshagentCheckBox;


    public LinuxPreferencesDialog() {
        super();
    }

    @Override
    protected String getFxmlFile() {
        return LINUX_PREFERENCES_FXML;
    }

    public void initialize() {
        super.initialize();

        if (OSDetector.findOS() == OSDetector.OS.MAC) {
            terminalCommandLabel.setText("AppleScript commands:");
        }


        if (PreferencesUtil.getString(PreferencesUtil.Preference.PREF_COMMAND_UNIX_TERMINAL) != null)
            terminalCommandTextArea.setText(PreferencesUtil.getString(PreferencesUtil.Preference.PREF_COMMAND_UNIX_TERMINAL));

        sshagentCheckBox.setSelected(PreferencesUtil.getBoolean(PreferencesUtil.Preference.PREF_SSHAGENT_USE));

//        if (PreferencesUtil.getPubKeyLocation() != null) {
//            useCustomKeyPairRadioButton.setSelected(true);
//            pubKeyFileTextField.setText(PreferencesUtil.getPubKeyLocation());
//            testPublicKey();
//        }

        pubKeyFileTextField.disableProperty().bind(useCustomKeyPairRadioButton.selectedProperty().not());
        pubKeyBrowseButton.disableProperty().bind(useCustomKeyPairRadioButton.selectedProperty().not());
    }


    @Override
    protected boolean testPrivateKeyFile(File file) throws IOException {
        if (file.exists() && file.isFile()) {
            //check if it is an putty private key
            BufferedReader reader = new BufferedReader(new FileReader(file));
            StringBuilder fileContents = new StringBuilder();

            String line;
            while ((line = reader.readLine()) != null) {
                fileContents.append(line);
            }

            reader.close();


            return KeyUtil.hasAnyPrivateKey(fileContents.toString());
        } else
            return false;
    }

    private String fileToString(File file) throws IOException {
        if (file.exists() && file.isFile()) {
            //check if it is an putty private key
            BufferedReader reader = new BufferedReader(new FileReader(file));
            StringBuilder fileContents = new StringBuilder();

            String line;
            while ((line = reader.readLine()) != null) {
                fileContents.append(line);
            }

            reader.close();
            return fileContents.toString();
        } else
            return null;
    }

    protected boolean testPublicKeyFile(File file) throws IOException {
        return KeyUtil.isOpenSshRsaKey(fileToString(file));

    }

    @FXML
    protected void onPubKeyBrowseButtonAction(ActionEvent actionEvent) {
        FileChooser fc = FileChooserBuilder.create()
                .title("Select your Private Key")
                .initialDirectory(getLoggedInUserPrivateKeyFile().getParentFile())
                .build();

        File selectedFile = fc.showOpenDialog(pubKeyFileTextField.getScene().getWindow());
        if (selectedFile != null) {
            pubKeyFileTextField.setText(selectedFile.getAbsolutePath());
            testPublicKey();
        }

    }

    protected void testPublicKey() {
        if (pubKeyFileTextField.getText().length() == 0) {
            pubKeyFileTextField.setStatus(TextFieldWithStatus.Status.NONE);
            return;
        }

        try {
            if (testPublicKeyFile(new File(pubKeyFileTextField.getText()))) {
                pubKeyFileTextField.setStatus(TextFieldWithStatus.Status.OK);
            } else {
                Dialogs.showWarningDialog((Stage) pubKeyFileTextField.getScene().getWindow(),
                        " Please select a valid public key.",
                        "The provided key is not valid.",
                        "Invalid key file");
                pubKeyFileTextField.setStatus(TextFieldWithStatus.Status.ERROR);
            }
        } catch (IOException ex) {
            Dialogs.showErrorDialog((Stage) pubKeyFileTextField.getScene().getWindow(),
                    "An error occured while processing the key file", "Error", "Error", ex);
            pubKeyFileTextField.setStatus(TextFieldWithStatus.Status.ERROR);
        }
    }

    @Override
    protected boolean applySettings() {

        if (!terminalCommandTextArea.getText().contains("%")) {
            Dialogs.showErrorDialog((Stage) this.getScene().getWindow(),
                    "Your terminal command must contain '%' at the location on which the SSH-command can be included");
            return false;
        }

        if (useCustomKeyPairRadioButton.isSelected() && pubKeyFileTextField.getStatus() != TextFieldWithStatus.Status.OK) {
            Dialogs.showErrorDialog((Stage) this.getScene().getWindow(), "The provided public key file is not valid");
            return false;
        }

        //only continue to save if parent-save is also OK
        if (!super.applySettings())
            return false;

        PreferencesUtil.setString(PreferencesUtil.Preference.PREF_COMMAND_UNIX_TERMINAL, terminalCommandTextArea.getText());

        PreferencesUtil.setBoolean(PreferencesUtil.Preference.PREF_SSHAGENT_USE, sshagentCheckBox.isSelected());

//        if (useCustomKeyPairRadioButton.isSelected()) {
//            PreferencesUtil.setPubKeyLocation(pubKeyFileTextField.getText());
//            try {
//                PreferencesUtil.setPublicKey(fileToString(new File(pubKeyFileTextField.getText())));
//            } catch (IOException e) {
//                LOG.error("Could not open public key to save it!", e);
//                return false;
//            }
//        } else {
//            PreferencesUtil.setPubKeyLocation(null);
//            PreferencesUtil.setKeyLocation(userLoginModelManager.getKeyCertUserLoginModel().getKeyCertFile().getAbsolutePath());
//            PreferencesUtil.setPublicKey(KeyUtil.rsaPublicKeyToOpenSshAuthorizedKeysFormat(userLoginModelManager.getKeyCertUserLoginModel().getPublicKey()));
//        }

        return true;


    }
}
