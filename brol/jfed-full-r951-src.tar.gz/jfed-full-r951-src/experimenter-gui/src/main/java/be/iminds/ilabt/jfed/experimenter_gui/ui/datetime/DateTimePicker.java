package be.iminds.ilabt.jfed.experimenter_gui.ui.datetime;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.TextField;
import javafx.util.StringConverter;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * User: twalcari
 * Date: 12/18/13
 * Time: 2:03 PM
 */
public class DateTimePicker extends TextField {

    private static final Logger LOG = LoggerFactory.getLogger(DateTimePicker.class);
    private static final DateTimeFormatter DEFAULT_DATETIMEFORMATTER = DateTimeFormat.forPattern("YYYY-MM-dd HH:mm");
    private static final String VALID_STYLE = "datetimepicker-valid";
    private static final String INVALID_STYLE = "datetimepicker-invalid";
    private final DateTimeFormatter dateTimeFormatter;
    private ObjectProperty<DateTime> dateTime = new SimpleObjectProperty<>();


    public DateTimePicker(DateTime dateTime, DateTimeFormatter dateTimeFormatter) {
        this.dateTime.set(dateTime);
        if (dateTimeFormatter != null)
            this.dateTimeFormatter = dateTimeFormatter;
        else
            this.dateTimeFormatter = DEFAULT_DATETIMEFORMATTER;


        //add layout
        this.getStylesheets().add(DateTimePicker.class.getResource("datetime.css").toExternalForm());

        textProperty().bindBidirectional(this.dateTime, new StringConverter<DateTime>() {
            @Override
            public String toString(DateTime date) {
                return DateTimePicker.this.dateTimeFormatter.print(date);
            }

            @Override
            public DateTime fromString(String s) {
                return DateTimePicker.this.dateTimeFormatter.parseDateTime(s);
            }
        });

        this.dateTime.addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
                if (DateTimePicker.this.dateTime.get() == null) {
                    getStyleClass().remove(VALID_STYLE);
                    getStyleClass().add(INVALID_STYLE);
                } else {
                    getStyleClass().remove(INVALID_STYLE);
                    getStyleClass().add(VALID_STYLE);
                }
            }
        });

    }

    public DateTimePicker() {
        this(new DateTime(), null);
    }


    public DateTimePicker(DateTime dateTime) {
        this(dateTime, null);
    }

    public DateTime getDateTime() {
        return dateTime.get();
    }

    public void setDateTime(DateTime dateTime) {
        this.dateTime.set(dateTime);
    }

    public ObjectProperty<DateTime> dateTimeProperty() {
        return dateTime;
    }
}
