package be.iminds.ilabt.jfed.experimenter_gui.call_gui;

import be.iminds.ilabt.jfed.experimenter_gui.model.ExperimenterModel;
import be.iminds.ilabt.jfed.highlevel.controller.JavaFXTaskThread;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.ui.javafx.log_gui.LogHistoryPanel;
import be.iminds.ilabt.jfed.ui.javafx.util.TimeUtils;
import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageBuilder;
import org.apache.logging.log4j.LogManager;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * TasksPanel
 */
public class TasksPanel extends BorderPane {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();
    private static Stage callsStage = null;

    private ExperimenterModel experimenterModel;

    @FXML
    private LogHistoryPanel logPanel;
    @FXML
    private TaskList allTaskList;
    @FXML
    private TaskList dependingOnTaskList;
    @FXML
    private TaskList dependersTaskList;
    @FXML
    private TextField taskNameField;
    @FXML
    private Parent taskExceptionBox;
    @FXML
    private TextArea taskExceptionArea;
    @FXML
    private TextField taskStateField;
    @FXML
    private TextField startTimeField;
    @FXML
    private TextField stopTimeField;
    @FXML
    private Label durationLabel;
    private ObjectProperty<JavaFXTaskThread.SingleTask> selectedSingleTask =
            new SimpleObjectProperty<JavaFXTaskThread.SingleTask>(null);
    private ChangeListener<Throwable> updateListener = null;

    public TasksPanel() {
        URL location = getClass().getResource("Calls.fxml");
        assert location != null;
        FXMLLoader fxmlLoader = new FXMLLoader(location);
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();

            if (experimenterModel != null)
                doAllInit();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        taskExceptionBox.managedProperty().bind(taskExceptionBox.visibleProperty());
    }

    public static synchronized void showTasks(ExperimenterModel experimenterModel) {
        try {
            if (callsStage == null) {
                TasksPanel callsPanel = new TasksPanel();
                callsPanel.setExperimenterModel(experimenterModel);

                Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();

                callsStage = StageBuilder.create()
                        .x(primaryScreenBounds.getMinX())
                        .y(primaryScreenBounds.getMinY())
                        .width(primaryScreenBounds.getWidth())
                        .height(primaryScreenBounds.getHeight())
                        .title("jFed Calls Overview")
                        .scene(new Scene(callsPanel))
                        .build();
            }
            assert callsStage != null;
            callsStage.show();
        } catch (Exception e) {
            throw new RuntimeException("Something went wrong showing the Calls", e);
        }
    }

    public ExperimenterModel getExperimenterModel() {
        return experimenterModel;
    }

    public void setExperimenterModel(ExperimenterModel experimenterModel) {
        assert this.experimenterModel == null;
        this.experimenterModel = experimenterModel;

        if (logPanel != null)
            doAllInit();
    }

    /**
     * init after easymodel set, and fxml loaded.
     */
    private void doAllInit() {
        assert logPanel != null;
        assert experimenterModel != null;

        ObservableList<JavaFXTaskThread.SingleTask> allTasks = JavaFXTaskThread.getInstance().getAllTasks();
        allTaskList.setItems(allTasks);

        final ChangeListener<Date> showTimeListener = new ChangeListener<Date>() {
            @Override
            public void changed(ObservableValue<? extends Date> observableValue, Date date, Date date1) {
                showTime();
            }
        };

        allTaskList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<JavaFXTaskThread.SingleTask>() {
            @Override
            public void changed(ObservableValue<? extends JavaFXTaskThread.SingleTask> observableValue,
                                JavaFXTaskThread.SingleTask oldSingleTask,
                                final JavaFXTaskThread.SingleTask newSingleTask) {
                if (oldSingleTask != null) {
                    taskStateField.textProperty().unbind();
                    oldSingleTask.runStartDateProperty().removeListener(showTimeListener);
                    oldSingleTask.runStopDateProperty().removeListener(showTimeListener);
                }

                selectedSingleTask.set(newSingleTask);

                if (updateListener != null && oldSingleTask != null) {
                    oldSingleTask.getException().removeListener(updateListener);
                    updateListener = null;
                }

                if (newSingleTask != null) {
                    taskNameField.textProperty().set(newSingleTask.getName());
                    taskStateField.textProperty().bind(Bindings.convert(newSingleTask.stateProperty()));
                    dependingOnTaskList.setItems(newSingleTask.getObservableDependsOn());
                    dependersTaskList.setItems(newSingleTask.getObservableDependingOnThis());
                    logPanel.setApiCallHistory(newSingleTask.getApiCallHistory());

                    updateListener = new ChangeListener<Throwable>() {
                        @Override
                        public void changed(ObservableValue<? extends Throwable> observableValue, Throwable oldThrowable, Throwable newThrowable) {
                            updateException(newSingleTask);
                        }
                    };
                    newSingleTask.getException().addListener(updateListener);
                    updateException(newSingleTask);

                    newSingleTask.runStartDateProperty().addListener(showTimeListener);
                    newSingleTask.runStopDateProperty().addListener(showTimeListener);
                    showTime();
                } else {
                    taskExceptionBox.setVisible(false);
                    dependingOnTaskList.setItems(null);
                    dependersTaskList.setItems(null);
                    logPanel.clearApiCallHistory();
                }
            }
        });

        if (!allTasks.isEmpty())
            allTaskList.getSelectionModel().selectFirst();
    }

    public void updateException(JavaFXTaskThread.SingleTask singleTask) {
        if (singleTask.getException().get() == null) {
            taskExceptionBox.setVisible(false);
            taskExceptionArea.setText("");
        } else {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            singleTask.getException().get().printStackTrace(pw);
            pw.close();
            final String stacktrace = sw.getBuffer().toString();

            taskExceptionBox.setVisible(true);
            taskExceptionArea.setText(stacktrace);
        }
    }

    public void printStackTrace() {
        System.err.println("Stacktrace:\n" + taskExceptionArea.getText());
        logger.info("User requested print of stacktrace:\n" + taskExceptionArea.getText());
    }

    public void showTime() {
        JavaFXTaskThread.SingleTask task = selectedSingleTask.get();
        if (task != null) {
            Date start = task.runStartDateProperty().get();

            if (start != null) {
                startTimeField.setText(start + "");
            }

            Date stop = task.runStopDateProperty().get();
            if (stop != null) {
                assert (start != null);
                stopTimeField.setText(stop + "");

                long durationMillis = stop.getTime() - start.getTime();
                durationLabel.setText(TimeUtils.formatMillis(durationMillis, TimeUnit.DAYS, TimeUnit.MILLISECONDS));
            }
        }
    }
}
