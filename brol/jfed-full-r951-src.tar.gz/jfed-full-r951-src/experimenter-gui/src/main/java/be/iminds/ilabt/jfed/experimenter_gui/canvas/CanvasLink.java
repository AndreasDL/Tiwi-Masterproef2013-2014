package be.iminds.ilabt.jfed.experimenter_gui.canvas;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.shape.Line;

/**
 * User: twalcari
 * Date: 11/8/13
 * Time: 12:19 PM
 */
public class CanvasLink extends Line implements ChangeListener<Number> {

    private static final String CANVAS_LINK_STYLECLASS = "canvas-link";
    private static final String CANVAS_LINK_SELECTED_STYLECLASS = "canvas-link";
    private final ChangeListener<Bounds> boundsChangeListener = new ChangeListener<Bounds>() {
        @Override
        public void changed(ObservableValue<? extends Bounds> observableValue, Bounds bounds, Bounds bounds2) {
            CanvasLink.this.updateLink();
        }
    };

    private final BooleanProperty selected = new SimpleBooleanProperty();
    private Node nodeA;
    private Node nodeB;

    public CanvasLink() {
        /*
            Styling
         */

        //add listener to selected-property for styling
        selected.addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean newValue, Boolean oldValue) {
                if (newValue) {
                    getStyleClass().remove(CANVAS_LINK_STYLECLASS);
                    getStyleClass().add(CANVAS_LINK_SELECTED_STYLECLASS);

                } else {
                    getStyleClass().remove(CANVAS_LINK_SELECTED_STYLECLASS);
                    getStyleClass().add(CANVAS_LINK_STYLECLASS);

                }
            }
        });

        getStyleClass().add(CANVAS_LINK_STYLECLASS);

        /*
            Event Listeners
         */
       // setOnMouseClicked(this);
    }

    public CanvasLink(Node nodeA, Node nodeB) {
        this();
        setNodeA(nodeA);
        setNodeB(nodeB);
    }

    public static double getCenterX(Node node) {
        return node.getLayoutX() + node.getLayoutBounds().getMinX() + node.getLayoutBounds().getWidth() / 2.0;

    }

    public static double getCenterY(Node node) {
        return node.getLayoutY() + node.getLayoutBounds().getMinY() + node.getLayoutBounds().getHeight() / 2.0;

    }

    public static void setCenterX(double x, Node node) {
        node.setLayoutX(x - node.getLayoutBounds().getMinX() - node.getLayoutBounds().getWidth() / 2.0);


    }

    public static void setCenterY(double y, Node node) {
        node.setLayoutY(y - node.getLayoutBounds().getMinY() - node.getLayoutBounds().getHeight() / 2.0);

    }

    private void removeItemListeners(Node item) {
        item.layoutXProperty().removeListener(this);
        item.layoutYProperty().removeListener(this);
        item.boundsInLocalProperty().removeListener(boundsChangeListener);
    }

    private void addItemListeners(Node item) {
        item.layoutXProperty().addListener(this);
        item.layoutYProperty().addListener(this);
        item.boundsInLocalProperty().addListener(boundsChangeListener);
    }

    public Node getNodeA() {
        return nodeA;
    }

    public void setNodeA(Node nodeA) {

        //remove listeners to old item
        if (this.nodeA != null)
            removeItemListeners(this.nodeA);

        this.nodeA = nodeA;

        if (nodeA != null)
            addItemListeners(nodeA);

    }

    public Node getNodeB() {
        return nodeB;
    }

    public void setNodeB(Node nodeB) {
        if (this.nodeB != null)
            removeItemListeners(this.nodeB);

        this.nodeB = nodeB;

        if (nodeB != null)
            addItemListeners(nodeB);
    }

    private void updateLink() {
        if (nodeA == null || nodeB == null) {
            setStartX(-1);
            setStartY(-1);
            setEndX(-1);
            setEndY(-1);
        } else {
            setStartX(getCenterX(nodeA));
            setStartY(getCenterY(nodeA));
            setEndX(getCenterX(nodeB));
            setEndY(getCenterY(nodeB));
        }
    }

    public double getCenterX() {
        return (getStartX() + getEndX()) / 2.0;
    }

    public double getCenterY() {
        return (getStartY() + getEndY()) / 2.0;
    }

    @Override
    public void changed(ObservableValue<? extends Number> observableValue, Number oldValue, Number newValue) {
        updateLink();
    }

    public boolean isSelected() {
        return selected.get();
    }

    public void setSelected(boolean selected) {
        this.selected.set(selected);
    }

    public BooleanProperty selectedProperty() {
        return selected;
    }

//    @Override
//    public void handle(MouseEvent event) {
//        if (event.isPrimaryButtonDown() && !isSelected()) {
//            setSelected(true);
//        }
//    }
}
