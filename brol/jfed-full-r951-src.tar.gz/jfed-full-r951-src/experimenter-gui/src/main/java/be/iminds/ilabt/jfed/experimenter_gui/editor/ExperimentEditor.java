package be.iminds.ilabt.jfed.experimenter_gui.editor;

import be.iminds.ilabt.jfed.experimenter_gui.ExperimenterConfiguration;
import be.iminds.ilabt.jfed.experimenter_gui.ExperimenterGUI;
import be.iminds.ilabt.jfed.experimenter_gui.canvas.EditableExperimentCanvas;
import be.iminds.ilabt.jfed.experimenter_gui.editor.bo.NodeDescription;
import be.iminds.ilabt.jfed.experimenter_gui.editor.impl.NodeDescriptionToolboxItem;
import be.iminds.ilabt.jfed.experimenter_gui.editor.raw.RawRspecEditor;
import be.iminds.ilabt.jfed.highlevel.model.rspec_source.RequestRspecSource;
import be.iminds.ilabt.jfed.rspec.model.InvalidRspecException;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.StringRspec;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.TilePane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooserBuilder;
import javafx.stage.Stage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

//import be.iminds.ilabt.jfed.experimenter_gui.editor.impl.RspecToolboxItem;

//import be.iminds.ilabt.jfed.experimenter_gui.editor.impl.RspecToolboxItem;

/**
 * User: twalcari
 * Date: 11/5/13
 * Time: 6:24 PM
 */
public class ExperimentEditor extends BorderPane {

    public static final String EXPERIMENT_EDITOR_FXML = "ExperimentEditor.fxml";
    public static final String RSPEC_EXTENSION = ".rspec";
    private static final Logger LOG = LogManager.getLogger();
    private final EventHandler<MouseEvent> toolboxOnDragDetectedHandler = new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent mouseEvent) {
            //set selected toolboxitem as draggedItem
            ToolboxItem originalItem = (ToolboxItem) mouseEvent.getSource();
            // assert (originalItem instanceof NodeDescriptionToolboxItem);
            draggedItem = originalItem;

            //start dragging animation
            //setCursor(Cursor.CROSSHAIR);

            setStatus("Drop the item somewhere in the canvas.");

            //make JavaFX fire drag-events
            originalItem.startFullDrag();

            mouseEvent.consume();

        }
    };
    //TODO find a way to get this handler to work
    private final EventHandler<MouseDragEvent> onMouseDragReleasedHandlerOutsideCanvas =
            new EventHandler<MouseDragEvent>() {
                @Override
                public void handle(MouseDragEvent mouseDragEvent) {
                    if (draggedItem != null) {
                        draggedItem = null;
                        setStatus("Item can only be dropped on the canvas");
                        setCursor(null);

                        mouseDragEvent.consume();
                    }
                }
            };
    private final ExperimenterGUI experimenterGui;
    private final StringProperty statusProperty = new SimpleStringProperty();
    private ToolboxItem draggedItem = null;
    private EditableExperimentCanvas canvas;
    private RawRspecEditor rawRspecEditor;
    @FXML
    private TilePane tpComputingElements;
    private File file;
    private StringProperty name = new SimpleStringProperty();

    public RawRspecEditor getRawRspecEditor() {
        return rawRspecEditor;
    }

    /**
     * This starts the experiment editor in graphical mode
     *
     * @param experimenterGui
     * @param rspecSource
     * @param name
     * @param file
     */
    public ExperimentEditor(ExperimenterGUI experimenterGui, RequestRspecSource rspecSource, String name, File file) {
        super();

        this.experimenterGui = experimenterGui;
        this.file = file;
        this.name.set(name);

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(EXPERIMENT_EDITOR_FXML));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }


        //initialize GUI
        if (!rspecSource.isXmlBased()) {
            showEditableExperimentCanvas(rspecSource.getModelRspec());
        } else {
            showRawRspecEditor(rspecSource.getStringRspec(), true);
        }

    }

    public boolean isCanvasVisible() {
        return this.canvas != null;
    }

    private void showEditableExperimentCanvas(ModelRspec modelRspec) {
        this.canvas = new EditableExperimentCanvas(this, modelRspec);
        setCenter(this.canvas);

        this.rawRspecEditor = null;
    }

    private void showRawRspecEditor(StringRspec stringRspec, boolean dirty) {
        this.rawRspecEditor = new RawRspecEditor(stringRspec);

        setCenter(this.rawRspecEditor);
        this.canvas = null;
    }

    public boolean switchToRawRspecEditor() {
        if (canvas == null)
            return true;

        RequestRspecSource rrs = new RequestRspecSource(canvas.getModelRspec());

        showRawRspecEditor(rrs.getStringRspec(), false);
        return true;

    }

    public boolean switchToEditableExperimentCanvas() {
        if (rawRspecEditor == null)
            return true;
        RequestRspecSource newRspecSource = null;
        try {
            StringRspec stringRspec = rawRspecEditor.getResultRspec();

            newRspecSource = new RequestRspecSource(stringRspec);
            if (newRspecSource == null) {
                throw new InvalidRspecException("Got null from RawRspecEditor");
            }
        } catch (InvalidRspecException e) {
            Dialogs.showErrorDialog((Stage) getScene().getWindow(),
                    "The Rspec that you provided is invalid. Please verify your input.", "Unable to process Rspec",
                    "Invalid Rspec", e);
            return false;
        }

        assert (newRspecSource != null);

        showEditableExperimentCanvas(newRspecSource.getModelRspec());
        return true;
    }

    public void initialize() {
        //initialize event handlers
        setOnMouseDragReleased(onMouseDragReleasedHandlerOutsideCanvas);

        //load toolbox content
        loadToolboxContent();
    }

    /**
     * For the moment, this function will initialize some hard-coded Rspec-nodes.
     * This should be loaded dynamically from the Rspec advertisments later on..
     */
    private void loadToolboxContent() {
        ExperimenterConfiguration conf = ExperimenterConfiguration.getInstance();

        for (NodeDescription nd : conf.getNodeDescriptions()) {
            NodeDescriptionToolboxItem ndti = new NodeDescriptionToolboxItem(nd);
            registerToolboxDragHandlers(ndti);
            tpComputingElements.getChildren().add(ndti);
        }
    }

    private void registerToolboxDragHandlers(final ToolboxItem toolboxItem) {
        toolboxItem.setOnDragDetected(toolboxOnDragDetectedHandler);
    }

    public boolean save() {


        if (file == null) {
            FileChooser fc = FileChooserBuilder.create()
                    .title("Save experiment")
                    .extensionFilters(ExperimenterGUI.RSPEC_EXTENSION_FILTER)
                    .initialFileName(name.get() + RSPEC_EXTENSION)
                    .build();
            file = fc.showSaveDialog(this.getScene().getWindow());
        }

        if (file != null) {
            //change the name of the experiment definition
            String newName = file.getName();
            newName = newName.replace(RSPEC_EXTENSION, "");

            this.name.set(newName);

            try (FileWriter writer = new FileWriter(file)) {
                writer.write(getRequestRspecSource().getRspecXmlString());
                writer.flush();
                writer.close();
                return true;
            } catch (IOException ex) {
                return false;
            }
        } else
            return false;
    }

    public void setStatus(String status) {
        statusProperty.set(status);
    }

    public void setSecondaryStatus(String status) {
        experimenterGui.setSecondaryStatus(status);
    }

    public EditableExperimentCanvas getCanvas() {
        return canvas;
    }

    public RequestRspecSource getRequestRspecSource() {
        if (canvas != null) {
            return new RequestRspecSource(canvas.getModelRspec());
        } else {
            assert (rawRspecEditor != null);
            return new RequestRspecSource(rawRspecEditor.getResultRspec());
        }
    }

    public File getFile() {
        return file;
    }


    public StringProperty statusProperty() {
        return statusProperty;
    }

    public String getName() {
        return name.get();
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public StringProperty nameProperty() {
        return name;
    }

    public ToolboxItem getDraggedItem() {
        return draggedItem;
    }

    public void clearDraggedItem() {
        draggedItem = null;
    }
}
