package be.iminds.ilabt.jfed.experimenter_gui.slices.import_wizard;

import be.iminds.ilabt.jfed.experimenter_gui.ui.wizard.WizardPage;
import javafx.collections.FXCollections;
import javafx.scene.Parent;
import javafx.scene.control.ListView;

/**
 * User: twalcari
 * Date: 12/4/13
 * Time: 5:02 PM
 */
public class SelectSliceWizardPage extends WizardPage {
    @Override
    public String getTitle() {
        return "Select an existing slice";
    }

    @Override
    public Parent getContent() {
        ListView<String> slices = new ListView<>(FXCollections.observableArrayList("slice1", "slice2", "slice3"));
        return slices;
    }
}
