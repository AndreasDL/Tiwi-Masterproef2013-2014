package be.iminds.ilabt.jfed.experimenter_gui.connectivity_tester;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * User: twalcari
 * Date: 1/6/14
 * Time: 10:58 AM
 */
public class ConnectivityTestApplication extends Application {


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {

        ConnectivityTester tester = new ConnectivityTester();
        tester.startTests();

        stage.setTitle("jFed Connectivity Tester");
        stage.setScene(new Scene(tester));
        stage.setResizable(false);
        stage.show();
    }
}
