package be.iminds.ilabt.jfed.experimenter_gui.editor;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.net.URL;

/**
 * User: twalcari
 * Date: 10/18/13
 * Time: 5:16 PM
 */
public class ToolboxItem extends Label {

    @FXML
    protected ImageView imageView;

    public ToolboxItem(String text, Image image) {

        URL location = ToolboxItem.class.getResource("ToolboxItem.fxml");
        assert (location != null);
        FXMLLoader fxmlLoader = new FXMLLoader(location, null);
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        this.setText(text);
        imageView.setImage(image);
    }


    public ToolboxItem(ToolboxItem item) {
        this(item.getText(), item.getImageView().getImage());
    }

    public ImageView getImageView() {
        return imageView;
    }

    @Override
    public String toString() {
        return "ToolboxItem{" +
                "imageView=" + imageView +
                '}';
    }
}
