package be.iminds.ilabt.jfed.experimenter_gui.editor.bo;

/**
 * User: twalcari
 * Date: 1/10/14
 * Time: 3:48 PM
 */
public class RspecNodeDescription {

    private final String componentManagerUrn;
    private final String componentIdUrn;
    private final boolean exclusive;
    private final String sliverType;
    private final String osImage;

    public RspecNodeDescription(String componentManagerUrn, String componentIdUrn, boolean exclusive,
                                String sliverType, String osImage) {
        this.componentManagerUrn = componentManagerUrn;
        this.componentIdUrn = componentIdUrn;
        this.exclusive = exclusive;
        this.sliverType = sliverType;
        this.osImage = osImage;
    }

    public RspecNodeDescription(String componentManagerUrn, String componentIdUrn, boolean exclusive,
                                String sliverType) {
        this(componentManagerUrn, componentIdUrn, exclusive, sliverType, null);
    }

    public String getComponentManagerUrn() {
        return componentManagerUrn;
    }

    public String getComponentIdUrn() {
        return componentIdUrn;
    }

    public boolean isExclusive() {
        return exclusive;
    }

    public String getSliverType() {
        return sliverType;
    }

    public String getOsImage() {
        return osImage;
    }
}
