package be.iminds.ilabt.jfed.experimenter_gui.preferences;

import be.iminds.ilabt.jfed.util.OSDetector;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageBuilder;

/**
 * User: twalcari
 * Date: 12/6/13
 * Time: 2:44 PM
 */
public class PreferencesDialogFactory {
    public static void showPreferencesDialog() {
        PreferencesDialog dialog = null;

        switch (OSDetector.findOS()) {
            case WIN:
                dialog = new WindowsPreferencesDialog();
                break;
            case UNIX:
            case MAC:
                dialog = new LinuxPreferencesDialog();
                break;
        }

        Stage preferencesStage = StageBuilder.create().title("jFed Preferences").scene(new Scene(dialog)).build();
        preferencesStage.showAndWait();
    }
}
