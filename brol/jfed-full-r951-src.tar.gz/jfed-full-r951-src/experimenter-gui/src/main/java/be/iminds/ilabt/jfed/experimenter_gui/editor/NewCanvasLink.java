package be.iminds.ilabt.jfed.experimenter_gui.editor;

import be.iminds.ilabt.jfed.experimenter_gui.canvas.CanvasLink;
import be.iminds.ilabt.jfed.experimenter_gui.canvas.ExperimentCanvas;
import be.iminds.ilabt.jfed.experimenter_gui.canvas.impl.RspecCanvasLink;
import be.iminds.ilabt.jfed.experimenter_gui.canvas.impl.RspecCanvasNode;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.CacheHint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;

/**
 * This class visualises a new canvas link in the making.
 * It is visualised by a line that starts from the supposed origin of  the link,
 * and ends with a circle when the target is unknown
 * <p/>
 * User: twalcari
 * Date: 11/8/13
 * Time: 5:47 PM
 */
public class NewCanvasLink {

    private final ExperimentCanvas experimentCanvas;
    private final Line line;
    private final Circle circle;
    private final BooleanProperty visible = new SimpleBooleanProperty(false);
    private RspecCanvasNode originNode;
    private RspecCanvasLink originLink;
    private RspecCanvasNode targetNode;
    private RspecCanvasLink targetLink;

    public NewCanvasLink(ExperimentCanvas experimentCanvas) {

        this.experimentCanvas = experimentCanvas;

        line = new Line();
        line.getStyleClass().add("new-canvas-link-line");
        line.setCache(true);
        line.setCacheHint(CacheHint.SPEED);
        line.visibleProperty().bind(visible);

        experimentCanvas.getCanvas().getChildren().add(0, line);

        circle = new Circle();
        circle.setRadius(3.5);
        circle.getStyleClass().add("new-canvas-link-end");
        circle.setCache(true);
        circle.setCacheHint(CacheHint.SPEED);
        circle.visibleProperty().bind(visible);

        experimentCanvas.getCanvas().getChildren().add(0, circle);


        //hidden by default
        setVisible(false);

    }

    public boolean isVisible() {
        return visible.get();
    }

    public void setVisible(boolean visible) {
        this.visible.set(visible);
    }

    public BooleanProperty visibleProperty() {
        return visible;
    }

    public RspecCanvasNode getOriginNode() {
        return originNode;
    }

    public void setOriginNode(RspecCanvasNode originNode) {
        this.originNode = originNode;
        if (originNode != null) {
            this.originLink = null;

            line.setStartX(CanvasLink.getCenterX(originNode));
            line.setStartY(CanvasLink.getCenterY(originNode));
        }
    }

    public RspecCanvasLink getOriginLink() {
        return originLink;
    }

    public void setOriginLink(RspecCanvasLink originLink) {
        this.originLink = originLink;
        if (originLink != null) {
            this.originNode = null;

            line.setStartX(originLink.getCenterX());
            line.setStartY(originLink.getCenterY());
        }
    }

    public void clear() {
        this.originLink = null;
        this.originNode = null;
        this.targetLink = null;
        this.targetNode = null;
    }

    public void setNewEnd(double x, double y) {
        line.setEndX(x);
        line.setEndY(y);

        circle.setCenterX(x);
        circle.setCenterY(y);
    }

    public RspecCanvasNode getTargetNode() {
        return targetNode;
    }

    public void setTargetNode(RspecCanvasNode node) {
        assert (originNode != null || originLink != null);

        this.targetNode = node;
        this.targetLink = null;

        setNewEnd(CanvasLink.getCenterX(node), CanvasLink.getCenterY(node));

    }

    public RspecCanvasLink getTargetLink() {
        return targetLink;
    }

    public void setTargetLink(RspecCanvasLink link) {
        assert (originNode != null || originLink != null);

        this.targetNode = null;
        this.targetLink = link;

        setNewEnd(link.getCenterX(), link.getCenterY());
    }

    /**
     * @return true if an origin and target are specified.
     */
    public boolean isLinkComplete() {
        return (originNode != null || originLink != null)
                && (targetNode != null || targetLink != null);
    }

    public boolean isLegalLink() {
        return isLinkComplete()
                && originNode != targetNode; // no self links + no links between two RspecLinks
    }

    public boolean isStitchedLink() {
        if (!isLinkComplete())
            return false;

        String originComponentManagerId = null;
        if (originNode != null)
            originComponentManagerId = originNode.getRspecNode().getComponentManagerId();
        else {
            assert (originLink.getRspecLink().getInterfaces().size() > 0);
            originComponentManagerId =
                    originLink.getRspecLink().getInterfaces().get(0).getNode().getComponentManagerId();
        }

        assert (originComponentManagerId != null);

        String targetComponentManagerId = null;
        if (targetNode != null) {
            targetComponentManagerId = targetNode.getRspecNode().getComponentManagerId();
        } else {
            assert (targetLink.getRspecLink().getInterfaces().size() > 0);
            targetComponentManagerId =
                    targetLink.getRspecLink().getInterfaces().get(0).getNode().getComponentManagerId();
        }

        assert (targetComponentManagerId != null);
        return !originComponentManagerId.equals(targetComponentManagerId);

    }

    public boolean isOriginDefined() {
        return originNode != null || originLink != null;
    }
}
