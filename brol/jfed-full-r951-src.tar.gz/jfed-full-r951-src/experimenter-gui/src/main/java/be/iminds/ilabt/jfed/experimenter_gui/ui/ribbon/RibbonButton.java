package be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon;

import com.cathive.fonts.fontawesome.FontAwesomeIconView;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Control;
import javafx.scene.input.KeyCombination;

/**
 * User: twalcari
 * Date: 11/6/13
 * Time: 9:48 AM
 */
public class RibbonButton extends Button implements Runnable {

    static final double SMALL_ICON_SIZE = 16;
    static final double BIG_ICON_SIZE = 24;
    private static final String BIG_RIBBON_BUTTON_STYLE = "ribbon-button";
    private static final String SMALL_RIBBON_BUTTON_STYLE = "ribbon-button-small";
    private boolean small = false;
    private KeyCombination accelerator = null;

    public RibbonButton() {
        initialize();
    }

    public RibbonButton(String s) {
        super(s);
        initialize();
    }

    public RibbonButton(String s, Node node) {
        super(s, node);
        initialize();
    }

    /**
     * Helper method for accelerators
     */

    public void run() {
        this.fire();
    }

    private void initialize() {
        getStylesheets().add(getClass().getResource(RibbonBar.STYLESHEET_URL).toExternalForm());
        getStyleClass().add(BIG_RIBBON_BUTTON_STYLE);

        graphicProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
                updateStyle();
            }
        });

        sceneProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
                updateAccelerator();
            }
        });
    }

    public boolean isSmall() {
        return small;
    }

    public void setSmall(boolean small) {
        this.small = small;
        updateStyle();
    }

    public KeyCombination getAccelerator() {
        return accelerator;
    }

    public void setAccelerator(KeyCombination accelerator) {
        removeAccelerator();
        this.accelerator = accelerator;
        updateAccelerator();
    }

    protected void removeAccelerator() {
        if (getScene() == null
                || this.accelerator == null
                || getScene().getAccelerators().get(this.accelerator) != RibbonButton.this)
            return;

        getScene().getAccelerators().remove(this.accelerator);

    }

    protected void updateAccelerator() {
        if (getScene() == null)
            return;

        if (accelerator != null) {
            if (getScene().getAccelerators().get(accelerator) != null)
                throw new RuntimeException("Accelerator " + accelerator + " is already defined in scene.");
            getScene().getAccelerators().put(accelerator, RibbonButton.this);
        }


    }

    protected void updateStyle() {
        if (small) {
            getStyleClass().remove(BIG_RIBBON_BUTTON_STYLE);
            getStyleClass().add(SMALL_RIBBON_BUTTON_STYLE);
        } else {
            getStyleClass().remove(SMALL_RIBBON_BUTTON_STYLE);
            getStyleClass().add(BIG_RIBBON_BUTTON_STYLE);
        }


        if (getGraphic() == null)
            return;

        if (getGraphic() instanceof FontAwesomeIconView) {
            FontAwesomeIconView faiv = (FontAwesomeIconView) getGraphic();
            faiv.setSize(small ? SMALL_ICON_SIZE : BIG_ICON_SIZE);
        } else if (getGraphic() instanceof Control) {
            if (small) {
                ((Control) getGraphic()).setPrefHeight(SMALL_ICON_SIZE);
                ((Control) getGraphic()).setPrefWidth(SMALL_ICON_SIZE);
            } else {
                ((Control) getGraphic()).setPrefHeight(BIG_ICON_SIZE);
                ((Control) getGraphic()).setPrefWidth(BIG_ICON_SIZE);
            }
        }
    }

}
