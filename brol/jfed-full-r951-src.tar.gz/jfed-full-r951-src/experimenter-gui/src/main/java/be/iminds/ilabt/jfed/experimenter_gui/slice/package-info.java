/**
 * This package contains the visualisation of the proces of requesting, using and destroying a slice.
 *
 * @author twalcari
 */
package be.iminds.ilabt.jfed.experimenter_gui.slice;