package be.iminds.ilabt.jfed.experimenter_gui.canvas;

import be.iminds.ilabt.jfed.experimenter_gui.canvas.impl.RspecCanvasLink;
import be.iminds.ilabt.jfed.experimenter_gui.canvas.impl.RspecCanvasNode;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.RspecLink;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * User: twalcari
 * Date: 11/14/13
 * Time: 12:21 PM
 */
public class ExperimentCanvas extends ScrollPane {
    private static final Logger LOG = LogManager.getLogger();
    private static final double CANVAS_MARGIN = 100;
    private static final double MAX_CURSOR_NODE_DISTANCE = 40;
    private static final double MIN_ZOOM = 0.25, MAX_ZOOM = 5, ZOOM_FACTOR = 1.5;
    protected final ModelRspec model;
    private final ChangeListener<? super Bounds> canvasItemsLayoutBoundsListener = new ChangeListener<Bounds>() {
        @Override
        public void changed(ObservableValue<? extends Bounds> observableValue, Bounds oldValue, Bounds newValue) {
            checkForCanvasResize(newValue);
        }
    };
    private final Pane pCanvas;
    private final Map<RspecNode, RspecCanvasNode> nodes = new HashMap<>();
    private final Map<RspecLink, RspecCanvasLink> links = new HashMap<>();
    /**
     * These variables are used to perform dragging of the canvas
     */
    private Point2D dragOrigin;
    private Point2D scrollPaneStart;
    private SelectionProvider selectionProvider = new SelectionProvider();
    private double zoom = 1;

    public ExperimentCanvas(ModelRspec model) {
        this.model = model;

        this.getStyleClass().add("canvas-scrollpane");
        this.getStylesheets().add(ExperimentCanvas.class.getResource("canvas.css").toExternalForm());

        //create content pane
        this.pCanvas = new Pane();
        this.pCanvas.getStyleClass().add("canvas");
        setContent(pCanvas);

        //make panning in the contentPane possible
        setHmin(0);
        hmaxProperty().bind(pCanvas.widthProperty());

        setVmin(0);
        vmaxProperty().bind(pCanvas.heightProperty());

        //set GUI event handlers
        viewportBoundsProperty().addListener(new ChangeListener<Bounds>() {
            @Override
            public void changed(ObservableValue<? extends Bounds> observableValue, Bounds oldValue, Bounds newValue) {
                if (newValue.getWidth() > pCanvas.getPrefWidth()) {
                    pCanvas.setPrefWidth(newValue.getWidth());
                }

                if (newValue.getHeight() > pCanvas.getPrefHeight()) {
                    pCanvas.setPrefHeight(newValue.getHeight());
                }
            }
        });

        pCanvas.getChildren().addListener(new ListChangeListener<Node>() {
            @Override
            public void onChanged(Change<? extends Node> change) {
                while (change.next()) {
                    if (change.wasAdded()) {
                        for (Node node : change.getAddedSubList()) {
                            checkForCanvasResize(node.getLayoutBounds());
                            node.layoutBoundsProperty().addListener(canvasItemsLayoutBoundsListener);
                        }
                    }

                    if (change.wasRemoved()) {
                        for (Node node : change.getRemoved()) {
                            node.layoutBoundsProperty().removeListener(canvasItemsLayoutBoundsListener);
                        }
                    }
                }
            }
        });


        pCanvas.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                onCanvasMousePressed(mouseEvent);
            }
        });
        pCanvas.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                onCanvasMouseDragged(mouseEvent);
            }
        });
        pCanvas.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                onCanvasMouseReleased(mouseEvent);
            }
        });
        pCanvas.setOnMouseMoved(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                onCanvasMouseMoved(mouseEvent);
            }
        });

        //load model into GUI
        load();

        //couple model and GUI
        model.getNodes().addListener(new ListChangeListener<RspecNode>() {
            @Override
            public void onChanged(Change<? extends RspecNode> change) {
                while (change.next()) {
                    if (change.wasAdded()) {
                        for (RspecNode node : change.getAddedSubList())
                            addNodeToCanvas(node);
                    }

                    if (change.wasRemoved()) {
                        for (RspecNode node : change.getRemoved()) {
                            removeNodeFromCanvas(node);
                        }
                    }
                }
            }
        });
        model.getLinks().addListener(new ListChangeListener<RspecLink>() {
            @Override
            public void onChanged(Change<? extends RspecLink> change) {
                while (change.next()) {
                    if (change.wasAdded()) {
                        for (RspecLink link : change.getAddedSubList())
                            addLinkToCanvas(link);
                    }

                    if (change.wasRemoved()) {
                        for (RspecLink link : change.getRemoved()) {
                            removeLinkFromCanvas(link);
                        }
                    }
                }
            }
        });
    }

    /**
     * Helper method that computes the distance between two points
     */
    private static double squareDistance(double xa, double ya, double xb, double yb) {
        return ((xa - xb) * (xa - xb)) + ((ya - yb) * (ya - yb));
    }

    /**
     * This method is called when a mouseclick is performed on a canvas node
     */
    protected void canvasItemOnMouseClicked(MouseEvent mouseEvent) {

        if (mouseEvent.getButton() == MouseButton.PRIMARY) {

            if (mouseEvent.getSource() instanceof CanvasNode) {
                getSelectionProvider().setSelectedCanvasNode((CanvasNode) mouseEvent.getSource());
            } else if (mouseEvent.getSource() instanceof CanvasLink) {
                getSelectionProvider().setSelectedCanvasLink((RspecCanvasLink) mouseEvent.getSource());
            } else {
                LOG.warn("unexpected item selected: " + mouseEvent.getSource());
            }

            mouseEvent.consume();
        }
    }

    /**
     * This method is called when a dragDetected-event is caught by a canvas node
     */
    protected void canvasNodeOnDragDetected(MouseEvent mouseEvent) {
        CanvasNode node = (CanvasNode) mouseEvent.getSource();
        getSelectionProvider().setSelectedCanvasNode(node);

        mouseEvent.consume();
    }

    /**
     * This method is called when a mouseDragged-event is caught by a canvas node
     */
    protected void canvasNodeOnMouseDragged(MouseEvent mouseEvent) {

    }

    /**
     * This method handles the end of a panning-operation
     */
    protected void onCanvasMouseReleased(MouseEvent mouseEvent) {
        dragOrigin = null;
        scrollPaneStart = null;
    }

    protected void onCanvasMouseMoved(MouseEvent mouseEvent) {
    }

    private void onCanvasMousePressed(MouseEvent mouseEvent) {
        dragOrigin = new Point2D(mouseEvent.getSceneX(), mouseEvent.getSceneY());
        scrollPaneStart = new Point2D(getHvalue(), getVvalue());
    }

    /**
     * Performs panning of the canvas
     */
    protected void onCanvasMouseDragged(MouseEvent mouseEvent) {
        //perform panning instead of connecting nodes
        assert (dragOrigin != null);
        double dx = dragOrigin.getX() - mouseEvent.getSceneX();
        double dy = dragOrigin.getY() - mouseEvent.getSceneY();

        setHvalue(scrollPaneStart.getX() + dx);
        setVvalue(scrollPaneStart.getY() + dy);
    }

    private void load() {
        assert (nodes.isEmpty());

        for (RspecNode node : model.getNodes()) {
            addNodeToCanvas(node);
        }

        for (RspecLink link : model.getLinks()) {
            addLinkToCanvas(link);
        }
    }

    private void checkForCanvasResize(Bounds bounds) {

        if (bounds.getMaxX() + CANVAS_MARGIN > pCanvas.getPrefWidth()) {
            pCanvas.setPrefWidth(bounds.getMaxX() + CANVAS_MARGIN);
        }

        if (bounds.getMaxY() + CANVAS_MARGIN > pCanvas.getPrefHeight()) {
            pCanvas.setPrefHeight(bounds.getMaxY() + CANVAS_MARGIN);
        }

    }

    public Pane getCanvas() {
        return pCanvas;
    }

    /**
     * returns a node if there is one within range.
     * Returns the closest if multiple, returns NULL if no node close enough.
     */
    public RspecCanvasNode findNearbyNode(double x, double y) {
        RspecCanvasNode node = null;
        double curDistSq = MAX_CURSOR_NODE_DISTANCE * MAX_CURSOR_NODE_DISTANCE;
        for (RspecCanvasNode nc : nodes.values()) {
            double nMinX = nc.getLayoutX() + nc.getBoundsInLocal().getMinX();
            double nMinY = nc.getLayoutY() + nc.getBoundsInLocal().getMinY();
            double nMaxX = nc.getLayoutX() + nc.getBoundsInLocal().getMaxX();
            double nMaxY = nc.getLayoutY() + nc.getBoundsInLocal().getMaxY();

            double nx = nMinX;
            if (x >= nMinX && x <= nMaxX) nx = x;
            else if (x > nMaxX) nx = nMaxX;

            double ny = nMinY;
            if (y >= nMinY && y <= nMaxY) ny = y;
            else if (y > nMaxY) ny = nMaxY;

            double sqD = squareDistance(x, y, nx, ny);
            if (sqD <= curDistSq) {
                curDistSq = sqD;
                node = nc;
            }
        }
        return node;
    }

    /**
     * returns a link if there is a link center within range.
     * Returns the closest if multiple, returns NULL if no link close enough.
     */
    public RspecCanvasLink findNearbyLink(double x, double y) {
        RspecCanvasLink res = null;
        double curDistSq = MAX_CURSOR_NODE_DISTANCE * MAX_CURSOR_NODE_DISTANCE;
        for (RspecCanvasLink lc : links.values()) {
            Button linkCenter = lc.getLinkCenter();
            if (linkCenter == null) continue; //this means that the link is not shown anymore
            double nMinX = linkCenter.getLayoutX() + linkCenter.getBoundsInLocal().getMinX();
            double nMinY = linkCenter.getLayoutY() + linkCenter.getBoundsInLocal().getMinY();
            double nMaxX = linkCenter.getLayoutX() + linkCenter.getBoundsInLocal().getMaxX();
            double nMaxY = linkCenter.getLayoutY() + linkCenter.getBoundsInLocal().getMaxY();

            double nx = nMinX;
            double ny = nMinY;
            if (x >= nMinX && x <= nMaxX) nx = x;
            if (y >= nMinY && y <= nMaxY) ny = y;
            if (x > nMaxX) nx = nMaxX;
            if (y > nMaxY) ny = nMaxY;

            double sqD = squareDistance(x, y, nx, ny);
            if (sqD <= (curDistSq)) {
                curDistSq = sqD;
                res = lc;
            }
        }
        return res;
    }

    /**
     * Should only be called by the addNodeToCanvasAndModel or load-method
     *
     * @param rspecNode
     */
    private void addNodeToCanvas(RspecNode rspecNode) {
        RspecCanvasNode newNode = new RspecCanvasNode(rspecNode, this);

        nodes.put(rspecNode, newNode);

        pCanvas.getChildren().add(newNode);

        //add event listeners
        newNode.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                canvasItemOnMouseClicked(mouseEvent);
            }
        });
        newNode.setOnDragDetected(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                canvasNodeOnDragDetected(mouseEvent);
            }
        });
        newNode.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                canvasNodeOnMouseDragged(mouseEvent);
            }
        });

        checkForCanvasResize(newNode.getLayoutBounds());

    }

    private void addLinkToCanvas(RspecLink rspecLink) {
        RspecCanvasLink newLink = new RspecCanvasLink(rspecLink, this);
        newLink.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                canvasItemOnMouseClicked(mouseEvent);
            }
        });

        links.put(rspecLink, newLink);

    }

    private void removeLinkFromCanvas(RspecLink rspecLink) {
        RspecCanvasLink rspecCanvasLink = links.get(rspecLink);
        rspecCanvasLink.remove();
        links.remove(rspecLink);
    }

    private void removeNodeFromCanvas(RspecNode rspecNode) {
        //remove from canvas
        RspecCanvasNode rspecCanvasNode = nodes.get(rspecNode);
        pCanvas.getChildren().remove(rspecCanvasNode);

        //remove event listeners
        //add event listeners
        rspecCanvasNode.setOnMouseClicked(null);
        rspecCanvasNode.setOnDragDetected(null);
        rspecCanvasNode.setOnMouseDragged(null);


        nodes.remove(rspecNode);
    }

    public SelectionProvider getSelectionProvider() {
        return selectionProvider;
    }

    public RspecCanvasNode getRspecCanvasNode(RspecNode node) {
        return nodes.get(node);
    }

    public RspecCanvasLink getRspecCanvasLink(RspecLink link) {
        return links.get(link);
    }

    public Collection<RspecCanvasLink> getRspecCanvasLinks() {
        return links.values();
    }

    public ModelRspec getModelRspec() {
        return model;
    }

    public double getZoom() {
        return zoom;
    }

    public void setZoom(double zoom) {
        if (zoom < MIN_ZOOM || zoom > MAX_ZOOM)
            throw new IllegalArgumentException("Zoom must be between " + MIN_ZOOM + " and " + MAX_ZOOM);


        double transform = zoom / this.zoom;
        //update the location of all nodes
        for (RspecCanvasNode node : nodes.values()) {
            node.setLayoutX(node.getLayoutX() * transform);
            node.setLayoutY(node.getLayoutY() * transform);
        }


        this.zoom = zoom;


    }

    public void zoomIn() {
        double newZoom = zoom * ZOOM_FACTOR;
        if (newZoom > MAX_ZOOM)
            newZoom = MAX_ZOOM;

        setZoom(newZoom);
    }

    public void zoomOut() {
        double newZoom = zoom / ZOOM_FACTOR;
        if (newZoom < MIN_ZOOM)
            newZoom = MIN_ZOOM;

        setZoom(newZoom);
    }
}
