package be.iminds.ilabt.jfed.experimenter_gui.preferences;

import be.iminds.ilabt.jfed.experimenter_gui.util.ui.LabelWithStatus;
import be.iminds.ilabt.jfed.experimenter_gui.util.ui.TextFieldWithStatus;
import be.iminds.ilabt.jfed.lowlevel.GeniUser;
import be.iminds.ilabt.jfed.lowlevel.ssh_key_info.SshKeyInfo;
import be.iminds.ilabt.jfed.ssh_terminal_tool.putty.PageantHelper;
import be.iminds.ilabt.jfed.ssh_terminal_tool.putty.PuTTYPrivateKeyFile;
import be.iminds.ilabt.jfed.ssh_terminal_tool.ssh_key_info.UserSshKeyInfo;
import be.iminds.ilabt.jfed.util.IOUtils;
import be.iminds.ilabt.jfed.util.PreferencesUtil;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import be.iminds.ilabt.jfed.util.KeyUtil;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.DirectoryChooserBuilder;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

/**
 * User: twalcari
 * Date: 12/6/13
 * Time: 2:25 PM
 */
public class WindowsPreferencesDialog extends PreferencesDialog {
    private static final Logger LOG = LoggerFactory.getLogger(WindowsPreferencesDialog.class);

    private static final FileChooser.ExtensionFilter PPK_FILE_EXTENSION =
            new FileChooser.ExtensionFilter("PuTTY Private Key (*.ppk)", "*.ppk");
    private static final String DEFAULT_PUTTY_DIR = "PuTTY";
    private static final String[] DEFAULT_PUTTY_LOCATIONS =
            new String[]{System.getenv("ProgramFiles") + File.separator + DEFAULT_PUTTY_DIR,
                    System.getenv("ProgramFiles(x86)") + File.separator + DEFAULT_PUTTY_DIR, "C:\\PuTTY"};
    private static final String WINDOWS_PREFERENCES_FXML = "WindowsPreferences.fxml";
    @FXML protected Label textKeyLabel;
    @FXML protected TextArea textKeyTextArea;

    @FXML private TextFieldWithStatus puttyDirTextField;
    @FXML private Button puttyDirBrowseButton;

    @FXML protected HBox puttyDirScanResult;
    @FXML protected LabelWithStatus puttyDirScanPuttyLabel;
    @FXML protected LabelWithStatus puttyDirScanPageantLabel;
    @FXML protected LabelWithStatus puttyDirScanPlinkLabel;

    @FXML protected CheckBox pageantCheckBox;

    public WindowsPreferencesDialog() {
        super();
    }

    public void initialize() {
        super.initialize();
//        puttyDirTextField.statusProperty().addListener(new ChangeListener<TextFieldWithStatus.Status>() {
//            @Override
//            public void changed(ObservableValue<? extends TextFieldWithStatus.Status> observableValue, TextFieldWithStatus.Status oldValue, TextFieldWithStatus.Status newValue) {
//                generateButton.setDisable(newValue != TextFieldWithStatus.Status.OK);
//            }
//        });

        textKeyLabel.disableProperty().bind(useCustomKeyPairRadioButton.selectedProperty().not());
        textKeyTextArea.disableProperty().bind(useCustomKeyPairRadioButton.selectedProperty().not());

        puttyDirTextField.focusedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean oldValue, Boolean newValue) {
                if (newValue) {
                    puttyDirTextField.setStatus(TextFieldWithStatus.Status.NONE);
                } else {
                    testPuttyDir();
                }
            }
        });

        //load settings

        if (PreferencesUtil.getFile(PreferencesUtil.Preference.PREF_PUTTY_DIRECTORY) != null) {
            puttyDirTextField.setText(PreferencesUtil.getFile(PreferencesUtil.Preference.PREF_PUTTY_DIRECTORY).getPath());
        } else {
            //try to detect the location of PuTTY
            String puttyDir = findPuTTYDirectory();

            if (puttyDir != null) {
                puttyDirTextField.setText(puttyDir);
            }
        }

        pageantCheckBox.setSelected(PreferencesUtil.getBoolean(PreferencesUtil.Preference.PREF_PUTTY_PAGEANT));

        //load settings
//        if (PreferencesUtil.getKeyLocation() != null) {
//            String key = getPublicKeyFromFile(new File(PreferencesUtil.getKeyLocation()));
//
//            if (key != null && !key.equals(PreferencesUtil.getPublicKey())) {
//                Dialogs.showErrorDialog(null,
//                        "Please save your preferences to complete the recovery process",
//                        "Recovered from inconsistent configuration");
//            }
//
//            textKeyTextArea.setText(key);
//        }

        //evaluate inputs
        testPuttyDir();

        //set focus
        Platform.runLater(new Runnable() {

            @Override
            public void run() {
                if (puttyDirTextField.getText().length() == 0)
                    puttyDirBrowseButton.requestFocus();
                else
//                if (fileTextField.getText().length() == 0)
//                    generateButton.requestFocus();
//                else
                    saveButton.requestFocus();
            }
        });

    }

    private void testPuttyDir() {
        if (puttyDirTextField.getText().length() == 0) {
            puttyDirTextField.setStatus(TextFieldWithStatus.Status.NONE);
            return;
        }

        puttyDirTextField.setStatus(validatePuTTYDirectory(puttyDirTextField.getText()) ?
                TextFieldWithStatus.Status.OK :
                TextFieldWithStatus.Status.ERROR);

        puttyDirScanResult.setVisible(true);
        puttyDirScanResult.setManaged(true);

        boolean puttyOk;
        boolean pageantOk;
        boolean plinkOk;

        File puttyDir = new File(puttyDirTextField.getText());
        if (!puttyDir.exists() || !puttyDir.isDirectory()) {
            puttyOk = false;
            pageantOk = false;
            plinkOk = false;
        } else {
            puttyOk = new File(puttyDir, "putty.exe").exists();
            pageantOk = new File(puttyDir, "pageant.exe").exists();
            plinkOk = new File(puttyDir, "plink.exe").exists();
        }

        if (puttyOk) {
            puttyDirScanPuttyLabel.setText("putty.exe is present: can open SSH terminals");
            puttyDirScanPuttyLabel.setStatus(LabelWithStatus.Status.OK);
        } else {
            puttyDirScanPuttyLabel.setText("putty.exe is missing: cannot open SSH terminals");
            puttyDirScanPuttyLabel.setStatus(LabelWithStatus.Status.ERROR);
        }
        if (pageantOk) {
            puttyDirScanPageantLabel.setText("pageant.exe is present");
            puttyDirScanPageantLabel.setStatus(LabelWithStatus.Status.OK);
        } else {
            puttyDirScanPageantLabel.setText("pageant.exe is missing");
            puttyDirScanPageantLabel.setStatus(LabelWithStatus.Status.ERROR);
        }
        if (plinkOk) {
            puttyDirScanPlinkLabel.setText("plink.exe is present: can use SSH proxy");
            puttyDirScanPlinkLabel.setStatus(LabelWithStatus.Status.OK);
        } else {
            puttyDirScanPlinkLabel.setText("plink.exe is missing: cannot use SSH proxy");
            puttyDirScanPlinkLabel.setStatus(LabelWithStatus.Status.ERROR);
        }

        pageantCheckBox.setDisable(!pageantOk);
        if (!pageantOk)
            pageantCheckBox.setSelected(false);
    }

    private boolean validatePuTTYDirectory(String dir) {
        return PreferencesUtil.isValidPuttyDir(new File(dir));
    }

    private String findPuTTYDirectory() {
        for (String location : DEFAULT_PUTTY_LOCATIONS) {
            if (validatePuTTYDirectory(location))
                return location;
        }
        return null;

    }

    @Override
    protected void testPrivateKey() {
        super.testPrivateKey();
        if (fileTextField.getStatus() == TextFieldWithStatus.Status.OK) {
            textKeyTextArea.setText(getPublicKeyFromFile(new File(fileTextField.getText())));
        } else {
            textKeyTextArea.setText("");
        }
    }

//    @FXML
//    private void onGenerateButtonAction(ActionEvent actionEvent) {
//
//        //check if puttygen is present
//        File puttygenFile = new File(puttyDirTextField.getText() + File.separator +
//                "puttygen.exe");
//        if (!puttygenFile.exists()) {
//            Dialogs.showErrorDialog((Stage) this.getScene().getWindow(),
//                    "PuTTYgen is required to generate a PuTTY Private Key, but could not be found in the PuTTY installation directory.\n" +
//                            "Please verify your PuTTY-installation",
//                    "PuTTYgen cannot be found.");
//            return;
//        }
//
//        //find the private key which was used to log in
//        File privateKey = getPrivateKeyFile();
//
//        final String privateKeyLocation = privateKey.getAbsolutePath();
//
//        Dialogs.showInformationDialog((Stage) generateButton.getScene().getWindow(),
//                "1) The PuTTY Key Generator will automatically be started with the correct key. Enter your passphrase when requested.\n" +
//                        "2) Click on OK when PuTTY says \"Succesfully imported foreign key\"\n" +
//                        "3) Click on the button \"Save private key\" and save the file.\n" +
//                        "4) Close the PuTTY Key Generator\n" +
//                        "5) Click on Browse... in the jFed preferences-dialog, and select your newly generated key.",
//                "Follow these steps to create and register your PuTTY Private key:",
//                "Generate a PuTTY Private key");
//
//
//        Runnable processOutputMonitor = new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    String[] command = new String[]{puttyDirTextField.getText() + File.separator +
//                                                            "puttygen.exe", privateKeyLocation};
//
//
//                    Process p = Runtime.getRuntime()
//                            .exec(command);
//                    BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
//                    String line;
//                    while ((line = input.readLine()) != null) {
//                        LOG.debug("LoginService putty output: " + line);
//                    }
//                    input.close();
//
//                } catch (IOException e) {
//                    Dialogs.showErrorDialog((Stage) generateButton.getScene().getWindow(), "An error occured while starting the PuTTY Key Generator", "Error", "Error", e);
//                    e.printStackTrace();
//                }
//            }
//        };
//        Thread t = new Thread(processOutputMonitor);
//        t.setName("Puttygen Thread");
//        t.setDaemon(true);
//        t.start();
//    }

    @Override
    protected boolean applySettings() {
        if (puttyDirTextField.getStatus() != TextFieldWithStatus.Status.OK) {
            Dialogs.showErrorDialog((Stage) this.getScene().getWindow(),
                    "Please provide a valid PuTTY installation directory before saving. This directory needs to contain: putty.exe puttygen.exe and plink.exe");
            return false;
        }

        PreferencesUtil.setFile(PreferencesUtil.Preference.PREF_PUTTY_DIRECTORY, new File(puttyDirTextField.getText()));

        PreferencesUtil.setBoolean(PreferencesUtil.Preference.PREF_PUTTY_PAGEANT, pageantCheckBox.isSelected());

        //only continue to save if parent-save is also OK
        if (!super.applySettings())
            return false;

        //Ok, finally, register keys with pageant
        if (PreferencesUtil.getBoolean(PreferencesUtil.Preference.PREF_PUTTY_PAGEANT)) {
            SshKeyInfo sshKeyInfo = PreferencesUtil.getOverriddenSshKeyInfo();
            if (sshKeyInfo == null &&  experimenterModel.getGeniUserProvider().isUserLoggedIn()) {
                GeniUser geniUser = experimenterModel.getGeniUserProvider().getLoggedInGeniUser();
                sshKeyInfo = new UserSshKeyInfo(geniUser);
            }
            PageantHelper.registerKey(sshKeyInfo);

            if (!PreferencesUtil.getString(PreferencesUtil.Preference.PREF_SSHPROXY_USE_FOR_SSH).equalsIgnoreCase("NEVER")) {
                SshKeyInfo proxySshKeyInfo = PreferencesUtil.getOverriddenProxySshKeyInfo();
                if (proxySshKeyInfo == null &&  experimenterModel.getGeniUserProvider().isUserLoggedIn()) {
                    GeniUser geniUser = experimenterModel.getGeniUserProvider().getLoggedInGeniUser();
                    proxySshKeyInfo = new UserSshKeyInfo(geniUser);
                }
                PageantHelper.registerKey(proxySshKeyInfo);
            }
        }

        return true;
    }

    @FXML
    private void onPuttyDirBrowseButtonAction(ActionEvent actionEvent) {

        DirectoryChooser dc =
                DirectoryChooserBuilder.create()
                        .title("Select the PuTTY Installation Directory")
                        .build();

        File selectedDir = dc.showDialog(puttyDirTextField.getScene().getWindow());

        if (selectedDir != null) {
            puttyDirTextField.setText(selectedDir.getAbsolutePath());
            testPuttyDir();
        }
    }

    @Override
    protected boolean testPrivateKeyFile(File file) throws IOException {
        if (file.exists() && file.isFile()) {
            //check if it is an putty private key
            return (PuTTYPrivateKeyFile.isPuttyPrivateKey(file));// || PuttyPrivateKey.isOpenSSHPubKey(file)){
        }
        return false;
    }

    protected String getPublicKeyFromFile(File file) {
        String key = null;

        //try to extract public key from this file
        try {
            if (PuTTYPrivateKeyFile.isPuttyPrivateKey(file)) {
                PuTTYPrivateKeyFile ppk = PuTTYPrivateKeyFile.read(file);
                key = ppk.getPublicKeyOpenSshString();
            } else if (KeyUtil.isOpenSshRsaKey(file)) {
                key = IOUtils.fileToString(file).replace("\n", "");
            }
        } catch (IOException ex) {
            Dialogs.showErrorDialog((Stage) fileTextField.getScene().getWindow(),
                    "An error occured while processing the key file", "Error", "Error", ex);
        }
        return key;
    }

    @Override
    protected String getFxmlFile() {
        return WINDOWS_PREFERENCES_FXML;
    }
}
