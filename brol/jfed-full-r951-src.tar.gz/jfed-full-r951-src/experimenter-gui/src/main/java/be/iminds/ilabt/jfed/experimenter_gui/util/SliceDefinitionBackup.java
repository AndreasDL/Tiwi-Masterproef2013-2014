package be.iminds.ilabt.jfed.experimenter_gui.util;

import be.iminds.ilabt.jfed.highlevel.model.rspec_source.RequestRspecSource;
import be.iminds.ilabt.jfed.rspec.model.InvalidRspecException;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.util.JFedUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * User: twalcari
 * Date: 12/6/13
 * Time: 9:40 AM
 */
public class SliceDefinitionBackup {


    private static final DateTimeFormatter EXPIRATION_DATETIME_FORMAT = ISODateTimeFormat.dateTime();
    private static final String SPLIT_HEADER = ": ";
    private static final String HEADER_ISRAWRSPEC = "Is-Raw-Rspec";
    private static final String HEADER_EXPIRATION_DATE = "Expiration-Date";
    private static final String HEADER_VERSION = "Version";
    private static final String CURRENT_VERSION = "2.0";
    private static final Logger LOG = LoggerFactory.getLogger(SliceDefinitionBackup.class);
    private static final String SLICE_DEFINITON_EXT = ".rspec";
    private static final String SLICE_DEFINITION_BASEDIR = JFedUtils.getUserDataDirectory() + "slice_backup";

    static {
        Path path = Paths.get(SLICE_DEFINITION_BASEDIR);
        try {
            Files.createDirectories(path);
        } catch (IOException e) {
            LOG.error("Error while creating slice-definition-backup directory", e);
        }
    }

    /**
     * This method saves the experiment definition used for this slice to disk, so that it is later possible
     * to recreate this slice in another instance of the jFed Experimenter Toolkit
     */
    public static void saveExperimentDefinition(RequestRspecSource requestRspecSource, String name, DateTime expirationTime) {

        File file = new File(SLICE_DEFINITION_BASEDIR + File.separator + name + SLICE_DEFINITON_EXT);

        try (FileWriter writer = new FileWriter(file)) {
            writer.write(HEADER_VERSION + SPLIT_HEADER + CURRENT_VERSION + "\n");
            writer.write(HEADER_EXPIRATION_DATE + SPLIT_HEADER + EXPIRATION_DATETIME_FORMAT.print(expirationTime) + "\n");
            writer.write(HEADER_ISRAWRSPEC + SPLIT_HEADER + (requestRspecSource.isXmlBased() ? "true"
                    : "false") + "\n");
            writer.write("\n");
            writer.write(requestRspecSource.getRspecXmlString());
            writer.flush();
            writer.close();
            LOG.debug("Wrote Experiment backup-file to " + file.getAbsolutePath());
        } catch (IOException ex) {
            LOG.error("An error occured while saving the experiment definition of slice " + name, ex);
        }

    }

    /**
     * This method saves the experiment definition used for this slice to disk, so that it is later possible
     * to recreate this slice in another instance of the jFed Experimenter Toolkit
     */
    public static ModelRspec recoverExperimentDefinition(String name) {

        File file = new File(SLICE_DEFINITION_BASEDIR + File.separator + name + SLICE_DEFINITON_EXT);

        if (!file.exists())
            return null;

        LOG.debug("Found Experiment backup-file at " + file.getAbsolutePath());

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line = reader.readLine();

            if (line == null || !line.contains(SPLIT_HEADER)) {
                //old file format or corrupt file
                LOG.warn("Experiment Backup-file is invalid or in old format");
            }

            //read headers first
            Map<String, String> headers = new HashMap<>();

            while (line != null && !line.isEmpty()) {
                if (!line.contains(SPLIT_HEADER)) {
                    LOG.error("Experiment Backup-file is corrupt. Expected header, but got '{}'", line);
                }
                String[] parts = line.split(SPLIT_HEADER);
                headers.put(parts[0], parts[1]);

                line = reader.readLine();
            }

            if (headers.containsKey(HEADER_EXPIRATION_DATE)) {

                try {
                    DateTime expirationDate =
                            EXPIRATION_DATETIME_FORMAT.parseDateTime(headers.get(HEADER_EXPIRATION_DATE));

                    if (expirationDate.isBefore(new DateTime())) {
                        //we found a slice backup of a slice which has already expired.
                        LOG.info("The experiment backup-file that was found is already expired");
                        return null;
                    }

                } catch (NumberFormatException ex) {
                    LOG.error("Could not parse expiration date in recovery file", ex);
                    return null;
                }
            } else {
                LOG.error("Could not find expiration date in recovery file");
                return null;
            }


            //now read the rest of the file
            StringBuilder fileContents = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                fileContents.append(line);
            }

            reader.close();

            try {
                return ModelRspec.fromGeni3RequestRspecXML(fileContents.toString());
            } catch (InvalidRspecException ex) {
                LOG.error("Found invalid Rspec XML while loading the experiment definition of slice " + name, ex);
                return null;
            }

        } catch (IOException ex) {
            LOG.error("An error occured while loading the experiment definition of slice " + name, ex);
            return null;
        }

    }
}
