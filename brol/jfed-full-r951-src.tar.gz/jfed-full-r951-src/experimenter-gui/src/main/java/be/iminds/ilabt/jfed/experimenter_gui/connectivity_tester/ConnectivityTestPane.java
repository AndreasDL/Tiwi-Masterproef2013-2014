package be.iminds.ilabt.jfed.experimenter_gui.connectivity_tester;

import be.iminds.ilabt.jfed.experimenter_gui.ui.status.TaskStatusIndicator;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.scene.control.TitledPane;
import javafx.scene.web.WebView;
import org.w3c.dom.Document;

/**
 * User: twalcari
 * Date: 1/6/14
 * Time: 11:58 AM
 */
public class ConnectivityTestPane extends TitledPane implements EventHandler<WorkerStateEvent> {

    private static final String CONNECTIVITY_TEST_CSS = "connectivity-test.css";
    private final TaskStatusIndicator taskStatusIndicator;
    private final WebView webView;
    private final ConnectivityTestTask ctt;

    public ConnectivityTestPane(ConnectivityTestTask ctt) {
        this.ctt = ctt;

        setText(ctt.getTest().getName());
        setDisable(true);

        // add taskStatusIndicator as graphic
        taskStatusIndicator = new TaskStatusIndicator(TaskStatusIndicator.Status.INACTIVE);
        taskStatusIndicator.setPrefHeight(16);
        taskStatusIndicator.setPrefWidth(16);

        ctt.progressProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
                if (ConnectivityTestPane.this.ctt.getProgress() == ConnectivityTestTask.TASK_STARTED) {
                    taskStatusIndicator.setStatus(TaskStatusIndicator.Status.BUSY);
                }
            }
        });

        ctt.setOnSucceeded(this);
        ctt.setOnFailed(this);


        setGraphic(taskStatusIndicator);

        webView = new WebView();
        //let the webview adapt to the height of the document
        webView.getEngine().documentProperty().addListener(new ChangeListener<Document>() {
            @Override public void changed(ObservableValue<? extends Document> prop, Document oldDoc, Document newDoc) {
                String heightText = webView.getEngine().executeScript(
                        "window.getComputedStyle(document.body, null).getPropertyValue('height')"
                ).toString();
                double height = Double.valueOf(heightText.replace("px", ""));

                webView.setPrefHeight(height + 20);
            }
        });
        webView.getEngine().loadContent(createInProgressHtml());

        setContent(webView);
    }

    /**
     * This function will be called when the ConnectivityTestTask has finished (succeeded or failed)
     */
    @Override
    public void handle(WorkerStateEvent workerStateEvent) {
        assert (ctt.isDone());

        setDisable(false);
        //set status
        if (ctt.getStatus() == null) {
            taskStatusIndicator.setStatus(TaskStatusIndicator.Status.FAILED);
        } else {
            switch (ctt.getStatus()) {
                case SUCCEEDED:
                    taskStatusIndicator.setStatus(TaskStatusIndicator.Status.SUCCESS);
                    break;
                case FAILED:
                    taskStatusIndicator.setStatus(TaskStatusIndicator.Status.FAILED);
                    break;
                case WARNING:
                    taskStatusIndicator.setStatus(TaskStatusIndicator.Status.WARNING);
                    break;
            }
        }

        //create report
        webView.getEngine().loadContent(generateHtmlReport());
    }


    private String createInProgressHtml(){
        //generate the html
        StringBuilder sb = new StringBuilder();
        sb.append("<html>");
        sb.append(String.format("<head><link type='text/css' href='%s' rel='stylesheet' /></head>",
                getClass().getResource(CONNECTIVITY_TEST_CSS)));
        sb.append("<body>");

        sb.append("<div class='result-header status-skipped'>");
        sb.append(String.format("<p><strong>Status:</strong> %s</p>", "Awaiting execution..."));
        sb.append("</div>");

        sb.append("<div class='result-body status-skipped'>");
        sb.append("</div>");
        sb.append("</body></html>");

        return sb.toString();
    }

    private String generateHtmlReport() {

        //generate all strings to be inserted into the html

        String status = null;
        String statusClass = null;
        if (ctt.getStatus() == null) {
            status = "Failed";
            statusClass = "status-failed";
        } else {
            switch (ctt.getStatus()) {
                case SUCCEEDED:
                    status = "Success";
                    statusClass = "status-success";
                    break;
                case WARNING:
                    status = "Warning";
                    statusClass = "status-warning";
                    break;
                case FAILED:
                    status = "Failed";
                    statusClass = "status-failed";
                    break;
                case SKIPPED:
                    status = "Skipped";
                    statusClass = "status-skipped";
            }
        }

        //generate the html
        StringBuilder sb = new StringBuilder();
        sb.append("<html>");
        sb.append(String.format("<head><link type='text/css' href='%s' rel='stylesheet' /></head>",
                getClass().getResource(CONNECTIVITY_TEST_CSS)));
        sb.append("<body>");

        sb.append(String.format("<div class='result-header %s'>", statusClass));
        sb.append(String.format("<p><strong>Status:</strong> %s</p>", status));
        sb.append("</div>");

        sb.append(String.format("<div class='result-body %s'>", statusClass));
        if (ctt.getTest().getMessage() != null) {
            sb.append(String.format("<p><strong>Message:</strong> %s</p>", ctt.getTest().getMessage()));
        }

        if (ctt.getTest().getException() != null) {
            sb.append(String.format("<p><strong>Exception:</strong><br /><pre>%s</pre></p>",
                    ctt.getTest().getExceptionString()));
        }
        sb.append("</div>");
        sb.append("</body></html>");

        return sb.toString();

    }
}
