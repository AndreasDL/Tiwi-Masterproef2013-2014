package be.iminds.ilabt.jfed.experimenter_gui.ribbon_tabs;

import be.iminds.ilabt.jfed.experimenter_gui.ExperimenterGUI;
import be.iminds.ilabt.jfed.experimenter_gui.slice.SliceController;
import be.iminds.ilabt.jfed.experimenter_gui.tabs.SliceControllerTab;
import be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon.RibbonTab;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.ToggleButton;

import java.io.IOException;

/**
 * User: twalcari
 * Date: 11/12/13
 * Time: 4:16 PM
 */
public class SliceControllerRibbonTab extends RibbonTab {
    public static final String SLICE_CONTROLLER_TOOLBAR_FXML =
            "/be/iminds/ilabt/jfed/experimenter_gui/slice/SliceControllerToolbar.fxml";
    private final ExperimenterGUI experimenterGui;

    private SliceControllerTab currentSliceControllerTab;

    //this variable determines if this tab should be selected in the GUI the next time it is added to the RibbonTabPane
    private boolean wasActive = false;
    @FXML
    private Button updateExperimentButton;
    @FXML
    private Button stopExperimentButton;
    @FXML
    private ToggleButton canvasToggleButton;
    @FXML
    private ToggleButton rawToggleButton;

    public SliceControllerRibbonTab(final ExperimenterGUI experimenterGui) {
        this.experimenterGui = experimenterGui;

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(SLICE_CONTROLLER_TOOLBAR_FXML));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        if (experimenterGui.getTabPane().getSelectionModel().getSelectedItem() instanceof SliceControllerTab)
            register((SliceControllerTab) experimenterGui.getTabPane().getSelectionModel().getSelectedItem());
        experimenterGui.getTabPane().getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
            @Override
            public void changed(ObservableValue<? extends Tab> observableValue, Tab oldTab, Tab newTab) {
                if (oldTab != null && oldTab instanceof SliceControllerTab) {
                    unregister((SliceControllerTab) oldTab);
                }
                if (newTab != null && newTab instanceof SliceControllerTab) {
                    register((SliceControllerTab) newTab);
                }
            }
        });
    }

    private SliceController getCurrentSliceController() {
        if (currentSliceControllerTab == null)
            return null;
        else
            return currentSliceControllerTab.getSliceController();
    }

    private void register(SliceControllerTab sliceControllerTab) {
        assert (currentSliceControllerTab == null);

        currentSliceControllerTab = sliceControllerTab;

        this.setDisable(false);
        if (wasActive)
            getTabPane().getSelectionModel().select(this);

        if (getCurrentSliceController().isCanvasVisible()) {
            canvasToggleButton.setSelected(true);
        } else {
            rawToggleButton.setSelected(true);
        }

        canvasToggleButton.setDisable(!getCurrentSliceController().isCanvasAvailable());

    }

    private void unregister(SliceControllerTab sliceControllerTab) {
        assert (currentSliceControllerTab == sliceControllerTab);
        currentSliceControllerTab = null;

        //hide tab
        wasActive = this.isSelected();
        if (this.isSelected())
            this.getTabPane().getSelectionModel().selectFirst();
        this.setDisable(true);
    }


    @FXML
    public void onUpdateExperimentPressed() {
        getCurrentSliceController().requestUpdate();
    }

    public void onStopExperimentPressed() {
        getCurrentSliceController().stopExperiment();
    }

    @FXML
    private void switchToCanvasAction() {
        if (getCurrentSliceController().switchToModelView()) {
            canvasToggleButton.setSelected(true);
        } else {
            rawToggleButton.setSelected(true);
        }
    }

    @FXML
    private void switchToRawAction() {
        if (getCurrentSliceController().switchToRawView()) {
            rawToggleButton.setSelected(true);
        }
    }
}
