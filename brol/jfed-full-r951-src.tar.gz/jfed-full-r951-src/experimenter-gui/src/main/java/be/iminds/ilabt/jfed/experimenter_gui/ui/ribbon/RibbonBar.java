package be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon;

import javafx.scene.control.TabPane;

/**
 * User: twalcari
 * Date: 11/6/13
 * Time: 9:41 AM
 */
public class RibbonBar extends TabPane {

    public static final String STYLESHEET_URL = "ribbon.css";
    private static final String RIBBON_STYLE = "ribbon";

    public RibbonBar() {
        super();
        getStylesheets().add(getClass().getResource(STYLESHEET_URL).toExternalForm());
        getStyleClass().add(RIBBON_STYLE);
    }
}
