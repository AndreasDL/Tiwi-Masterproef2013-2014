package be.iminds.ilabt.jfed.experimenter_gui.model;

import be.iminds.ilabt.jfed.experimenter_gui.connectivity_tester.ConnectivityTester;
import be.iminds.ilabt.jfed.gui_model.GuiModel;
import be.iminds.ilabt.jfed.highlevel.controller.HighLevelController;
import be.iminds.ilabt.jfed.highlevel.model.AuthorityList;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.lowlevel.GeniUserProvider;
import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.JFedAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnectionPool;
import be.iminds.ilabt.jfed.lowlevel.userloginmodel.UserLoginModelManager;
import be.iminds.ilabt.jfed.util.JavaFXLogger;
import be.iminds.ilabt.jfed.util.ProxyPreferencesManager;

/**
 * User: twalcari
 * Date: 1/22/14
 * Time: 1:47 PM
 */
public class ExperimenterModel implements GuiModel {

    private static final ExperimenterModel INSTANCE = new ExperimenterModel();
    private final JavaFXLogger logger;
    private final AuthorityListModel authorityListModel;
    private final UserLoginModelManager userLoginModelManager;
    private final EasyModel easyModel;
    private final SfaConnectionPool sfaConnectionPool;
    private final HighLevelController highLevelController;
    private final ConnectivityTester connectivityTester;
    private final ProxyPreferencesManager proxyPreferencesManager;

    private ExperimenterModel() {
        this.logger = new JavaFXLogger(true /*synchronous processing*/);
        //initialize UserLoginModelManager
        this.authorityListModel = JFedAuthorityList.getAuthorityListModel();
        this.userLoginModelManager = new UserLoginModelManager(authorityListModel, logger);
        this.userLoginModelManager.load();

        this.easyModel = new EasyModel(logger, authorityListModel, userLoginModelManager);
        this.sfaConnectionPool = new SfaConnectionPool();
        this.highLevelController = new HighLevelController(easyModel, this.sfaConnectionPool, userLoginModelManager);

        this.proxyPreferencesManager = new ProxyPreferencesManager(userLoginModelManager, sfaConnectionPool);

        this.connectivityTester = new ConnectivityTester();
    }

    public static ExperimenterModel getInstance() { return INSTANCE; }

    @Override public JavaFXLogger getLogger() { return logger; }

    @Override public AuthorityListModel getAuthorityListModel() { return authorityListModel; }
    @Override public AuthorityList getAuthorityList() { return easyModel.getAuthorityList(); }

    @Override public UserLoginModelManager getUserLoginModelManager() { return userLoginModelManager; }
    @Override public GeniUserProvider getGeniUserProvider() { return userLoginModelManager; }

    @Override public EasyModel getEasyModel() { return easyModel; }

    public ConnectivityTester getConnectivityTester() { return connectivityTester; }

    public ProxyPreferencesManager getProxyPreferencesManager() { return proxyPreferencesManager; }

    @Override public SfaConnectionPool getSfaConnectionPool() { return sfaConnectionPool; }
    @Override public GeniConnectionProvider getConnectionProvider() { return sfaConnectionPool; }

    @Override public HighLevelController getHighLevelController() { return highLevelController; }
}
