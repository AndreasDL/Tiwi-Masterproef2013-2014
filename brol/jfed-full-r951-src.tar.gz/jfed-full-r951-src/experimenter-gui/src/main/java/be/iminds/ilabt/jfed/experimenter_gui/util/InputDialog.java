package be.iminds.ilabt.jfed.experimenter_gui.util;

import be.iminds.ilabt.jfed.ui.javafx.util.JavaFXDialogUtil;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.*;

import java.io.IOException;
import java.net.URL;

/**
 * User: twalcari
 * Date: 11/7/13
 * Time: 11:01 AM
 */
public class InputDialog implements EventHandler<WindowEvent> {
    private static final String INPUT_DIALOG_SOURCE = "InputDialog.fxml";
    @FXML
    private ImageView imageView;
    @FXML
    private Label messageLabel;
    @FXML
    private TextField inputField;
    @FXML
    private Button okButton;
    private boolean valid = false;
    private Stage stage;

    public static String showInputDialog(String message) {
        return showInputDialog(message, null, null, null);
    }

    public static String showInputDialog(String message, Image image) {
        return showInputDialog(message, null, image, null);
    }

    public static String showInputDialog(String message, String defaultAnswer) {
        return showInputDialog(message, defaultAnswer, null);
    }

    public static String showInputDialog(String message, String defaultAnswer, Image image) {
        return showInputDialog(message, defaultAnswer, image, null);
    }

    public static String showInputDialog(String message, String defaultAnswer, Image image, Window window) {
        try {
            //create dialog from FXML
            URL dialogURL = InputDialog.class.getResource(INPUT_DIALOG_SOURCE);
            FXMLLoader loader = new FXMLLoader(dialogURL, null);

            GridPane root = (GridPane) loader.load();

            InputDialog controller = loader.getController();

            controller.setImage(image);
            controller.setMessage(message);

            if (defaultAnswer != null) {
                controller.setUserInput(defaultAnswer);

            }


            final Stage dialog = new Stage();
            dialog.initStyle(StageStyle.UTILITY);
            if (window != null) {
                dialog.initOwner(window);
                dialog.initModality(Modality.WINDOW_MODAL);
            } else
                dialog.initModality(Modality.APPLICATION_MODAL);
            controller.setStage(dialog);

            //create scene and show dialog
            Scene scene = new Scene(root);
            dialog.setTitle(message);
            dialog.setScene(scene);
            dialog.sizeToScene();
            dialog.showAndWait();

            dialog.setOnCloseRequest(controller);

            return controller.getUserInput();
        } catch (IOException e) {
            throw new RuntimeException("Error while loading input dialog", e);
        }

    }

    public void initialize() {

        this.inputField.selectAll();
        this.inputField.requestFocus();
    }

    public void onOKPressed() {

        if (inputField.getText().length() > 0) {
            valid = true;
            stage.close();
        } else {
            JavaFXDialogUtil.errorMessage("Input is required!");
        }
    }

    public void setImage(Image image) {
        imageView.setImage(image);

        imageView.setVisible(image != null);
        imageView.setManaged(image != null);

    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public String getUserInput() {
        if (valid)
            return inputField.getText();
        else
            return null;
    }

    public void setUserInput(String userInput) {
        this.inputField.setText(userInput);
    }

    public void setMessage(String message) {
        this.messageLabel.setText(message);
    }

    /**
     * Is called when the user closes the dialog with the close button
     *
     * @param windowEvent
     */
    @Override
    public void handle(WindowEvent windowEvent) {
        valid = false;
    }
}
