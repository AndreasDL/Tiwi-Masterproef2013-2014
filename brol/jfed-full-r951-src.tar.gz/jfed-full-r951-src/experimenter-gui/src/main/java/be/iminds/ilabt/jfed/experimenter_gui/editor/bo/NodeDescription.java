package be.iminds.ilabt.jfed.experimenter_gui.editor.bo;

import be.iminds.ilabt.jfed.experimenter_gui.ExperimenterConfiguration;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * A node description defines a certain class of nodes (e.g. a physical machine, a VM, a node with wireless
 * capabilities).
 * <p/>
 * A node description is backed by one or more RspecNodeDescriptions, which define Rspecs of configurations
 * that match the description.
 * <p/>
 * <p/>
 * User: twalcari
 * Date: 1/10/14
 * Time: 3:38 PM
 */
public class NodeDescription {
    private final String id;
    private final String name;
    private final NodeType type;
    private final List<RspecNodeDescription> rspecNodeDescriptions;
    private final Map<String, ExperimenterConfiguration.EnabledTestbed> enabledTestbeds;

    public NodeDescription(String id, String name, NodeType type, List<RspecNodeDescription> rspecNodeDescriptions, Map<String, ExperimenterConfiguration.EnabledTestbed> enabledTestbeds) {
        this.id = id;
        this.type = type;
        this.rspecNodeDescriptions = rspecNodeDescriptions;
        this.name = name;
        this.enabledTestbeds = enabledTestbeds;
    }

    /**
     * A user-readable name for the Node description.
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * An ordered list of Rspec Node descriptions. The list defines in which order the various RspecNodeDescriptions
     * have to be queried for availability.
     *
     * @return
     */
    public List<RspecNodeDescription> getRspecNodeDescriptions() {
        return Collections.unmodifiableList(rspecNodeDescriptions);
    }

    public NodeType getType() {
        return type;
    }

    public Map<String, ExperimenterConfiguration.EnabledTestbed> getEnabledTestbeds() {
        return enabledTestbeds;
    }

    public String getId() {
        return id;
    }

    public static enum NodeType {
        COMPUTER, VM, SERVER, WIRELESS
    }

}
