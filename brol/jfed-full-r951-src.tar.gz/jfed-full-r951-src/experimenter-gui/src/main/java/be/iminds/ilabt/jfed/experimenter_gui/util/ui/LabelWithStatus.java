package be.iminds.ilabt.jfed.experimenter_gui.util.ui;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 * User: twalcari
 * Date: 11/19/13
 * Time: 1:39 PM
 */
public class LabelWithStatus extends Label implements ChangeListener<LabelWithStatus.Status> {

    private final ObjectProperty<Status> status = new SimpleObjectProperty<>(Status.NONE);

    public LabelWithStatus() {
        initialize();
    }

    public LabelWithStatus(String s) {
        super(s);
        initialize();
    }

    private void initialize() {
        getStylesheets().add(getClass().getResource("label-with-status.css").toExternalForm());
        this.status.addListener(this);
    }

    public Status getStatus() {
        return status.get();
    }

    public void setStatus(Status status) {
        this.status.set(status);
    }

    public ObjectProperty<Status> statusProperty() {
        return status;
    }

    @Override
    public void changed(ObservableValue<? extends Status> observableValue, Status oldValue, Status newValue) {
        getStyleClass().remove(oldValue.styleName);
        getStyleClass().add(newValue.styleName);
    }

    public static enum Status {
        NONE("label-normal"),
        OK("label-ok"),
        WARNING("label-warning"),
        ERROR("label-error");
        private final String styleName;

        private Status(String styleName) {
            this.styleName = styleName;
        }
    }
}
