package be.iminds.ilabt.jfed.experimenter_gui;

import be.iminds.ilabt.jfed.experimenter_gui.model.ExperimenterModel;
import be.iminds.ilabt.jfed.experimenter_gui.preferences.PreferencesDialogFactory;
import be.iminds.ilabt.jfed.experimenter_gui.tabs.SliceControllerTab;
import be.iminds.ilabt.jfed.highlevel.controller.TaskThread;
import be.iminds.ilabt.jfed.lowlevel.userloginmodel.UserLoginModelManager;
import be.iminds.ilabt.jfed.ssh_terminal_tool.SshAgentHelper;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import be.iminds.ilabt.jfed.ui.javafx.util.ExtraInfoCallBackGUIs;
import be.iminds.ilabt.jfed.util.JFedUtils;
import be.iminds.ilabt.jfed.util.PreferencesUtil;
import be.iminds.ilabt.jfed.util.SSHKeyHelper;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * User: twalcari
 * Date: 10/31/13
 * Time: 6:17 PM
 */
public class Launch extends Application {
    /* solution for MAC OS HeadlessException bug. See https://ibcn-jira.intec.ugent.be/browse/FEDIBBTDEV-239 */
    static {
        System.setProperty("java.awt.headless", "false");
    }

    private static final Logger LOG = LogManager.getLogger();
    private static final String EXPERIMENTER_GUI_FXML = "ExperimenterGUI.fxml";
    private static final String USER_LOGIN_FXML = "login/UserLogin.fxml";
    private final TaskThread taskThread = TaskThread.getInstance();
    private UserLoginModelManager userLoginModelManager;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        try {
            //check for filesystem access
            if (JFedUtils.getUserDataDirectory() == null) {

                Dialogs.showErrorDialog(stage, "Please verify your security settings and try again.\n\n" +
                        "If you are trying to run jFed through Safari on OS X, you need to change your Safari security settings.\n" +
                        "(cfr. http://doc.fed4fire.eu/firstexperiment.html#start-up-jfed)"
                        , "jFed was unable to access the filesystem.", "Fatal Error");

                exit();
                return;
            }


            ExperimenterModel experimenterModel = ExperimenterModel.getInstance();
            userLoginModelManager = experimenterModel.getUserLoginModelManager();

            ExtraInfoCallBackGUIs.prepareExtraInfoCallback(stage.getOwner());

            showUserLogin();
            //exit if user isn't logged in now
            if (!userLoginModelManager.isUserLoggedIn()) {
                exit();
                return;
            }

            //show information dialog about public/private keys on first run of jFed

            if (PreferencesUtil.getInt(PreferencesUtil.Preference.PREF_FIRSTRUN_VERSION) < PreferencesUtil.CURRENT_FIRSTRUN_VERSION) {
                Dialogs.showInformationDialog(null,
                        "In order to successfully run experiments, you need to configure " +
                                "your SSH Key Authentication settings.\n\n" +
                                "Please complete your settings before continuing.",
                        "Initial configuration required",
                        "Welcome to the jFed Experimenter Tool!");

                PreferencesDialogFactory.showPreferencesDialog();

                PreferencesUtil.setInt(PreferencesUtil.Preference.PREF_FIRSTRUN_VERSION, PreferencesUtil.CURRENT_FIRSTRUN_VERSION);

//                if (PreferencesUtil.getKeyLocation() == null) {
//                    Dialogs.showWarningDialog(null, "Logging into nodes will be impossible until you correct this.",
//                            "You did not specify a valid private key");
//                }
            }

            showExperimenterGui(stage);

        } catch (Throwable ex) {
            LOG.fatal("Fatal error in jFed Experimenter Main Thread: "+ ex.getMessage(), ex);
            Dialogs.showErrorDialog(stage, "jFed experimenter will terminate.", "A fatal error occurred!", "Fatal Error", ex);
            throw ex;
        }
    }

    private void showUserLogin() {
        try {

            URL location = getClass().getResource(USER_LOGIN_FXML);
            assert location != null;

            final FXMLLoader loader = new FXMLLoader(location);
            loader.load();
            Stage userLoginStage = new Stage();
            userLoginStage.setTitle("jFed login");
            userLoginStage.setResizable(false);
            userLoginStage.setScene(new Scene(loader.<BorderPane>getRoot()));

            assert userLoginStage != null;
            userLoginStage.showAndWait();
        } catch (Exception e) {
            throw new RuntimeException("Something went wrong showing the User Login Screen: " + e.getMessage(), e);
        }
    }

    public void showExperimenterGui(Stage stage) {
        try {
            URL location = getClass().getResource(EXPERIMENTER_GUI_FXML);
            assert location != null;

            FXMLLoader loader = new FXMLLoader(location);
            loader.load();
            final ExperimenterGUI experimenterGUI = loader.getController();

            stage.setTitle("jFed Experimenter Toolkit");
            stage.setScene(new Scene(loader.<BorderPane>getRoot()));

            stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent windowEvent) {
                    List<SliceControllerTab> activeSlicesTabs = new ArrayList<>();
                    for (Tab tab : experimenterGUI.getTabPane().getTabs()) {
                        if (tab instanceof SliceControllerTab) {
                            SliceControllerTab sct = (SliceControllerTab) tab;
                            if (sct.getSliceController().isSliceActive())
                                activeSlicesTabs.add(sct);
                        }
                    }

                    if (!activeSlicesTabs.isEmpty()) {
                        //show a warning
                        Dialogs.DialogResponse dr =
                                Dialogs.showWarningDialog(null, "There are currently resources in use." +
                                        " Are you sure you want to exit?",
                                        "Resources in use",
                                        "Resources in use",
                                        Dialogs.DialogOptions.YES_NO_CANCEL);
                        if (dr != Dialogs.DialogResponse.YES) {
                            windowEvent.consume();
                            return;
                        }
                    }

                    exit();
                }
            });

            stage.show();
        } catch (Exception e) {
            throw new RuntimeException("Something went wrong showing the ExperimenterGUI: " + e.getMessage(), e);
        }
    }

    public void exit() {
        LOG.info("Close was requested. Trying to terminate");
        taskThread.requestStop();

        //stop any running ssh-agent
        SshAgentHelper.stopSshAgent();

        Platform.exit();
        System.exit(0);
    }
}
