package be.iminds.ilabt.jfed.experimenter_gui.ribbon_tabs;

import be.iminds.ilabt.jfed.experimenter_gui.ExperimenterGUI;
import be.iminds.ilabt.jfed.experimenter_gui.canvas.CanvasNode;
import be.iminds.ilabt.jfed.experimenter_gui.editor.ExperimentEditor;
import be.iminds.ilabt.jfed.experimenter_gui.tabs.ExperimentEditorTab;
import be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon.RibbonTab;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * User: twalcari
 * Date: 11/12/13
 * Time: 4:16 PM
 */
public class ExperimentEditorRibbonTab extends RibbonTab {
    public static final String EXPERIMENT_EDITOR_TOOLBAR_FXML =
            "/be/iminds/ilabt/jfed/experimenter_gui/editor/ExperimentEditorToolbar.fxml";
    private final ExperimenterGUI experimenterGui;

    private ExperimentEditorTab currentExperimentEditorTab;

    private final InvalidationListener pasteListener = new InvalidationListener() {
        @Override
        public void invalidated(Observable observable) {
            pasteButton.setDisable(getCurrentExperimentEditor().getCanvas().getClipboard().isEmpty());
        }
    };

    private final InvalidationListener nodeSelectionListener = new InvalidationListener() {
        @Override
        public void invalidated(Observable observable) {
            CanvasNode selectedCanvasNode =
                    getCurrentExperimentEditor().getCanvas().getSelectionProvider().getSelectedCanvasNode();
            copyButton.setDisable(selectedCanvasNode == null);
            duplicateButton.setDisable(selectedCanvasNode == null);

        }
    };

    //this variable determines if this tab should be selected in the GUI the next time it is added to the RibbonTabPane
    private boolean wasActive = false;
    @FXML
    private Button pasteButton;
    @FXML
    private Button copyButton;
    @FXML
    private Button duplicateButton;
    @FXML
    private Button zoomInButton;
    @FXML
    private Button zoomOutButton;
    @FXML
    private Button resetZoomButton;

    @FXML
    private Button formatCodeButton;
    @FXML
    private ToggleGroup viewToggleGroup;
    @FXML
    private ToggleButton canvasToggleButton;
    @FXML
    private ToggleButton rawToggleButton;

    public ExperimentEditorRibbonTab(ExperimenterGUI experimenterGui) {
        this.experimenterGui = experimenterGui;

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(EXPERIMENT_EDITOR_TOOLBAR_FXML));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        if (experimenterGui.getTabPane().getSelectionModel().getSelectedItem() instanceof ExperimentEditorTab)
            registerTab((ExperimentEditorTab) experimenterGui.getTabPane().getSelectionModel().getSelectedItem());


        experimenterGui.getTabPane().getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
            @Override
            public void changed(ObservableValue<? extends Tab> observableValue, Tab oldTab, Tab newTab) {
                if (oldTab != null && oldTab instanceof ExperimentEditorTab) {
                    unregisterTab((ExperimentEditorTab) oldTab);
                }
                if (newTab != null && newTab instanceof ExperimentEditorTab) {
                    registerTab((ExperimentEditorTab) newTab);
                }
            }
        });

        tabPaneProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
                if (ExperimentEditorRibbonTab.this.experimenterGui.getTabPane().getSelectionModel().getSelectedItem()
                        instanceof ExperimentEditorTab)
                    registerTab((ExperimentEditorTab) ExperimentEditorRibbonTab.this.experimenterGui.getTabPane().getSelectionModel().getSelectedItem());

                tabPaneProperty().removeListener(this);
            }
        });
    }

    public ExperimentEditor getCurrentExperimentEditor() {
        if (currentExperimentEditorTab == null)
            return null;
        else
            return currentExperimentEditorTab.getExperimentEditor();
    }

    private void registerTab(ExperimentEditorTab newTab) {
        //assert (currentExperimentEditorTab == null);
        currentExperimentEditorTab = newTab;

        //show tab
        this.setDisable(false);
        if (wasActive)
            this.getTabPane().getSelectionModel().select(this);

        if (newTab.getExperimentEditor().isCanvasVisible()) {
            canvasToggleButton.setSelected(true);
            registerEditableExperimentCanvas();
        } else {
            rawToggleButton.setSelected(true);
            registerRawRspecEditor();
        }
    }

    private void unregisterTab(ExperimentEditorTab oldTab) {
        assert (currentExperimentEditorTab == oldTab);

        currentExperimentEditorTab = null;

        //hide tab
        wasActive = this.isSelected();
        if (this.isSelected())
            this.getTabPane().getSelectionModel().selectFirst();
        this.setDisable(true);

    }

    @FXML
    private void onAutoArrangeAction() {
        assert (getCurrentExperimentEditor() != null);
        assert (getCurrentExperimentEditor().isCanvasVisible());
        getCurrentExperimentEditor().getCanvas().arrangeNodesOnCircle();
    }

    @FXML
    public void onZoomInAction() {
        assert (getCurrentExperimentEditor() != null);
        assert (getCurrentExperimentEditor().isCanvasVisible());
        getCurrentExperimentEditor().getCanvas().zoomIn();
    }

    @FXML
    public void onZoomOutAction() {
        assert (getCurrentExperimentEditor() != null);
        assert (getCurrentExperimentEditor().isCanvasVisible());
        getCurrentExperimentEditor().getCanvas().zoomOut();
    }

    @FXML
    public void onResetZoomAction() {
        assert (getCurrentExperimentEditor() != null);
        assert (getCurrentExperimentEditor().isCanvasVisible());
        getCurrentExperimentEditor().getCanvas().setZoom(1);
    }

    @FXML
    private void onCopyAction() {
        assert (getCurrentExperimentEditor() != null);
        assert (getCurrentExperimentEditor().isCanvasVisible());
        getCurrentExperimentEditor().getCanvas().copySelected();

    }

    @FXML
    private void onPasteAction() {
        assert (getCurrentExperimentEditor() != null);
        assert (getCurrentExperimentEditor().isCanvasVisible());
        getCurrentExperimentEditor().getCanvas().paste();

    }

    @FXML
    private void onDuplicateAction() {
        assert (getCurrentExperimentEditor() != null);
        assert (getCurrentExperimentEditor().isCanvasVisible());
        getCurrentExperimentEditor().getCanvas().duplicateSelected();

    }

    @FXML
    private void switchToCanvasAction() {
        assert (getCurrentExperimentEditor() != null);
        assert (!getCurrentExperimentEditor().isCanvasVisible());

        if (getCurrentExperimentEditor().getRawRspecEditor().isDirty()) {
            //show warning dialog
            Dialogs.DialogResponse response =
                    Dialogs.showWarningDialog((Stage) canvasToggleButton.getScene().getWindow(),
                            "The Rspec will be interpreted, and unsupported directives will be lost." +
                                    "Do you want to continue?",
                            "Possible data loss!",
                            "Possible data loss!",
                            Dialogs.DialogOptions.YES_NO);
            if (response != Dialogs.DialogResponse.YES)
                return;
        }


        if (getCurrentExperimentEditor().switchToEditableExperimentCanvas()) {
            canvasToggleButton.setSelected(true);
            registerEditableExperimentCanvas();
        } else {
            rawToggleButton.setSelected(true);
        }
    }

    @FXML
    private void switchToRawEditorAction() {
        unregisterEditableExperimentCanvas();

        if (getCurrentExperimentEditor().switchToRawRspecEditor()) {
            registerRawRspecEditor();
            rawToggleButton.setSelected(true);
        } else {
            registerEditableExperimentCanvas();
        }
    }

    @FXML
    private void onFormatCodeAction() {
        assert (getCurrentExperimentEditor() != null);
        assert (!getCurrentExperimentEditor().isCanvasVisible());

        if (!
                getCurrentExperimentEditor().getRawRspecEditor().formatXmlCode())
            Dialogs.showWarningDialog((Stage) formatCodeButton.getScene().getWindow(),
                    "Formatting your Rspec failed. Please check if the XML is valid",
                    "The Rspec could not be formatted",
                    "The Rspec could not be formatted",
                    Dialogs.DialogOptions.OK);
    }

    private void unregisterEditableExperimentCanvas() {
        assert (getCurrentExperimentEditor() != null);
        assert (getCurrentExperimentEditor().isCanvasVisible());
        getCurrentExperimentEditor().getCanvas().getClipboard().removeListener(pasteListener);
        getCurrentExperimentEditor().getCanvas().getSelectionProvider().selectedCanvasNodeProperty().removeListener(nodeSelectionListener);


    }

    private void registerEditableExperimentCanvas() {
        assert (getCurrentExperimentEditor() != null);
        assert (getCurrentExperimentEditor().isCanvasVisible());

        getCurrentExperimentEditor().getCanvas().getClipboard().addListener(pasteListener);
        getCurrentExperimentEditor().getCanvas().getSelectionProvider().selectedCanvasNodeProperty()
                .addListener(nodeSelectionListener);

        pasteListener.invalidated(getCurrentExperimentEditor().getCanvas().getClipboard());
        nodeSelectionListener.invalidated(getCurrentExperimentEditor().getCanvas().getSelectionProvider().selectedCanvasNodeProperty());

        //enable all zoom buttons
        zoomInButton.setDisable(false);
        zoomOutButton.setDisable(false);
        resetZoomButton.setDisable(false);

        //disable format buttons
        formatCodeButton.setDisable(true);
    }

    private void registerRawRspecEditor() {
        copyButton.setDisable(true);
        pasteButton.setDisable(true);
        duplicateButton.setDisable(true);

        //disable all zoom buttons
        zoomInButton.setDisable(true);
        zoomOutButton.setDisable(true);
        resetZoomButton.setDisable(true);

        //enable format button
        formatCodeButton.setDisable(false);
    }

}
