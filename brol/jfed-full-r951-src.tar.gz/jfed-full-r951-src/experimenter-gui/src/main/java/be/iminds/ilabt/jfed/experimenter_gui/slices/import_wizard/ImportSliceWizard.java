package be.iminds.ilabt.jfed.experimenter_gui.slices.import_wizard;

import be.iminds.ilabt.jfed.experimenter_gui.ui.wizard.Wizard;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 * User: twalcari
 * Date: 12/4/13
 * Time: 5:05 PM
 */
public class ImportSliceWizard extends Application {

    public static void main(String[] args){
        launch();

    }

    @Override
    public void start(Stage stage) throws Exception {
        Wizard wizard = new Wizard(new SelectSliceWizardPage());

        wizard.show();
    }
}
