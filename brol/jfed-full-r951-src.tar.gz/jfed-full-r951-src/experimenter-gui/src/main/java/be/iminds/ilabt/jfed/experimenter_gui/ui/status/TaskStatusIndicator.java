package be.iminds.ilabt.jfed.experimenter_gui.ui.status;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;

/**
 * User: twalcari
 * Date: 11/28/13
 * Time: 9:13 AM
 */
public class TaskStatusIndicator extends StackPane implements ChangeListener<TaskStatusIndicator.Status> {
    private static final Image imageInactive =
            new Image(TaskStatusIndicator.class.getResourceAsStream("/images/16/task-accepted.png"));
    private static final Image imageSuccess =
            new Image(TaskStatusIndicator.class.getResourceAsStream("/images/16/task-complete.png"));
    private static final Image imageFail =
            new Image(TaskStatusIndicator.class.getResourceAsStream("/images/16/task-reject.png"));
    private static final Image imageWarning =
            new Image(TaskStatusIndicator.class.getResourceAsStream("/images/16/task-attempt.png"));
    private final ProgressIndicator progressIndicator;
    private final ImageView imageView;
    private final ObjectProperty<Status> status = new SimpleObjectProperty<>(Status.INACTIVE);

    public TaskStatusIndicator() {
        setPrefHeight(16);
        setPrefWidth(16);

        this.progressIndicator = new ProgressIndicator();
        this.progressIndicator.setProgress(-1);
        this.progressIndicator.setVisible(false);

        this.imageView = new ImageView();
        imageView.setImage(imageInactive);

        getChildren().addAll(imageView, progressIndicator);

        statusProperty().addListener(this);

        //hack for handling mouseClicked-event correctly
        progressIndicator.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if (TaskStatusIndicator.this.getOnMouseClicked() != null)
                    TaskStatusIndicator.this.getOnMouseClicked().handle(mouseEvent);
            }
        });

    }

    public TaskStatusIndicator(Status status){
        this();
        setStatus(status);
    }

    public Status getStatus() {
        return status.get();
    }

    public void setStatus(Status status) {
        this.status.set(status);
    }

    public ObjectProperty<Status> statusProperty() {
        return status;
    }

    @Override
    public void changed(ObservableValue<? extends Status> observableValue, Status oldValue, Status newValue) {
        if (newValue == Status.BUSY) {
            imageView.setVisible(false);
            progressIndicator.setVisible(true);
        } else {
            imageView.setVisible(true);
            progressIndicator.setVisible(false);

            switch (newValue) {
                case INACTIVE:
                    imageView.setImage(imageInactive);
                    break;
                case SUCCESS:
                    imageView.setImage(imageSuccess);
                    break;
                case FAILED:
                    imageView.setImage(imageFail);
                    break;
                case WARNING:
                    imageView.setImage(imageWarning);
                    break;
            }

        }
    }

    public static enum Status {INACTIVE, BUSY, SUCCESS, FAILED, WARNING}


}
