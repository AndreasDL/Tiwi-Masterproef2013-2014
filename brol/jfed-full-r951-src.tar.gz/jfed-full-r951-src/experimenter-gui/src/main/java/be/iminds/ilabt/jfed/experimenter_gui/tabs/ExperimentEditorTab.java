package be.iminds.ilabt.jfed.experimenter_gui.tabs;

import be.iminds.ilabt.jfed.experimenter_gui.ExperimenterGUI;
import be.iminds.ilabt.jfed.experimenter_gui.editor.ExperimentEditor;
import be.iminds.ilabt.jfed.experimenter_gui.ribbon_tabs.ExperimentEditorRibbonTab;
import be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon.RibbonTab;
import be.iminds.ilabt.jfed.highlevel.model.rspec_source.RequestRspecSource;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import com.cathive.fonts.fontawesome.FontAwesomeIcon;
import com.cathive.fonts.fontawesome.FontAwesomeIconView;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tab;

import java.io.File;

/**
 * User: twalcari
 * Date: 11/7/13
 * Time: 4:58 PM
 */
public class ExperimentEditorTab extends Tab implements RibbonEnabled, StatusEnabled {


    private static ExperimentEditorRibbonTab ribbonTabInstance;
    private final ExperimenterGUI experimenterGui;
    private final ExperimentEditor experimentEditor;


    public ExperimentEditorTab(ExperimenterGUI experimenterGui, RequestRspecSource requestRspecSource,
                               String name, File file) {
        this.experimenterGui = experimenterGui;
        this.experimentEditor = new ExperimentEditor(experimenterGui, requestRspecSource, name, file);
        setContent(experimentEditor);

        textProperty().bind(experimentEditor.nameProperty());

        FontAwesomeIconView tabIcon = new FontAwesomeIconView();
        tabIcon.setIcon(FontAwesomeIcon.ICON_EDIT);
        setGraphic(tabIcon);


        ContextMenu contextMenu = new ContextMenu();
        MenuItem changeNameMenuItem = new MenuItem("Change name", new FontAwesomeIconView(FontAwesomeIcon.ICON_PENCIL));
        changeNameMenuItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                showEditNameDialog();
            }
        });
        contextMenu.getItems().add(changeNameMenuItem);
        setContextMenu(contextMenu);
    }

    private void showEditNameDialog() {
        String newName = Dialogs.showInputDialog(null,
                "Enter a new name:", "Change Experiment Definition name",
                "Change Experiment Definition name", this.experimentEditor.getName());

        if (newName.isEmpty())
            return;

        experimentEditor.setName(newName);
    }

    public ExperimentEditor getExperimentEditor() {
        return experimentEditor;
    }

    @Override
    public RibbonTab getRibbonTab() {
        if (ribbonTabInstance == null) {
            ribbonTabInstance = new ExperimentEditorRibbonTab(experimenterGui);
        }
        return ribbonTabInstance;
    }

    @Override
    public StringProperty statusProperty() {
        return experimentEditor.statusProperty();
    }
}
