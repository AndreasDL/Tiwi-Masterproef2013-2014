package be.iminds.ilabt.jfed.experimenter_gui.ui.wizard;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

import java.io.IOException;

/**
 * User: twalcari
 * Date: 12/4/13
 * Time: 3:01 PM
 */
public abstract class WizardPage extends VBox {
    private static final String WIZARDPAGE_FXML = "WizardPage.fxml";
    @FXML
    protected Label pageTitle;
    @FXML
    protected Pane content;
    @FXML
    protected Button prevButton;
    @FXML
    protected Button nextButton;
    @FXML
    protected Button cancelButton;
    @FXML
    protected Button finishButton;

    public WizardPage() {

        //initialize the Scene
        FXMLLoader fxmlLoader = new FXMLLoader(WizardPage.class.getResource(WIZARDPAGE_FXML));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

    }

    public void initialize() {

        pageTitle.setText(getTitle());
        content.getChildren().add(getContent());
    }

    HBox getButtons() {
        Region spring = new Region();
        HBox.setHgrow(spring, Priority.ALWAYS);
        HBox buttonBar = new HBox(5);
        cancelButton.setCancelButton(true);
        finishButton.setDefaultButton(true);
        buttonBar.getChildren().addAll(spring, prevButton, nextButton, cancelButton, finishButton);
        return buttonBar;
    }

    public abstract String getTitle();

    public abstract Parent getContent();

    boolean hasNextPage() {
        return getWizard().hasNextPage();
    }

    boolean hasPriorPage() {
        return getWizard().hasPriorPage();
    }

    @FXML
    protected void nextPage(ActionEvent actionEvent) {
        getWizard().nextPage();
    }

    @FXML
    protected void prevPage(ActionEvent actionEvent) {
        getWizard().prevPage();
    }

    @FXML
    protected void cancel(ActionEvent actionEvent) {
    }

    @FXML
    protected void finish(ActionEvent actionEvent) {
    }

    void navTo(String id) {
        getWizard().navTo(id);
    }

    Wizard getWizard() {
        return (Wizard) getParent();
    }

    public void manageButtons() {
        if (!hasPriorPage()) {
            prevButton.setDisable(true);
        }

        if (!hasNextPage()) {
            nextButton.setDisable(true);
        }
    }
}
