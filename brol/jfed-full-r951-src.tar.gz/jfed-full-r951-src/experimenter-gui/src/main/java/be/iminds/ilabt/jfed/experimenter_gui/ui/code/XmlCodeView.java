package be.iminds.ilabt.jfed.experimenter_gui.ui.code;

import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.layout.Region;
import javafx.scene.web.WebView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * User: twalcari
 * Date: 2/6/14
 * Time: 9:18 AM
 */
public class XmlCodeView extends Region {
    private static final Logger LOG = LoggerFactory.getLogger(XmlCodeView.class);
    public static final String PRETTY_PRINT_XSL = "pretty-print.xsl";

    private final WebView webView = new WebView();
    private String content;
    private boolean editable = true;

    /**
     * a template for editing code - this can be changed to any template derived from the
     * supported modes at http://codemirror.net to allow syntax highlighted editing of
     * a wide variety of languages.
     */
    private final String editingTemplate =
            "<!doctype html>" +
                    "<html>" +
                    "<head>" +
                    "  <link rel=\"stylesheet\" href=\"" + XmlCodeView.class.getResource("codemirror.css").toExternalForm() + "\">" +
                    "  <script src=\"" + XmlCodeView.class.getResource("codemirror.js").toExternalForm() + "\"></script>" +
                    "  <script src=\"" + XmlCodeView.class.getResource("xml.js").toExternalForm() + "\"></script>" +
                    "</head>" +
                    "<body>" +
                    "<form><textarea id=\"code\" name=\"code\">\n" +
                    "${code}" +
                    "</textarea></form>" +
                    "<script>" +
                    "  var editor = CodeMirror.fromTextArea(document.getElementById(\"code\"), {" +
                    "    lineNumbers: true," +
                    "    htmlMode: false," +
                    "    lineWrapping: true," +
                    "    autofocus: true," +
                    "    readOnly: ${readOnly}," +
                    "    mode: \"application/xml\"" +
                    "  });" +
                    "</script>" +
                    "</body>" +
                    "</html>";

    //instance initializer
    {
        getChildren().add(webView);
    }

    public XmlCodeView() {
        this(null);
    }

    public XmlCodeView(String content) {
        this(content, true);
    }

    public XmlCodeView(String content, boolean editable) {
        this.content = content;
        this.editable = editable;

        updateView();
    }

    public void setContent(String content) {
        this.content = content;
        updateView();

    }

    public boolean isEditable() {
        return editable;
    }

    public void setEditable(boolean editable) {
        this.editable = editable;
        updateView();
    }

    private void updateView() {
        String editorContent = editingTemplate
                .replace("${code}", content != null ? content : "")
                .replace("${readOnly}", editable ? "false" : "true");

        webView.getEngine().loadContent(editorContent);
    }

    @Override
    protected void layoutChildren() {
        double w = getWidth();
        double h = getHeight();
        layoutInArea(webView, 0, 0, w, h, 0, HPos.CENTER, VPos.CENTER);
    }

    public String getContent() {
        String editorContent = (String) webView.getEngine().executeScript("editor.getValue();");

        return editorContent;
    }

    public boolean formatXmlCode() {

        String currentContent = getContent();

        String formattedContent = formatXmlCode(currentContent);

        if (formattedContent != null) {
            setContent(formattedContent);
            return true;
        } else
            return false;


    }

    public static String formatXmlCode(String xml) {
        try {
            //Read xml
            InputSource src = new InputSource(new StringReader(xml));
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            dbFactory.setNamespaceAware(true);
            Document doc = null;

            doc = dbFactory.newDocumentBuilder().parse(src);

            // Pretty-prints a DOM document to XML using TrAX.
            // Note that a stylesheet is needed to make formatting reliable.
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer(
                    new StreamSource(XmlCodeView.class.getResourceAsStream(PRETTY_PRINT_XSL)));
            StringWriter stringWriter = new StringWriter();
            StreamResult streamResult = new StreamResult(stringWriter);
            DOMSource domSource = new DOMSource(doc);
            transformer.transform(domSource, streamResult);

            // return result
            return stringWriter.toString();

        } catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
            LOG.error("Error while trying to format XML", e);
            return null;
        }
    }

    public boolean isDirty() {
        return !getContent().equals(content);
    }
}
