package be.iminds.ilabt.jfed.experimenter_gui.dialogs;

import be.iminds.ilabt.jfed.experimenter_gui.model.ExperimenterModel;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.highlevel.model.Slice;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;

/**
 * User: twalcari
 * Date: 12/5/13
 * Time: 9:21 PM
 */
public class RecoverSliceDialog extends BorderPane {

    private static final String RECOVER_SLICE_DIALOG_FXML = "RecoverSliceDialog.fxml";
    @FXML
    private ListView<Slice> slicesListView;
    @FXML
    private Button okButton;
    @FXML
    private Button cancelButton;
    private Slice selectedSlice = null;

    private final EasyModel easyModel;

    //instance initializer
    {
        ExperimenterModel experimenterModel = ExperimenterModel.getInstance();
        easyModel = experimenterModel.getEasyModel();
    }

    public RecoverSliceDialog() {

        //initialize the Scene
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(RECOVER_SLICE_DIALOG_FXML));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        slicesListView.setCellFactory(new Callback<ListView<Slice>, ListCell<Slice>>() {
            @Override
            public ListCell<Slice> call(ListView<Slice> sliceListView) {
                return new SimpleSliceListCell();
            }
        });

        slicesListView.setItems(easyModel.slicesProperty());
        slicesListView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 2) {
                    onOKPressed();
                }
            }
        });


    }

    @FXML
    private void onOKPressed() {

        if (slicesListView.getSelectionModel().isEmpty()) {
            Dialogs.showErrorDialog((Stage) okButton.getScene().getWindow(),
                    "Please select the slice you wish to recover", "No slice selected");
            return;
        }

        selectedSlice = slicesListView.getSelectionModel().getSelectedItem();

        onCancelPressed();
    }

    @FXML
    private void onCancelPressed() {
        ((Stage) cancelButton.getScene().getWindow()).close();
    }

    public Slice getSelectedSlice() {
        return selectedSlice;
    }

    public void showDialog() {
        Scene scene = new Scene(this);

        Stage dialogStage = new Stage();
        dialogStage.setScene(scene);

        dialogStage.setTitle("Recover an existing experiment");
        dialogStage.setResizable(false);
        dialogStage.showAndWait();
    }

    private static class SimpleSliceListCell extends ListCell<Slice> {

        @Override
        protected void updateItem(Slice slice, boolean empty) {
            super.updateItem(slice, empty);
            if (!empty) {
                this.setText(slice.getName());
            } else
                this.setText("");
        }
    }
}
