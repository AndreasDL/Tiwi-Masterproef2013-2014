package be.iminds.ilabt.jfed.experimenter_gui.bugreporting;

import be.iminds.ilabt.jfed.experimenter_gui.connectivity_tester.ConnectivityTester;
import be.iminds.ilabt.jfed.experimenter_gui.model.ExperimenterModel;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.lowlevel.userloginmodel.UserLoginModelManager;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.classic.spi.ThrowableProxyUtil;
import ch.qos.logback.core.read.CyclicBufferAppender;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.WeakInvalidationListener;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageBuilder;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.BasicClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.*;

/**
 * User: twalcari
 * Date: 12/9/13
 * Time: 8:58 AM
 */
public class BugReportDialog extends BorderPane {
    private static final Logger LOG = LoggerFactory.getLogger(BugReportDialog.class);

    private static final String BUGREPORT_DIALOG_FXML = "BugReportDialog.fxml";
    private static final String VERSION_PROPERTIES_FILE = "/version.properties";
    private static final String PROP_VERSION = "version";
    private static final String PROP_BUILD_TIMESTAMP = "build.date";

    private static final String PROP_BUILD_JENKINS = "build.jenkins_build";
    private static final String BUG_REPORT_URL = "https://flsmonitor.fed4fire.eu/jfedexperimenter/submit.php";
    private final EasyModel easyModel;
    private final UserLoginModelManager userLoginModelManager;
    private final ConnectivityTester connectivityTester;
    @FXML
    private TextArea descriptionTextArea;
    @FXML
    private TextField versionTextField;
    @FXML
    private TextField environmentTextField;
    @FXML
    private TextField credentialsTextField;
    @FXML
    private TextField emailTextField;
    @FXML
    private Button submitButton;
    @FXML
    private Button cancelButton;
    @FXML
    private Label includedCallsLabel;
    @FXML
    private ProgressIndicator submitProgressIndicator;
    @FXML
    private Label progressLabel;


    public BugReportDialog() {
        ExperimenterModel experimenterModel = ExperimenterModel.getInstance();

        this.easyModel = experimenterModel.getEasyModel();
        this.userLoginModelManager = experimenterModel.getUserLoginModelManager();

        //start connectivity tests if this hasn't happened yet
        this.connectivityTester = experimenterModel.getConnectivityTester();
        this.connectivityTester.startTests();

        try {
            URL location = getClass().getResource(BUGREPORT_DIALOG_FXML);

            FXMLLoader loader = new FXMLLoader(location);
            loader.setRoot(this);
            loader.setController(this);

            loader.load();


        } catch (Exception e) {
            throw new RuntimeException("Something went wrong showing the Bug reporting dialog: " + e.getMessage(), e);
        }
    }

    public void initialize() {


        Properties prop = new Properties();
        //now load the version-properties file
        try {
            prop.load(getClass().getResourceAsStream(VERSION_PROPERTIES_FILE));
        } catch (IOException e) {
            throw new RuntimeException("Something went wrong showing the Bug reporting dialog: " + e.getMessage(), e);

        }

        //now load the info into the disabled textfield

        versionTextField.setText(prop.getProperty(PROP_VERSION, "Unknown")
                + " (" + prop.getProperty(PROP_BUILD_TIMESTAMP, "once upon a time") + ")");

        if (!prop.getProperty(PROP_BUILD_JENKINS).isEmpty())
            versionTextField.setText(versionTextField.getText() + "  - build #" + prop.getProperty(PROP_BUILD_JENKINS));

        StringBuilder environment = new StringBuilder();
        environment.append(System.getProperty("os.name"));
        environment.append(" ");
        environment.append(System.getProperty("os.version"));
        environment.append(" ");
        environment.append(System.getProperty("os.arch"));
        environment.append(" - Java ");
        environment.append(System.getProperty("java.version"));
        environment.append(" (");
        environment.append(System.getProperty("java.vendor"));
        environment.append(")");

        environmentTextField.setText(environment.toString());
        credentialsTextField.setText(userLoginModelManager.getUserUrnString());


        //try to get user e-mailaddress
        if (userLoginModelManager.getUserLoginModelType() ==
                UserLoginModelManager.UserLoginModelType.KEY_CERT_INTERNAL_INFO) {

            try {
                for (List<?> list : userLoginModelManager.getClientCertificateChain().get(0)
                        .getSubjectAlternativeNames()) {
                    if (list.get(0).equals(1)) {  //if 1, then this is a rfc822Name-field
                        emailTextField.setText(list.get(1).toString());
                        break;
                    }
                }
            } catch (CertificateParsingException e) {
                e.printStackTrace();
            }
        }

        includedCallsLabel.setText("" + easyModel.getApiCallHistory().getHistory().size() + " calls");
        easyModel.getApiCallHistory().getHistory().addListener(new WeakInvalidationListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        includedCallsLabel.setText("" + easyModel.getApiCallHistory().getHistory().size() + " calls");
                    }
                });
            }
        }));

    }

    @FXML
    private void onSubmitButtonAction() {

        if (descriptionTextArea.getText().isEmpty()) {
            Dialogs.showErrorDialog((Stage) this.getScene().getWindow(),
                    "Please fill in a description to submit a bug report.",
                    "Description is a mandatory field");
            return;
        }

        submitButton.setDisable(true);
        submitProgressIndicator.setVisible(true);


        BugReport bugReport = new BugReport();
        bugReport.setDescription(descriptionTextArea.getText());
        bugReport.setVersion(versionTextField.getText());
        bugReport.setEnvironment(environmentTextField.getText());
        bugReport.setReporterCredential(credentialsTextField.getText());
        bugReport.setMail(emailTextField.getText());
        bugReport.setCalls(easyModel.getApiCallHistory().getHistory());
        bugReport.setConnectivityTests(connectivityTester.getTests());

        //create the loglines
        List<LogLine> logLines = new ArrayList<>();
        // get the root logger where the MEMORY-logger is attached to
        ch.qos.logback.classic.Logger rootLogger =
                (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);

        CyclicBufferAppender<LoggingEvent> cyclicBufferAppender =
                (CyclicBufferAppender) rootLogger.getAppender("MEMORY");
        for (int i = 0; i < cyclicBufferAppender.getLength(); i++) {
            LoggingEvent loggingEvent = cyclicBufferAppender.get(i);

            LogLine logLine = new LogLine();
            logLine.setClassName(loggingEvent.getLoggerName());
            logLine.setThreadName(loggingEvent.getThreadName());
            logLine.setLevel(loggingEvent.getLevel().toString());
            logLine.setTime(loggingEvent.getTimeStamp());
            logLine.setMessage(loggingEvent.getFormattedMessage());
            if (loggingEvent.getThrowableProxy() != null)
                logLine.setThrowable(ThrowableProxyUtil.asString(loggingEvent.getThrowableProxy()));
            logLines.add(logLine);
        }

        bugReport.setLogLines(logLines);

        final SubmitTask submitTask = new SubmitTask(bugReport);

        progressLabel.textProperty().bind(submitTask.messageProperty());

        submitTask.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
            @Override
            public void handle(WorkerStateEvent workerStateEvent) {
                Dialogs.showInformationDialog((Stage) BugReportDialog.this.getScene().getWindow(),
                        submitTask.getValue(),
                        "Bug report result");
                onCancelButtonAction();
            }
        });

        submitTask.setOnFailed(new EventHandler<WorkerStateEvent>() {
            @Override
            public void handle(WorkerStateEvent workerStateEvent) {
                Dialogs.showErrorDialog((Stage) BugReportDialog.this.getScene().getWindow(),
                        "An error occurred while sending the bug report. Are you connected to the internet?",
                        "Error while sending bug report",
                        "Error while sending bug report",
                        submitTask.getException());
                onCancelButtonAction();

            }
        });

        new Thread(submitTask).start();
    }

    @FXML
    private void onCancelButtonAction() {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    public void showDialog() {
        Stage bugReportStage = StageBuilder.create().title("jFed Bug Report").scene(new Scene(this)).build();

        bugReportStage.showAndWait();
    }

    private class SubmitTask extends Task<String> {

        private final BugReport bugReport;

        private SubmitTask(BugReport bugReport) {
            this.bugReport = bugReport;
        }

        @Override
        protected String call() throws Exception {

            String dotsString = "";
            while (!connectivityTester.testsDone()) {
                dotsString += ".";
                if (dotsString.length() > 3)
                    dotsString = ".";

                updateMessage("Waiting for connectivity tests to finish" + dotsString);
                Thread.sleep(1000);
            }

            updateMessage("Preparing bugreport");

            StringWriter sw = new StringWriter();
            //serialize bugreport
            try {
                Marshaller m = JAXBContext.newInstance(BugReport.class).createMarshaller();
                m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
                m.marshal(bugReport, sw);
            } catch (JAXBException e) {
                throw new RuntimeException(e);
            }


            Map<String, String> bugReportMap = new HashMap<>();
            bugReportMap.put("report", sw.toString());


            updateMessage("Sending bugreport to the server");
            return doHttpPost(bugReportMap);
        }

        private String doHttpPost(Map<String, String> fields) throws IOException {
            //make sure certificate exceptions are ignored
            SSLSocketFactory sf = null;
            try {
                sf = new SSLSocketFactory(new TrustStrategy() {

                    public boolean isTrusted(
                            final X509Certificate[] chain, String authType) throws CertificateException {
                        // Oh, I am easy...
                        return true;
                    }

                }, new X509HostnameVerifier() {
                    @Override
                    public void verify(String host, SSLSocket ssl) throws IOException {

                    }

                    @Override
                    public void verify(String host, X509Certificate cert) throws SSLException {

                    }

                    @Override
                    public void verify(String host, String[] cns, String[] subjectAlts) throws SSLException {

                    }

                    @Override
                    public boolean verify(String s, SSLSession sslSession) {
                        return true;
                    }
                }
                );
            } catch (NoSuchAlgorithmException | KeyManagementException | KeyStoreException | UnrecoverableKeyException e) {
                e.printStackTrace();
            }

            Scheme httpsScheme = new Scheme("https", 443, sf);
            SchemeRegistry schemeRegistry = new SchemeRegistry();
            schemeRegistry.register(httpsScheme);

            ClientConnectionManager cm = new BasicClientConnectionManager(schemeRegistry);
            HttpClient httpClient = new DefaultHttpClient(cm);
            HttpPost httpPost = new HttpPost(BUG_REPORT_URL);

            List<NameValuePair> params = new ArrayList<>();
            for (Map.Entry<String, String> field : fields.entrySet()) {
                params.add(new BasicNameValuePair(field.getKey(), field.getValue()));
            }
            httpPost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));

            HttpResponse response = httpClient.execute(httpPost);


            HttpEntity entity = response.getEntity();

            if (entity != null) {

                StringBuilder result = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(entity.getContent(), "UTF-8"))) {
                    String line = null;
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    return result.toString();
                } catch (IOException ex) {
                    return null;
                }
            } else
                return null;
        }
    }

}
