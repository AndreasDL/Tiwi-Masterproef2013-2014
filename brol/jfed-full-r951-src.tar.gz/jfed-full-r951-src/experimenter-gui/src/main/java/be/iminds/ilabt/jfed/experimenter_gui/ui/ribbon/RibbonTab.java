package be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon;

import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.layout.HBox;

/**
 * User: twalcari
 * Date: 11/6/13
 * Time: 9:43 AM
 */
public class RibbonTab extends Tab {

    private static final String RIBBON_CONTAINER_ID = "container";
    private static final String RIBBON_TAB_STYLE = "ribbon-tab";
    private HBox container;

    public RibbonTab() {
        super();
        setClosable(false); //tabs cannot be closed by user


        //create the container for all the components

        container = new HBox();
        container.setId(RIBBON_CONTAINER_ID);
        container.setPrefHeight(75);
        container.setMinHeight(30);

        container.setSpacing(5);

        //container.getStylesheets().add(getClass().getResource(RibbonBar.STYLESHEET_URL).getPath());

        setContent(container);
    }

    public HBox getContainer() {
        return container;
    }

    public ObservableList<Node> getGroups() {
        return container.getChildren();
    }

    @Override
    public String toString() {
        return "RibbonTab{" +
                "container=" + container +
                '}';
    }

    public boolean makeVisibleOnRegistration() {
        return true;
    }

}
