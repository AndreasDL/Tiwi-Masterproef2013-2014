package be.iminds.ilabt.jfed.experimenter_gui.slice;

import be.iminds.ilabt.jfed.experimenter_gui.canvas.ExperimentCanvas;
import be.iminds.ilabt.jfed.experimenter_gui.canvas.impl.RspecCanvasNode;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import com.cathive.fonts.fontawesome.FontAwesomeIcon;
import com.cathive.fonts.fontawesome.FontAwesomeIconView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

/**
 * User: twalcari
 * Date: 11/18/13
 * Time: 5:49 PM
 */
public class SliceExperimentCanvas extends ExperimentCanvas {
    private final SliceController sliceController;
    private final ContextMenu nodeContextMenu;

    public SliceExperimentCanvas(final SliceController sliceController, ModelRspec model) {
        super(model);
        this.sliceController = sliceController;

        //initialize GUI
        nodeContextMenu = new ContextMenu();

        MenuItem sshMenuItem =
                new MenuItem("Open SSH terminal", new FontAwesomeIconView(FontAwesomeIcon.ICON_TERMINAL));
        sshMenuItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                assert (getSelectionProvider().getSelectedCanvasNode() instanceof RspecCanvasNode);
                RspecCanvasNode rspecCanvasNode = (RspecCanvasNode) getSelectionProvider().getSelectedCanvasNode();

                sliceController.launchSSHTerminal(rspecCanvasNode.getRspecNode());
            }
        });
        nodeContextMenu.getItems().add(sshMenuItem);

        MenuItem infoMenuItem = new MenuItem("Show Node Info", new FontAwesomeIconView(FontAwesomeIcon.ICON_INFO));
        infoMenuItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                assert (getSelectionProvider().getSelectedCanvasNode() instanceof RspecCanvasNode);
                RspecCanvasNode rspecCanvasNode = (RspecCanvasNode) getSelectionProvider().getSelectedCanvasNode();

                NodePropertiesDialog.showSimplePropertiesDialog(sliceController.getSlice(),
                        rspecCanvasNode.getRspecNode());
            }
        });
        nodeContextMenu.getItems().add(infoMenuItem);
    }

    @Override
    protected void canvasItemOnMouseClicked(MouseEvent mouseEvent) {
        super.canvasItemOnMouseClicked(mouseEvent);

        if (mouseEvent.getSource() instanceof RspecCanvasNode)
            if (mouseEvent.getButton() != MouseButton.PRIMARY || mouseEvent.isControlDown()) {

                getSelectionProvider().setSelectedCanvasNode((RspecCanvasNode) mouseEvent.getSource());
                //show context menu
                nodeContextMenu.show((Node) mouseEvent.getSource(),
                        mouseEvent.getScreenX(), mouseEvent.getScreenY());


            }
    }

    public static String statusToStyleClass(SliverStatus status) {
        switch (status) {
            case READY:
                return "canvas-node-ready";

            case CHANGING:
                return "canvas-node-changing";

            case FAIL:
                return "canvas-node-fail";

            case UNALLOCATED:
                return "canvas-node-unallocated";

            case UNINITIALISED:
                return "canvas-node-uninitialised";

            case UNKNOWN:
                return "canvas-node-unknown";
            default:
                throw new IllegalArgumentException();
        }
    }


}
