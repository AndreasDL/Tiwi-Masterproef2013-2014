package be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.io.IOException;

/**
 * User: twalcari
 * Date: 11/6/13
 * Time: 9:45 AM
 */
public class RibbonComponentGroup  extends VBox {
    public static final String RIBBON_COMPONENT_GROUP_FXML = "RibbonComponentGroup.fxml";

    @FXML
    private GridPane buttonPane;

    @FXML
    private Label label;

    public RibbonComponentGroup() {
        super();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(RIBBON_COMPONENT_GROUP_FXML));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
             fxmlLoader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public GridPane getButtonPane() {
        return buttonPane;
    }

    public Label getLabel() {
        return label;
    }

    public String getLabelText(){
        return label.getText();
    }

    public void setLabelText(String text){
        label.setText(text);
    }

    public ObservableList<Node> getButtonChildren(){
        return buttonPane.getChildren();
    }

    @Override
    public String toString() {
        return "RibbonComponentGroup{" +
                "buttonPane=" + buttonPane +
                ", label=" + label +
                '}';
    }
}
