package be.iminds.ilabt.jfed.experimenter_gui.slices;

/**
 * User: twalcari
 * Date: 11/22/13
 * Time: 11:22 AM
 */
public class SlicesController {

    public SlicesController(){

    }
}
