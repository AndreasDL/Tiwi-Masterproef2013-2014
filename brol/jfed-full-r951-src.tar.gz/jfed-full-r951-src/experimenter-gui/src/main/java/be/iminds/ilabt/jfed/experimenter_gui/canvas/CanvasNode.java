package be.iminds.ilabt.jfed.experimenter_gui.canvas;

import be.iminds.ilabt.jfed.experimenter_gui.editor.ToolboxItem;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

/**
 * User: twalcari
 * Date: 10/18/13
 * Time: 5:16 PM
 */
public class CanvasNode extends Label implements ChangeListener<CanvasNode> {

    private static final Logger LOG = LogManager.getLogger();
    protected final ExperimentCanvas experimentCanvas;
    @FXML
    protected ImageView imageView;


    public CanvasNode(ExperimentCanvas experimentCanvas, String text, Image image) {
        this.experimentCanvas = experimentCanvas;
        FXMLLoader fxmlLoader = new FXMLLoader(CanvasNode.class.getResource("CanvasNode.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        this.setText(text);

        imageView.setImage(image);

        experimentCanvas.getSelectionProvider().selectedCanvasNodeProperty().addListener(this);
    }

    public CanvasNode(CanvasNode item) {
        this(item.experimentCanvas, item.getText(), item.getImageView().getImage());
    }

    public CanvasNode(ToolboxItem item, ExperimentCanvas experimentCanvas) {
        this(experimentCanvas, item.getText(), item.getImageView().getImage());
    }

    public ImageView getImageView() {
        return imageView;
    }

    /**
     * Helper method for changing the exterior of the node when it is selected in the ExperimentEditor.
     *
     * @param observableValue
     * @param oldValue
     * @param newValue
     */
    @Override
    public void changed(ObservableValue<? extends CanvasNode> observableValue,
                        CanvasNode oldValue, CanvasNode newValue) {
        this.setFocused(this == newValue);

    }


}
