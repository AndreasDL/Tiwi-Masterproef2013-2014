package be.iminds.ilabt.jfed.experimenter_gui.bugreporting;

import be.iminds.ilabt.jfed.connectivity_tester.AbstractConnectivityTest;
import be.iminds.ilabt.jfed.connectivity_tester.ConnectivityTest;
import be.iminds.ilabt.jfed.log.ApiCallDetails;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * User: twalcari
 * Date: 12/9/13
 * Time: 12:01 PM
 */

@XmlRootElement(name = "bugreport")
public class BugReport {

    private String description;
    private String environment;
    private String version;
    private String reporterCredential;
    private String mail;
    private List<ApiCallDetails> calls = null;
    private List<ConnectivityTest> connectivityTests = null;
    private List<LogLine> logLines = null;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getReporterCredential() {
        return reporterCredential;
    }

    public void setReporterCredential(String reporterCredential) {
        this.reporterCredential = reporterCredential;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    @XmlElementWrapper(name = "calls")
    @XmlElement(name = "call")
    public List<ApiCallDetails> getCalls() {
        return calls;
    }

    public void setCalls(List<ApiCallDetails> calls) {
        this.calls = calls;
    }

    @XmlElementWrapper(name = "connectivity-tests")
    @XmlElement(name = "connectivity-test", type= AbstractConnectivityTest.class)
    public List<ConnectivityTest> getConnectivityTests() {
        return connectivityTests;
    }

    public void setConnectivityTests(List<ConnectivityTest> connectivityTests) {
        this.connectivityTests = connectivityTests;
    }

    @XmlElementWrapper(name = "log")
    @XmlElement(name = "logline")
    public List<LogLine> getLogLines() {
        return logLines;
    }

    public void setLogLines(List<LogLine> logLines) {
        this.logLines = logLines;
    }
}
