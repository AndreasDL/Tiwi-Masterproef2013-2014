package be.iminds.ilabt.jfed.experimenter_gui.slice.raw;

import be.iminds.ilabt.jfed.experimenter_gui.slice.SliceController;
import be.iminds.ilabt.jfed.experimenter_gui.ui.code.XmlCodeView;
import be.iminds.ilabt.jfed.highlevel.model.Sliver;
import be.iminds.ilabt.jfed.highlevel.model.rspec_source.ManifestRspecSource;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.rspec.model.InvalidRspecException;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * User: twalcari
 * Date: 2/6/14
 * Time: 8:17 AM
 */
public class TestBedStatusView extends VBox {

    private static final Logger LOG = LoggerFactory.getLogger(TestBedStatusView.class);
    private static final String TESTBED_STATUS_VIEW_FXML = "TestBedStatusView.fxml";

    private final SliceController sliceController;
    private final RawSliceView rawSliceView;
    private final Sliver sliver;
    private ModelRspec modelRspec;

    @FXML
    private Label testbedNameLabel;

    @FXML
    private Label testbedStatusLabel;

    @FXML
    private Button switchViewButton;

    @FXML
    private StackPane detailsStackPane;

    @FXML
    private TableView<RspecNode> nodesTableView;

    @FXML
    private TableColumn<RspecNode, String> nodeNameTableColumn;

    @FXML
    private TableColumn<RspecNode, String> hostnameTableColumn;

    @FXML
    private TableColumn<RspecNode, Number> portTableColumn;

    @FXML
    private TableColumn<RspecNode, String> usernameTableColumn;

    @FXML
    private TableColumn<RspecNode, Boolean> loginTableColumn;

    @FXML
    private XmlCodeView manifestXmlView;

    public TestBedStatusView(final SliceController sliceController, final RawSliceView rawSliceView, final Sliver sliver) {
        this.sliceController = sliceController;
        this.rawSliceView = rawSliceView;
        this.sliver = sliver;

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(TESTBED_STATUS_VIEW_FXML));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        //initialize view
        prefWidthProperty().bind(rawSliceView.getTestbedsScrollPane().widthProperty().subtract(10));
        detailsStackPane.prefWidthProperty().bind(widthProperty().subtract(20));

        nodeNameTableColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<RspecNode, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<RspecNode, String> t) {
                return new ReadOnlyStringWrapper(t.getValue().getId());
            }
        });

        hostnameTableColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<RspecNode, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<RspecNode, String> t) {
                if (!t.getValue().getLoginServices().isEmpty()) {
                    return new ReadOnlyStringWrapper(t.getValue().getLoginServices().get(0).getHostname());
                } else
                    return null;
            }
        });

        portTableColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<RspecNode, Number>, ObservableValue<Number>>() {
            @Override
            public ObservableValue<Number> call(TableColumn.CellDataFeatures<RspecNode, Number> t) {
                if (!t.getValue().getLoginServices().isEmpty()) {
                    try {
                        return new ReadOnlyIntegerWrapper(Integer.parseInt(t.getValue().getLoginServices().get(0).getPort()));
                    } catch (NumberFormatException ex) {
                        LOG.error("Could not convert loginService port to number.", ex);
                        return null;
                    }
                } else
                    return null;
            }
        });

        usernameTableColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<RspecNode, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<RspecNode, String> t) {
                if (!t.getValue().getLoginServices().isEmpty()) {
                    return new ReadOnlyStringWrapper(t.getValue().getLoginServices().get(0).getUsername());
                } else
                    return null;
            }
        });

        loginTableColumn.setCellValueFactory(
                new Callback<TableColumn.CellDataFeatures<RspecNode, Boolean>,
                        ObservableValue<Boolean>>() {

                    @Override
                    public ObservableValue<Boolean> call(TableColumn.CellDataFeatures<RspecNode, Boolean> p) {
                        return new SimpleBooleanProperty(p.getValue() != null);
                    }
                });

        loginTableColumn.setCellFactory(new Callback<TableColumn<RspecNode, Boolean>, TableCell<RspecNode, Boolean>>() {
            @Override
            public TableCell<RspecNode, Boolean> call(TableColumn<RspecNode, Boolean> t) {
                return new TableCell<RspecNode, Boolean>() {
                    @Override
                    protected void updateItem(Boolean item, boolean empty) {
                        if (empty) {
                            setText(null);
                            setGraphic(null);
                        } else {
                            final Button loginButton = new Button("Login");
                            loginButton.setOnAction(new EventHandler<ActionEvent>() {
                                @Override
                                public void handle(ActionEvent actionEvent) {
                                    sliceController.launchSSHTerminal((RspecNode) getTableRow().getItem());
                                }
                            });
                            setGraphic(loginButton);
                            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                        }
                    }
                };
            }
        });

        //set tablecolumn widths
        nodeNameTableColumn.prefWidthProperty().bind(
                nodesTableView.widthProperty().subtract(loginTableColumn.getPrefWidth() + 2).multiply(0.3));
        hostnameTableColumn.prefWidthProperty().bind(
                nodesTableView.widthProperty().subtract(loginTableColumn.getPrefWidth() + 2).multiply(0.3));
        portTableColumn.prefWidthProperty().bind(
                nodesTableView.widthProperty().subtract(loginTableColumn.getPrefWidth() + 2).multiply(0.2));
        usernameTableColumn.prefWidthProperty().bind(
                nodesTableView.widthProperty().subtract(loginTableColumn.getPrefWidth() + 2).multiply(0.2));


        //load model into view
        testbedNameLabel.setText(sliver.getAuthority().getName());

        updateSliverStatus(sliver.getStatus());
        sliver.statusProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
                updateSliverStatus(sliver.getStatus());
            }
        });

        sliver.manifestRspecProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
                processSliverManifest();
            }
        });
        if (sliver.getManifestRspec() != null) {
            processSliverManifest();
        }

        LOG.debug("Initialized TestBedStatusView for sliver {}", sliver.getUrn());

    }

    private void processSliverManifest() {
        if (sliver.getManifestRspec() == null)
            return;
        try {
            processSliverManifest(
                    (ManifestRspecSource) sliver.getManifestRspec().getRSpec());
        } catch (InvalidRspecException ex) {
            LOG.error("Unable to process sliver {} manifest Rspec", sliver.getUrn(), ex);
            showUnprocessableManifestError();
        }
    }


    private void processSliverManifest(ManifestRspecSource manifestRspecSource) {
        try {
            manifestXmlView.setContent(manifestRspecSource.getRspecXmlString());
            switchViewButton.setDisable(false);

            this.modelRspec = manifestRspecSource.getModelRspec();

            if (modelRspec == null)
                throw new InvalidRspecException("Did not receive a parse model");

            nodesTableView.setItems(modelRspec.getNodes());


        } catch (InvalidRspecException ex) {
            LOG.error("Unable to process sliver {} manifest Rspec", sliver.getUrn(), ex);
            showUnprocessableManifestError();
        }
    }

    private void showUnprocessableManifestError() {
        nodesTableView.setVisible(false);
        switchViewButton.setDisable(true);
        switchViewButton.setText("Nodes Info Unavailable");
    }


    private void updateSliverStatus(SliverStatus sliverStatus) {
        testbedStatusLabel.setText(sliverStatus.name());

        //remove all old styleclasses
        for (SliverStatus s : SliverStatus.values()) {
            testbedStatusLabel.getStyleClass().remove(statusToStyleClass(s));
        }
        //apply new styleclasses
        testbedStatusLabel.getStyleClass().add(statusToStyleClass(sliverStatus));
    }

    private static String statusToStyleClass(SliverStatus status) {
        switch (status) {
            case READY:
                return "testbed-status-ready";

            case CHANGING:
                return "testbed-status-changing";

            case FAIL:
                return "testbed-status-fail";

            case UNALLOCATED:
                return "testbed-status-unallocated";

            case UNINITIALISED:
                return "testbed-status-uninitialised";

            case UNKNOWN:
                return "testbed-status-unknown";
            default:
                throw new IllegalArgumentException();
        }
    }


    @FXML
    private void switchViewAction() {
        assert (manifestXmlView != null);
        if (nodesTableView.isVisible()) {
            nodesTableView.setVisible(false);
            switchViewButton.setText("Show Nodes Info");
        } else {
            nodesTableView.setVisible(true);
            switchViewButton.setText("Show Manifest XML");
        }
    }
}
