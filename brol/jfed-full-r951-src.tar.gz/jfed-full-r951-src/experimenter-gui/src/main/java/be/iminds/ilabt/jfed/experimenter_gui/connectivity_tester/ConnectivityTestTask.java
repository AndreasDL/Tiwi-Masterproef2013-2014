package be.iminds.ilabt.jfed.experimenter_gui.connectivity_tester;

import be.iminds.ilabt.jfed.connectivity_tester.ConnectivityTest;
import be.iminds.ilabt.jfed.experimenter_gui.ui.status.TaskStatusIndicator;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.concurrent.Task;

/**
 * User: twalcari
 * Date: 1/6/14
 * Time: 11:57 AM
 */
public class ConnectivityTestTask extends Task<TaskStatusIndicator.Status> {
    public static final double TASK_STARTED=0.5, TASK_ENDED = 1;
    private static final double END_STATUS = 1;

    private final ConnectivityTest test;
    private ObjectProperty<ConnectivityTest.Status> status = new SimpleObjectProperty<>(null);

    public ConnectivityTest.Status getStatus() {
        return status.get();
    }

    public ObjectProperty<ConnectivityTest.Status> statusProperty() {
        return status;
    }

    public ConnectivityTestTask(ConnectivityTest test) {
        this.test = test;
    }

    @Override
    protected TaskStatusIndicator.Status call() throws Exception {
        updateProgress(TASK_STARTED, END_STATUS);

        ConnectivityTest.Status ctStatus = test.call();

        status.set(ctStatus);

        updateProgress(TASK_ENDED, END_STATUS);

        switch (ctStatus) {
            case FAILED:
                return TaskStatusIndicator.Status.FAILED;
            case WARNING:
                return TaskStatusIndicator.Status.WARNING;
            case SUCCEEDED:
                return TaskStatusIndicator.Status.SUCCESS;
            case SKIPPED:
                return TaskStatusIndicator.Status.INACTIVE;
            default:
                throw new IllegalStateException();
        }

    }

    public ConnectivityTest getTest() {
        return test;
    }
}
