package be.iminds.ilabt.jfed.experimenter_gui.canvas.impl;

import be.iminds.ilabt.jfed.experimenter_gui.canvas.CanvasLink;
import be.iminds.ilabt.jfed.experimenter_gui.canvas.ExperimentCanvas;
import be.iminds.ilabt.jfed.rspec.model.RspecInterface;
import be.iminds.ilabt.jfed.rspec.model.RspecLink;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Visualisation class for Rspec links.
 * <p/>
 * These can have a connection to more than two nodes, and are thus a collection of
 * two OR MORE links to a central "link"-component
 * User: twalcari
 * Date: 11/13/13
 * Time: 9:22 AM
 */
public class RspecCanvasLink implements ListChangeListener<RspecInterface> {

    private static final String LINK_CENTER_STYLECLASS = "link-center";
    private final RspecLink link;
    private final ExperimentCanvas experimentCanvas;
    private final LinkCenter linkCenter;
    private final Map<RspecInterface, InterfaceLink> links = new HashMap<>();
    private final ChangeListener updateOnLayoutXYChange = new ChangeListener<Double>() {
        @Override
        public void changed(ObservableValue<? extends Double> ov, Double t, Double t1) {
            updateLayout();
        }
    };
    private final ChangeListener updateOnBoundsChange = new ChangeListener<Bounds>() {
        @Override
        public void changed(ObservableValue<? extends Bounds> ov, Bounds t, Bounds t1) {
            updateLayout();
        }
    };
    private double centerX, centerY;
    private final ObjectProperty<EventHandler<MouseEvent>> onMouseClicked = new SimpleObjectProperty<>();

    public RspecCanvasLink(RspecLink link, ExperimentCanvas experimentCanvas) {
        this.link = link;
        this.experimentCanvas = experimentCanvas;

        //create centernode
        this.linkCenter = new LinkCenter();
        experimentCanvas.getCanvas().getChildren().add(linkCenter);


        //add links between center and RspecNode

        for (RspecInterface iface : link.getInterfaces()) {
            addInterface(iface);
        }

        link.getInterfaces().addListener(this);
    }

    private void addInterface(RspecInterface iface) {
        assert (!links.containsKey(iface));

        RspecCanvasNode rspecCanvasNode = experimentCanvas.getRspecCanvasNode(iface.getNode());
        assert (rspecCanvasNode != null);

        rspecCanvasNode.layoutXProperty().addListener(updateOnLayoutXYChange);
        rspecCanvasNode.layoutYProperty().addListener(updateOnLayoutXYChange);
        rspecCanvasNode.boundsInLocalProperty().addListener(updateOnBoundsChange);


        InterfaceLink canvasLink = new InterfaceLink(iface, rspecCanvasNode, linkCenter);

        links.put(iface, canvasLink);

        //add as first element to make sure that links are rendered first, and are thus overriden by nodes
        experimentCanvas.getCanvas().getChildren().add(0, canvasLink);

        updateLayout();
    }

    private void removeInterface(RspecInterface iface) {
        InterfaceLink canvasLink = links.get(iface);
        RspecCanvasNode rspecCanvasNode = canvasLink.getNodeA();

        rspecCanvasNode.layoutXProperty().removeListener(updateOnLayoutXYChange);
        rspecCanvasNode.layoutYProperty().removeListener(updateOnLayoutXYChange);
        rspecCanvasNode.boundsInLocalProperty().removeListener(updateOnBoundsChange);

        experimentCanvas.getCanvas().getChildren().remove(canvasLink);
        links.remove(iface);
        updateLayout();

        if (links.size() == 1) {
            experimentCanvas.getModelRspec().deleteLink(link);
        }
    }

    private void updateLayout() {
        if (links.isEmpty()) return;

        centerX = 0;
        centerY = 0;
        for (InterfaceLink ntlcLink : links.values()) {
            RspecCanvasNode node = ntlcLink.getNodeA();

            centerX += CanvasLink.getCenterX(node);
            centerY += CanvasLink.getCenterY(node);
        }
        centerX /= links.size();
        centerY /= links.size();

        CanvasLink.setCenterX(centerX, linkCenter);
        CanvasLink.setCenterY(centerY, linkCenter);
    }

    /**
     * Should be called when the RspecCanvasLink is removed from the canvas
     */
    public void remove() {
        experimentCanvas.getCanvas().getChildren().remove(linkCenter);

        for (InterfaceLink ntlcLink : links.values()) {
            experimentCanvas.getCanvas().getChildren().remove(ntlcLink);
        }

        link.getInterfaces().removeListener(this);
    }

    @Override
    public void onChanged(Change<? extends RspecInterface> change) {
        while (change.next()) {
            if (change.wasAdded()) {
                for (RspecInterface iface : change.getAddedSubList()) {
                    addInterface(iface);
                }
            }

            if (change.wasRemoved()) {
                for (RspecInterface iface : change.getRemoved()) {
                    removeInterface(iface);
                }
            }
        }
    }

    public double getCenterX() {
        return centerX;
    }

    public double getCenterY() {
        return centerY;
    }

    public RspecLink getRspecLink() {
        return link;
    }

    public Button getLinkCenter() {
        return linkCenter;
    }

    public Collection<InterfaceLink> getInterfaceLinks() {
        return links.values();
    }

    public void setOnMouseClicked(EventHandler<MouseEvent> onMouseClicked) {
        this.onMouseClicked.set(onMouseClicked);
    }

    public EventHandler<MouseEvent> getOnMouseClicked() {
        return onMouseClicked.get();
    }

    public class LinkCenter extends Button {

        public LinkCenter() {
            super();
            textProperty().bind(link.idProperty());

            getStyleClass().add(LINK_CENTER_STYLECLASS);
            setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    onLinkCenterClicked();
                }
            });
            layoutBoundsProperty().addListener(new InvalidationListener() {
                @Override
                public void invalidated(Observable observable) {
                    updateLayout();
                }
            });
            focusedProperty().addListener(new ChangeListener<Boolean>() {
                @Override
                public void changed(ObservableValue<? extends Boolean> observableValue, Boolean oldValue, Boolean newValue) {
                    for (CanvasLink cl : links.values()) {
                        cl.setSelected(newValue);

                    }
                }
            });

            onMouseClickedProperty().bind(RspecCanvasLink.this.onMouseClicked);
        }

        public RspecLink getRspecLink() {
            return link;
        }

        private void onLinkCenterClicked() {
            experimentCanvas.getSelectionProvider().setSelectedCanvasLink(RspecCanvasLink.this);
        }

        public RspecCanvasLink getRspecCanvasLink() {
            return RspecCanvasLink.this;
        }
    }


    public class InterfaceLink extends CanvasLink {
        private final RspecInterface rspecInterface;

        public InterfaceLink(RspecInterface rspecInterface, RspecCanvasNode nodeA, Button nodeB) {
            super(nodeA, nodeB);
            this.rspecInterface = rspecInterface;

            onMouseClickedProperty().bind(RspecCanvasLink.this.onMouseClicked);

        }

        @Override
        public Button getNodeB() {
            return (Button) super.getNodeB();
        }

        @Override
        public void setNodeB(Node nodeB) {
            if (nodeB instanceof Button)
                super.setNodeB(nodeB);
            else
                throw new IllegalArgumentException("nodeB must be of type Button fro InterfaceLink");
        }

        @Override
        public RspecCanvasNode getNodeA() {
            return (RspecCanvasNode) super.getNodeA();
        }

        @Override
        public void setNodeA(Node nodeA) {
            if (nodeA instanceof RspecCanvasNode)
                super.setNodeA(nodeA);
            else
                throw new IllegalArgumentException("nodeA must be of type RspecCanvasNode fro InterfaceLink");
        }

        public RspecInterface getRspecInterface() {
            return rspecInterface;
        }


    }
}
