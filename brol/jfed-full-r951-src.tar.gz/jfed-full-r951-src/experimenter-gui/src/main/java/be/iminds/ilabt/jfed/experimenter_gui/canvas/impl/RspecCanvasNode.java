package be.iminds.ilabt.jfed.experimenter_gui.canvas.impl;

import be.iminds.ilabt.jfed.experimenter_gui.canvas.CanvasNode;
import be.iminds.ilabt.jfed.experimenter_gui.canvas.ExperimentCanvas;
import be.iminds.ilabt.jfed.experimenter_gui.util.ImageUtil;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;

/**
 * User: twalcari
 * Date: 11/8/13
 * Time: 12:13 PM
 */
public class RspecCanvasNode extends CanvasNode {

    private final RspecNode node;


    public RspecCanvasNode(RspecNode node, ExperimentCanvas experimentCanvas) {
        super(experimentCanvas, node.getId(), ImageUtil.getRspecNodeImage(node));
        this.node = node;

        idProperty().bind(node.idProperty());
        textProperty().bind(node.idProperty());

        layoutXProperty().bindBidirectional(node.editorXProperty());
        layoutYProperty().bindBidirectional(node.editorYProperty());
    }

    private void onConfigurePressed() {
    }

    private void onDeletePressed() {
        experimentCanvas.getModelRspec().deleteNode(node);
    }

    public RspecNode getRspecNode() {
        return node;
    }

}
