package be.iminds.ilabt.jfed.experimenter_gui.slice.progress;

import be.iminds.ilabt.jfed.experimenter_gui.ui.status.TaskStatusIndicator;
import javafx.beans.property.*;

/**
 * User: twalcari
 * Date: 11/27/13
 * Time: 11:41 AM
 */
public class ProgressItem {


    private final ObjectProperty<TaskStatusIndicator.Status> progress = new SimpleObjectProperty<>();
    private final StringProperty text = new SimpleStringProperty();

    public ProgressItem(String text, TaskStatusIndicator.Status progress) {
        this.progress.set(progress);
        this.text.set(text);
    }

    public ProgressItem(String text){
        this(text, TaskStatusIndicator.Status.INACTIVE);
    }


    public TaskStatusIndicator.Status getProgress() {
        return progress.get();
    }

    public ObjectProperty<TaskStatusIndicator.Status> progressProperty() {
        return progress;
    }

    public String getText() {
        return text.get();
    }

    public StringProperty textProperty() {
        return text;
    }

    public void setProgress(TaskStatusIndicator.Status progress) {
        this.progress.set(progress);
    }

    public void setText(String text) {
        this.text.set(text);
    }
}
