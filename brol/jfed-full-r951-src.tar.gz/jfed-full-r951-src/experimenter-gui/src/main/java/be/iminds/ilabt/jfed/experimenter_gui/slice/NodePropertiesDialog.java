package be.iminds.ilabt.jfed.experimenter_gui.slice;

import be.iminds.ilabt.jfed.highlevel.model.Slice;
import be.iminds.ilabt.jfed.highlevel.model.rspec_source.ManifestRspecSource;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;

/**
 * User: twalcari
 * Date: 1/17/14
 * Time: 10:33 AM
 */
public class NodePropertiesDialog extends BorderPane {
    private static final Logger LOG = LoggerFactory.getLogger(NodePropertiesDialog.class);

    private static final String NODE_PROPERTIES_FXML = "NodeProperties.fxml";
    private final boolean valid;
    private final Slice slice;
    private final RspecNode node;
    @FXML
    private Label authenticationTypeLabel;
    @FXML
    private Label titleLabel;
    @FXML
    private TextField hostnameTextField;
    @FXML
    private TextField usernameTextField;
    @FXML
    private TextField portTextField;


    private NodePropertiesDialog(Slice slice, RspecNode node) {
        this.slice = slice;
        this.node = node;

        if (node == null) { LOG.warn("Unexpected null in NodePropertiesDialog: NodePropertiesDialog(slice, null)"); valid = false; return; }
        if (slice.getManifestRspec() == null) { LOG.warn("Unexpected null in NodePropertiesDialog: slice.getManifestRspec() == null"); valid = false; return; }
//        RspecNode manifestRspecNode = slice.getManifestRspec().getModelRspec().getNodeById(node.getId());
        List<ManifestRspecSource.LoginService> loginServices = slice.getManifestRspec().getNodeLoginInfo(node);

//        if (manifestRspecNode == null) { LOG.warn("Unexpected null in NodePropertiesDialog: manifestRspecNode == null"); valid = false; return; }
//

        //this hack is now in ManifestRspecSource
//        if (manifestRspecNode.getLoginServices().isEmpty()) {
//            ///////////// HACK to make PLE work /////////////
//            //ple changes node id in manifest (which is a major bug on their part)
//            //if ple and if can find node for same component manager, use that one instead!
//            if (node.getComponentManagerId().contains("ple:ibbtple")) {
//                LOG.warn("No node with login info found: Using hack for PLE to find a node that might match");
//                String searchedComponentId = node.getComponentId();
//                for (RspecNode altNode : slice.getManifestRspec().getModelRspec().getNodes()) {
//                    LOG.warn("  PLE hack: checking if node for \"" + altNode.getComponentId() + "\" matches searched component id \"" + searchedComponentId + "\"");
//                    if (altNode.getComponentId() != null && altNode.getComponentId().equals(searchedComponentId))
//                        manifestRspecNode = altNode;
//                }
//
//                if (manifestRspecNode.getLoginServices().size() > 0) {
//                    LOG.warn("===> PLE HACK successfully found a node to login to. Not guaranteed to be the correct node if multiple for the same component_id exist.");
//                } else {
//                    LOG.warn("===> PLE HACK failed to find login node");
//                }
//            }
//            ///////////// HACK to make PLE work /////////////
//
//        }


//        this.valid = !manifestRspecNode.getLoginServices().isEmpty();
        this.valid = loginServices != null && !loginServices.isEmpty();

        if (!valid)
            return;


        //initialize the Scene
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(NODE_PROPERTIES_FXML));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }


        titleLabel.setText(titleLabel.getText().replace("{}", node.getId()));


//        RspecNode.LoginService loginService = manifestRspecNode.getLoginServices().get(0);
        ManifestRspecSource.LoginService loginService = loginServices.get(0);
        authenticationTypeLabel.setText(loginService.getAuthentication());
        hostnameTextField.setText(loginService.getHostname());
        portTextField.setText(loginService.getPort()+"");
        usernameTextField.setText(loginService.getUsername());


    }

    public static void showSimplePropertiesDialog(Slice slice, RspecNode node) {
        NodePropertiesDialog npd = new NodePropertiesDialog(slice, node);

        if (npd.isValid()) {
            Scene scene = new Scene(npd);

            Stage dialogStage = new Stage();
            dialogStage.setScene(scene);

            dialogStage.setTitle("Properties of " + node.getId());
            dialogStage.setResizable(false);
            dialogStage.showAndWait();
        } else {
            Dialogs.showWarningDialog(null,
                    "The selected node doesn't provide any information to perform an interactive login. Is this node ready?",
                    "No information available about this node");
        }

    }

    public boolean isValid() {
        return valid;
    }

    @FXML
    public void onOKAction() {
        Stage stage = (Stage) getScene().getWindow();
        stage.close();
    }
}
