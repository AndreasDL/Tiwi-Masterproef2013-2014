package be.iminds.ilabt.jfed.experimenter_gui.login;

import be.iminds.ilabt.jfed.experimenter_gui.model.ExperimenterModel;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.lowlevel.GeniUser;
import be.iminds.ilabt.jfed.lowlevel.userloginmodel.KeyCertUserLoginModel;
import be.iminds.ilabt.jfed.lowlevel.userloginmodel.UserLoginModel;
import be.iminds.ilabt.jfed.lowlevel.userloginmodel.UserLoginModelManager;
import be.iminds.ilabt.jfed.ssh_terminal_tool.putty.PuttyHelper;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.JavaFXLogger;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.apache.logging.log4j.LogManager;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * This logincontroller supports only one type of login: KEY_CERT_INTERNAL_INFO
 * <p/>
 * User: twalcari
 * Date: 10/31/13
 * Time: 5:27 PM
 */

public class UserLoginController extends BorderPane {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();
    @FXML
    private Label usernameLabel;
    @FXML
    private Label authorityLabel;
    @FXML
    private TextField fileInput;
    @FXML
    private Button fileBrowseButton;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label messageLabel;
    @FXML
    private ToggleButton advancedButton;
    @FXML
    private HBox bottomBar;
    @FXML
    private Button loginButton;

    private UserLoginModelManager userLoginModelManager;
    private ExperimenterModel experimenterModel;


    public UserLoginController() {
       this.experimenterModel = ExperimenterModel.getInstance();
        this.userLoginModelManager = experimenterModel.getUserLoginModelManager();
    }

    @FXML
    public void initialize() {

        if (userLoginModelManager.getUserLoginModelType() != UserLoginModelManager.UserLoginModelType.KEY_CERT_INTERNAL_INFO) {
            Dialogs.showErrorDialog(null,
                    "Unsupported login-model detected.",
                    "Only KEY_CERT_INTERNAL_INFO is supported, but got " + userLoginModelManager.getUserLoginModelType().name());

            userLoginModelManager.setUserLoginModelType(UserLoginModelManager.UserLoginModelType.KEY_CERT_INTERNAL_INFO);
        }

        switch (userLoginModelManager.getUserLoginModelType()) {
            case KEY_CERT_INTERNAL_INFO:
                KeyCertUserLoginModel m = userLoginModelManager.getKeyCertUserLoginModel();
                if (m.isPemGiven()) {
                    modelToGUI();
                    setMessage("Enter the password associated with the certificate", MessageType.INFO);

                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            passwordField.requestFocus();
                        }
                    });

//                    } else {
//                        setMessage("Invalid certificate. Please select another file.", MessageType.ERROR);
//                    }
                }
                break;
//            case PLANETLAB:
//
//                PlanetlabUserLoginModel m = userLoginModelManager.getPlanetlabUserLoginModel();
//                if(m.getSshPrivateKeyFile() != null){
//
//                    if(m.isValid()){
//                        setMessage("Enter the password associated with the Planetlab private key", MessageType.INFO);
//                    } else {
//                        setMessage("Invalid Planetlab private key. Please select another file.", MessageType.ERROR);
//                    }
//                }
//
//                break;

            default:
                throw new RuntimeException("Unexpected value " + userLoginModelManager.getUserLoginModelType());
        }
    }

    private void setMessage(String message, MessageType type) {
        messageLabel.setText(message);

        for (MessageType t : MessageType.values())
            messageLabel.getStyleClass().remove(t.getStyleName());

        messageLabel.getStyleClass().add(type.getStyleName());
    }

    private void readCertificate() {
        assert (userLoginModelManager.getUserLoginModelType() == UserLoginModelManager.UserLoginModelType.KEY_CERT_INTERNAL_INFO);

        KeyCertUserLoginModel m = userLoginModelManager.getKeyCertUserLoginModel();
        if (m.isPemGiven() && m.getUserUrnString() != null) {
            //derive username from userURN
            GeniUrn userUrn = GeniUrn.parse(m.getUserUrnString());
            usernameLabel.setText(userUrn.getResourceName());

            //get user-friendly authority name
            if (m.getUserAuthority() == null)
                throw new RuntimeException("Could not fetch User Authority. Are you connected to the Internet?");
            authorityLabel.setText(m.getUserAuthority().getName());

        } else {
            //reset to empty
            usernameLabel.setText("-");
            authorityLabel.setText("-");

        }
    }

    public void unlockAndLogin() {
        boolean unlocked = unlock();
        if (unlocked)
            login();
        else {
            LOG.info("Unlocking user certificate failed.");
            return;
        }
    }

    /**
     * Unlocks the certificate by decoding the private key with the given password
     *
     * @return
     */
    public boolean unlock() {
        final char[] password = passwordField.getText().toCharArray();

        KeyCertUserLoginModel m = null;
        m = userLoginModelManager.getKeyCertUserLoginModel();

        boolean success = m.unlock(password);
        if (success) {
            LOG.debug("Sucessfully decrypted certificate");
            setMessage("Logging in...", MessageType.INFO);
        } else {
            setMessage("Password isn't correct.\nPlease enter your password again.", MessageType.ERROR);
        }

        return success;
    }

    public void login() {
        boolean success = userLoginModelManager.login();
        LOG.debug("Login success=" + success);
        if (success) {
            //create a PPK encrypted with the same password, and store that PPK. Then forget the password.
            if (!passwordField.getText().isEmpty())
                PuttyHelper.makePpkIfNeeded(userLoginModelManager.getLoggedInGeniUser(), passwordField.getText());

            //forget password in GUI
            passwordField.setText("");

            //always save latest successful login details
            if (userLoginModelManager.hasChanged()) {
                userLoginModelManager.save();
            }
            assert loginButton.getScene().getWindow() instanceof Stage;
            ((Stage) loginButton.getScene().getWindow()).close();

        } else {
            UserLoginModel m = userLoginModelManager.getCurrentUserLoginModel();
            return;
        }
    }

    @FXML
    private void openCertificateFileChooser() {
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showOpenDialog(null);

        if (file != null) {
            KeyCertUserLoginModel m = userLoginModelManager.getKeyCertUserLoginModel();

            m.setKeyCertPemFile(file);
        }

        modelToGUI();
    }

    /**
     * This function gets all applicable information from the userLoginModel and puts it in the right fields of the GUI
     */
    private void modelToGUI() {
        KeyCertUserLoginModel m = userLoginModelManager.getKeyCertUserLoginModel();
        assert m != null;

        if (m.getKeyCertFile() != null && m.getKeyCertFile().exists()) {
            fileInput.setText(m.getKeyCertFile().getAbsolutePath());
            readCertificate();
        }
    }

    @FXML
    public void showAdvancedLogin() {
        advancedButton.getScene().getWindow().hide();

        be.iminds.ilabt.jfed.ui.javafx.userlogin.UserLoginController.showUserLogin(experimenterModel, false);

        if (!userLoginModelManager.isUserLoggedIn()) {
            Dialogs.showErrorDialog(null, "You did not succesfully log in. Quiting...");
            System.exit(0);
        }

    }

    private static enum MessageType {
        INFO("label-info"),
        WARNING("label-warning"),
        ERROR("label-error");
        private final String styleName;

        MessageType(String styleName) {
            this.styleName = styleName;
        }

        private String getStyleName() {
            return styleName;
        }
    }
}
