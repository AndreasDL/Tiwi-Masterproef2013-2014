package be.iminds.ilabt.jfed.experimenter_gui.slice;

import be.iminds.ilabt.jfed.experimenter_gui.model.ExperimenterModel;
import be.iminds.ilabt.jfed.experimenter_gui.preferences.PreferencesDialogFactory;
import be.iminds.ilabt.jfed.experimenter_gui.slice.progress.ProgressItem;
import be.iminds.ilabt.jfed.experimenter_gui.slice.progress.ProgressView;
import be.iminds.ilabt.jfed.experimenter_gui.slice.raw.RawSliceView;
import be.iminds.ilabt.jfed.experimenter_gui.ui.status.TaskStatusIndicator;
import be.iminds.ilabt.jfed.highlevel.controller.*;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.highlevel.model.Slice;
import be.iminds.ilabt.jfed.highlevel.model.Sliver;
import be.iminds.ilabt.jfed.highlevel.model.rspec_source.ManifestRspecSource;
import be.iminds.ilabt.jfed.highlevel.model.rspec_source.RequestRspecSource;
import be.iminds.ilabt.jfed.lowlevel.GeniUser;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.ssh_key_info.SshKeyInfo;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;
import be.iminds.ilabt.jfed.ssh_terminal_tool.ExternalSshTerminal;
import be.iminds.ilabt.jfed.ssh_terminal_tool.ssh_key_info.UserSshKeyInfo;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import be.iminds.ilabt.jfed.util.KeyUtil;
import be.iminds.ilabt.jfed.util.PreferencesUtil;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * User: twalcari
 * Date: 11/18/13
 * Time: 5:00 PM
 */
public class SliceController extends BorderPane {
    private static final Logger LOG = LoggerFactory.getLogger(SliceController.class);
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private final ModelSliceView modelSliceView;
    private final RawSliceView rawSliceView;

    private final ProgressView progressView = new ProgressView();
    private final EasyModel easyModel;
    private final ExperimenterModel experimenterModel;
    private final TaskThread tt = TaskThread.getInstance();
    private final HighLevelController hlc;
    private final RequestRspecSource requestRspecSource;
    private final String name;
    private final Map<Sliver, ChangeListener<SliverStatus>> sliverStatusListeners = new HashMap<>();
    private final StringProperty statusProperty = new SimpleStringProperty();
    private final ListChangeListener<Sliver> sliverListChangeListener = new ListChangeListener<Sliver>() {
        @Override
        public void onChanged(Change<? extends Sliver> change) {
            try {
                do {
                    for (final Sliver sliver : change.getAddedSubList()) {

                        onSliverUpdate(sliver, sliver.getStatus());
                        ChangeListener<SliverStatus> statusChangeListener =
                                new ChangeListener<SliverStatus>() {
                                    @Override
                                    public void changed(ObservableValue<? extends SliverStatus> observableValue, SliverStatus oldValue, SliverStatus newValue) {
                                        onSliverUpdate(sliver, newValue);

                                    }
                                };
                        sliverStatusListeners.put(sliver, statusChangeListener);
                        sliver.statusProperty().addListener(statusChangeListener);

                        LOG.debug("Adding progressItem for sliver " + sliver.getUrn());

                        final ProgressItem sliverReadyProgressItem =
                                new ProgressItem("Waiting for nodes from " + sliver.getAuthority().getName() + " to become ready.", TaskStatusIndicator.Status.BUSY);
                        progressView.getItems().add(sliverReadyProgressItem);

                        final ChangeListener<SliverStatus> sliverReadyListener =
                                new ChangeListener<SliverStatus>() {
                                    @Override
                                    public void changed(ObservableValue<? extends SliverStatus> observableValue, SliverStatus oldValue, SliverStatus newValue) {
                                        LOG.debug("Updating progress item for sliver {} to {}", sliver.getUrn(), newValue.name());

                                        boolean ended = true;

                                        if (newValue == SliverStatus.READY)
                                            sliverReadyProgressItem.setProgress(TaskStatusIndicator.Status.SUCCESS);
                                        else if (newValue == SliverStatus.FAIL)
                                            sliverReadyProgressItem.setProgress(TaskStatusIndicator.Status.FAILED);
                                        else
                                            ended = false;

                                        if (ended)
                                            sliver.statusProperty().removeListener(this);
                                    }
                                };
                        sliver.statusProperty().addListener(sliverReadyListener);
                        sliverReadyListener.changed(sliver.statusProperty(), sliver.getStatus(), sliver.getStatus());
                    }

                    for (Sliver sliver : change.getRemoved()) {
                        sliver.statusProperty().removeListener(sliverStatusListeners.get(sliver));
                        sliverStatusListeners.remove(sliver);
                    }
                } while (change.next());

            } catch (Exception ex) {
                LOG.error("Error while processing sliver change", ex);
                throw ex;
            }
        }
    };
    private DateTime expirationDate;
    //progressitems
    //private final ProgressItem createSliceProgressItem;
    //private final ProgressItem createSliversProgressItem;
    private Slice slice;

    //instance initializer
    {
        this.experimenterModel = ExperimenterModel.getInstance();
        this.easyModel = experimenterModel.getEasyModel();

        this.hlc = experimenterModel.getHighLevelController();
    }

    public SliceController(RequestRspecSource requestRspecSource, String name, DateTime expirationDate) {
        this.requestRspecSource = requestRspecSource;
        this.name = name;
        this.expirationDate = expirationDate;

        this.rawSliceView = new RawSliceView(this);
        if (!requestRspecSource.isXmlBased()) {
            //create experiment canvas
            this.modelSliceView = new ModelSliceView(this, requestRspecSource.getModelRspec());
            setCenter(modelSliceView);
        } else {
            this.modelSliceView = null;
            setCenter(rawSliceView);
        }
        setBottom(progressView);

        createSlice();
    }

    public SliceController(Slice slice) {
        this.slice = slice;
        this.requestRspecSource = slice.getRequestRspec();
        this.name = slice.getName();
        this.expirationDate = new DateTime(slice.getExpirationDate());

        this.rawSliceView = new RawSliceView(this, slice);
        if (!requestRspecSource.isXmlBased()) {
            //create experiment canvas
            this.modelSliceView = new ModelSliceView(this, slice.getRequestRspec().getModelRspec());
            setCenter(modelSliceView);
        } else {
            this.modelSliceView = null;
            setCenter(rawSliceView);
        }
        setBottom(progressView);

        //request status of slivers from all authorities
        restoreSlice();

    }

    public boolean isCanvasVisible() {
        return getCenter() == modelSliceView;
    }

    private void restoreSlice() {
        for (final Sliver sliver : slice.getSlivers()) {
            onSliverUpdate(sliver, sliver.getStatus());
            ChangeListener<SliverStatus> statusChangeListener =
                    new ChangeListener<SliverStatus>() {
                        @Override
                        public void changed(ObservableValue<? extends SliverStatus> observableValue, SliverStatus oldValue, SliverStatus newValue) {
                            onSliverUpdate(sliver, newValue);

                        }
                    };
            sliverStatusListeners.put(sliver, statusChangeListener);
            sliver.statusProperty().addListener(statusChangeListener);
        }
        //add listeners to sliver status
        slice.getSlivers().addListener(sliverListChangeListener);

        if (!requestRspecSource.getStringRspec().isWellFormed()) {
            Dialogs.showErrorDialog((Stage) SliceController.this.getScene().getWindow(),
                    "The RSpec XML is not well-formed. Cannot get Status.");
            return;
        }

        //request a status update from each authority
        for (final String componentManagerUrn : requestRspecSource.getAllComponentManagerUrns()) {
            final SfaAuthority auth = easyModel.getAuthorityList().getByUrn(componentManagerUrn).getSfaAuthority();
            Task manifestTask = hlc.getSliceManifest(slice, auth);

            ProgressItem manifestProgressItem =
                    new ProgressItem("Restore manifest from " + auth.getName(), TaskStatusIndicator.Status.BUSY);
            progressView.getItems().add(manifestProgressItem);
            manifestTask.addCallback(new ProgressItemTaskFinishedCallback(manifestProgressItem));

            tt.addTask(manifestTask);

            Task refreshTask = hlc.getSliceStatus(slice, auth);

            ProgressItem pi =
                    new ProgressItem("Restore node status from " + auth.getName(), TaskStatusIndicator.Status.BUSY);
            progressView.getItems().add(pi);
            refreshTask.addCallback(new ProgressItemTaskFinishedCallback(pi));
            refreshTask.addCallback(new TaskFinishedCallback() {
                @Override
                public void onTaskFinished(Task task, SingleTask singleTask, final SingleTask.TaskState state) {
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            if (state == SingleTask.TaskState.FAILED) {
                                if (modelSliceView != null) {
                                    //assume that the sliver is not longer allocated
                                    modelSliceView.onSliverUpdate(auth, SliverStatus.UNKNOWN);


                                } else {
                                    LOG.warn("Could not restore node status for authority {}", auth.getName());
                                }
                            }
                        }
                    });

                }
            });

            tt.addTask(refreshTask);
        }
    }

    private void createSlice() {
        final HighLevelController.CreateSliceTask createSliceTask = hlc.createSlice(name, expirationDate.toDate());

        ProgressItem createSliceProgressItem =
                new ProgressItem("Register experiment " + name, TaskStatusIndicator.Status.BUSY);
        progressView.getItems().add(createSliceProgressItem);
        createSliceTask.addCallback(new ProgressItemTaskFinishedCallback(createSliceProgressItem));
        createSliceTask.addCallback(new TaskFinishedCallback() {
            @Override
            public void onTaskFinished(Task task, SingleTask singleTask, SingleTask.TaskState state) {

                if (createSliceTask.getSlice() == null) {
                    LOG.error("Create Slice task failed.");
                    //an error occurred, stop the process!
                    return;
                }

                slice = createSliceTask.getSlice();

                //start initializing slivers
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        //show expiration in status
                        slice.expirationDateProperty().addListener(new InvalidationListener() {
                            @Override
                            public void invalidated(Observable observable) {
                                updateExpirationStatus();
                            }
                        });

                        //update raw view
                        if (rawSliceView != null) {
                            LOG.debug("Initializing slice in RawSliceView");
                            rawSliceView.setSlice(slice);
                        }

                        if (slice.getExpirationDate() != null)
                            updateExpirationStatus();

                        initializeSlivers();
                    }
                });

            }
        });

        tt.addTask(createSliceTask);
    }

    private void updateExpirationStatus() {

        statusProperty.set("This experiment run will expire at " + DATE_FORMAT.format(slice.getExpirationDate()));

    }

    private void initializeSlivers() {
        if (!requestRspecSource.getStringRspec().isWellFormed()) {
            Dialogs.showErrorDialog((Stage) SliceController.this.getScene().getWindow(),
                    "The RSpec XML is not well-formed. Cannot create slivers.");
            return;
        }

        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                Dialogs.showInformationDialog((Stage) SliceController.this.getScene().getWindow(),
                        "It will take some time to start and initialize all nodes. " +
                                "You will be able to login by right-clicking on the node when it becomes green. " +
                                "Typically it takes about 3 minutes. " +
                                "Planetlab nodes take about 10-15 minutes before you can login through ssh (after they become green).\n\n" +
                                "If SSH-login does not work when the node is green, try again after some time.",
                        "Your experiment run is initializing...",
                        "Experiment run is initializing");
            }
        });

        //assert (!HighLevelController.needsStitching(model));

        //by setting this property, the slivers are created
        slice.setRequestRspec(requestRspecSource);

        //set user key to key in login cert
        SshKeyInfo sshKeyInfo = new UserSshKeyInfo(experimenterModel.getGeniUserProvider().getLoggedInGeniUser());
        SshKeyInfo overrideSshKeyInfo = PreferencesUtil.getOverriddenSshKeyInfo();
        if (overrideSshKeyInfo != null)
            sshKeyInfo = overrideSshKeyInfo;
        if (sshKeyInfo.getPublicKey() != null)
            easyModel.addUserKey(KeyUtil.publicKeyToOpenSshAuthorizedKeysFormat(sshKeyInfo.getPublicKey()));
        else
            LOG.warn("No public key in sshKeyInfo (class=" + sshKeyInfo.getClass().getName() + ")");

        List<HighLevelController.CreateSliverTask> initTasks =
                hlc.createSliversNoStitching(slice, expirationDate.toDate());

        for (HighLevelController.CreateSliverTask initTask : initTasks) {
            ProgressItem pi = new ProgressItem("Initialize nodes at " + initTask.getSfaAuthority().getName(),
                    TaskStatusIndicator.Status.BUSY);
            progressView.getItems().add(pi);

            initTask.addCallback(new ProgressItemTaskFinishedCallback(pi));
            initTask.addCallback(new TaskFinishedCallback() {
                @Override
                public void onTaskFinished(Task task, SingleTask singleTask, SingleTask.TaskState state) {
                    HighLevelController.CreateSliverTask csTask = (HighLevelController.CreateSliverTask) task;

                    //only continue if previous call succeeded
                    if (state != SingleTask.TaskState.SUCCESS)
                        return;

                    final Sliver sliver = csTask.getSliver();
                    assert sliver != null;

                    onSliverUpdate(sliver, sliver.getStatus());
//                    ChangeListener<SliverStatus> statusChangeListener =
//                            new ChangeListener<SliverStatus>() {
//                                @Override
//                                public void changed(ObservableValue<? extends SliverStatus> observableValue,
//                                                    SliverStatus oldValue, SliverStatus newValue) {
//                                    onSliverUpdate(sliver, newValue);
//                                }
//                            };
//
//                    sliverStatusListeners.put(sliver, statusChangeListener);
//                    sliver.statusProperty().addListener(statusChangeListener);
//
//                    LOG.debug("SliceController.initializeSlivers is listening to changes in sliver status sliverurn=" + sliver.getUrn());
//
//                    final ProgressItem sliverReadyProgressItem =
//                            new ProgressItem("Waiting for nodes from " + sliver.getAuthority().getName() +
//                                    " to become ready.", TaskStatusIndicator.Status.BUSY);
//                    new SliverProgressItemChangeListener(sliver, sliverReadyProgressItem);
//
//                    Platform.runLater(new Runnable() {
//                        @Override
//                        public void run() {
//                            progressView.getItems().add(sliverReadyProgressItem);
//                        }
//                    });
//
//                    LOG.info("sliver urn: " + sliver.getUrn());
                }
            });
        }

        //add listeners to sliver status
        slice.getSlivers().addListener(sliverListChangeListener);

        tt.addTasks(initTasks);
    }

    private void onSliverUpdate(Sliver sliver, SliverStatus status) {
        LOG.debug("SliceController.onSliverUpdate state=" + status + " @ " + sliver.getAuthority().getUrn() + " sliverurn=" + sliver.getUrn());

        if (modelSliceView != null) {
            modelSliceView.onSliverUpdate(sliver, status);
        }
    }


    public void stopExperiment() {
        assert (slice != null);
        Task delTask = hlc.deleteSlice(slice);

        ProgressItem pi =
                new ProgressItem("Delete all active nodes from experiment '" + name + "'", TaskStatusIndicator.Status.BUSY);
        progressView.getItems().add(pi);
        delTask.addCallback(new ProgressItemTaskFinishedCallback(pi));

        tt.addTask(delTask);
    }

    public void requestUpdate() {
        Task updateTask = hlc.getSliceStatus(slice);

        ProgressItem pi = new ProgressItem("Update experiment status", TaskStatusIndicator.Status.BUSY);
        progressView.getItems().add(pi);
        updateTask.addCallback(new ProgressItemTaskFinishedCallback(pi));

        tt.addTask(updateTask);
    }

    public void launchSSHTerminal(RspecNode rspecNode) {
        ExternalSshTerminal externalSshterminal =
                new ExternalSshTerminal(experimenterModel.getProxyPreferencesManager());
        if (!externalSshterminal.isConfigured()) {
            Dialogs.showWarningDialog((Stage) this.getScene().getWindow(),
                    "jFed must be configured with the location of the terminal application and a valid Private Key.");
            PreferencesDialogFactory.showPreferencesDialog();
        }
        if (!externalSshterminal.isConfigured()) {
            Dialogs.showErrorDialog((Stage) this.getScene().getWindow(),
                    "jFed was not properly configured. Please configure jFed first, and try again.");
            return;
        }

        //get the associated manifest RSpec-node

        if (slice == null) {
            LOG.warn("Could not open SSH terminal: slice=null");
            Dialogs.showErrorDialog((Stage) this.getScene().getWindow(),
                    "There is currently insufficient information available to login.");
            return;
        } else if (slice.getManifestRspec() == null || rspecNode == null) {
            Dialogs.showErrorDialog((Stage) this.getScene().getWindow(),
                    "There is currently insufficient information available to login.");
            LOG.warn("Could not open SSH terminal: slice=" + slice + " slice.getManifestRspec()=" + slice.getManifestRspec() + " rspecNode=" + rspecNode);
            return;
        }

        final List<ManifestRspecSource.LoginService> loginServices =
                slice.getManifestRspec().getNodeLoginInfo(rspecNode);

        if (loginServices == null || loginServices.isEmpty()) {
            Dialogs.showErrorDialog((Stage) this.getScene().getWindow(),
                    "The selected node doesn't provide any information to perform an interactive login.",
                    "Could not open SSH terminal",
                    "Could not open SSH terminal",
                    new RuntimeException(
                            "node id=\"" + rspecNode.getId() + "\" "
                                    + slice.getAllLastReceivedRspecString().toString()));
            return;
        }

        GeniUser geniUser = experimenterModel.getGeniUserProvider().getLoggedInGeniUser();
        UserSshKeyInfo userSshKeyInfo = new UserSshKeyInfo(geniUser);

        externalSshterminal.launch(loginServices.get(0).getUsername(),
                loginServices.get(0).getHostname(),
                loginServices.get(0).getPort(),

                //info on the authority proxy. Note that this might not be used, if the preferences specify another proxy!
                geniUser.getUserAuthority().getProxies(),
                geniUser.getUserUrn().getResourceName()/* username */,
                userSshKeyInfo/* this is always the SSH key from log file. Even if other key is used, this is the info needed. The externalSshterminal will get key from preferences if needed. */);
    }

    public StringProperty statusProperty() {
        return statusProperty;
    }

    public void renewSlice() {

        //renew so that the slice will expire six hours from now
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR, 6);
        Date newExpirationDate = calendar.getTime();

        Task renewSliceTask = hlc.renewSlice(slice, newExpirationDate);

        tt.addTask(renewSliceTask);
    }

    /**
     * Returns whether this slice has active resources
     */
    public boolean isSliceActive() {

        if (slice == null)
            return false;

        for (Sliver sliver : slice.getSlivers()) {
            switch (sliver.getStatus()) {
                case READY:
                case UNKNOWN:
                case CHANGING:
                    return true;
            }
        }
        return false;
    }

    public Slice getSlice() {
        return slice;
    }

    public boolean switchToModelView() {
        if (requestRspecSource.isXmlBased())
            return false;

        assert (modelSliceView != null);
        setCenter(modelSliceView);
        return true;

    }

    public boolean switchToRawView() {

        assert (rawSliceView != null);
        setCenter(rawSliceView);
        return true;

    }

    public boolean isCanvasAvailable() {
        return !requestRspecSource.isXmlBased();
    }

    private static final class SliverProgressItemChangeListener implements ChangeListener<SliverStatus> {

        private final Sliver sliver;
        private final ProgressItem progressItem;

        private SliverProgressItemChangeListener(Sliver sliver, ProgressItem progressItem) {
            this.sliver = sliver;
            this.progressItem = progressItem;

            this.sliver.statusProperty().addListener(this);
        }

        @Override
        public void changed(ObservableValue<? extends SliverStatus> observableValue, SliverStatus oldValue, final SliverStatus newValue) {
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    if (newValue == SliverStatus.READY)
                        progressItem.setProgress(TaskStatusIndicator.Status.SUCCESS);
                    else if (newValue == SliverStatus.FAIL)
                        progressItem.setProgress(TaskStatusIndicator.Status.FAILED);
                }
            });

            if (newValue == SliverStatus.READY || newValue == SliverStatus.FAIL) {
                sliver.statusProperty().removeListener(this);
            }

        }
    }

    private static final class ProgressItemTaskFinishedCallback implements TaskFinishedCallback {
        private final ProgressItem progressItem;

        public ProgressItemTaskFinishedCallback(ProgressItem progressItem) {
            this.progressItem = progressItem;
        }

        @Override
        public void onTaskFinished(final Task task, final SingleTask singleTask, final SingleTask.TaskState state) {

            Platform.runLater(new Runnable() {
                public void run() {
                    if (state == SingleTask.TaskState.SUCCESS)
                        progressItem.setProgress(TaskStatusIndicator.Status.SUCCESS);
                    else if (state == SingleTask.TaskState.FAILED || state == SingleTask.TaskState.CANCELLED)
                        progressItem.setProgress(TaskStatusIndicator.Status.FAILED);
                    else
                        throw new IllegalStateException("Did not expected state " + state.name()
                                + " for finished task " + task.toString());
                }
            });

        }
    }
}
