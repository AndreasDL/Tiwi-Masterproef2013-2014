package be.iminds.ilabt.jfed.experimenter_gui.canvas;

import be.iminds.ilabt.jfed.experimenter_gui.canvas.impl.RspecCanvasLink;
import be.iminds.ilabt.jfed.experimenter_gui.canvas.impl.RspecCanvasNode;
import be.iminds.ilabt.jfed.experimenter_gui.editor.ExperimentEditor;
import be.iminds.ilabt.jfed.experimenter_gui.editor.NewCanvasLink;
import be.iminds.ilabt.jfed.experimenter_gui.editor.bo.NodeDescription;
import be.iminds.ilabt.jfed.experimenter_gui.editor.bo.RspecNodeDescription;
import be.iminds.ilabt.jfed.experimenter_gui.editor.impl.NodeDescriptionToolboxItem;
import be.iminds.ilabt.jfed.experimenter_gui.editor.properties.SimplePropertiesDialog;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.RspecInterface;
import be.iminds.ilabt.jfed.rspec.model.RspecLink;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import be.iminds.ilabt.jfed.ui.rspeceditor.editor.ComponentManagerInfo;
import com.cathive.fonts.fontawesome.FontAwesomeIcon;
import com.cathive.fonts.fontawesome.FontAwesomeIconView;
import javafx.beans.property.ReadOnlyListProperty;
import javafx.beans.property.ReadOnlyListWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Bounds;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * User: twalcari
 * Date: 11/18/13
 * Time: 5:11 PM
 */
public class EditableExperimentCanvas extends ExperimentCanvas {
    private static final Logger LOG = LoggerFactory.getLogger(EditableExperimentCanvas.class);
    private static final double EDITOR_LOCATION_SHIFT = 15;

    private final Map<RspecNode, NodeDescription> nodeDescriptionMap = new HashMap<>();
    private final ObservableList<CanvasNode> clipboard = FXCollections.observableArrayList();


    private final NewCanvasLink newCanvasLink;
    private final ContextMenu nodeContextMenu;
    private final ContextMenu linkContextMenu;
    private final ContextMenu linkInterfaceContextMenu;
    private final ExperimentEditor experimentEditor;

    public EditableExperimentCanvas(ExperimentEditor experimentEditor, ModelRspec model) {
        super(model);
        this.experimentEditor = experimentEditor;
        this.newCanvasLink = new NewCanvasLink(this);

        this.setOnMouseDragReleased(new EventHandler<MouseDragEvent>() {
            @Override
            public void handle(MouseDragEvent mouseDragEvent) {
                onMouseDragReleased(mouseDragEvent);
            }
        });


        // create context menus

        this.nodeContextMenu = new ContextMenu();

        FontAwesomeIconView configureIcon = new FontAwesomeIconView();
        configureIcon.setIcon(FontAwesomeIcon.ICON_PENCIL);
        MenuItem configureItem = new MenuItem("Configure node", configureIcon);
        configureItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                assert (getSelectionProvider().getSelectedCanvasNode() instanceof RspecCanvasNode);
                RspecCanvasNode rspecCanvasNode = (RspecCanvasNode) getSelectionProvider().getSelectedCanvasNode();

                onConfigurePressed(rspecCanvasNode);
            }
        });
        nodeContextMenu.getItems().add(configureItem);

        FontAwesomeIconView deleteIcon = new FontAwesomeIconView();
        deleteIcon.setIcon(FontAwesomeIcon.ICON_REMOVE);
        MenuItem deleteItem = new MenuItem("Delete", deleteIcon);
        deleteItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                assert (getSelectionProvider().getSelectedCanvasNode() instanceof RspecCanvasNode);
                RspecCanvasNode rspecCanvasNode = (RspecCanvasNode) getSelectionProvider().getSelectedCanvasNode();

                onDeleteNodePressed(rspecCanvasNode);
            }
        });
        nodeContextMenu.getItems().add(deleteItem);

        //contextMenu for links
        this.linkContextMenu = new ContextMenu();

        MenuItem linkDeleteItem = new MenuItem("Delete", deleteIcon);
        linkDeleteItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                RspecCanvasLink rspecCanvasLink = getSelectionProvider().getSelectedCanvasLink();

                onDeleteLinkPressed(rspecCanvasLink);
            }
        });
        linkContextMenu.getItems().add(linkDeleteItem);

        //contextMenu for interfaces
        this.linkInterfaceContextMenu = new ContextMenu();

        MenuItem linkInterfaceDeleteItem = new MenuItem("Delete", deleteIcon);
        linkInterfaceDeleteItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                RspecCanvasLink.InterfaceLink ifaceLink = getSelectionProvider().getSelectedInterfaceLink();
                assert (ifaceLink != null);

                onDeleteLinkInterfacePressed(ifaceLink);
            }
        });
        linkInterfaceContextMenu.getItems().add(linkInterfaceDeleteItem);


    }

    private void onDeleteLinkInterfacePressed(RspecCanvasLink.InterfaceLink ifaceLink) {
        ifaceLink.getRspecInterface().delete();
    }

    private void onConfigurePressed(RspecCanvasNode rspecCanvasNode) {
        SimplePropertiesDialog.showSimplePropertiesDialog(model, rspecCanvasNode.getRspecNode());
    }

    private void onDeleteNodePressed(RspecCanvasNode rspecCanvasNode) {
        model.deleteNode(rspecCanvasNode.getRspecNode());
    }

    private void onDeleteLinkPressed(RspecCanvasLink rspecCanvasLink) {
        model.deleteLink(rspecCanvasLink.getRspecLink());
    }

    @Override
    protected void canvasItemOnMouseClicked(MouseEvent mouseEvent) {
        super.canvasItemOnMouseClicked(mouseEvent);

        if (mouseEvent.getSource() instanceof RspecCanvasNode)
            if (mouseEvent.getButton() != MouseButton.PRIMARY || mouseEvent.isControlDown()) {

                getSelectionProvider().setSelectedCanvasNode((RspecCanvasNode) mouseEvent.getSource());
                //show context menu
                nodeContextMenu.show((Node) mouseEvent.getSource(),
                        mouseEvent.getScreenX(), mouseEvent.getScreenY());


            }

        if (mouseEvent.getSource() instanceof RspecCanvasLink.LinkCenter) {
            if (mouseEvent.getButton() != MouseButton.PRIMARY || mouseEvent.isControlDown()) {

                getSelectionProvider().setSelectedCanvasLink(
                        ((RspecCanvasLink.LinkCenter) mouseEvent.getSource()).getRspecCanvasLink());
                assert (getSelectionProvider().getSelectedCanvasLink() != null);

                //show context menu
                linkContextMenu.show(getSelectionProvider().getSelectedCanvasLink().getLinkCenter(),
                        mouseEvent.getScreenX(), mouseEvent.getScreenY());

            }
        }

        if (mouseEvent.getSource() instanceof RspecCanvasLink.InterfaceLink) {
            if (mouseEvent.getButton() != MouseButton.PRIMARY || mouseEvent.isControlDown()) {

                getSelectionProvider().setSelectedInterfaceLink((RspecCanvasLink.InterfaceLink) mouseEvent.getSource());


                //show context menu
                linkInterfaceContextMenu.show(getSelectionProvider().getSelectedInterfaceLink(),
                        mouseEvent.getScreenX(), mouseEvent.getScreenY());

            }

        }

    }

    private void setStatus(String status) {
        experimentEditor.setStatus(status);
    }

    @Override
    protected void canvasNodeOnDragDetected(MouseEvent mouseEvent) {
        super.canvasNodeOnDragDetected(mouseEvent);

        //make canvas link invisible when starting to drag
        newCanvasLink.setVisible(false);
    }

    @Override
    protected void canvasNodeOnMouseDragged(MouseEvent mouseEvent) {
        CanvasNode node = (CanvasNode) mouseEvent.getSource();
        Bounds canvasOrigin = getCanvas().
                localToScene(getCanvas().getBoundsInLocal());
        double newX = mouseEvent.getSceneX()
                - canvasOrigin.getMinX()
                - node.getBoundsInParent().getWidth() / 2;
        double newY = mouseEvent.getSceneY()
                - canvasOrigin.getMinY()
                - node.getBoundsInParent().getHeight() / 2;

        //setSecondaryStatus("Moving to " + newX + ", " + newY);

        node.relocate(newX, newY);

        mouseEvent.consume();
    }

    @Override
    protected void onCanvasMouseReleased(MouseEvent mouseEvent) {
        super.onCanvasMouseReleased(mouseEvent);


        //have we made a new connection?
        if (newCanvasLink.isLinkComplete()) {

            if (!newCanvasLink.isLegalLink()) {
                setStatus("The requested link is illegal and was ignored.");

            } else if (newCanvasLink.isStitchedLink()) {
                setStatus("Stitched links are currently not supported, and this link was thus ignored.");
                Dialogs.showWarningDialog((Stage) this.getScene().getWindow(),
                        "Only links between nodes on the same testbed are currently supported.",
                        "Stitched links are currently not supported");
            } else {
                boolean newLink = false;

                //do we have to make a new RspecLink?
                RspecLink rspecLink;
                if (newCanvasLink.getOriginLink() != null)
                    rspecLink = newCanvasLink.getOriginLink().getRspecLink();
                else if (newCanvasLink.getTargetLink() != null)
                    rspecLink = newCanvasLink.getTargetLink().getRspecLink();
                else {
                    //create new rspecLink
                    rspecLink = new RspecLink(model, model.nextLinkName());
                    newLink = true;
                }

                //add node(s) to rspecLink
                if (newCanvasLink.getOriginNode() != null) {
                    addRspecNodeToRspecLink(newCanvasLink.getOriginNode().getRspecNode(), rspecLink);
                }
                if (newCanvasLink.getTargetNode() != null) {
                    addRspecNodeToRspecLink(newCanvasLink.getTargetNode().getRspecNode(), rspecLink);
                }

                //do we have to add the link to the model? (only when a new rspecLink was created)

                if (newLink) {
                    model.getLinks().add(rspecLink);
                    setStatus("Created a new link '" + rspecLink.getId() + "'");
                }
            }

        }
        newCanvasLink.clear();
        newCanvasLink.setVisible(false);
    }

    private boolean addRspecNodeToRspecLink(RspecNode rspecNode, RspecLink rspecLink) {

        if (rspecNode.getLinks().contains(rspecLink)) {
            setStatus("Cannot add a node '" + rspecNode.getId()
                    + "' multiple times to link '" + rspecLink.getId() + "'");
            return false;
        }

        new RspecInterface(rspecNode,
                rspecLink,
                model.nextIfaceName(rspecNode));

        //move this out of the GUI?
        if (rspecNode.getComponentManagerId() != null &&
                !rspecLink.getComponentManagerUrns().contains(rspecNode.getComponentManagerId()))
            rspecLink.getComponentManagerUrns().add(rspecNode.getComponentManagerId());

        return true;
    }

    @Override
    protected void onCanvasMouseMoved(MouseEvent mouseEvent) {
        if (!mouseEvent.isPrimaryButtonDown()) {

            //if the mouse is close nearby a node, show a "newCanvasLink"

            RspecCanvasNode nearbyNode = findNearbyNode(mouseEvent.getX(), mouseEvent.getY());
            RspecCanvasLink nearbyLink = null;
            if (nearbyNode != null) {
                newCanvasLink.setOriginNode(nearbyNode);
            } else {
                nearbyLink = findNearbyLink(mouseEvent.getX(), mouseEvent.getY());
                if (nearbyLink != null) {
                    newCanvasLink.setOriginLink(nearbyLink);
                }
            }

            if (nearbyNode != null || nearbyLink != null) {
                newCanvasLink.setNewEnd(mouseEvent.getX(), mouseEvent.getY());
                newCanvasLink.setVisible(true);

                setStatus("Click and drag the circle to a target node to create a new link.");
            } else {

                newCanvasLink.setVisible(false);
            }
        }
    }

    /**
     * Performs panning of the canvas when the newCanvasLink is not visible, or when the shift-button is down.
     * Otherwise, it tries to connect two nodes
     */
    protected void onCanvasMouseDragged(MouseEvent mouseEvent) {
        if (mouseEvent.isShiftDown() || !newCanvasLink.isVisible()) {
            super.onCanvasMouseDragged(mouseEvent);
        } else {

            //try to connect this node if canvas isn't fixed
            RspecCanvasNode targetNode = findNearbyNode(mouseEvent.getX(), mouseEvent.getY());

            if (targetNode != null && targetNode != newCanvasLink.getOriginNode()) {
                newCanvasLink.setTargetNode(targetNode);
            } else {

                RspecCanvasLink targetLink = findNearbyLink(mouseEvent.getX(), mouseEvent.getY());

                if (targetLink != null) {
                    newCanvasLink.setTargetLink(targetLink);
                } else {
                    newCanvasLink.setNewEnd(mouseEvent.getX(), mouseEvent.getY());
                }
            }
        }

    }

    public void duplicateSelected() {

        if (getSelectionProvider().getSelectedCanvasNode() != null &&
                getSelectionProvider().getSelectedCanvasNode() instanceof RspecCanvasNode) {
            RspecCanvasNode rspecCanvasNode = (RspecCanvasNode) getSelectionProvider().getSelectedCanvasNode();

            RspecNode newRspecNode = new RspecNode(rspecCanvasNode.getRspecNode(), false);
            newRspecNode.setId(model.nextNodeName());
            newRspecNode.setEditorX(newRspecNode.getEditorX() + EDITOR_LOCATION_SHIFT);
            newRspecNode.setEditorY(newRspecNode.getEditorY() + EDITOR_LOCATION_SHIFT);

            model.getNodes().add(newRspecNode);

            //we now know that a RSepcCanvasNode has been created, and we can thus safely create the interfaces
            newRspecNode.copyInterfaces(rspecCanvasNode.getRspecNode());

            getSelectionProvider().setSelectedCanvasNode(
                    getRspecCanvasNode(newRspecNode));
        } else {
            Dialogs.showWarningDialog((Stage) getScene().getWindow(),
                    "Nothing to duplicate!\r\nPlease select an item first.",
                    "Duplicate action failed");

        }

    }

    public void arrangeNodesOnCircle() {
        arrangeNodesOnCircle(getCanvas().getWidth(), getCanvas().getHeight());
    }


    private void arrangeNodesOnCircle(double width, double height) {
        LOG.debug("Arranging all nodes on a circle of {}x{}", width, height);
        if (width < 100.0) width = 300.0;
        if (height < 100.0) height = 300.0;

        int size = model.getNodes().size();
        double radiusW = width / 3.0; //diameter of 2/3 width
        double radiusH = height / 3.0; //diameter of 2/3 height

        double centerX = width / 2.0;
        double centerY = height / 2.0;
        double angle = 0.0;
        double step = step = (2 * Math.PI) / size;
        for (RspecNode n : model.getNodes()) {
            RspecCanvasNode cn = getRspecCanvasNode(n);

            double x = (Math.cos(angle) * radiusW) + centerX;
            double y = (Math.sin(angle) * radiusH) + centerY;

            x -= cn.getWidth() / 2.0;
            y -= cn.getHeight() / 2.0;

            n.setEditorX(x);
            n.setEditorY(y);

            angle += step;
        }
    }

    private void addNode(NodeDescription nodeDescription, Point2D location) {
        RspecNodeDescription rnd = nodeDescription.getRspecNodeDescriptions().get(0);

        RspecNode rspecNode = new RspecNode(model.nextNodeName());
        rspecNode.setEditorNodeDescriptionType(nodeDescription.getId());

        rspecNode.setComponentManagerId(rnd.getComponentManagerUrn());
        rspecNode.setExclusive(rnd.isExclusive());
        rspecNode.setComponentId(rnd.getComponentIdUrn());
        rspecNode.setSliverTypeName(rnd.getSliverType());
        rspecNode.setOsImage(rnd.getOsImage());


        rspecNode.setEditorX(location.getX());
        rspecNode.setEditorY(location.getY());

        model.getNodes().add(rspecNode);

        nodeDescriptionMap.put(rspecNode, nodeDescription);

        setStatus("Added node " + rspecNode.getId() + " to the canvas");
    }

    @FXML
    public void onMouseDragReleased(MouseDragEvent mouseDragEvent) {
        //we are adding a new element from the toolbox
        assert (experimentEditor.getDraggedItem() != null);
        assert (experimentEditor.getDraggedItem() instanceof NodeDescriptionToolboxItem);

        NodeDescriptionToolboxItem ndti = (NodeDescriptionToolboxItem) experimentEditor.getDraggedItem();

        Point2D location = new Point2D(
                mouseDragEvent.getSceneX()
                        - getCanvas().getLocalToSceneTransform().getTx()
                        - experimentEditor.getDraggedItem().getPrefWidth() / 2,
                mouseDragEvent.getSceneY()
                        - getCanvas().getLocalToSceneTransform().getTy()
                        - experimentEditor.getDraggedItem().getPrefHeight() / 2);
        addNode(ndti.getNodeDescription(), location);


        setCursor(null);

        experimentEditor.clearDraggedItem();
        mouseDragEvent.consume();

    }


    private void addNode(ComponentManagerInfo cmi, Point2D location) {
        //register node in model
        RspecNode rspecNode = new RspecNode(model.nextNodeName());

        rspecNode.setComponentManagerId(cmi.getUrn());

        //set editor location
        rspecNode.setEditorX(location.getX());
        rspecNode.setEditorY(location.getY());

        model.getNodes().add(rspecNode);

        setStatus("Added node " + rspecNode.getId() + " to the canvas");
    }


    public void copySelected() {
        clipboard.clear();

        if (getSelectionProvider().getSelectedCanvasNode() == null) {
            Dialogs.showWarningDialog((Stage) getScene().getWindow(),
                    "Nothing to copy!\r\nPlease select an item first.",
                    "Copy action failed");
        }

        clipboard.add(getSelectionProvider().getSelectedCanvasNode());
    }

    public void paste() {
        if (clipboard.isEmpty()) {
            Dialogs.showWarningDialog((Stage) getScene().getWindow(),
                    "Nothing to paste!\r\nPlease copy an item first.",
                    "Paste action failed");
        }

        /* If the user pastes the same node two times, we want it to appear on two different places.
           Therefore we modify the clipboard to the newly created items    */
        List<CanvasNode> newClipboard = new ArrayList<>();

        for (CanvasNode canvasNode : clipboard) {
            if (canvasNode instanceof RspecCanvasNode) {
                RspecCanvasNode rspecCanvasNode = (RspecCanvasNode) canvasNode;

                RspecNode newRspecNode = new RspecNode(rspecCanvasNode.getRspecNode(), false);
                newRspecNode.setId(model.nextNodeName());
                newRspecNode.setEditorX(newRspecNode.getEditorX() + EDITOR_LOCATION_SHIFT);
                newRspecNode.setEditorY(newRspecNode.getEditorY() + EDITOR_LOCATION_SHIFT);

                model.getNodes().add(newRspecNode);

                //we now know that a RSepcCanvasNode has been created, and we can thus safely create the interfaces
                newRspecNode.copyInterfaces(rspecCanvasNode.getRspecNode());

                newClipboard.add(getRspecCanvasNode(newRspecNode));
            }
        }

        clipboard.clear();
        clipboard.addAll(newClipboard);
    }

    public ReadOnlyListProperty<CanvasNode> getClipboard() {
        return new ReadOnlyListWrapper<>(clipboard).getReadOnlyProperty();
    }
}
