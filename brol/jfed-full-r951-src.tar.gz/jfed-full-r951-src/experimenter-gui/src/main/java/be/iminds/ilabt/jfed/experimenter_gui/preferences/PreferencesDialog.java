package be.iminds.ilabt.jfed.experimenter_gui.preferences;

import be.iminds.ilabt.jfed.experimenter_gui.model.ExperimenterModel;
import be.iminds.ilabt.jfed.util.JFedCommonDialogs;
import be.iminds.ilabt.jfed.experimenter_gui.util.ui.TextFieldWithStatus;
import be.iminds.ilabt.jfed.lowlevel.ssh_key_info.SshKeyInfo;
import be.iminds.ilabt.jfed.lowlevel.userloginmodel.UserLoginModelManager;
import be.iminds.ilabt.jfed.ssh_terminal_tool.putty.PuTTYPrivateKeyFile;
import be.iminds.ilabt.jfed.ssh_terminal_tool.ssh_key_info.UserSshKeyInfo;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import be.iminds.ilabt.jfed.util.OSDetector;
import be.iminds.ilabt.jfed.util.PreferencesUtil;
import be.iminds.ilabt.jfed.util.ProxyPreferencesManager;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooserBuilder;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.ExecutionException;

/**
 * User: twalcari
 * Date: 11/19/13
 * Time: 11:03 AM
 */
public abstract class PreferencesDialog extends BorderPane {
    private static final Logger LOG = LoggerFactory.getLogger(PreferencesDialog.class);

    protected static final FileChooser.ExtensionFilter ALL_FILE_EXTENSION =
            new FileChooser.ExtensionFilter("All files (*.*)", "*.*");

    protected UserLoginModelManager userLoginModelManager;

    @FXML
    protected RadioButton useCertificateRadioButton;
    @FXML
    protected RadioButton useCustomKeyPairRadioButton;
    @FXML
    protected TextFieldWithStatus fileTextField;
    @FXML
    protected Button browseButton;
    //  @FXML protected Button generateButton;
    @FXML
    protected Button saveButton;
    @FXML
    protected Button applyButton;
    @FXML
    protected Button cancelButton;
    @FXML
    protected Button resetButton;


    @FXML
    protected RadioButton neverProxyForJFedRadioButton;
    @FXML
    protected RadioButton autoProxyForJFedRadioButton;
    @FXML
    protected RadioButton alwaysProxyForJFedRadioButton;

    @FXML
    protected RadioButton neverProxyForSshRadioButton;
    @FXML
    protected RadioButton autoProxyForSshRadioButton;
    @FXML
    protected RadioButton alwaysProxyForSshRadioButton;

    @FXML
    protected Button tryProxyButton;
    @FXML
    protected Label tryProxyResultLabel;
    @FXML
    protected ProgressIndicator proxyProgressBar;


    protected final ExperimenterModel experimenterModel;

    public PreferencesDialog() {
        experimenterModel = ExperimenterModel.getInstance();
        userLoginModelManager = experimenterModel.getUserLoginModelManager();

        try {
            URL location = getClass().getResource(getFxmlFile());

            FXMLLoader loader = new FXMLLoader(location);
            loader.setRoot(this);
            loader.setController(this);

            loader.load();
        } catch (Exception e) {
            throw new RuntimeException("Something went wrong showing the Preferences dialog: " + e.getMessage(), e);
        }

    }

    protected abstract String getFxmlFile();

    public void initialize() {
        fileTextField.disableProperty().bind(useCustomKeyPairRadioButton.selectedProperty().not());
        browseButton.disableProperty().bind(useCustomKeyPairRadioButton.selectedProperty().not());

        fileTextField.focusedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean oldValue, Boolean newValue) {
                if (newValue) {
                    fileTextField.setStatus(TextFieldWithStatus.Status.NONE);
                } else {
                    testPrivateKey();
                }
            }
        });

        //load settings
        String useProxyForJFed = PreferencesUtil.getString(PreferencesUtil.Preference.PREF_SSHPROXY_USE_FOR_JFED);
        String useProxyForSsh = PreferencesUtil.getString(PreferencesUtil.Preference.PREF_SSHPROXY_USE_FOR_SSH);
        if (useProxyForJFed.equalsIgnoreCase("NEVER")) neverProxyForJFedRadioButton.setSelected(true);
        if (useProxyForJFed.equalsIgnoreCase("AUTO")) autoProxyForJFedRadioButton.setSelected(true);
        if (useProxyForJFed.equalsIgnoreCase("ALWAYS")) alwaysProxyForJFedRadioButton.setSelected(true);
        if (useProxyForSsh.equalsIgnoreCase("NEVER")) neverProxyForSshRadioButton.setSelected(true);
        if (useProxyForSsh.equalsIgnoreCase("AUTO")) autoProxyForSshRadioButton.setSelected(true);
        if (useProxyForSsh.equalsIgnoreCase("ALWAYS")) alwaysProxyForSshRadioButton.setSelected(true);

        if (PreferencesUtil.getBoolean(PreferencesUtil.Preference.PREF_SSH_OVERRIDE)) {
            useCustomKeyPairRadioButton.setSelected(true);

            if (PreferencesUtil.getFile(PreferencesUtil.Preference.PREF_SSH_PUTTY_KEY_FILE) != null) {
                fileTextField.setText(PreferencesUtil.getFile(PreferencesUtil.Preference.PREF_SSH_PUTTY_KEY_FILE).getPath());
            } else {
                if (PreferencesUtil.getFile(PreferencesUtil.Preference.PREF_SSH_PRIVATE_KEY_FILE) != null) {
                    fileTextField.setText(PreferencesUtil.getFile(PreferencesUtil.Preference.PREF_SSH_PRIVATE_KEY_FILE).getPath());
                }
            }
        } else {
            useCustomKeyPairRadioButton.setSelected(false);
            fileTextField.setText("");
            fileTextField.setStatus(TextFieldWithStatus.Status.NONE);
        }

        //evaluate inputs
        if (useCustomKeyPairRadioButton.isSelected())
            testPrivateKey();
    }

    protected void testPrivateKey() {
        if (fileTextField.getText().length() == 0) {
            fileTextField.setStatus(TextFieldWithStatus.Status.NONE);
            return;
        }

        try {
            if (testPrivateKeyFile(new File(fileTextField.getText()))) {
                fileTextField.setStatus(TextFieldWithStatus.Status.OK);

            } else {
                Dialogs.showWarningDialog(null,
                        " Please select a valid private key.",
                        "The provided key is not valid.",
                        "Invalid key file");
                fileTextField.setStatus(TextFieldWithStatus.Status.ERROR);
            }
        } catch (IOException ex) {
            Dialogs.showErrorDialog((Stage) fileTextField.getScene().getWindow(),
                    "An error occured while processing the key file", "Error", "Error", ex);
            fileTextField.setStatus(TextFieldWithStatus.Status.ERROR);
        }
    }

    // protected abstract String getPublicKeyFromFile(File file) throws IOException;

    @FXML
    protected void onBrowseButtonAction(ActionEvent actionEvent) {
        FileChooser fc = FileChooserBuilder.create()
                .title("Select your Private Key")
                .initialDirectory(getLoggedInUserPrivateKeyFile().getParentFile())
                .build();

        File selectedFile = fc.showOpenDialog(fileTextField.getScene().getWindow());
        if (selectedFile != null) {
            fileTextField.setText(selectedFile.getAbsolutePath());
            testPrivateKey();
        }

    }

    protected abstract boolean testPrivateKeyFile(File file) throws IOException;

    protected File getLoggedInUserPrivateKeyFile() {
        File privateKey;

        switch (userLoginModelManager.getUserLoginModelType()) {
            case KEY_CERT_INTERNAL_INFO:
            case KEY_CERT_EXTERNAL_INFO:
                privateKey = userLoginModelManager.getKeyCertUserLoginModel().getKeyCertFile();
                break;
            case PLANETLAB:
                privateKey = userLoginModelManager.getPlanetlabUserLoginModel().getSshPrivateKeyFile();
                break;
            default:
                throw new RuntimeException("Unexpected UserLoginModelType");
        }
        return privateKey;
    }

    private void convertPuttyKeysIfNeeded() {
        //make proxy keys if proxy might be used for SSH (AUTO or ALWAYS, so not if NEVER)
        convertPuttyKeysIfNeeded(
                !PreferencesUtil.getString(PreferencesUtil.Preference.PREF_SSHPROXY_USE_FOR_SSH).equalsIgnoreCase("NEVER")
        );
    }

    private void convertPuttyKeysIfNeeded(boolean makeProxyKeys) {
        if (OSDetector.os == OSDetector.OS.WIN) {
            //make putty key for SSH connections if needed
            SshKeyInfo sshKeyInfo = PreferencesUtil.getOverriddenSshKeyInfo();
            if (sshKeyInfo != null) {
                File puttyKeyFile = sshKeyInfo.getPuttyKeyFile();
                assert puttyKeyFile.exists();
                sshKeyInfo.release(); //remove again if tmp file
            }
            //make putty key for proxy connections, if needed
            if (makeProxyKeys) {
                //proxy can be used for SSH
                sshKeyInfo = PreferencesUtil.getOverriddenProxySshKeyInfo();
                if (sshKeyInfo != null) {
                    File puttyKeyFile = sshKeyInfo.getPuttyKeyFile();
                    assert puttyKeyFile.exists();
                    sshKeyInfo.release(); //remove again if tmp file
                } else {
                    //proxy key not overriden, so convert user key, for use with proxy
                    sshKeyInfo = new UserSshKeyInfo(experimenterModel.getGeniUserProvider().getLoggedInGeniUser());
                    if (sshKeyInfo != null) {
                        File puttyKeyFile = sshKeyInfo.getPuttyKeyFile();
                        assert puttyKeyFile.exists();
                        sshKeyInfo.release(); //remove again if tmp file
                    }
                }
            }
        }
    }

    protected boolean applySettings() {
        if (useCustomKeyPairRadioButton.isSelected()) {
            PreferencesUtil.setBoolean(PreferencesUtil.Preference.PREF_SSH_OVERRIDE, true);
            if (fileTextField.getStatus() != TextFieldWithStatus.Status.OK) {
                Dialogs.showErrorDialog((Stage) this.getScene().getWindow(), "The provided private key file is not valid");
                return false;
            }

            File newPrivKeyFile = new File(fileTextField.getText());
            boolean isPuttyFile = false;
            try {
                isPuttyFile = PuTTYPrivateKeyFile.isPuttyPrivateKey(newPrivKeyFile);
            } catch (IOException e) {
                Dialogs.showErrorDialog((Stage) this.getScene().getWindow(), "The provided private key file is not valid");
                return false;
            }
            if (isPuttyFile) {
                PreferencesUtil.clear(PreferencesUtil.Preference.PREF_SSH_PRIVATE_KEY_FILE);
                PreferencesUtil.setFile(PreferencesUtil.Preference.PREF_SSH_PUTTY_KEY_FILE, newPrivKeyFile);
            } else {
                PreferencesUtil.clear(PreferencesUtil.Preference.PREF_SSH_PUTTY_KEY_FILE);
                PreferencesUtil.setFile(PreferencesUtil.Preference.PREF_SSH_PRIVATE_KEY_FILE, newPrivKeyFile);
            }
        } else
            PreferencesUtil.setBoolean(PreferencesUtil.Preference.PREF_SSH_OVERRIDE, false);

        if (neverProxyForJFedRadioButton.isSelected())
            PreferencesUtil.setString(PreferencesUtil.Preference.PREF_SSHPROXY_USE_FOR_JFED, "NEVER");
        if (autoProxyForJFedRadioButton.isSelected())
            PreferencesUtil.setString(PreferencesUtil.Preference.PREF_SSHPROXY_USE_FOR_JFED, "AUTO");
        if (alwaysProxyForJFedRadioButton.isSelected())
            PreferencesUtil.setString(PreferencesUtil.Preference.PREF_SSHPROXY_USE_FOR_JFED, "ALWAYS");

        if (neverProxyForSshRadioButton.isSelected())
            PreferencesUtil.setString(PreferencesUtil.Preference.PREF_SSHPROXY_USE_FOR_SSH, "NEVER");
        if (autoProxyForSshRadioButton.isSelected())
            PreferencesUtil.setString(PreferencesUtil.Preference.PREF_SSHPROXY_USE_FOR_SSH, "AUTO");
        if (alwaysProxyForSshRadioButton.isSelected())
            PreferencesUtil.setString(PreferencesUtil.Preference.PREF_SSHPROXY_USE_FOR_SSH, "ALWAYS");

        //convert PuTTY keys if needed. make proxy key only if proxy selected.
        convertPuttyKeysIfNeeded();

        return true;
    }

    @FXML
    protected void onTryButtonAction() {
        assert (experimenterModel.getGeniUserProvider().isUserLoggedIn());

        tryProxyButton.setDisable(true);
        saveButton.requestFocus(); //prevent reset button from getting focus

        final ProxyPreferencesManager proxyPrefMan = experimenterModel.getProxyPreferencesManager();
        proxyPrefMan.resetProxyReachabilityCache();
        tryProxyResultLabel.setText("Proxy test in progress...");
        proxyProgressBar.setProgress(0);
        proxyProgressBar.setVisible(true);


        final Task<Boolean> tryProxyTask =
                proxyPrefMan.getTryProxyTask(experimenterModel.getGeniUserProvider().getLoggedInGeniUser());

        proxyProgressBar.progressProperty().bind(tryProxyTask.progressProperty());
        tryProxyResultLabel.textProperty().bind(tryProxyTask.messageProperty());
        tryProxyTask.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
            @Override
            public void handle(WorkerStateEvent workerStateEvent) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        tryProxyResultLabel.textProperty().unbind();
                        try {
                            if (tryProxyTask.get()) {
                                autoProxyForSshRadioButton.setDisable(false);
                                autoProxyForJFedRadioButton.setDisable(false);
                                alwaysProxyForSshRadioButton.setDisable(false);
                                alwaysProxyForJFedRadioButton.setDisable(false);

                                String proxies = "";
                                String prevHostname = "";
                                for (ProxyPreferencesManager.ProxyInfo pi : proxyPrefMan.getReachableProxies()) {
                                    if (pi.getHostname().equals(prevHostname))
                                        proxies += "," + pi.getPort();
                                    else
                                        proxies += " " + pi;

                                    prevHostname = pi.getHostname();
                                }
                                tryProxyResultLabel.setText("Proxy reachable:" + proxies);
                            } else {
                                autoProxyForSshRadioButton.setDisable(true);
                                autoProxyForJFedRadioButton.setDisable(true);
                                alwaysProxyForSshRadioButton.setDisable(true);
                                alwaysProxyForJFedRadioButton.setDisable(true);

                                tryProxyResultLabel.setText("No proxies reachable.");
                            }
                        } catch (InterruptedException | ExecutionException e) {
                            LOG.error("An error occured while trying the proxies");
                        }

                        tryProxyButton.setDisable(false);
                    }
                });
            }
        });
        //start the task
        Thread t = new Thread(tryProxyTask, "Try-Proxy");
        t.setDaemon(true);
        t.start();

        convertPuttyKeysIfNeeded(true/*always make proxy keys*/);
    }

    @FXML
    protected void onSaveButtonAction() {
        if (applySettings())
            onCancelButtonAction();

        //send proxy settings to ConnectionPool
        experimenterModel.getProxyPreferencesManager().updateProxySettings();
    }

    @FXML
    protected void onApplyButtonAction() {
        applySettings();

        //send proxy settings to ConnectionPool
        experimenterModel.getProxyPreferencesManager().updateProxySettings();
    }

    @FXML
    protected void onCancelButtonAction() {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    protected void onResetAction() {
        JFedCommonDialogs.requestEraseJFedConfiguration((Stage) getScene().getWindow());
    }

}
