package be.iminds.ilabt.jfed.experimenter_gui.editor.impl;

import be.iminds.ilabt.jfed.experimenter_gui.editor.ToolboxItem;
import be.iminds.ilabt.jfed.experimenter_gui.editor.bo.NodeDescription;
import be.iminds.ilabt.jfed.experimenter_gui.util.ImageUtil;

/**
 * User: twalcari
 * Date: 1/10/14
 * Time: 4:34 PM
 */
public class NodeDescriptionToolboxItem extends ToolboxItem {

    private final NodeDescription nodeDescription;

    public NodeDescriptionToolboxItem(NodeDescription nodeDescription) {
        super(nodeDescription.getName(), ImageUtil.getNodeTypeImage(nodeDescription.getType()));
        this.nodeDescription = nodeDescription;
    }

    public NodeDescription getNodeDescription() {
        return nodeDescription;
    }
}
