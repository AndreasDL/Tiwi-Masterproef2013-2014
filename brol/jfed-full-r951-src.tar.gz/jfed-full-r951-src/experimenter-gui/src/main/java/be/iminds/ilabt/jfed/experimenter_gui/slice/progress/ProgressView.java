package be.iminds.ilabt.jfed.experimenter_gui.slice.progress;

import be.iminds.ilabt.jfed.experimenter_gui.ui.status.TaskStatusIndicator;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TitledPane;
import javafx.util.Callback;

import java.io.IOException;
import java.util.List;

/**
 * User: twalcari
 * Date: 11/27/13
 * Time: 11:11 AM
 */
public class ProgressView extends TitledPane {
    public static final String PROGRESS_VIEW_FXML = "ProgressView.fxml";
    @FXML
    private ListView<ProgressItem> progressItemListView;

    public ProgressView() {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(PROGRESS_VIEW_FXML));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        progressItemListView.setCellFactory(new Callback<ListView<ProgressItem>, ListCell<ProgressItem>>() {
            @Override
            public ListCell<ProgressItem> call(ListView<ProgressItem> progressItemListView) {
                return new ProgressViewItem();
            }
        });

    }

    public List<ProgressItem> getItems() {
        return progressItemListView.getItems();
    }

    private static class ProgressViewItem extends ListCell<ProgressItem> {

        private final TaskStatusIndicator taskStatusIndicator;

        public ProgressViewItem() {
            // add taskStatusIndicator as graphic
            taskStatusIndicator = new TaskStatusIndicator();
            taskStatusIndicator.setPrefHeight(16);
            taskStatusIndicator.setPrefWidth(16);

            setGraphic(taskStatusIndicator);
        }

        @Override
        protected void updateItem(ProgressItem progressItem, boolean empty) {
            super.updateItem(progressItem, empty);

            if (!empty) {
                textProperty().bind(progressItem.textProperty());
                taskStatusIndicator.statusProperty().bind(progressItem.progressProperty());

                taskStatusIndicator.setVisible(true);
            } else {
                textProperty().unbind();
                setText("");
                taskStatusIndicator.setVisible(false);
            }

        }
    }
}
