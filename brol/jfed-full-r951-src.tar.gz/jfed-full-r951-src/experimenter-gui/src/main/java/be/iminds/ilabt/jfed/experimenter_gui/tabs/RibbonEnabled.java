package be.iminds.ilabt.jfed.experimenter_gui.tabs;

import be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon.RibbonTab;

/**
 * User: twalcari
 * Date: 11/12/13
 * Time: 3:27 PM
 */
public interface RibbonEnabled {

    public RibbonTab getRibbonTab();
}
