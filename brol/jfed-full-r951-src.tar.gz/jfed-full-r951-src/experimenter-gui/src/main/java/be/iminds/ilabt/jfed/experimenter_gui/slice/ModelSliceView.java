package be.iminds.ilabt.jfed.experimenter_gui.slice;

import be.iminds.ilabt.jfed.experimenter_gui.canvas.impl.RspecCanvasNode;
import be.iminds.ilabt.jfed.experimenter_gui.model.ExperimenterModel;
import be.iminds.ilabt.jfed.highlevel.model.AuthorityInfo;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.highlevel.model.Sliver;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import javafx.scene.layout.BorderPane;

/**
 * This controller is used when the Rspec can be parsed into a ModelRspec
 * <p/>
 * User: twalcari
 * Date: 2/5/14
 * Time: 5:45 PM
 */
public class ModelSliceView extends BorderPane {

    private final SliceExperimentCanvas experimentCanvas;

    private final Multimap<SfaAuthority, RspecNode> authRspecNodeMultimap = HashMultimap.create();
    private final EasyModel easyModel;

    {
        ExperimenterModel experimenterModel = ExperimenterModel.getInstance();
        easyModel = experimenterModel.getEasyModel();
    }

    public ModelSliceView(final SliceController sliceController, ModelRspec model) {
        //initialize model
        //initialize rspecNodeMultimap
        initializeRspecNodeMultimap(model);

        //initialize GUI
        this.experimentCanvas = new SliceExperimentCanvas(sliceController, model);
        setCenter(experimentCanvas);

        //update gui
        for (RspecNode node : model.getNodes()) {
            setRspecNodeStatus(node, SliverStatus.UNKNOWN);
        }


    }

    private void initializeRspecNodeMultimap(ModelRspec model) {
        //create authRspecNodeMultimap
        for (RspecNode node : model.getNodes()) {
            AuthorityInfo ai = easyModel.getAuthorityList().getByUrn(node.getComponentManagerId());
            assert (ai != null);

            authRspecNodeMultimap.put(ai.getSfaAuthority(), node);
        }
    }

    public void onSliverUpdate(Sliver sliver, SliverStatus status) {
        onSliverUpdate(sliver.getAuthority(), status);
    }

    public void onSliverUpdate(SfaAuthority auth, SliverStatus status) {
        for (RspecNode rspecNode : authRspecNodeMultimap.get(auth)) {
            setRspecNodeStatus(rspecNode, status);
        }
    }

    private void setRspecNodeStatus(RspecNode rspecNode, SliverStatus status) {
        RspecCanvasNode canvasNode = experimentCanvas.getRspecCanvasNode(rspecNode);

        //remove all old styleclasses
        for (SliverStatus s : SliverStatus.values()) {
            canvasNode.getStyleClass().remove(SliceExperimentCanvas.statusToStyleClass(s));
        }

        //apply new styleclasses
        canvasNode.getStyleClass().add(SliceExperimentCanvas.statusToStyleClass(status));
    }
}
