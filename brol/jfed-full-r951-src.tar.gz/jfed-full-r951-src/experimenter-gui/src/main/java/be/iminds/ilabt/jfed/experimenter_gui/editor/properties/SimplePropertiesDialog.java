package be.iminds.ilabt.jfed.experimenter_gui.editor.properties;

import be.iminds.ilabt.jfed.experimenter_gui.ExperimenterConfiguration;
import be.iminds.ilabt.jfed.experimenter_gui.editor.bo.NodeDescription;
import be.iminds.ilabt.jfed.experimenter_gui.model.ExperimenterModel;
import be.iminds.ilabt.jfed.highlevel.controller.SingleTask;
import be.iminds.ilabt.jfed.highlevel.controller.Task;
import be.iminds.ilabt.jfed.highlevel.controller.TaskFinishedCallback;
import be.iminds.ilabt.jfed.highlevel.controller.TaskThread;
import be.iminds.ilabt.jfed.highlevel.model.AuthorityInfo;
import be.iminds.ilabt.jfed.highlevel.model.RSpecInfo;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.rspec.model.*;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import be.iminds.ilabt.jfed.ui.rspeceditor.editor.ComponentManagerInfo;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

/**
 * User: twalcari
 * Date: 11/28/13
 * Time: 5:03 PM
 */
public class SimplePropertiesDialog extends BorderPane {

    private static final String[] FIXED_ASSIGNMENT_REQUIRED = {"ple:ibbtple", "bonfire-project.eu"};
    private static final Logger LOG = LoggerFactory.getLogger(SimplePropertiesDialog.class);
    private static final String SIMPLE_PROPERTIES_FXML = "SimpleProperties.fxml";
    private static final double PROGRESS_FETCH_REQUESTED = 0.10;
    private static final double PROGRESS_FETCH_COMPLETE = 0.60;
    private static final ExperimenterConfiguration config = ExperimenterConfiguration.getInstance();

    //instance initializer
    {
        this.experimenterModel = ExperimenterModel.getInstance();
    }

    private final RspecNode node;
    private final NodeDescription nodeDescription;
    private final ModelRspec model;
    private final ExperimenterModel experimenterModel;
    private final TaskThread tt = TaskThread.getInstance();
    //    private static final String[] ALLOWED_FOR_DEMO =
//            {"wall2.ilabt.iminds.be",
//             "wilab2.ilabt.iminds.be",
//             "ple:ibbtple",
//             "emulab.net",
//             "bonfire-project.eu"};
    private Map<String, ComponentManagerInfo> componentManagerInfoMap = null;
    @FXML
    private Button saveButton;
    @FXML
    private Button cancelButton;
    @FXML
    private ComboBox<ComponentManagerInfo> testbedsComboBox;
    @FXML
    private ComboBox<ComponentManagerInfo.ComponentId> selectNodeComboBox;
    @FXML
    private ToggleGroup selectNodeToggleGroup;
    @FXML
    private RadioButton nodeAssignedRadioButton, noNodeAssignedRadioButton;
    @FXML
    private ProgressBar nodeAdvertisementFetchProgressBar;
    @FXML
    private TextField nameTextField;
    @FXML
    private Button refreshAdvertisementButton;

    private SimplePropertiesDialog(ModelRspec model, RspecNode node) {
        assert (model != null);
        assert (node != null);
        this.model = model;
        this.node = node;
        this.nodeDescription = config.getNodeDescription(node.getEditorNodeDescriptionType());

        //initialize the Scene
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(SIMPLE_PROPERTIES_FXML));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        nameTextField.setTooltip(
                TooltipBuilder.create()
                        .text("Only alphanumerical, max. " + getMaximumNodeNameLength() + " characters")
                        .build()
        );

        nameTextField.setText(node.getId());

        //populate ComponentManagerInfo if needed
        if (componentManagerInfoMap == null)
            populateComponentManagerInfoMap(experimenterModel);
        assert (componentManagerInfoMap != null);


        ObservableList<ComponentManagerInfo> testBedsList =
                FXCollections.observableArrayList(componentManagerInfoMap.values());
        Collections.sort(testBedsList, new Comparator<ComponentManagerInfo>() {
            @Override
            public int compare(ComponentManagerInfo o1, ComponentManagerInfo o2) {
                assert (o1 != null);
                assert (o2 != null);
                return o1.getUrnPart().compareTo(o2.getUrnPart());
            }
        });


        testbedsComboBox.setItems(testBedsList);
        testbedsComboBox.setConverter(new StringConverter<ComponentManagerInfo>() {
            @Override
            public String toString(ComponentManagerInfo componentManagerInfo) {
                return experimenterModel.getAuthorityList().getByUrn(componentManagerInfo.getUrn()).getSfaAuthority().getName();
                // return componentManagerInfo.getUrnPart();
            }

            @Override
            public ComponentManagerInfo fromString(String s) {
                throw new UnsupportedOperationException();
            }

        });
        testbedsComboBox.getSelectionModel().selectedItemProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
                boolean fixrequired = false;
                for (String name : FIXED_ASSIGNMENT_REQUIRED) {
                    if (testbedsComboBox.getSelectionModel().getSelectedItem().getUrnPart().equals(name))
                        fixrequired = true;
                }

                if (!fixrequired) {
                    noNodeAssignedRadioButton.setDisable(false);
                    noNodeAssignedRadioButton.setSelected(true);
                } else {
                    nodeAssignedRadioButton.setSelected(true);
                    noNodeAssignedRadioButton.setDisable(true);
                    refreshComponentIdsList(false);
                }

            }
        });


        //select the current testbed in the list
        ComponentManagerInfo currentItem = componentManagerInfoMap.get(node.getComponentManagerId());

        assert (currentItem != null);
        testbedsComboBox.getSelectionModel().select(currentItem);


        selectNodeToggleGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            @Override
            public void changed(ObservableValue<? extends Toggle> observableValue, Toggle oldValue, Toggle newValue) {
                refreshComponentIdsList(false);
            }
        });

        if (node.getComponentId() != null)
            nodeAssignedRadioButton.setSelected(true);


        selectNodeComboBox.setConverter(new StringConverter<ComponentManagerInfo.ComponentId>() {
            @Override
            public String toString(ComponentManagerInfo.ComponentId componentId) {
                return componentId.getName();
            }

            @Override
            public ComponentManagerInfo.ComponentId fromString(String s) {
                throw new UnsupportedOperationException();
            }
        });


        refreshAdvertisementButton.disableProperty().bind(selectNodeComboBox.disableProperty());

    }

    public static void showSimplePropertiesDialog(ModelRspec model, RspecNode node) {

        Scene scene = new Scene(new SimplePropertiesDialog(model, node));

        Stage dialogStage = new Stage();
        dialogStage.setScene(scene);

        dialogStage.setTitle("Properties of " + node.getId());
        dialogStage.setResizable(false);
        dialogStage.showAndWait();


    }

    private void populateComponentManagerInfoMap(ExperimenterModel experimenterModel) {
        componentManagerInfoMap = new HashMap<>();

        //fill the testbed-dropdown with all possible items
        for (AuthorityInfo ai : experimenterModel.getAuthorityList().authorityInfosProperty()) {

            SfaAuthority auth = ai.getSfaAuthority();
            if (auth == null) {
                LOG.warn("Resolve Slice returned unknown component manager ");
                //only process testbed when it is listed in the enabledTestbeds of the NodeDescription
            } else if (nodeDescription.getEnabledTestbeds().containsKey(auth.getUrnString())) {
                ComponentManagerInfo componentManagerInfo =
                        new ComponentManagerInfo(auth.getUrnString(), auth.getNameForUrn());
                componentManagerInfo.setIndex(ai.getIndex());

                //FIXME HACK for PlanetLab
                if (auth.getType() != null && auth.getType().equals("planetlab")) {
                    List<String> sliverTypes = new ArrayList<>();
                    sliverTypes.add("plab-vserver");
                    componentManagerInfo.setSliverTypes(sliverTypes);
                }

                componentManagerInfoMap.put(ai.getSfaAuthority().getUrnString(), componentManagerInfo);
                componentManagerInfo.getComponentIds().addAll(listComponentIds(ai));
            }
        }
    }

    private List<ComponentManagerInfo.ComponentId> listComponentIds(AuthorityInfo ai) {
        List<ComponentManagerInfo.ComponentId> result = new ArrayList<>();

        ComponentManagerInfo cmi = componentManagerInfoMap.get(ai.getSfaAuthority().getUrnString());
        assert (cmi != null);

        //FIXME why not AllAdvertisementRspec() ?
        RSpecInfo rspec = ai.getAvailableAdvertisementRspec();

        ExperimenterConfiguration.EnabledTestbed enabledTestbed =
                nodeDescription.getEnabledTestbeds().get(ai.getSfaAuthority().getUrnString());

        if (rspec != null) {
            try {
                for (RspecNode rspecInfoNode : rspec.getRSpec().getModelRspec().getNodes()) {
                    if (enabledTestbed.getEnabledComponentIds() == null ||
                            enabledTestbed.getEnabledComponentIds().contains(rspecInfoNode.getComponentId()))
                        result.add(
                                new ComponentManagerInfo.ComponentId(
                                        rspecInfoNode.getComponentId(),
                                        rspecInfoNode.getComponentName(),
                                        rspecInfoNode)
                        );
                }
                LOG.info("Added {} nodes to the list of testbed {}",
                        rspec.getRSpec().getModelRspec().getNodes().size(), ai.getSfaAuthority().getName());

                //sort them

                Collections.sort(result, new Comparator<ComponentManagerInfo.ComponentId>() {
                    @Override
                    public int compare(ComponentManagerInfo.ComponentId o1, ComponentManagerInfo.ComponentId o2) {
                        return o1.getName().compareTo(o2.getName());
                    }
                });
            } catch (InvalidRspecException ex) {
                LOG.error("Error while parsing Rspec XML", ex);
            }

        } else {
            LOG.warn("No detailed node-info available for testbed " + ai.getSfaAuthority().getName());
        }
        return result;
    }

    private void refreshComponentIdsList(boolean forceRefresh) {

        selectNodeComboBox.setDisable(selectNodeToggleGroup.getSelectedToggle() != nodeAssignedRadioButton);

        if (selectNodeToggleGroup.getSelectedToggle() == nodeAssignedRadioButton) {
            //if we don't have the componentId's available, lets fetch them!
            ComponentManagerInfo cmi = testbedsComboBox.getSelectionModel().getSelectedItem();

            if (cmi.getComponentIds().isEmpty() || forceRefresh) {
                fetchNodesAdvertisement(cmi);
            } else {
                //we can directly show the list to select from
                showNodeAssignmentList(cmi);
            }
        }

    }

    private void showNodeAssignmentList(ComponentManagerInfo cmi) {
        ComponentManagerInfo currentCmi = testbedsComboBox.getSelectionModel().getSelectedItem();

        //only show the nodes list if it is still the selected testbed
        if (cmi != currentCmi)
            return;

        //load the choices into the nodeChoiceBox
        selectNodeComboBox.setItems(cmi.getComponentIds());

        if (node.getComponentId() != null) {
            for (ComponentManagerInfo.ComponentId cid : cmi.getComponentIds()) {
                if (cid.getUrn().equals(node.getComponentId())) {
                    selectNodeComboBox.getSelectionModel().select(cid);
                    break;
                }
            }
        }

        //set visibilty
        nodeAdvertisementFetchProgressBar.setVisible(false);
        selectNodeComboBox.setDisable(false);

    }

    private void fetchNodesAdvertisement(final ComponentManagerInfo cmi) {

        //show progressbar
        selectNodeComboBox.setDisable(true);
        selectNodeComboBox.getSelectionModel().clearSelection();
        nodeAdvertisementFetchProgressBar.setProgress(0);
        nodeAdvertisementFetchProgressBar.setVisible(true);

        SfaAuthority authority = experimenterModel.getAuthorityList().getByUrn(cmi.getUrn()).getSfaAuthority();
        Task fetchAdvertisementTask = experimenterModel.getHighLevelController().getAdvertisement(authority);

        fetchAdvertisementTask.addCallback(new TaskFinishedCallback() {
            @Override
            public void onTaskFinished(Task task, SingleTask singleTask,
                                       SingleTask.TaskState state) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        nodeAdvertisementFetchProgressBar.setProgress(PROGRESS_FETCH_COMPLETE);
                    }
                });

                final List<ComponentManagerInfo.ComponentId> newComponentIds =
                        listComponentIds(experimenterModel.getAuthorityList().getByUrn(cmi.getUrn()));
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        cmi.getComponentIds().clear();
                        cmi.getComponentIds().addAll(newComponentIds);
                        showNodeAssignmentList(cmi);
                        nodeAdvertisementFetchProgressBar.setProgress(1);
                    }
                });


            }
        });
        nodeAdvertisementFetchProgressBar.setProgress(PROGRESS_FETCH_REQUESTED);
        tt.addTask(fetchAdvertisementTask);
    }

    @FXML
    public void onSaveAction(ActionEvent actionEvent) {

        if (!isValidNodeName(nameTextField.getText())) {
            Dialogs.showErrorDialog((Stage) this.getScene().getWindow(),
                    "A node name may only contain alphanumerical characters, and is maximum " + getMaximumNodeNameLength() + " characters long.",
                    "The entered node name is invalid.");
            return;
        }
        if (nodeAssignedRadioButton.isSelected() && selectNodeComboBox.getSelectionModel().isEmpty()) {
            Dialogs.showErrorDialog((Stage) this.getScene().getWindow(), "Please select a node from the list",
                    "No node selected");
            return;
        }

        node.setId(nameTextField.getText());

        ComponentManagerInfo cmi = testbedsComboBox.getSelectionModel().getSelectedItem();

        node.setComponentManagerId(cmi.getUrn());
        node.setSliverTypeName(cmi.getSliverTypes().get(0));

        if (selectNodeToggleGroup.getSelectedToggle() == noNodeAssignedRadioButton) {
            node.setComponentId(null);
        } else {
            ComponentManagerInfo.ComponentId cid = selectNodeComboBox.getSelectionModel().getSelectedItem();
            node.setComponentId(cid.getUrn());
        }

        List<RspecLink> toRemove = new ArrayList<>();
        //check for stitched links, and remove if needed
        for (RspecInterface iface : node.getInterfaces()) {
            Set<String> componentManagerIds = new HashSet<>();
            for (RspecInterface iface2 : iface.getLink().getInterfaces()) {
                componentManagerIds.add(iface2.getNode().getComponentManagerId());
            }

            if (componentManagerIds.size() > 1) {
                toRemove.add(iface.getLink());

                Dialogs.showWarningDialog((Stage) this.getScene().getWindow(),
                        "Detetected a stitchted link. This will be removed.",
                        "Stitched links are currently not supported");

            }

        }

        //TODO remove only interface if link has more than two interfaces
        for (RspecLink link : toRemove) {
            model.deleteLink(link);
        }

        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void onRefreshAdvertisementAction() {
        refreshComponentIdsList(true);
    }

    private int getMaximumNodeNameLength() {
        return 10;
    }

    private boolean isValidNodeName(String text) {
        if (text.length() > getMaximumNodeNameLength())
            return false;

        for (char c : text.toCharArray()) {
            boolean validChar = (c >= 'a' && c <= 'z')
                    || (c >= 'A' && c <= 'Z')
                    || (c >= '0' && c <= '9');

            if (!validChar) {
                return false;
            }
        }

        return true;
    }

    @FXML
    public void onCancelAction(ActionEvent actionEvent) {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }
}
