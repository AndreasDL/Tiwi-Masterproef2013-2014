package be.iminds.ilabt.jfed.experimenter_gui.slice.raw;

import be.iminds.ilabt.jfed.experimenter_gui.slice.SliceController;
import be.iminds.ilabt.jfed.highlevel.model.Slice;
import be.iminds.ilabt.jfed.highlevel.model.Sliver;
import javafx.collections.ListChangeListener;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * User: twalcari
 * Date: 2/6/14
 * Time: 8:21 AM
 */
public class RawSliceView extends StackPane {
    private static final Logger LOG = LoggerFactory.getLogger(RawSliceView.class);

    private static final String RAW_SLICE_VIEW_FXML = "RawSliceView.fxml";

    private final SliceController sliceController;

    @FXML
    private HBox initializingBox;
    @FXML
    private ScrollPane testbedsScrollPane;
    @FXML
    private VBox testbedsVBox;

    private Slice slice = null;


    public RawSliceView(SliceController sliceController) {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(RAW_SLICE_VIEW_FXML));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        this.sliceController = sliceController;
    }

    public RawSliceView(SliceController sliceController, Slice slice) {
        this(sliceController);

        setSlice(slice);
    }

    /**
     * A slice can only be set one time, after  that, the field becomes immutable
     *
     * @param slice
     */
    public void setSlice(Slice slice) {
        if (this.slice == null) {
            this.slice = slice;

            LOG.debug("Initializing RawSliceView with slice {}", slice.getUrn());

            this.slice.getSlivers().addListener(new ListChangeListener<Sliver>() {
                @Override
                public void onChanged(Change<? extends Sliver> change) {
                    do {
                        for (Sliver sliver : change.getAddedSubList()) {
                            addSliverToView(sliver);
                        }
                    } while (change.next());
                }
            });
            for (Sliver sliver : slice.getSlivers())
                addSliverToView(sliver);

        } else
            throw new RuntimeException("Slice has already been set in RawSliceView!");
    }

    private void addSliverToView(Sliver sliver) {
        LOG.debug("Adding sliver {} to RawSliceView", sliver.getUrn());

        getChildren().remove(initializingBox);

        testbedsVBox.getChildren().add(new TestBedStatusView(sliceController, this, sliver));

        LOG.debug("TestbedsVBox now contains {} children and has size {}x{}", new Object[]{
                testbedsVBox.getChildren().size(), testbedsVBox.getHeight(), testbedsVBox.getWidth()});

    }

    public ScrollPane getTestbedsScrollPane() {
        return testbedsScrollPane;
    }

}
