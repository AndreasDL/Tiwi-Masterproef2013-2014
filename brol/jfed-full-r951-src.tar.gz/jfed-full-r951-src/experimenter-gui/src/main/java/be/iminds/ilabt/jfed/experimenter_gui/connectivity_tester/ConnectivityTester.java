package be.iminds.ilabt.jfed.experimenter_gui.connectivity_tester;

import be.iminds.ilabt.jfed.connectivity_tester.ConnectivityTest;
import be.iminds.ilabt.jfed.connectivity_tester.ConnectivityTestSuite;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageBuilder;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * User: twalcari
 * Date: 1/3/14
 * Time: 9:49 AM
 */
public class ConnectivityTester extends BorderPane {

    static final String FXML = "ConnectivityTester.fxml";
    private final ExecutorService es = Executors.newSingleThreadExecutor();
    private Stage stage;
    @FXML
    private ScrollPane testsScrollPane;
    @FXML
    private Accordion testsAccordion;

    private List<ConnectivityTest> tests;
    private boolean testsStarted = false;


    public ConnectivityTester() {
        tests = new ConnectivityTestSuite().getTests();

        URL location = ConnectivityTester.class.getResource(FXML);
        assert location != null;

        FXMLLoader loader = new FXMLLoader(location);
        loader.setController(this);
        loader.setRoot(this);

        try {
            loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public synchronized void showDialog() {
        if (stage == null) {
            stage = StageBuilder.create()
                    .title("jFed Connectivity Tester")
                    .scene(new Scene(this))
                    .resizable(false)
                    .build();
        }

        stage.show();

        startTests();
    }

    public void initialize() {

    }

    public void startTests() {
        //only start tests once
        if(testsStarted)
            return;

        testsStarted = true;
        //load the tests
        for (ConnectivityTest test : tests) {

            ConnectivityTestTask ctt = new ConnectivityTestTask(test);
            ConnectivityTestPane pane = new ConnectivityTestPane(ctt);
            testsAccordion.getPanes().add(pane);
            es.submit(ctt);
        }

        es.shutdown();
    }

    public boolean testsDone(){
        return es.isTerminated();
    }

    public List<ConnectivityTest> getTests() {
        return tests;
    }
}
