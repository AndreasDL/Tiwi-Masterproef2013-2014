package be.iminds.ilabt.jfed.experimenter_gui;

import be.iminds.ilabt.jfed.experimenter_gui.bugreporting.BugReportDialog;
import be.iminds.ilabt.jfed.experimenter_gui.call_gui.TasksPanel;
import be.iminds.ilabt.jfed.experimenter_gui.connectivity_tester.ConnectivityTester;
import be.iminds.ilabt.jfed.experimenter_gui.dialogs.RecoverSliceDialog;
import be.iminds.ilabt.jfed.experimenter_gui.editor.ExperimentEditor;
import be.iminds.ilabt.jfed.experimenter_gui.model.ExperimenterModel;
import be.iminds.ilabt.jfed.experimenter_gui.preferences.PreferencesDialogFactory;
import be.iminds.ilabt.jfed.experimenter_gui.tabs.ExperimentEditorTab;
import be.iminds.ilabt.jfed.experimenter_gui.tabs.RibbonEnabled;
import be.iminds.ilabt.jfed.experimenter_gui.tabs.SliceControllerTab;
import be.iminds.ilabt.jfed.experimenter_gui.tabs.StatusEnabled;
import be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon.RibbonBar;
import be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon.RibbonButton;
import be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon.RibbonTab;
import be.iminds.ilabt.jfed.experimenter_gui.ui.status.TaskStatusIndicator;
import be.iminds.ilabt.jfed.experimenter_gui.util.SliceDefinitionBackup;
import be.iminds.ilabt.jfed.highlevel.controller.*;
import be.iminds.ilabt.jfed.highlevel.model.AuthorityInfo;
import be.iminds.ilabt.jfed.highlevel.model.Slice;
import be.iminds.ilabt.jfed.highlevel.model.rspec_source.RequestRspecSource;
import be.iminds.ilabt.jfed.lowlevel.userloginmodel.UserLoginModelManager;
import be.iminds.ilabt.jfed.rspec.model.InvalidRspecException;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;
import be.iminds.ilabt.jfed.rspec.model.StringRspec;
import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import com.google.common.base.Function;
import com.google.common.collect.Iterables;
import com.google.common.collect.Ordering;
import com.sun.javafx.collections.ObservableListWrapper;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.FileChooserBuilder;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.StringConverter;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.*;

/**
 * User: twalcari
 * Date: 10/18/13
 * Time: 4:21 PM
 */
public class ExperimenterGUI extends BorderPane implements ListChangeListener<Tab> {

    public static final String EXPERIMENT_FILE_EXTENSION = ".rspec";
    public static final FileChooser.ExtensionFilter RSPEC_EXTENSION_FILTER =
            new FileChooser.ExtensionFilter("RSpec Experiment", "*" + EXPERIMENT_FILE_EXTENSION);
    private static final Logger LOG = LoggerFactory.getLogger(ExperimenterGUI.class);
    private final Map<RibbonTab, Integer> ribbonTabUsage = new HashMap<>();
    private final TaskThread taskThread = TaskThread.getInstance();
    private final ExperimenterConfiguration conf = ExperimenterConfiguration.getInstance();
    private final UserLoginModelManager userLoginModelManager;
    //  private final be.iminds.ilabt.jfed.log.Logger logger;
    private final ExperimenterModel experimenterModel;
    private final ConnectivityTester connectivityTester;
    @FXML
    private RibbonBar ribbonBar;
    @FXML
    private RibbonButton newExperimentButton;
    @FXML
    private RibbonButton openExperimentButton;
    @FXML
    private RibbonButton openExperimentURLButton;
    @FXML
    private RibbonButton saveExperimentButton;
    @FXML
    private RibbonButton startExperimentButton;
    @FXML
    private RibbonButton stopExperimentButton;
    @FXML
    private RibbonButton recoverExperimentButton;
    @FXML
    private VBox noTabsOpenBox;
    @FXML
    private TabPane tabPane;
    @FXML
    private Label leftStatus;
    @FXML
    private Label rightStatus;
    @FXML
    private TaskStatusIndicator callsStatusIndicator;
    @FXML
    private RibbonButton updateExperimentButton;

    public ExperimenterGUI() {
        this.experimenterModel = ExperimenterModel.getInstance();

        this.userLoginModelManager = experimenterModel.getUserLoginModelManager();
        this.connectivityTester = experimenterModel.getConnectivityTester();
    }

    private static int getMaximumSliceNameLength(int longestNodeNameLength) {
        assert (longestNodeNameLength > 0);
        return 18 - longestNodeNameLength;
    }

    private static boolean isValidSliceName(String sliceName, int longestNodeNameLength) {
        if (sliceName == null)
            return false;
        if (sliceName.length() == 0)
            return false;
        if (sliceName.length() > getMaximumSliceNameLength(longestNodeNameLength))
            return false;

        for (char c : sliceName.toCharArray()) {
            boolean validChar = (c >= 'a' && c <= 'z')
                    || (c >= 'A' && c <= 'Z')
                    || (c >= '0' && c <= '9');

            if (!validChar) {
                return false;
            }
        }

        return true;
    }

    public void initialize() {

        // hide/show "no tabs" notification when a tab is opened/all tabas are closed
        tabPane.getTabs().addListener(new ListChangeListener<Tab>() {
            @Override
            public void onChanged(Change<? extends Tab> change) {
                noTabsOpenBox.setVisible(tabPane.getTabs().size() == 0);
            }
        });

        tabPane.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
            @Override
            public void changed(ObservableValue<? extends Tab> observableValue, Tab oldValue, Tab newValue) {

                if (newValue == null)
                    return;

                saveExperimentButton.setDisable(!(newValue instanceof ExperimentEditorTab));

                startExperimentButton.setDisable(!(newValue instanceof ExperimentEditorTab));

                updateExperimentButton.setDisable(!(newValue instanceof SliceControllerTab));

                stopExperimentButton.setDisable(!(newValue instanceof SliceControllerTab));

            }
        });

        tabPane.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
            @Override
            public void changed(ObservableValue<? extends Tab> observableValue, Tab oldValue, Tab newValue) {
                if (oldValue != null && oldValue instanceof StatusEnabled)
                    leftStatus.textProperty().unbind();

                if (newValue != null && newValue instanceof StatusEnabled)
                    leftStatus.textProperty().bind(((StatusEnabled) newValue).statusProperty());
                else {
                    leftStatus.setText("");
                }
            }
        });

        tabPane.getTabs().addListener(this);

        //initialize progress indicator

        final JavaFXTaskThread callThread = JavaFXTaskThread.getInstance();
        callThread.busyProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean oldValue, Boolean newValue) {
                callsStatusIndicator.setStatus(
                        newValue ? TaskStatusIndicator.Status.BUSY : TaskStatusIndicator.Status.SUCCESS);

            }
        });
        callsStatusIndicator.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                onOpenCallOverviewAction();
            }
        });

        //force a refresh of the slices-list
        assert TaskThread.getInstance() != null;
        assert experimenterModel != null;
        assert experimenterModel.getHighLevelController() != null;
        TaskThread.getInstance().addTasks(experimenterModel.getHighLevelController().refreshSlices());

    }

    @FXML
    public void onNewExperimentPressed(ActionEvent actionEvent) {

        ExperimentEditorTab newTab =
                new ExperimentEditorTab(this, new RequestRspecSource(new ModelRspec()),
                        getNextNewExperimentDefinitionName(), null);
        tabPane.getTabs().add(newTab);
        tabPane.getSelectionModel().select(newTab);
    }

    private String getNextNewExperimentDefinitionName() {

        String baseName = "Untitled";

        if (!experimentDefinitionNameExists(baseName))
            return baseName;

        int counter = 1;
        String name = baseName + counter;
        while (experimentDefinitionNameExists(name)) {
            counter++;
            name = baseName + counter;
        }
        return name;


    }

    private boolean experimentDefinitionNameExists(String name) {
        for (Tab tab : tabPane.getTabs()) {
            if (tab instanceof ExperimentEditorTab) {
                ExperimentEditor ee = ((ExperimentEditorTab) tab).getExperimentEditor();

                if (ee.getName().equals(name))
                    return true;
            }
        }
        return false;
    }

    @FXML
    private void onOpenExperimentPressed() {

        FileChooser fc = FileChooserBuilder.create()
                .title("Open Experiment Definition")
                .extensionFilters(RSPEC_EXTENSION_FILTER)
                .build();

        List<File> files = fc.showOpenMultipleDialog(openExperimentButton.getScene().getWindow());

        if (files == null)
            return;

        for (File file : files) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                StringBuilder fileContents = new StringBuilder();

                String line;
                while ((line = reader.readLine()) != null) {
                    fileContents.append(line);
                    fileContents.append(System.getProperty("line.separator"));
                }

                reader.close();

                StringRspec stringRspec = new StringRspec(fileContents.toString());
                boolean isParsed = false;
                ModelRspec model = null;
                try {
                    model = ModelRspec.fromGeni3RequestRspecXML(fileContents.toString());
                    isParsed = false;
                } catch (InvalidRspecException ex) {
//                    Dialogs.showErrorDialog((Stage) openExperimentURLButton.getScene().getWindow(),
//                            "The given URL does not contain a valid Rspec.",
//                            "Opening Rspec from URL failed",
//                            "Opening Rspec from URL failed",
//                            ex);
//                    return;
                }

                RequestRspecSource requestRspecSource = null;
                if (isParsed)
                    requestRspecSource = new RequestRspecSource(model);
                else
                    requestRspecSource = new RequestRspecSource(stringRspec);

                ExperimentEditorTab newTab =
                        new ExperimentEditorTab(this, requestRspecSource,
                                file.getName().replace(EXPERIMENT_FILE_EXTENSION, ""), file);
                tabPane.getTabs().add(newTab);
                tabPane.getSelectionModel().select(newTab);


            } catch (IOException e) {
                Dialogs.showErrorDialog((Stage) openExperimentButton.getScene().getWindow(),
                        "Could not open file " + file.getAbsolutePath(),
                        "Error while opening Experiment Definition",
                        "Error while opening Experiment Definition", e);

            } catch (RuntimeException e) {
                Dialogs.showErrorDialog((Stage) openExperimentButton.getScene().getWindow(),
                        "An Error occurred while processing file " + file.getAbsolutePath(),
                        "Error while opening Experiment Definition",
                        "Error while opening Experiment Definition", e);
            }


        }

    }

    @FXML
    private void onSaveExperimentPressed() {
        Tab selectedTab = tabPane.getSelectionModel().getSelectedItem();

        assert selectedTab instanceof ExperimentEditorTab;

        ExperimentEditorTab eeTab = (ExperimentEditorTab) selectedTab;
        eeTab.getExperimentEditor().save();

    }

    public void setSecondaryStatus(String status) {
        rightStatus.setText(status);
    }

    /**
     * Adds and removes ribbonTabs associated with experimenterGUI-tabs
     */
    @Override
    public void onChanged(Change<? extends Tab> change) {

        List<RibbonTab> toBeAdded = new ArrayList<>();
        List<RibbonTab> toBeRemoved = new ArrayList<>();

        while (change.next()) {

            if (change.wasAdded()) {
                for (Tab tab : change.getAddedSubList()) {
                    if (tab instanceof RibbonEnabled) {
                        RibbonTab rt = ((RibbonEnabled) tab).getRibbonTab();
                        if (ribbonTabUsage.containsKey(rt)) {
                            ribbonTabUsage.put(rt, ribbonTabUsage.get(rt) + 1);
                        } else {
                            ribbonTabUsage.put(rt, 1);
                            toBeAdded.add(rt);
                        }
                    }
                }
            }

            if (change.wasRemoved()) {

                for (Tab tab : change.getRemoved()) {
                    if (tab instanceof RibbonEnabled) {
                        RibbonTab rt = ((RibbonEnabled) tab).getRibbonTab();
                        assert (ribbonTabUsage.containsKey(rt));
                        ribbonTabUsage.put(rt, ribbonTabUsage.get(rt) - 1);

                        if (ribbonTabUsage.get(rt) == 0)
                            toBeRemoved.add(rt);
                    }
                }
            }
        }
        for (RibbonTab rt : toBeAdded) {
            ribbonBar.getTabs().add(rt);
            if (rt.makeVisibleOnRegistration())
                ribbonBar.getSelectionModel().select(rt);
        }

        for (RibbonTab rt : toBeRemoved) {
            ribbonBar.getTabs().remove(rt);
        }
    }

    public Tab getActiveTab() {
        return tabPane.getSelectionModel().getSelectedItem();
    }

    public TabPane getTabPane() {
        return tabPane;
    }

    @FXML
    private void onRunExperimentPressed() {

        //get model from the active tab
        Tab selectedTab = tabPane.getSelectionModel().getSelectedItem();

        assert selectedTab instanceof ExperimentEditorTab;

        ExperimentEditorTab eeTab = (ExperimentEditorTab) selectedTab;
        ExperimentEditor ee = eeTab.getExperimentEditor();

//        try {
        final RequestRspecSource requestRspecSource = ee.getRequestRspecSource();

        if (!requestRspecSource.getStringRspec().isWellFormed()) {
            Stage stage = (Stage) ribbonBar.getScene().getWindow();
            Dialogs.showErrorDialog(stage,
                    "The RSpec XML is not well-formed. Cannot create slivers, \"Run Experiment\" aborted.");
            return;
        }

        if (requestRspecSource.getAllComponentManagerUrns().isEmpty()) {
            Stage stage = (Stage) ribbonBar.getScene().getWindow();
            Dialogs.showErrorDialog(stage,
                    "jFed could not find component managers in the RSpec XML. Either there is an error in the RSpec, or jFed does not support this RSpec. Either way, it is impossible to continue, \"Run Experiment\" aborted.");
            return;
        }

        Set<String> unknownComponentManagerUrns = new HashSet<>();
        for (String componentManagerUrn : requestRspecSource.getAllComponentManagerUrns()) {
            final AuthorityInfo ai = experimenterModel.getAuthorityList().getByUrn(componentManagerUrn);
           if (ai == null) {
               unknownComponentManagerUrns.add(componentManagerUrn);
           }
        }
        if (!unknownComponentManagerUrns.isEmpty()) {
            Stage stage = (Stage) ribbonBar.getScene().getWindow();
            String urns = "";
            for (String unknownComponentManagerUrn : unknownComponentManagerUrns) {
                if (!urns.isEmpty())
                    urns += ", ";
                urns += unknownComponentManagerUrn;
            }
            Dialogs.showErrorDialog(stage,
                    "jFed does not have information about some component managers in the RSpec XML: "+urns+" \nIt is impossible to correctly continue, \"Run Experiment\" aborted.");
            return;
        }

        new CreateSliceDialog(requestRspecSource).showDialog();
//        } catch (InvalidRspecException ex) {
//            Dialogs.showErrorDialog((Stage) startExperimentButton.getScene().getWindow(),
//                    "The Rspec that you provided is invalid. Please verify your input.", "Unable to process Rspec",
//                    "Invalid Rspec", ex);
//        }


    }

    @FXML
    public void onOpenExperimentFromURLPressed(ActionEvent actionEvent) {


        //create a custom pane for entering the URL

        GridPane dialogPane = new GridPane();
        Label label = new Label("Please enter the URL:");
        dialogPane.add(label, 0, 0);

        final TextField urlTextField = new TextField();
        urlTextField.setPrefColumnCount(40);
        dialogPane.add(urlTextField, 0, 1);

        Dialogs.showCustomDialog((Stage) openExperimentURLButton.getScene().getWindow(),
                dialogPane, "Open Experiment Definition", "Open Experiment Definition", Dialogs.DialogOptions.OK_CANCEL, new Callback<Void, Void>() {
            @Override
            public Void call(Void aVoid) {
                String urlString = urlTextField.getText();
                if (urlString.isEmpty())
                    return null;

                try {
                    URL url = new URL(urlString);
                    BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));

                    StringBuilder fileContents = new StringBuilder();

                    String line;
                    while ((line = reader.readLine()) != null) {
                        fileContents.append(line);
                        fileContents.append(System.getProperty("line.separator"));
                    }

                    reader.close();

                    StringRspec stringRspec = new StringRspec(fileContents.toString());
                    ModelRspec model = null;
                    boolean isParsed = false;
                    try {
                        model = ModelRspec.fromGeni3RequestRspecXML(fileContents.toString());
                        isParsed = false; //true
                    } catch (InvalidRspecException ex) {
                        Dialogs.showErrorDialog((Stage) openExperimentURLButton.getScene().getWindow(),
                                "The given URL does not contain a valid Rspec.",
                                "Opening Rspec from URL failed",
                                "Opening Rspec from URL failed",
                                ex);
                        return null;
                    }

                    RequestRspecSource requestRspecSource = null;
                    if (isParsed) {
                        requestRspecSource = new RequestRspecSource(model);
                    } else {
                        requestRspecSource = new RequestRspecSource(stringRspec);
                    }

                    //get name from url
                    String name = urlString.substring(urlString.lastIndexOf('/') + 1);
                    name = name.replace(EXPERIMENT_FILE_EXTENSION, "");

                    ExperimentEditorTab newTab =
                            new ExperimentEditorTab(ExperimenterGUI.this, requestRspecSource, name, null);
                    tabPane.getTabs().add(newTab);
                    tabPane.getSelectionModel().select(newTab);

                } catch (MalformedURLException e) {
                    Dialogs.showErrorDialog((Stage) openExperimentButton.getScene().getWindow(), "The given URL was malformed.", "Error while opening Experiment Definition", "Error while opening Experiment Definition", e);

                } catch (IOException e) {
                    Dialogs.showErrorDialog((Stage) openExperimentButton.getScene().getWindow(), "An exception occured while opening an experiment description from an URL.", "Error while opening Experiment Definition", "Error while opening Experiment Definition", e);
                }
                return null;
            }

        });


    }

    @FXML
    public void onForceStopPressed(ActionEvent actionEvent) {

        LOG.info("Removing old slivers");

        Task refreshTask = experimenterModel.getHighLevelController().resolveUserAndSlices();

        refreshTask.addCallback(new TaskFinishedCallback() {
            @Override
            public void onTaskFinished(Task task, SingleTask singleTask, SingleTask.TaskState state) {

                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        Dialogs.showWarningDialog((Stage) openExperimentButton.getScene().getWindow(), "Requesting termination of " + experimenterModel.getEasyModel().getSlices().size() + " experiments.\r\nThis also includes all earlier terminated experiments that haven't expired yet.", "Terminating all running experiments");
                    }
                });

                for (Slice slice : experimenterModel.getEasyModel().getSlices()) {
                    LOG.warn("Removing old slice " + slice.getUrnString());

                    experimenterModel.getHighLevelController().deleteSlice(slice);
                    LOG.info("Deleted slice " + slice.getUrnString());
                }
            }
        });

        taskThread.addTask(refreshTask);


    }

    private boolean sliceNameExists(String name) {
        for (Slice slice : experimenterModel.getEasyModel().getSlices()) {
            if (slice.getName().equals(name))
                return true;
        }
        return false;
    }

    @FXML
    private void onStopExperimentPressed() {
        assert (tabPane.getSelectionModel().getSelectedItem() instanceof SliceControllerTab);

        SliceControllerTab tab = (SliceControllerTab) tabPane.getSelectionModel().getSelectedItem();

        tab.getSliceController().stopExperiment();
    }

    @FXML
    private void onRenewSlicePressed() {
        assert (tabPane.getSelectionModel().getSelectedItem() instanceof SliceControllerTab);
        SliceControllerTab tab = (SliceControllerTab) tabPane.getSelectionModel().getSelectedItem();

        tab.getSliceController().renewSlice();
    }

    @FXML
    public void showPreferencesDialog() {
        PreferencesDialogFactory.showPreferencesDialog();
    }

    @FXML
    private void onOpenCallOverviewAction() {
        TasksPanel.showTasks(experimenterModel);
    }

    @FXML
    private void onRecoverExperimentPressed() {
        //show the select slice dialog

        RecoverSliceDialog dialog = new RecoverSliceDialog();

        dialog.showDialog();

        Slice recoverSlice = dialog.getSelectedSlice();
        if (recoverSlice == null || recoverSlice.getName() == null || recoverSlice.getName().trim().isEmpty())
            return; //user cancelled recovery

        //try to find the rspec
        ModelRspec model = SliceDefinitionBackup.recoverExperimentDefinition(recoverSlice.getName());

        if (model == null) {
            Dialogs.showErrorDialog((Stage) recoverExperimentButton.getScene().getWindow(),
                    "Could not find recovery data for this file.",
                    "Slice recovery failed", "Computer says no.");
            return;
        }

        //TODO FEDIBBTDEV-275: determine if this is unmodified Xml generated by GUI, or if this is user modified Xml, and call the appropriate setter
        recoverSlice.setRequestRspec(new RequestRspecSource(model));

        SliceControllerTab sliceControllerTab = new SliceControllerTab(this, recoverSlice);
        tabPane.getTabs().add(sliceControllerTab);
    }

    @FXML
    private void onReportBugButtonAction() {
        BugReportDialog brp = new BugReportDialog();
        brp.showDialog();
    }

    @FXML
    private void onUpdateExperimentPressed() {
        assert (tabPane.getSelectionModel().getSelectedItem() instanceof SliceControllerTab);

        SliceControllerTab tab = (SliceControllerTab) tabPane.getSelectionModel().getSelectedItem();

        tab.getSliceController().requestUpdate();
    }

    @FXML
    public void onOpenConnectivityTestAction() {
        connectivityTester.showDialog();
    }

    @FXML
    public void onDocumentationAction() {
        try {
            java.awt.Desktop.getDesktop().browse(new URI("http://doc.fed4fire.eu"));
        } catch (IOException e) {
        } catch (URISyntaxException e) {
        }
    }

    private final class CreateSliceDialog extends GridPane {
        private static final String VALID_STYLE = "name-textfield-valid";
        private static final String INVALID_STYLE = "name-textfield-invalid";
        private static final String CREATE_SLICE_FXML = "CreateSliceDialog.fxml";
        private final RequestRspecSource requestRspecSource;
        private int longestNodeNameLength = 8;
        @FXML
        private TextField nameTextField;
        @FXML
        private ComboBox<Integer> hoursComboBox;
        @FXML
        private ComboBox<Integer> minutesComboBox;
        @FXML
        private ComboBox<Integer> daysComboBox;

        public CreateSliceDialog(RequestRspecSource requestRspecSource) {
            this.requestRspecSource = requestRspecSource;
            URL location = ExperimenterGUI.class.getResource(CREATE_SLICE_FXML);
            FXMLLoader loader = new FXMLLoader(location);

            loader.setRoot(this);
            loader.setController(this);

            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            //populate combo-boxes
            List<Integer> days = new ArrayList<>();
            for (int i = 0; i <= 100; i++)
                days.add(i);
            daysComboBox.setItems(new ObservableListWrapper<Integer>(days));
            daysComboBox.getSelectionModel().selectFirst();

            List<Integer> hours = new ArrayList<>();
            for (int i = 0; i <= 23; i++)
                hours.add(i);
            hoursComboBox.setItems(new ObservableListWrapper<Integer>(hours));
            hoursComboBox.getSelectionModel().select(new Integer(2));

            List<Integer> minutes = new ArrayList<>();
            for (int i = 0; i <= 59; i++)
                minutes.add(i);
            minutesComboBox.setItems(new ObservableListWrapper<Integer>(minutes));
            minutesComboBox.setConverter(new StringConverter<Integer>() {
                @Override
                public String toString(Integer integer) {
                    return String.format("%02d", integer);
                }

                @Override
                public Integer fromString(String s) {
                    return Integer.parseInt(s);
                }
            });
            minutesComboBox.getSelectionModel().selectFirst();

            //calculate max. slice name length
            if (!requestRspecSource.isXmlBased())
                longestNodeNameLength =
                        Ordering.<Integer>natural().max(Iterables.transform(requestRspecSource.getModelRspec().getNodes(),
                                new Function<RspecNode, Integer>() {
                                    @Override
                                    public Integer apply(RspecNode input) {
                                        return input.getId().length();
                                    }
                                }));

            String tooltip = nameTextField.getTooltip().getText();
            tooltip = tooltip.replace("{}", Integer.toString(getMaximumSliceNameLength(longestNodeNameLength)));
            nameTextField.getTooltip().setText(tooltip);


            //add listener to nameTextField

            nameTextField.textProperty().addListener(new InvalidationListener() {
                @Override
                public void invalidated(Observable observable) {
                    if (isValidSliceName(nameTextField.getText(), longestNodeNameLength)) {
                        nameTextField.getStyleClass().remove(INVALID_STYLE);
                        nameTextField.getStyleClass().add(VALID_STYLE);
                    } else {
                        nameTextField.getStyleClass().remove(VALID_STYLE);
                        nameTextField.getStyleClass().add(INVALID_STYLE);
                    }
                }
            });
        }

        public void showDialog() {
            String sliceName = null;
            DateTime expirationTime = null;

            boolean validationSucceeded = false;
            while (!validationSucceeded) {
                Dialogs.DialogResponse response = Dialogs.showCustomDialog(
                        (Stage) startExperimentButton.getScene().getWindow(),
                        this,
                        "Enter experiment run details",
                        "Start an experiment run",
                        Dialogs.DialogOptions.OK_CANCEL, null);
                if (response != Dialogs.DialogResponse.OK)
                    return;

                sliceName = nameTextField.getText();
                expirationTime = new DateTime()
                        .plusDays(daysComboBox.getSelectionModel().getSelectedItem())
                        .plusHours(hoursComboBox.getSelectionModel().getSelectedItem())
                        .plusMinutes(minutesComboBox.getSelectionModel().getSelectedItem())
                        .plusSeconds(15); //prevent problems with checks that are too strict

                //check if slicename is valid
                if (!isValidSliceName(sliceName, longestNodeNameLength)) {
                    Dialogs.showErrorDialog((Stage) startExperimentButton.getScene().getWindow(),
                            "The given name is invalid! Please adhere to the naming restrictions",
                            "Experiment run creation failed");

                } else if (sliceNameExists(sliceName)) {
                    Dialogs.showErrorDialog((Stage) startExperimentButton.getScene().getWindow(),
                            "The given name already exists!", "Experiment run creation failed");

//                } else if (expirationTime == null) {  //check if expirationTime is correct
//                    Dialogs.showErrorDialog((Stage) startExperimentButton.getScene().getWindow(),
//                            "The given expiration date is invalid!", "Experiment run creation failed");
//
//                } else if (!isValidExpirationDate(expirationTime)) {
//                    Dialogs.showErrorDialog((Stage) startExperimentButton.getScene().getWindow(),
//                            "The given expiration date lies outside the supported time-window: you must enter an expiration-time between 2 and 24 hours from now!", "Experiment run creation failed");

                } else
                    validationSucceeded = true;
            }

            //create backup for this slice

            SliceDefinitionBackup.saveExperimentDefinition(requestRspecSource, sliceName, expirationTime);

            //start slicecontroller with this model

            SliceControllerTab newTab =
                    new SliceControllerTab(ExperimenterGUI.this, requestRspecSource, sliceName, expirationTime);
            tabPane.getTabs().add(newTab);
            tabPane.getSelectionModel().select(newTab);
        }
    }

}
