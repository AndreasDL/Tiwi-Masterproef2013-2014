package be.iminds.ilabt.jfed.experimenter_gui.canvas;

import be.iminds.ilabt.jfed.experimenter_gui.canvas.impl.RspecCanvasLink;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;

/**
 * User: twalcari
 * Date: 11/8/13
 * Time: 12:27 PM
 */
public class SelectionProvider {

    private final ObjectProperty<CanvasNode> selectedCanvasNode = new SimpleObjectProperty<>(null);
    private final ObjectProperty<RspecCanvasLink.InterfaceLink> selectedInterfaceLink = new SimpleObjectProperty<>(null);
    private final ObjectProperty<RspecCanvasLink> selectedCanvasLink = new SimpleObjectProperty<>(null);

    //////////////////////////////////////////////////////////////////////////////////////////////////////////

    public SelectionProvider() {
    }

    public void clearAllSelections() {
        selectedCanvasNode.set(null);
        selectedCanvasLink.set(null);
        selectedInterfaceLink.set(null);
    }

    public CanvasNode getSelectedCanvasNode() {
        return selectedCanvasNode.get();
    }

    public void setSelectedCanvasNode(CanvasNode value) {
        selectedCanvasNode.set(value);

        if (value != null)              {
            selectedCanvasLink.set(null);
            selectedInterfaceLink.set(null);
        }
    }

    public ObjectProperty<CanvasNode> selectedCanvasNodeProperty() {
        return selectedCanvasNode;
    }

    public boolean isNodeSelected(CanvasNode item) {
        if (selectedCanvasNode.get() == null) return false;
        return selectedCanvasNode.get().equals(item);
    }

    public RspecCanvasLink getSelectedCanvasLink() {
        return selectedCanvasLink.get();
    }

    public void setSelectedCanvasLink(RspecCanvasLink value) {
        selectedCanvasLink.set(value);
        if (value != null) {
            selectedCanvasNode.set(null);
            selectedInterfaceLink.set(null);

        }
    }

    public ObjectProperty<RspecCanvasLink> selectedCanvasLinkProperty() {
        return selectedCanvasLink;
    }

    public boolean isLinkSelected(RspecCanvasLink link) {
        if (selectedCanvasLink.get() == null) return false;
        return selectedCanvasLink.get().equals(link);
    }

    public RspecCanvasLink.InterfaceLink getSelectedInterfaceLink() {
        return selectedInterfaceLink.get();
    }

    public ObjectProperty<RspecCanvasLink.InterfaceLink> selectedInterfaceLinkProperty() {
        return selectedInterfaceLink;
    }

    public void setSelectedInterfaceLink(RspecCanvasLink.InterfaceLink selectedInterfaceLink) {
        this.selectedInterfaceLink.set(selectedInterfaceLink);

        if(selectedInterfaceLink != null){
            selectedCanvasLink.set(null);
            selectedCanvasNode.set(null);
        }
    }
}
