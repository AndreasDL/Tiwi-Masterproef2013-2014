package be.iminds.ilabt.jfed.experimenter_gui;

import be.iminds.ilabt.jfed.experimenter_gui.editor.bo.NodeDescription;
import be.iminds.ilabt.jfed.experimenter_gui.editor.bo.RspecNodeDescription;
import com.google.common.collect.ImmutableSet;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.HierarchicalConfiguration;
import org.apache.commons.configuration.XMLConfiguration;

import java.util.*;

/**
 * User: twalcari
 * Date: 1/9/14
 * Time: 5:17 PM
 */
public class ExperimenterConfiguration {

    private final static String CONFIGURATION_LOC = "/configuration.xml";
    private final static String ENABLED_TESTBEDS = "enabled-testbeds.enabled-testbed";
    private static final String ENABLED_TESTBED_URN = "urn";
    private static final String ENABLED_COMPONENT_ID_URN = "enabled-componentIds.urn";
    private final static String NODE_DESCRIPTIONS = "node-descriptions.node-description";
    private final static String TYPE_DEFINITION = "type-definition";
    private final static ExperimenterConfiguration INSTANCE = new ExperimenterConfiguration();
    private List<NodeDescription> nodeDescriptions;

    private ExperimenterConfiguration() {

        try {
            HierarchicalConfiguration conf =
                    new XMLConfiguration(ExperimenterConfiguration.class.getResource(CONFIGURATION_LOC));

            //load the node descriptions
            nodeDescriptions = new ArrayList<>();
            for (HierarchicalConfiguration nodeConf : conf.configurationsAt(NODE_DESCRIPTIONS)) {
                String id = nodeConf.getString("[@id]");
                String name = nodeConf.getString("[@friendlyName]");
                NodeDescription.NodeType type =
                        NodeDescription.NodeType.valueOf(nodeConf.getString("[@type]").toUpperCase());


                List<RspecNodeDescription> rspecNodeDescriptions = new ArrayList<>();
                for (HierarchicalConfiguration typeConf : nodeConf.configurationsAt(TYPE_DEFINITION)) {
                    String cmUrn = typeConf.getString("component_manager_id");
                    boolean exclusive = typeConf.getBoolean("exclusive");
                    String cUrn = typeConf.getString("component_id");
                    String sliverType = typeConf.getString("sliver_type");

                    rspecNodeDescriptions.add(new RspecNodeDescription(cmUrn, cUrn, exclusive, sliverType));
                }

                Map<String, EnabledTestbed> enabledTestbeds = new HashMap<>();
                //load the enabled testbeds
                for (HierarchicalConfiguration tbConf : nodeConf.configurationsAt(ENABLED_TESTBEDS)) {
                    String tbUrn = tbConf.getString(ENABLED_TESTBED_URN);

                    String[] componentIdsArray = tbConf.getStringArray(ENABLED_COMPONENT_ID_URN);

                    ImmutableSet<String> componentIds =
                            componentIdsArray.length == 0 ?
                                    null :
                                    ImmutableSet.copyOf(componentIdsArray);

                    enabledTestbeds.put(tbUrn, new EnabledTestbed(tbUrn, componentIds));


                }

                nodeDescriptions.add(new NodeDescription(id, name, type, rspecNodeDescriptions, enabledTestbeds));
            }


        } catch (ConfigurationException e) {
            throw new RuntimeException("Error while loading jFed Experimenter Toolkit configuration", e);
        }


    }

    public static void main(String[] args) {
        ExperimenterConfiguration.getInstance();
    }

    public static ExperimenterConfiguration getInstance() {
        return INSTANCE;
    }

    public Collection<NodeDescription> getNodeDescriptions() {
        return nodeDescriptions;
    }

    public NodeDescription getNodeDescription(String id) {
        for (NodeDescription nd : nodeDescriptions) {
            if (nd.getId().equals(id))
                return nd;
        }
        return null;
    }


    public static class EnabledTestbed {
        private final String urn;

        private final ImmutableSet<String> enabledComponentIds;

        public EnabledTestbed(String urn, ImmutableSet<String> enabledComponentIds) {
            this.urn = urn;
            this.enabledComponentIds = enabledComponentIds;
        }

        public String getUrn() {
            return urn;
        }

        public ImmutableSet<String> getEnabledComponentIds() {
            return enabledComponentIds;
        }
    }
}
