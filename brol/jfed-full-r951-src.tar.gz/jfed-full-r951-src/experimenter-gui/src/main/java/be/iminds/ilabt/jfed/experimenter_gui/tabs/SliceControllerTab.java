package be.iminds.ilabt.jfed.experimenter_gui.tabs;

import be.iminds.ilabt.jfed.experimenter_gui.ExperimenterGUI;
import be.iminds.ilabt.jfed.experimenter_gui.ribbon_tabs.SliceControllerRibbonTab;
import be.iminds.ilabt.jfed.experimenter_gui.slice.SliceController;
import be.iminds.ilabt.jfed.experimenter_gui.ui.ribbon.RibbonTab;
import be.iminds.ilabt.jfed.highlevel.model.Slice;
import be.iminds.ilabt.jfed.highlevel.model.rspec_source.RequestRspecSource;
import com.cathive.fonts.fontawesome.FontAwesomeIcon;
import com.cathive.fonts.fontawesome.FontAwesomeIconView;
import javafx.beans.property.StringProperty;
import javafx.scene.control.Tab;
import org.joda.time.DateTime;

/**
 * User: twalcari
 * Date: 11/19/13
 * Time: 5:10 PM
 */
public class SliceControllerTab extends Tab implements StatusEnabled, RibbonEnabled {

    private static SliceControllerRibbonTab sliceControllerRibbonTab;
    private final ExperimenterGUI experimenterGui;
    private final SliceController sliceController;


    public SliceControllerTab(ExperimenterGUI experimenterGui, RequestRspecSource requestRspecSource, String name, DateTime expirationDate) {
        this.experimenterGui = experimenterGui;
        this.sliceController = new SliceController(requestRspecSource, name, expirationDate);

        setContent(sliceController);

        setText(name);

        FontAwesomeIconView tabIcon = new FontAwesomeIconView();
        tabIcon.setIcon(FontAwesomeIcon.ICON_PLAY_SIGN);
        setGraphic(tabIcon);
    }

    public SliceControllerTab(ExperimenterGUI experimenterGui, Slice slice) {
        this.experimenterGui = experimenterGui;
        this.sliceController = new SliceController(slice);

        setContent(sliceController);

        setText(slice.getName());

        FontAwesomeIconView tabIcon = new FontAwesomeIconView();
        tabIcon.setIcon(FontAwesomeIcon.ICON_PLAY_SIGN);
        setGraphic(tabIcon);
    }

    public SliceController getSliceController() {
        return sliceController;
    }

    @Override
    public StringProperty statusProperty() {
        return sliceController.statusProperty();
    }

    @Override
    public RibbonTab getRibbonTab() {
        if (sliceControllerRibbonTab == null)
            sliceControllerRibbonTab = new SliceControllerRibbonTab(experimenterGui);
        return sliceControllerRibbonTab;
    }
}
