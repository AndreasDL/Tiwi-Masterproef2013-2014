package be.iminds.ilabt.jfed.experimenter_gui.editor.raw;

import be.iminds.ilabt.jfed.experimenter_gui.ui.code.XmlCodeView;
import be.iminds.ilabt.jfed.rspec.model.StringRspec;

/**
 * User: twalcari
 * Date: 1/29/14
 * Time: 5:03 PM
 */
public class RawRspecEditor extends XmlCodeView {

    private final StringRspec inputModel;
    private boolean dirty = false;

    public RawRspecEditor(StringRspec inputModel, boolean dirty) {
        this(inputModel);
        this.dirty = dirty;
    }


    public RawRspecEditor(StringRspec inputModel) {
        super(inputModel.getXmlString(), true);
        this.inputModel = inputModel;
    }

    public StringRspec getResultRspec() {
        return new StringRspec(getContent());
    }

    @Override
    public boolean isDirty() {
        return dirty || super.isDirty();
    }
}
