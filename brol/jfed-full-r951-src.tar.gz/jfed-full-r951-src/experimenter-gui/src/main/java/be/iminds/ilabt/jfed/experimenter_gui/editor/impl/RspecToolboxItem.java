//package be.iminds.ilabt.jfed.experimenter_gui.editor.impl;
//
//import be.iminds.ilabt.jfed.experimenter_gui.editor.ToolboxItem;
//import be.iminds.ilabt.jfed.experimenter_gui.util.ImageUtil;
//import be.iminds.ilabt.jfed.ui.rspeceditor.editor.ComponentManagerInfo;
//
///**
// * User: twalcari
// * Date: 11/8/13
// * Time: 2:36 PM
// */
//public class RspecToolboxItem  extends ToolboxItem{
//
//    private final ComponentManagerInfo componentManagerInfo;
//
//    public RspecToolboxItem(ComponentManagerInfo componentManagerInfo) {
//        super(componentManagerInfo.getUrnPart(), ImageUtil.getComponentManagerInfoImage(componentManagerInfo));
//        this.componentManagerInfo = componentManagerInfo;
//    }
//
//    public ComponentManagerInfo getComponentManagerInfo() {
//        return componentManagerInfo;
//    }
//}
