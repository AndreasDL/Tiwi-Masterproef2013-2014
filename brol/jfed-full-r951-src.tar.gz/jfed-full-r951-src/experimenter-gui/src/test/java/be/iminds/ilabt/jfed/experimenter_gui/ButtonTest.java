package be.iminds.ilabt.jfed.experimenter_gui;

import be.iminds.ilabt.jfed.ui.javafx.dialogs.Dialogs;
import org.junit.Assert;
import org.junit.Test;

/**
 * User: twalcari
 * Date: 12/2/13
 * Time: 10:19 AM
 */
public class ButtonTest {

    @Test
    public void testButtons() {
        Assert.assertNotNull("Dialogs cannot be found", Dialogs.class);
    }

}
