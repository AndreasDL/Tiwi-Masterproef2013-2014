package be.iminds.ilabt.jfed.rspec.model;

import be.iminds.ilabt.jfed.util.XmlUtil;
import org.custommonkey.xmlunit.*;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.io.StringReader;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.stream.StreamSource;

import static org.custommonkey.xmlunit.XMLAssert.assertXMLEqual;

/**
 * TestRspecParsing
 */
public class TestRspecParsing {

    @Test
    public void testRspecA() throws Exception {
        isXmlReconstructable(rspecA);
    }

    @Test
    public void testRspecB() throws Exception {
        isXmlReconstructable(rspecB);
    }

    @Test
    public void testRspecC() throws Exception {
        isXmlReconstructable(rspecC);
    }

    @Test
    public void testRspecCsimple() throws Exception {
        isXmlReconstructable(rspecCsimple);
    }

    @Test
    public void testRspecCsimple2() throws Exception {
        isXmlReconstructable(rspecCsimple2);
    }

    @Test
    public void testRspecD() throws Exception {
        isXmlReconstructable(rspecD);
    }

    @Test
    public void testRspecE() throws Exception {
        isXmlReconstructable(rspecE);
    }

    @Test
    public void testRspecF() throws Exception {
        isXmlReconstructable(rspecF);
    }

    @Test
    public void testRspecG() throws Exception {
        isXmlReconstructable(rspecG);
    }

    @Test
    public void testRspecH() throws Exception {
        isXmlReconstructable(rspecH);
    }

    /**
     * Test if xslt transformation is removing generated and generated_by from the result rspecs
     */
    @Test
    public void testRspecTransform() throws Exception {
        {
            String testXml = "<rspec generated=\"bar\" generated_by=\"foo\" test=\"keepme\"/>";
            Document doc = rspecStringToDocument(testXml);
            Element e = doc.getDocumentElement();
            Assert.assertEquals(e.getTagName(), "rspec", "Problem with transform: "+XmlUtil.elementToXmlString(e));
            Assert.assertTrue(e.hasAttribute("test"), "Problem with transform: "+XmlUtil.elementToXmlString(e));
            Assert.assertEquals(e.getAttribute("test"), "keepme", "Problem with transform: "+XmlUtil.elementToXmlString(e));
            Assert.assertFalse(e.hasAttribute("generated"), "Problem with transform: "+XmlUtil.elementToXmlString(e));
            Assert.assertFalse(e.hasAttribute("generated_by"), "Problem with transform: "+XmlUtil.elementToXmlString(e));
        }

        {
            String testXml = "<rspec " +
                    "generated=\"bar\" " +
                    "generated_by=\"foo\" " +
                    "test=\"keepme\" " +
                    "xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd  \" " +
                    "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
                    "xmlns=\"http://www.geni.net/resources/rspec/3\"/>";
            Document doc = rspecStringToDocument(testXml);
            Element e = doc.getDocumentElement();
            Assert.assertEquals(e.getTagName(), "rspec", "Problem with transform: "+XmlUtil.elementToXmlString(e));
            Assert.assertTrue(e.hasAttribute("test"), "Problem with transform: "+XmlUtil.elementToXmlString(e));
            Assert.assertEquals(e.getAttribute("test"), "keepme", "Problem with transform: "+XmlUtil.elementToXmlString(e));
            Assert.assertFalse(e.hasAttribute("generated"), "Problem with transform: "+XmlUtil.elementToXmlString(e));
            Assert.assertFalse(e.hasAttribute("generated_by"), "Problem with transform: "+XmlUtil.elementToXmlString(e));
        }
    }

    /**
     * Parse the RSpec XML to a Document.
     *
     * Note: this uses an XSLT transformation to remove some attributes that may be ignored when comparing.
     * */
    private Document rspecStringToDocument(String rspec) throws Exception {
        String xslt = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<!-- Remove unwanted attributes or/and nodes -->\n" +
                "<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" xmlns:fo=\"http://www.w3.org/1999/XSL/Format\">\n" +
                "    <xsl:output method=\"xml\" encoding=\"UTF-8\" indent=\"yes\"/>\n" +
                " \n" +
                "    <!-- Copy everything -->\n" +
                "    <xsl:template match=\"@*|node()|text()|comment()|processing-instruction()\">\n" +
                "        <xsl:copy>\n" +
                "            <xsl:apply-templates select=\"@*|node()|text()|comment()|processing-instruction()\"/>\n" +
                "        </xsl:copy>\n" +
                "    </xsl:template>\n" +
                " \n" +
                "    <!-- To remove attributes or nodes, simply write a matching template that doesn't do anything. Therefore, it is removed -->\n" +
                "    <xsl:template match=\"/*[local-name()='rspec']/@generated\"/>\n" +
                "    <xsl:template match=\"/*[local-name()='rspec']/@generated_by\"/>\n" +
                "    <xsl:template match=\"/*[local-name()='rspec']/@xmlns:jFed\"/>\n" +
                " \n" +
                "</xsl:stylesheet>";

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);

        TransformerFactory factory = TransformerFactory.newInstance();
        Templates template = factory.newTemplates(new StreamSource(new StringReader(xslt)));
        Transformer xformer = template.newTransformer();

        DocumentBuilder builder = dbf.newDocumentBuilder();
        assert builder.isNamespaceAware();
        Document doc = builder.newDocument();
        DOMResult result = new DOMResult(doc);

        Source source = new StreamSource(new StringReader(rspec));
        xformer.transform(source, result);

        assert result.getNode().getNodeType() == Node.DOCUMENT_NODE;

        return (Document) result.getNode();
    }

    public boolean testSameXml(String origRspec, String reconstructedRspec) throws Exception {
        XMLUnit.setIgnoreWhitespace(true);
        XMLUnit.setIgnoreAttributeOrder(true);
        XMLUnit.setIgnoreComments(true);

        try {
            Document origRspecDoc = rspecStringToDocument(origRspec);
            Document reconstructedRspecDoc = rspecStringToDocument(reconstructedRspec);
            String origRspecDocXml = XmlUtil.elementToXmlString(origRspecDoc.getDocumentElement());
            String reconstructedRspecDocXml = XmlUtil.elementToXmlString(reconstructedRspecDoc.getDocumentElement());

            DetailedDiff diff = null;
            diff = new DetailedDiff(XMLUnit.compareXML(
                    origRspecDoc,
                    reconstructedRspecDoc
//                    origRspec,
//                    reconstructedRspec
            ));
//            IgnoreUnimportantRspecFields listener = new IgnoreUnimportantRspecFields();
//            diff.overrideDifferenceListener(listener);
//            diff.overrideElementQualifier(new RecursiveElementNameAndTextQualifier()); //ignore all sorts of position switches for Elements
            diff.overrideElementQualifier(new ElementNameAndAttributeQualifier());

            List<?> allDifferences = diff.getAllDifferences();
            Assert.assertTrue (diff.similar(), "Differences found: " + diff.toString()+"\n\nExpected XML:\n"+origRspecDocXml+"\n\nActual XML\n"+reconstructedRspecDocXml);
        } catch (SAXException e) {
            throw new RuntimeException("SAXException: "+e.getMessage()+"\n\nExpected XML:\n"+origRspec+"\n\nActual XML\n"+reconstructedRspec+"\n---", e);
        } catch (IOException e) {
            throw new RuntimeException("IOException: "+e.getMessage()+"\n\nExpected XML:\n"+origRspec+"\n\nActual XML\n"+reconstructedRspec+"\n---", e);
        }

        return false;
    }

    public boolean isXmlReconstructable(String origRspec) throws Exception {
        ModelRspec rspec = ModelRspec.fromGeni3RequestRspecXML(origRspec);
        String reconstructedRspec = rspec.toGeni3RequestRspec();
        return testSameXml(origRspec, reconstructedRspec);
    }


    public static final String rspecA = "<rspec type=\"request\" generated=\"2013-01-16T14:20:39Z\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
            "  <node client_id=\"PC\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC5\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"false\">\n" +
            "    <sliver_type name=\"test\"/>\n" +
            "  </node>\n" +
            "</rspec>\n";
    public static final String rspecA_mod = "<rspec type=\"request\" generated=\"2013-01-16T14:20:39Z\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
            "  <node client_id=\"PC\" component_manager_id=\"urn:publicid:IDN+wall2.test.ibbt.be+authority+cm\" exclusive=\"false\">\n" +
            "    <sliver_type name=\"emulab-openvz\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC2\" component_manager_id=\"urn:publicid:IDN+wall2.test.ibbt.be+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "  </node>\n" +
            "</rspec>\n";
    public static final String rspecB = "<rspec type=\"request\" generated_by=\"Flack\" generated=\"2013-01-11T10:30:10Z\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:flack=\"http://www.protogeni.net/resources/rspec/ext/flack/1\" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
            "  <node client_id=\"PC\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC:if0\">\n" +
            "      <flack:interface_info addressUnset=\"true\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"67\" y=\"116\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC-0\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC-0:if0\">\n" +
            "      <flack:interface_info addressUnset=\"true\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"375\" y=\"172\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <link client_id=\"lan0\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC:if0\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if0\"/>\n" +
            "    <property source_id=\"PC:if0\" dest_id=\"PC-0:if0\" capacity=\"1000000\"/>\n" +
            "    <property source_id=\"PC-0:if0\" dest_id=\"PC:if0\" capacity=\"1000000\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <client:client_info name=\"Flack\" environment=\"Flash Version: LNX 11,2,202,258, OS: Linux 2.6.32-34-generic, Arch: x86, Screen: 1920x1080 @ 72 DPI with touchscreen type none\" version=\"v14.46\" url=\"https://www.emulab.net/protogeni/flack2/flack.swf?mode=public&amp;debug=0&amp;usejs=1\"/>\n" +
            "  <history:slice_history backIndex=\"2\" note=\"Established lan0\" xmlns:history=\"http://www.protogeni.net/resources/rspec/ext/history/1\">\n" +
            "    <history:state>eNqVUk2P0zAQvfMrRj5waZvEaem2oVlArJBW6i4rFaEVl8pxp40hsYM/mvTf4zhZYA9IyyGKNZ55\n" +
            "z/Pe22jTIAd7aTAnGn86NJbACSVqZvGwLy45+VQx/uOvYk7ShM5nCZ1R+oUmWbrOFutvBDojMsNL\n" +
            "rNlWcWaFkjkprW2yOG7bNvLzIpJoY41GOc3RxIE8nsOLuuLxeVFnDuDZ6kqa7Ni/7RlNo5VV/0TB\n" +
            "zsZhJqZPELwSKO1/YgxDf0D87s8Q2nmk9ClOk4TGj3fbXZBlJqSxTHIcp14oD7l+BbCR6oAw0O6F\n" +
            "9+DhIwGu6kbJvlIzyU6ow43TMmtcUQkuDtntzf2kZVU1j2yvnSgKGxU4Yc6WSgt7mfCaAHa8ckac\n" +
            "fQasdhgIPaWpfEnv+3CAZHWfENbOGk7isSEomfUv2wt5VNDlZHlFwGeG0iUBJwvl5GEEDUObuO8O\n" +
            "p2GX7Gmlfn4gGfOG8iy0knUwx9dMCV9RGx+rDLb3j0DpNJ2mif/erKbweeerQroO0mgZzdPZfDEL\n" +
            "iRV8Ch80LzPoVssp7LhG9Ah0nSYdTVYJvIerFG4ebqEVtgSrHC9NaIJhcS8wgfPAnJMzXUSLfjdd\n" +
            "DfaZ0T+sXcWK4ODv+AxRS4dfZNrju9pvnw/mvGZ18/aAhTvlSTg7g99NTkehBm29BXwU9yywzclJ\n" +
            "s6bsWzZDPK5/AZ+ORig=</history:state>\n" +
            "    <history:state>eNrNU01v1DAQvfMrRj5w6ebDSbvbhk0BUSFV2pZKRajisnK8040hsYM/Num/x4lToIeKcuMQJZrM\n" +
            "vOf3/GatTYcc7EOHJdH4w6GxBPYoUTOLu231UJKPDePf/yiWJEtpHqU0ovQzTYvsrDhJvxIYjCgM\n" +
            "r7FlG8WZFUqWpLa2K5Kk7/vYz4tYok00GuU0R5NM5EkOL+pK5uPFg9mBZ2sbaYr78WxPaDqtrHoW\n" +
            "BQebTDMJfYTgjUBp/xEjDP0G8dqfIPR5rPQ+ydKUJndXm9vJlkhIY5nkOE+90B5y/gpgLdUOIdBu\n" +
            "hb+Dmw8EuGo7JcdKyyTbo57+OC2LzlWN4GJXXF5cH/WsafLYjt6JqrJxhUfM2VppYR+OeEsAB944\n" +
            "Iw4+A1Y7nAg9pWl8SW/HcIBk7ZgQ1kcdJ8ncMDlZjCfbCnmvYCjJckXAZ4bSJQEnK+XkbgadhtbJ\n" +
            "2P2MoCj9LyXlq5OgaZX9TVOQUzyqGgECy7xDKA9CK9lOgfM1U8MX1MavSgGb6zugdJEtstQ/J6cL\n" +
            "+HTrq0K6AbJ4GedZlB9H0xYKvoD3mtcFDKfLBdxyjegR6FmWDjQ9TeEdrDK4uLmEXtgarHK8NlMT\n" +
            "BOXeYQKHwFySAz2Oj8f70k2IpJkzia1rWDWl8tdKhPXJwis2/f3b1qsvw+28Zm33ZoeV25fp9O0M\n" +
            "fjMlnY0K5vo74LO7B4F9SfaadfXYsg6RP/8J/vSLjQ==</history:state>\n" +
            "    <history:state>eNrNVE1v00AQvfMrRj5wafyxTpu0Ji4gKqRKpVQqVBWXaL2eJEvttdldx86/Z73rhIRS0V4QB8vW\n" +
            "+M2bmTcfM6lqZKA3NaaexB8NKu3BEgVKqjGfZ5vU+1hQ9rBnTL04ImM/Ij4hX0iUxGfJyek3DzrF\n" +
            "E8VWWNKrilHNK5F6K63rJAzbtg2MPw8E6lCiqhrJUIU2eDiGZ6HCIb2gUzmYaGUhVLLoczsIU8tK\n" +
            "V0+yYKdD6xOSLQUrOAr9Qg7n9IvE1H7A0I6DSi7DOIpIeP/p6tbK4nOhNBUMB69nyuOdvwKYiSpH\n" +
            "cGHn3PTg5oMHrCrrSvSWkgq6RGn/NFIkdZMVnPE8uby4PmppUYwD3WvHs0wHGR7RRq8qyfXmiJUe\n" +
            "YMeKRvG1mQEtG7QBTUhVGJOc98MBgpb9hNDWr5kXDgAuNMoFZb8llvBFNHAYkJU72UHnXCwqoHlu\n" +
            "6lRfhUI9BIWsaoTxX9BC4S5EuHMcDI6uV8Mxdak3mXpg5pSQiQeNGGgsp2WZhT36CRH96L+V0Y/+\n" +
            "tZDj6YlTchr/TcmCi4f9dAsqtqnOHuk5lP1iRR8JNJe4+MOsPQM3iLlFmg2vUeoNuF3bJ4Pc5PMS\n" +
            "rwG073fg1Uu1330j1e6fa4JFbJvgE9uD/jW04M54aLo87ETvY79cmcm22p7FxRnuNoo1l5Uo7ZEz\n" +
            "NrWCO5TKnOcErq7vgZBRPIoj85ycjuDzrbFy0XQQB5NgHPvjY99efs5G8F6yVQLd6WQEt0wiGgZy\n" +
            "FkcdiU4jeAfTGC5uLqHlegW6athKWRC42s1EeLB2kVNvTY6D435fZeHOoBruIJZNQTN7CXdn2J3s\n" +
            "2L0C1S7elmYOUzdLr2lZv8kxa5ZpZL8bhd9VSgahnMJmB7cbs+bYpt5S0nrVQ2buzJ7/BAu7UtE=</history:state>\n" +
            "  </history:slice_history>\n" +
            "  <flack:slice_info view=\"graph\"/>\n" +
            "</rspec>";
    public static final String rspecC = "<rspec type=\"request\" generated_by=\"Flack\" generated=\"2013-06-19T07:43:46Z\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:flack=\"http://www.protogeni.net/resources/rspec/ext/flack/1\" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
            "  <node client_id=\"PCatEmulab\" component_manager_id=\"urn:publicid:IDN+emulab.net+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC:if0\">\n" +
            "      <ip address=\"192.168.1.1\" netmask=\"255.255.255.0\" type=\"ipv4\"/>\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <interface client_id=\"PCatEmulab:if0\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"57\" y=\"106\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PCatWall3\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC-0:if0\">\n" +
            "      <ip address=\"192.168.1.2\" netmask=\"255.255.255.0\" type=\"ipv4\"/>\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <interface client_id=\"PCatWall3:if0\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"444\" y=\"102\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC\" component_manager_id=\"urn:publicid:IDN+emulab.net+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC:if1\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"50\" y=\"192\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC-0\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC-0:if1\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"463\" y=\"225\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <link client_id=\"gre-tunnel0\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+emulab.net+authority+cm\"/>\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC:if0\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if0\"/>\n" +
//            "    <property source_id=\"PC:if0\" dest_id=\"PC-0:if0\"/>\n" +
//            "    <property source_id=\"PC-0:if0\" dest_id=\"PC:if0\"/>\n" +
            "    <link_type name=\"gre-tunnel\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"lan0\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+emulab.net+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC:if1\"/>\n" +
            "    <interface_ref client_id=\"PCatEmulab:if0\"/>\n" +
//            "    <property source_id=\"PC:if1\" dest_id=\"PCatEmulab:if0\"/>\n" +
//            "    <property source_id=\"PCatEmulab:if0\" dest_id=\"PC:if1\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"lan1\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PCatWall3:if0\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if1\"/>\n" +
//            "    <property source_id=\"PCatWall3:if0\" dest_id=\"PC-0:if1\"/>\n" +
//            "    <property source_id=\"PC-0:if1\" dest_id=\"PCatWall3:if0\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"461\" y=\"168\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <client:client_info name=\"Flack\" environment=\"Flash Version: LNX 11,2,202,280, OS: Linux 2.6.32-34-generic, Arch: x86, Screen: 1920x1080 @ 72 DPI with touchscreen type none\" version=\"v14.99\" url=\"https://www.emulab.net/protogeni/flack2/flack.swf\"/>\n" +
            "  <history:slice_history backIndex=\"8\" note=\"Added PC-0\" xmlns:history=\"http://www.protogeni.net/resources/rspec/ext/history/1\">\n" +
            "    <history:state>eNqVUk1r20AQvfdXDHu1pZVkxx/CCi0NhYCbBlxK6MWs12NrqbSr7ocl//usVkrTHArpQUiMZt6b\n" +
            "ee9ttGmQg702WBCNvx0aS+CMEjWzeNwfrgX5UjH+669iQbIknUXJIkrX35NlPk/zm+wngc6I3PAS\n" +
            "a7ZVnFmhZEFKa5uc0rZtYz8vYomWajTKaY6GBnI6g3d10XG9uDNH8Gx1JU1+6nd7Q9NoZdU/UbCz\n" +
            "NMzQ9AWCVwKl/U+MYegVxN/+BqGdxUqfaZYkKX36ut0FWSIhjWWS4zj1TnnI7QeAjVRHhIF2L7wH\n" +
            "j58JcFU3SvaVmkl2Rh3+OC3zxh0qwcUxv797mGDtKnbowSfM2VJpYa8TXhPAjlfOiIv33mqHgchT\n" +
            "mcqX9L4PBUhW98lgbdRwQseGoGDeb7QX8qSgK8jNkoDPSposCDh5UE4eR9AwtKF9d/gabshfTunn\n" +
            "B5IxZygvQitZB1N8zZTwA7Xxccph+/AEaTrNplnin1UyhW87XxXSdZDFi3iWRbN5FJIq+BQ+aV7m\n" +
            "0K0WU9hxjegR0nWWdGmySuAjLDO4e7yHVtgSrHK8NKEJhsO9sAQuA3NBLuk8Xq/9bboabDOjb6/i\n" +
            "0j+xGSKWDa/YtKdRhEE3Ly8fhbsIbAty1qwp+5bNYPntM4fDNpw=</history:state>\n" +
            "    <history:state>eNq1U8tu2zAQvPcrFrzaEkXJdmzBClo0KBDATQOkKIJeDIpeW0QlUiUpS/n7Uo80zSGoe+hBELDc\n" +
            "neEMZ7fG1ijAPdWYEYM/G7SOwAkVGu7wsM+fMvKp5OLHH8WMxBFLgmgVsM3X6CpdsHS5/k6gszK1\n" +
            "osCK77TgTmqVkcK5OqW0bdvQz8tQoaMGrW6MQEsHcprARV10ul7Y2QN4tqpUNj32d3tFUxvt9Jso\n" +
            "2Dk6zFD2DCFKicr9I8Y49ALitb9CaJNQmxONo4jRx8+7h8GWQCrruBI4TV1oD7l+B7BV+oAw0u6l\n" +
            "f4P7jwSErmqt+krFFT+hGU4ao9K6yUsp5CG9vbmbYdWUPO/BZ7xxhTbSPc1ERQA7UTZWnv3bO9Pg\n" +
            "QOSpbOlLZt+HAhSv+mTwNqgFoVPD4GDa32gv1VFDl5HlFQGfFRatCDQq1406TKDD0Jb23W8ICaKL\n" +
            "pbS8LJPQ9TGQee7CHP+fpGS5HjUx9jdNo5z0WVUPMLJMu4PqLI1W1RA0X7MFfENj/YqksLt7BMbm\n" +
            "8TyO/LeO5vDlwVelajqIw1WYxEGyCIbtk2IOH4woUujWqzk8CIPoEdgmjjoWrSN4D1cx3NzfQitd\n" +
            "AU43orBDE4zKvcMEziNzRs5sEW42XpspxyjaKYsvgaG/V2Fcm3j8hbY9TiaMxnl/xeTcWWKbkZPh\n" +
            "ddG3bMcYX/8CJi98CQ==</history:state>\n" +
            "    <history:state>eNrNVclu2zAQvfcrBrzG2h3HFuygS1AgQJoGSBEEvRgUNbaISJRKUpb996VEybGbBnEOBXoQZI3f\n" +
            "vFnekDOXqkIGelfhgkj8VaPSBNYoUFKN6TLZLcjXnLKnA+OChH4QOf7ECWY//It4HMbn4U8CW8Vj\n" +
            "xTIs6E3JqOalWJBM6yr2vKZpXOPPXYHak6jKWjJUXhfci+AklNen525VCiZakQsVr9rcjsJUstTl\n" +
            "qyy41V7n4wUDBcs5Cv1ODuv0TGJqP2JoIreUay/0/cB7/HZz37XF4UJpKhj2Xie2h1x+AJiLMkWw\n" +
            "YZfcaHD3hQAri6oUraWggq5Rdv/UUsRVneSc8TS+vro9w6LOadKSn9FaZ6XkenfGCgK4ZXmt+MZo\n" +
            "r2WNXSATSuXGJJftUICgRTsZtHEqRrwewIVGuaLsj4RivvJ7jhZUAU1TU42pM5iFbjCZuoFrOmby\n" +
            "KKgyqoXn5+7w+KQfQl5txkMgw9KJFe8DLrlYlQPv57IWaZ86JPZjRXOF+0S9vWNvsHRtLy3TdkHO\n" +
            "LwiYKQ/8CYFaJAecHcvca9GvSOD4J4vQ0DyPXN0OME8S7Sb4b8Vw/FPkCP87OcZR2OsRvaVHzsXT\n" +
            "YdFriY6uhcB8qHv+Qpy+hyefEe+9RG/p/EK2pcTVX87RCbhe4gFpbq0Kpd6BvT8OySA1+bzHqwcd\n" +
            "+h15ta0/nMnn1u8hVtsOOGjrBJ207atX9iGnQtP1scCtT/fLVhsPRbcsNly/klBsuCxF0d3fxqYy\n" +
            "eECpzOaJ4eb2EYJgFI5C3zxTfwTf742Vi3oLoTtxo9CJxk631DgbwSfJshi208kI7plENAzmlPjb\n" +
            "wJ/68BEuQri6u4aG6wx0WbNMdSCwLTCDQWBjIy/IJhi7s5kpUeb2hlf9Ff88Y95+w9htFNqXq5pV\n" +
            "3wTbPXP4h0O24di0faZV1kLmdjtc/galXIY0</history:state>\n" +
            "    <history:state>eNq1Vclu2zAQvfcrBrzG2h0vgh10CQoESNMAKdKgF4OiaIuIRKkkZcl/X1KUHLtpEKdoD4Ks8Zs3\n" +
            "yxtyFkJWlIDaVXSJBP1ZU6kQbCinAiuarpLdEn3OMXk8MC5R6AeR40+cYP7Nn8bjKPajHwhayWJJ\n" +
            "Mlrg65JgxUq+RJlSVex5TdO42p+5nCpPUFnWglDpdcG9CE5CeX16bitT0NGKnMt4bXI7ClOJUpUv\n" +
            "stBWeZ2PFwwUJGeUqzdyWKcnEl37EUMTuaXYeKHvB97Dl+u7ri0O41JhTmjvdWJ70MU7gAUvUwo2\n" +
            "7IppDW4/ISBlUZXcWArM8YaK7p9a8Liqk5wRlsZXlzdntKhznBjyM1yrrBRM7c5IgYC2JK8l22rt\n" +
            "lahpF0iHkrk2iZUZCuC4MJOBG6ciyOsBjCsq1pj8llDM1n7PYUAV4DTV1eg6g3noBpOZG7i6YzqP\n" +
            "AkutWnh+7g6Pj/ohZNV2PATSLJ1Y8T7givF1OfB+LGue9qlDYj/WOJd0n6i3d+wNls700jK1S3Q+\n" +
            "RaCnPPAnCGqeHHB2LAvPoF+QAKvvOM+jk5VoDNpVZopZkig3of9XEcc/RZPw32tiZfh7UcZR2KsS\n" +
            "vaZKzvjjYdUbQR1Vc07zofDFM3X6Jp58Ury3Er0m9DPdVoKu/3CaTsD1Gg9IfXdVVKgd2FvkkAxS\n" +
            "nc9bvHrQod+Rl2n94VA+tX4Psdp2wEFbJ+ikNa9e2fscc4U3xwIbn+6XrTYeijYsNly/mCjfMlHy\n" +
            "orvFtU1mcE+F1PsnhuubBwiCUTgKff3M/BF8vdNWxusWQnfiRqETjZ1utTEygg+CZDG0s8kI7oig\n" +
            "VDPoY+K3gT/z4T1MQ7i8vYKGqQxUWZNMdiCwLdCDgWBrIy/RNhi787kuUeT2npf9Rf80Y95+z9id\n" +
            "FNqXK5t13wTbPX36h1O2ZbQxfcZVZiALuyMufgGBaIi3</history:state>\n" +
            "    <history:state>eNrNVdFumzAUfd9XXPm1AQykaYKSat26SZXarlKnrtpL5DhOsAqG2SaQv5+NIU3WVU0fJu0BEZxz\n" +
            "z/U959p3KlXJKOhtyWZIsl8VUxrBmgkmiWbL+WI7Q18zQp/2FmcowmHs4ZEXTr7js2QYJ3jyE0Gj\n" +
            "eKJoynJyXVCieSFmKNW6TIKgrmvfxHNfMB1IpopKUqaCNnkQw1GooNue36glmGx5JlSysns7SFPK\n" +
            "QhevsrBGB21MEPYUNONM6HdyuKBnElP7AUMd+4VcBxHGYfB4c33fyuJxoTQRlHVRR8qDzj8ATEWx\n" +
            "ZODSzrnx4O7zhf6SVxlZIKBFXhbC/pMTQdZMtohKiqSsFhmnfJlcXd6esBZuk5yQSqeF5Hp7QnME\n" +
            "rKFZpfjG9ICWFWsTmpQqM0tybpsDBMlth5DaKykKOgAXmskVoX9sLOEr3HFYUAlkuTRVmXrDSeSH\n" +
            "o7Ef+kY5s4+cKONedHrq9w9GXTPycjPsExmW1rRkl3DOxaroeT8VlTCJVyRTRtrF/le/02AX2S04\n" +
            "Piuqo2pm6PQMgWn3EI8QVKKjafVoWaaBRb/iBdE/SJbFR1tRW7SvbTvzxUL7C/ZvLfHwMaZE/58p\n" +
            "wzjqXInfciXj4mm/6rVknq6EYFlf+PSFO52IRx+V4L1Ebxn9wre5ZKu/HKcjcJ3HPdJcYiWTegvu\n" +
            "Otkng6XZz3uiOtB+3EGUlX6/KZ+l30Gcty2w99YLW2vtq3P2ISNCk/WhwTam/eWqTfqiLYtL100o\n" +
            "JjZcFiJvr3OzplJ4YFKZQZTA9e0jhOEgGkTYPGM8gG/3ZpWLqoHIH/lx5MVDr51xnA7gQtI0gWY8\n" +
            "GsA9lYwZBnNMcBPiMYaPcBbB5d0V1FynoIuKpqoFgZPANAaCjcs8Q5tw6E8mpkSZuQtfdTf+c48F\n" +
            "u4HjhlPkXr6qV50ITj1z+vtTtuGstjqTMrWQqRsW578Bb6iMEw==</history:state>\n" +
            "    <history:state>eNrNVctu2zAQvPcrFrzGEvVw/BDsoI+0QIA0DZAiDXoxaJq2iEiUSlKW/PclJcqxmwZxDgV6EGTR\n" +
            "s7PcmSV3JlXJKOhdyeZIsl8VUxrBhgkmiWarxXI3R18yQh8PFucoCsLYC0ZeOP0ejJNhnITTnwga\n" +
            "xRNFU5aT64ISzQsxR6nWZYJxXde+iee+YBpLpopKUqZwmxzHcBIKu+35jVqByZZnQiVru7ejNKUs\n" +
            "dPEiC2s0bmNw2FPQjDOh38jRBT2RmNqPGOrYL+QGR0EQ4oev13etLB4XShNBmYs6UR508Q5gJooV\n" +
            "gy7tghsPbj8R/TmvMrJEQIu8LIT9JyeCbJhsEZUUSVktM075Krm6vDljLdwmOSOVTgvJ9e6M5ghY\n" +
            "Q7NK8a3pAS0r1iY0KVVmluTCNgcIktsOIbVXUoQdgAvN5JrQPzaW8HXgOCyoBLJamapMveE08sPR\n" +
            "xA99o5zZR06UcS86P/f7J0CuGXm5HfaJDEtrWrJPuOBiXfS8H4tKmMRrkikj7fLwq98p3ke6hY7P\n" +
            "itpRNXN0PkZg2j0MRggq4WhaPVqWGbboF734QbIsPtmK2qJ9bduZL5faX7J/a4kXnGJK9P+ZMowj\n" +
            "50r8misZF4+HVW8k83QlBMv6wmfP3HEinnxU8FuJXjP6mW8LydZ/OU4n4JzHPdJcYiWTegfddXJI\n" +
            "Biuzn7dEOdBh3FGUlf6wKZ+k30M6b1tg760Xttbal3P2PiNCk82xwTam/dVVm/RFW5YunZtQTGy5\n" +
            "LETeXudmTaVwz6QygyiB65sHCMNBNIgC80yCAXy7M6tcVA1E/siPIy8eeu2M43QAHyRNE2gmowHc\n" +
            "UcmYYTDHJGjCYBLAexhHcHl7BTXXKeiioqlqQdBJYBoDwbbLPEfbcOhPp6ZEmXUXvnI3/lOP4f3A\n" +
            "6YZT1L18Va+dCJ165vT3p2zLWW11JmVqIbNuWFz8BjnAjDQ=</history:state>\n" +
            "    <history:state>eNrNVVtv2jAYfd+v+OTXkjgXSiGCapdu0qSuq9Spq/aCjDHEauJktkPCv5/tJC30osLDtD2ggDnf\n" +
            "+S7nxN9UqpJR0NuSzZBkvyumNII1E0wSzZbzxXaGvmSE3u8czlAUhLEXjLxw8iM4S4ZxEsW/EDSK\n" +
            "J4qmLCeXBSWaF2KGUq3LBOO6rn0Tz33BNJZMFZWkTGGXHMdwEAp35fmNWoLJlmdCJStb216aUha6\n" +
            "eJWFNRq7GBz2FDTjTOgjOdqgRxLT+x5DHfuFXOMoCEJ89+3yxo3F40JpIijrog4cDzp/BzAVxZJB\n" +
            "m3bOjQbXn4j+nFcZWSCgRV4Wwv6TE0HWTDpEJUVSVouMU75Mvl5cnTAHt0lOSKXTQnK9PaE5AtbQ\n" +
            "rFJ8YzygZcVcQpNSZeZIzq05QJDcOoTUXkkR7gBcaCZXhD4pLOGroOOwoBLIcmm6Mv2Gk8gPR2M/\n" +
            "9M3kTB05UUa96PTU7z8B6szIy82wT2RYnGjJQ8I5F6ui5/1YVMIkXpFMmdEudn/1leKHyO6g5bND\n" +
            "bamaGTo9Q2DsHgYjBJXoaNw8HMsUW/SrWvwkWRYfLEVt0b62duaLhfYX7O9K4gWHiBL9f6IM46hT\n" +
            "JT5elX/3Zrxkr6BtZBK91UjGxf1uI2vJPF0JwbJewemzvroyDu4MH0v0lmOfGXAu2eqFe+EAXGfW\n" +
            "Hmlu45JJvYX2Xtwlg6Wp55ioDrQbtxdlR78r6+Pon0jrgL20XuiktY9O2duMCE3W+wLbGPet7Tbp\n" +
            "m7Ysbbpu1TKx4bIQudtL5kylcMukMhs1gcurOwjDQTSIAvMZBwP4fmNOuagaiPyRH0dePPTcsuZ0\n" +
            "AB8kTRNoxqMB3FDJmGEwDgyaMBgH8B7OIri4/go11ynooqKpciBoR2CMgWDTZp6hTTj0JxPTosza\n" +
            "zaW61fXoMfywOdstG7UPX9Wrbgjt9Mz7018XG85qO2dSphYybbfe+R9J6M5d</history:state>\n" +
            "    <history:state>eNrNVltvmzAUft+vsPzacDGkaYKSapduUqWuq9Spq/YSOY4TrIJhtgnk38/GkIZeidRdHhCK853v\n" +
            "+HzfsTlTIXNKgNrmdAYF/VVQqSBYU04FVnQ5X2xn8EuCyd3e4gwGPgodf+SgyXf/JBqGUYh+QlBJ\n" +
            "FkkS0xRfZAQrlvEZjJXKI88ry9LV8czlVHmCyqwQhEqvTu6FoBfKa7bnVnIJdLY04TJamb110uQi\n" +
            "U9mzLLRSXh3joZaCJIxydSCHDbon0bV3GMrQzcTaC3wfebdfL65rWRzGpcKc0Caqpzzw9B0AU54t\n" +
            "KbBp50x7cPUJq89pkeAFBCRL84ybf1LM8ZqKGlEIHuXFImGELaPzs8sjWsNNkiNcqDgTTG2PSAoB\n" +
            "rUhSSLbRPaBEQeuEOqVM9JKYm+YAHKemQ3Dp5AR6DYBxRcUKkwcbi9jKbzgMKAd4udRV6XrRJHDR\n" +
            "aOwiVyun95Fiqd0Ljo/d9vFh04ws3wzbRJqlNi3aJZwzvspa3o9ZwXXiFU6klnax/6vdqbeLfHnr\n" +
            "rabdEt46ueUzjlqqagaPTyDQZw35IwgK3tDUZtQsU8+gn22EHzhJwt59UBq0q8xZYouFchf0z/aD\n" +
            "4/fpiOAfd8QTpgzDoHElPNyV//FYor/b075VbxK8pl7C+N3+ZteCOqrgnCZt20wfidnU3ltO71Ci\n" +
            "147JI7nngq6euAl74JoT0iL19yenQm2B/RLsk4Gl3s8hUQ1oP64TZaTf76V76XcQa20NbK11UG2t\n" +
            "eTXO3iSYK7zuGmxinjRYg9/e2ZeNQH1wnfv/VTtQR9YDYjvQB9agZ63Ror2lJ7bwqK3fsNg8zcBH\n" +
            "+YaJjKf1dKTXZAxuqJB6rovAxeUtQGgQDAJfP2N/AL5d61XGiwoE7sgNAyccOvXIyMgAfBAkjkA1\n" +
            "Hg3ANRGUagZ9K/gV8sc+eA9OAnB2dQ5KpmKgsoLEsgYBW7vuDQg2NvMMbtDQnUx0iSKx85NsBqj7\n" +
            "7vB285ud9QL7cmW5akSw6umLtL34NoyWpvdxHhvI1M5ep78Bf0qekg==</history:state>\n" +
            "    <history:state>eNrNVl1P2zAUfd+vsPxKk9hJW9qoRftgk5CAITExtJfKdd3GInEy22nSfz87H9BAgVZiYw9RVPfc\n" +
            "c33vOXbuRKqMUaA3GZtCyX7nTGkIVkwwSTRbzOabKfwWE3q3tTiFPsKBg4YOHv9Ax2E/CIPBLwhK\n" +
            "xUNFI5aQ85QSzVMxhZHWWeh5RVG4Jp67gmlPMpXmkjLlVcm9AOyF8prtuaVaAJMtiYUKl3ZvnTSZ\n" +
            "THX6LAsrtVfFeLiloDFnQh/IUQc9kJjaOwxF4KZy5fkIYe/24vy6aovDhdJEUNZE7dkeePIBgIlI\n" +
            "FwzUaWfcaHD1heivSR6TOQQ0TbJU2H8SIsiKyQqRSxFm+TzmlC/Cs9PLI1bBbZIjkusolVxvjmgC\n" +
            "AStpnCu+Nh7QMmdVQpNSxWZJzqw5gCCJdQgpnIxCrwFwoZlcEvpoYyFfoobDgjJAFgtTlakXj30X\n" +
            "D0cudk3nzD4Soox6/mDgtg+CjRl5tu63iQxLJVp4n3DGxTJteT+nuTCJlyRWprXz7V/tTr37yJe3\n" +
            "3va0W8JbJ6/5rKI1VTmFg2MIzFnDaAhBLhqaSoyKZeJZ9LNG+EniONjbB4VFu9qeJT6fa3fO/q4f\n" +
            "HLSPI/x3dsQOUfoDVKuCR4er8j8eS/xvPd10b+wf3j0Hvb+ddzliGFQ1+f7gtZpiLu62a1pJ5uhc\n" +
            "CBa3R2HypMBmH3tbxDuU6LVePbHQTLLljtt9D1xz6luk+aZmTOoNqL9u22RgYfZzSFQD2o7rRNnW\n" +
            "b+v60PpH2lbAVlsHV9LaV6PsTUyEJquuwDZmp8AG/PbKviwE3gfX+aa9KgfutPWA2A70kTT4WWlM\n" +
            "095Sk7rwsK3fstR5miGWiTWXqUiqic+sqQjcMKnMrBqC88tbgHHP7/nIPCPUA9+vzSoXeQl8d+gG\n" +
            "vhP0nWoM5rQHPkkahaAcDXvgmkrGDIO56VCJ0QiBj+DYB6dXZ6DgOgI6zWmkKhCoazfegGBdZ57C\n" +
            "Ne6747EpUcb1TKiaofDBHd79TFrPr379clWxbJpQd89cau1lvuassN4nWWQhk3qePPkD3Q7kBg==</history:state>\n" +
            "  </history:slice_history>\n" +
            "  <flack:slice_info view=\"graph\"/>\n" +
            "</rspec>";
    public static final String rspecCsimple2 = "<rspec type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:flack=\"http://www.protogeni.net/resources/rspec/ext/flack/1\" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
            "  <node client_id=\"PCatEmulab\" component_manager_id=\"urn:publicid:IDN+emulab.net+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PCatEmulab:if0\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"57\" y=\"106\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC\" component_manager_id=\"urn:publicid:IDN+emulab.net+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC:if1\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"50\" y=\"192\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <link client_id=\"lan0\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+emulab.net+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC:if1\"/>\n" +
            "    <interface_ref client_id=\"PCatEmulab:if0\"/>\n" +
//            "    <property source_id=\"PC:if1\" dest_id=\"PCatEmulab:if0\"/>\n" +
//            "    <property source_id=\"PCatEmulab:if0\" dest_id=\"PC:if1\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <client:client_info name=\"Flack\"/>\n" +
            "  <flack:slice_info view=\"graph\"/>\n" +
            "</rspec>";
    public static final String rspecCsimple = "<rspec type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:flack=\"http://www.protogeni.net/resources/rspec/ext/flack/1\" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
            "  <node client_id=\"PCatEmulab\" component_manager_id=\"urn:publicid:IDN+emulab.net+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <flack:node_info x=\"57\" y=\"106\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <client:client_info name=\"Flack\"/>\n" +
            "  <flack:slice_info view=\"graph\"/>\n" +
            "</rspec>";
    public static final String rspecD = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
            "      <rspec generated=\"2013-07-04T12:43:37.853+02:00\" generated_by=\"Experimental jFed Rspec Editor\" type=\"request\" xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:jFed=\"http://jfed.iminds.be/rspec/ext/jfed/1\">\n" +
            "          <node client_id=\"node0\" component_id=\"urn:publicid:IDN+ple:quantavisple+node+marie.iet.unipi.it\" component_manager_id=\"urn:publicid:IDN+ple:ibbtple+authority+cm\" component_name=\"marie.iet.unipi.it\" exclusive=\"false\">\n" +
            "              <sliver_type name=\"plab-vserver\"/>\n" +
            "              <location country=\"unknown\" longitude=\"10.3252\" latitude=\"43.5052\"/>\n" +
            "              <hardware_type name=\"plab-pc\"/>\n" +
            "              <hardware_type name=\"pc\"/>\n" +
            "              <jFed:location x=\"39.68209446865495\" y=\"17.94001661349273\"/>\n" +
            "   <sliver/>\n" +
            "          </node>\n" +
            "      </rspec>";
    public static final String rspecE = "<rspec type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
            "  <node client_id=\"PC\" component_manager_id=\"urn:publicid:IDN+emulab.net+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC:if0\">\n" +
            "      <ip address=\"192.168.51.5\" netmask=\"255.255.255.0\" type=\"\"/>\n" +
            "    </interface>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC-0\" component_manager_id=\"urn:publicid:IDN+emulab.net+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC-0:if0\">\n" +
            "      <ip address=\"192.168.50.5\" netmask=\"255.255.255.0\" type=\"\"/>\n" +
            "    </interface>\n" +
            "  </node>\n" +
            "  <link client_id=\"lan0\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+emulab.net+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC:if0\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if0\"/>\n" +
//            "    <property source_id=\"PC:if0\" dest_id=\"PC-0:if0\"/>\n" +
//            "    <property source_id=\"PC-0:if0\" dest_id=\"PC:if0\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "  </link>\n" +
            "</rspec>";
    public static final String rspecF = "<rspec type=\"request\" generated_by=\"Flack\" generated=\"2013-05-27T08:26:32Z\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:flack=\"http://www.protogeni.net/resources/rspec/ext/flack/1\" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
            "  <node client_id=\"PC\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC:if0\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <interface client_id=\"PC:if1\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <interface client_id=\"PC:if2\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"149\" y=\"118\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC-0\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC-0:if0\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <interface client_id=\"PC-0:if1\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <interface client_id=\"PC-0:if2\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"140\" y=\"435\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC-1\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC-1:if0\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <interface client_id=\"PC-1:if1\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <interface client_id=\"PC-1:if2\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"482\" y=\"120\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC-2\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC-2:if0\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <interface client_id=\"PC-2:if1\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <interface client_id=\"PC-2:if2\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"495\" y=\"445\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <link client_id=\"lan0\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC-1:if0\"/>\n" +
            "    <interface_ref client_id=\"PC-2:if0\"/>\n" +
            "    <property source_id=\"PC-1:if0\" dest_id=\"PC-2:if0\" packet_loss=\"0.01\"/>\n" +
            "    <property source_id=\"PC-2:if0\" dest_id=\"PC-1:if0\" latency=\"6\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"489\" y=\"282\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"lan1\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC-2:if1\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if0\"/>\n" +
            "    <property source_id=\"PC-2:if1\" dest_id=\"PC-0:if0\" latency=\"4\" packet_loss=\"0.02\"/>\n" +
            "    <property source_id=\"PC-0:if0\" dest_id=\"PC-2:if1\" latency=\"4\" packet_loss=\"0.02\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"lan2\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if1\"/>\n" +
            "    <interface_ref client_id=\"PC:if0\"/>\n" +
            "    <property source_id=\"PC-0:if1\" dest_id=\"PC:if0\" capacity=\"25000\"/>\n" +
            "    <property source_id=\"PC:if0\" dest_id=\"PC-0:if1\" capacity=\"25000\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"lan3\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC:if1\"/>\n" +
            "    <interface_ref client_id=\"PC-1:if1\"/>\n" +
            "    <property source_id=\"PC:if1\" dest_id=\"PC-1:if1\" latency=\"20\"/>\n" +
            "    <property source_id=\"PC-1:if1\" dest_id=\"PC:if1\" latency=\"20\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"lan4\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC-2:if2\"/>\n" +
            "    <interface_ref client_id=\"PC:if2\"/>\n" +
//            "    <property source_id=\"PC-2:if2\" dest_id=\"PC:if2\"/>\n" +
//            "    <property source_id=\"PC:if2\" dest_id=\"PC-2:if2\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"388\" y=\"270\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"lan5\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC-1:if2\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if2\"/>\n" +
            "    <property source_id=\"PC-1:if2\" dest_id=\"PC-0:if2\" capacity=\"30000\" latency=\"30\" packet_loss=\"0.03\"/>\n" +
            "    <property source_id=\"PC-0:if2\" dest_id=\"PC-1:if2\" capacity=\"30000\" latency=\"30\" packet_loss=\"0.03\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"258\" y=\"270\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <client:client_info name=\"Flack\" environment=\"Flash Version: LNX 11,2,202,280, OS: Linux 2.6.32-34-generic, Arch: x86, Screen: 1920x1080 @ 72 DPI with touchscreen type none\" version=\"v14.91\" url=\"https://www.emulab.net/protogeni/flack2/flack.swf\"/>\n" +
            "  <history:slice_history backIndex=\"14\" note=\"Edited lan5\" xmlns:history=\"http://www.protogeni.net/resources/rspec/ext/history/1\">\n" +
            "    <history:state>eNqVUk1r20AQvfdXDHu1rdWHndjCCi0NhYCbBlxK6MWs1mNrqbSr7ocl//uuVkrbHArpQUiMZt6b\n" +
            "ee9ttWmRg722WBCNPx0aS+CMEjWzeDyU14J8qhn/8VexIGmcZIt4tUhvv8brPF3myeo7gd6I3PAK\n" +
            "G7ZTnFmhZEEqa9uc0q7rIj8vIomWajTKaY6GBnKawZu66LRe1JsjeLamliY/Dbu9omm1suqfKNhb\n" +
            "GmZo8gLBa4HS/ifGOPQHxN/+CqHLIqXPNI3jhD5/3u2DLAshjWWS4zT1RnnI3TuArVRHhJH2ILwH\n" +
            "Tx8JcNW0Sg6Vhkl2Rh3+OC3z1pW14OKYP9w/zjpW11lkB+1EWdqoxBlztlJa2OuMNwSw57Uz4uIz\n" +
            "YLXDQOgpTe1L+jCEAyRrhoSwbtFyQqeGoGQ+bHYQ8qSg99FIVgR8aJJsQ8DJUjl5nFDD1JYO7eFr\n" +
            "PCZ/uWkAGFmmwKG8CK1kE9zxNVPBN9TG5yqH3eMzJMk8naexf9bxHL7sfVVI10Ma3URZusiWixBZ\n" +
            "wefwQfMqh359M4c914geIdmkcZ/E6xjew20K908P0AlbgVWOVyY0wXi5V5jAZWQuyCVZRhvvu9P1\n" +
            "6J+ZDMTG1awMFv7Oz5i1dHxFpjtNIozCeX35pNxFYFeQs2ZtNbRsR+/vfgF9rDlv</history:state>\n" +
            "    <history:state>eNrNU01r20AQvfdXDHu19e3EtrBCS0Mh4KYBlxJ6Mav12Foq7ar7Ycn/PquV0jaH0PTWgxCMZt6b\n" +
            "9/Rmo3SLDMylxYIo/GlRGwInFKiowcO+vBTkU03Zjz+KBUnjJAviqyBdfo1XebrIk/V3Ar3muWYV\n" +
            "NnQrGTVcioJUxrR5FHVdF7p5Hgo0kUItrWKoI08eZfCmrmhaL+z1ARxbUwudH4fdXtC0Shr5Kgr2\n" +
            "JvIzUfIMwWqOwvwjxjj0G8Rpf4HQZaFUpyiN4yR6/LzdeVsCLrShguE09UZ7yM07gI2QB4SRds/d\n" +
            "P3j4SIDJppViqDRU0BMq/8Uqkbe2rDnjh/zu9n7W0brOQjN4x8vShCXOqDWVVNxcZqwhgD2rreZn\n" +
            "lwGjLHpCR6lrV1L7IRwgaDMkhHZBy0g0NXgn82GzPRdHCb2LRnJFwIUmydYErCilFYcJ1U9toqH9\n" +
            "FUVB/H9qWi29pixb/E3TKCd/VjUAjCzTEaE4cyVF4xPnarqCb6i0u5UctvePkCTzdJ7G7lnFc/iy\n" +
            "c1UubA9peB1maZAtAn+GnM3hg2JVDv3qeg47phAdQrJO4z6JVzG8h2UKtw930HFTgZGWVdo3wajc\n" +
            "OUzgPDIX5JwswrXLslX1mEk9hRIbW9PSx/LXTYz3k46vUHfHyYTROOcvm5w7c+wKclK0rYaWzZjn\n" +
            "myd7oX7i</history:state>\n" +
            "    <history:state>eNrNVMtu2zAQvPcrFrzakijJjm3BDlo0KBDATQO4KIJeDIpeW0QlUuXDkv8+1CNtcwia9pSDIGC1\n" +
            "O8MZ7XCtTY0c7KXGDdH406GxBE4oUTOLh31+2ZBPJeM//ihuSELjNKDzIFl8pcssmWUJ/U6gNSIz\n" +
            "vMCKbRVnVii5IYW1dRZFTdOEfl6EEm2k0SinOZqoJ49SeFVXNB4vbM0BPFtVSpMdu7M9o6m1supF\n" +
            "FGxt1M9E8RMELwVK+48Yw9BvEK/9GUKThkqfooTSOHr4vN31tgRCGsskx3HqlfaQ63cAa6kOCAPt\n" +
            "Xvh/cP+RAFdVrWRXqZhkJ9T9F6dlVru8FFwcstubu0nDyjINbeedyHMb5jhhzhZKC3uZ8IoAtrx0\n" +
            "Rpz9DljtsCf0lKb0Jb3vlgMkq7oNYU1QcxKNDb2TWXeyvZBHBa1fjXhOwC9NnK4IOJkrJw8jaj+1\n" +
            "jrr2FxQF9G1qWi56TWk6+w9N8ZvUNJvT4T/N/qppkJM9qeoABpbxYkB5FlrJqk+Rr5kCvqE2Pv8Z\n" +
            "bO8eII6nyTSh/lnSKXzZ+aqQroUkvArTJEhnQX+1CD6FD5oXGbTLqynsuEb0CPEqoW1MlxTewyKB\n" +
            "m/tbaIQtwCrHC9M3waDcO0zgPDBvyDmehSvvvdPlkDMzBg0rV7K8j9qvnA93QjK8QtMcRxMG47y/\n" +
            "fHTuLLDZkJNmddG1rIeMXj8CvcTEQQ==</history:state>\n" +
            "    <history:state>eNrNVE1r20AQvfdXDHu19bWyY0fYoaWhEEjTQEoJvZjVemItlXbV/bCUf9/VSmmbQ2iakw/GMJp5\n" +
            "b9+b4W20aZGDfWxxSzT+dGgsgQNK1Mziflc+bsmnmvEffxW3hKZZHqXLiK6+puuCLgpKvxPojSgM\n" +
            "r7Bh14ozK5TcksratkiSrutiPy9iiTbRaJTTHE0SyJMcXtWVTM+Le7MHz9bU0hQPw9ue0bRaWfUi\n" +
            "CvY2CTNJ9gTBa4HS/ifGOPQHxGt/htDlsdKHhKZpltx/vr4LtkRCGsskx2nqlfaQi3cAG6n2CCPt\n" +
            "Tvgd3H4kwFXTKjlUGibZAXX44rQsWlfWgot9cXV5M+tYXeexHbwTZWnjEmfM2UppYR9nvCGAPa+d\n" +
            "EUd/A1Y7DISe0tS+pHfDcYBkzXAhrItaTpKpIThZDC/bCfmgoPenkS0J+KPJ8nMCTpbKyf2EGqY2\n" +
            "ydD+gqIoPU1N61XQlOeLN2jKTlLTYpmOe1q8RRM9SU3LYT9hT6t/aRrlFE+qBoCRZQo7lEehlWxC\n" +
            "MviaqeAbauMzrYDrm3vIsjmd09T/1ukcvtz5qpCuBxqfxTmN8kUU4lLwOXzQvCqgX5/N4Y5rRI+Q\n" +
            "ndO0z9J1Cu9hReHy9go6YSuwyvHKhCYYlXuHCRxH5i05Zov43N+T0/WYHWYKD2xczcoQH7+za8w5\n" +
            "Ov7FpnuYTBiN8/7yybmjwG5LDpq11dCyGXPn4he0cQnB</history:state>\n" +
            "    <history:state>eNrNVV1vmzAUfd+vuPJrw5chbYqSah/VpEpdV6lTVe0lMsYEq2CYbQL59zOYZMmyam0ftj5EBHPv\n" +
            "ufccH/vOpaoZBb2p2QJJ9qNhSiNYMcEk0SxdJpsF+lwQ+ri3uEDYD0LHnzr47Js/i3EU4+l3BJ3i\n" +
            "saI5K8l1RYnmlVigXOs69ry2bV2Tz13BtCeZqhpJmfKG4l4Iz4ryxvbcTqVgqpWFUHHW93ZQppaV\n" +
            "rp5EYZ32hhwv2ELQgjOhX4hhk36BGO4HCG3oVnLlYd8PvIcv13eDLA4XShNB2Zj1THnQxTuAuahS\n" +
            "Brbskps9uP2EgFZlXYl+pSSCrJgcvjRSxHWTFJzyNL66vDlpSVGEru6140mi3YSdkEbnleR6c0JL\n" +
            "BKyjRaP42nhAy4YNBU1JVZgluezNAYKUvUNI69QUeWPAoGTcd7bkIqugM9YIpgiMaYLwHEEjkqoR\n" +
            "6Yg6ZM29PvwJRo7/NjnNzgZOYRi9glPw/zlxoZnMCD1qLeaZP6LsqO+CLX+SpsaR6qMlnZFCGfsm\n" +
            "+2/bKt4u82kpo6lv7RG9Rkr8dqXE/1zKUxxZV0azv0lZcPG4329BxLbX+ZGgI+8XS3qk0FKy7I+G\n" +
            "e04kPog0F3LNpN6AvRoP4SA1Pb0oDx/nHXbWC7ZvAiPYbxfEELHdiv6Mb+xj3Ih7k6HJ6nA/+pzh\n" +
            "n6Uabxn3KLbOOGqZWHNZiXKYS2ZN5XDPpDITNYbrmwcIggmeYN/8Zv4Evt6ZVS6aDrB76obYCSNn\n" +
            "GNacTuCDpHkM3ex0AndUMmYQgnPsd4E/8+E9nGG4vL2CluscdNXQXA1BYLkbXyBY28oLtA4i97yn\n" +
            "KAs7udQ4uljZFCQZhtductopi+3DVW02imDVM8dseyjWnLULtJKkzvuQuZ16Fz8BsmnS2w==</history:state>\n" +
            "    <history:state>eNrNVl1vmzAUfd+vuOK1CWBDmxQl1T6qSZW6rlKnqtpLZIwTrIJhtgnk389gkiVL26WV1vYhQnHu\n" +
            "uefec27MnUhVMgp6VbKpI9mviintwIIJJolmySxeTZ2vGaH3W4dTB/soGPrHQzz64Y8jHEYB+ulA\n" +
            "o3ikaMpycllQonkhpk6qdRl5Xl3XrsFzVzDtSaaKSlKmvI7cC+CgKK8vz21UAoYtz4SK5m1tOzSl\n" +
            "LHTxaBbWaK/DeGidgmacCf3MHBb0J4npfSdDHbiFXHjY95F39+3yppNlyIXSRFDWow6Uxzn7ADAR\n" +
            "RcLA0s648eD6iwO0yMtCtCc5EWTBZPdLJUVUVnHGKU+ii/Oro5pkWeDqVjsex9qN2RGpdFpIrldH\n" +
            "NHeANTSrFF+aGdCyYh2hoVSZOZKzdjhAkLydEFIPS+p4fUCnZNRWNuNiXkBjRgMdO2CGBgWnDlQi\n" +
            "LiqR9Fk71MRrwx/paOi/fU9caCbnhO6VFvG532fZtL4Jtv2TJDHuqc+26TnJlLE63v62ZvE2yCek\n" +
            "HI86KYMgfIGU6P1KiV5dyvDYt1MZvkRK/H6lxP9Xyqdo0as6eIJD+2cIx/9yMOPifrvejIi1RJM9\n" +
            "H3u5n+3knjEzyeYPzvkhkXgn0rx+Sib1CuyLYDcdJKamZ+HwPm63slaw7dkzgv11xXcRayvaq2Vl\n" +
            "H70RtwahyWLXjxbzmB/oTfywU3tIpH+ormhX14Nw/sM+otfyw7YarTtus1ieftFjYsllIfJuKzJn\n" +
            "KoVbJpXZ5yK4vLoDhAZ4gH3zGfsD+H5jTrmoGsDuiRvgYRAOu1WR0wF8kjSNoBmfDOCGSsZMBnSK\n" +
            "/Qb5Yx8+wgjD+fUF1FynoIuKpqoLAtu7mQsHlpZ56ixR6J62LcrM7k2qX5xYXmUk7lanzd5mdzxs\n" +
            "H66q570IVj1z264vqSVn9dRZSFKmbcjE7lxnvwEZqpv9</history:state>\n" +
            "    <history:state>eNrNV99vmzAQft9fYfHaALahbYqSaj+qSZO6rlKnqtpLZBwnWAXDbBPIfz+DSRaWdqOVlvQhQjnu\n" +
            "vrv7vjO2J1IVjAK9LtjUkexnyZR2wJIJJolm81m8njqfU0Ifd4xTB0MUuPDUxeff4TjCYRTgHw6o\n" +
            "FY8UTVhGrnNKNM/F1Em0LiLfr6rKM/HcE0z7kqm8lJQpv03uB2CQl9+V59VqDky2LBUqWjS19dIU\n" +
            "Mtf5syis1n4b46MNBE05E/qFGDboN4jpvYdQBV4ulz6GEPkPX6/vWlpcLpQmgrIuaiA9zuU7ACYi\n" +
            "nzNg08640eD2kwNonhW5aCwZEWTJZPumlCIqyjjllM+jL1c3JxVJ08DTDXc8jrUXsxNS6iSXXK9P\n" +
            "aOYAVtO0VHxlZkDLkrUJTUqVGpOcNcMBBMmaCSGVW1DH7xy40EwuCP2jsIgvYIdhnFq6o63rjItF\n" +
            "Dsh8bvpUH/NSmJAFSZUhJd79t8nhbyM7g8Vr6LBQtZlHdOoAM6kouHBAKTqctpUWZuI37s/Q6MI3\n" +
            "S6QL/y+Vf0uLDqvg+LxVMAjCVyiI3q6C6OCLITyFdjGEr6ESv10q8XEWAz74YjjDoV0M4fhfCqZc\n" +
            "PO7WmxKxoWiyp2NH94uV3BNmJtniyTkf4ol7nmarLZjUa2A3vT4cmJuaXhSH9+P6lTWE7c6eIWz7\n" +
            "zkrRemykaD4ta/vohLg3EZos+3o0Mc/pgY6ih53aIZ5wKK+oz+ugOPi0juiIeuCj6AGH6jGU1b4a\n" +
            "A6L2lYCHVMI2GW16bVBsnu56wcSKy1xk7Vnc2FQC7plU5hYRgeubB4DQCI8wNL8xHIFvd8bKRVkD\n" +
            "7J15AXaD0G0vKJyOwAdJkwjU47MRuKOSMYOALjCsERxD8B6cY3B1+wVUXCdA5yVNVOsEbO9mIhyw\n" +
            "spmnzgqF3kXTokztaV11x3WWlSmJ2wP79rZgbxbYPjxVLToSLHtm39tsFyvOqqmzlKRIGpeJPelf\n" +
            "/gKTn2Oo</history:state>\n" +
            "    <history:state>eNrNl11vmzAUhu/3KyxuG8A2pE1QUu2jmlSp6yp1qqrdRI7jBKtgmG1C8u9nMEnD0qo00pJeRCjm\n" +
            "nPfY72MDZyRVzijQ65yNHcn+FExpByyYYJJoNptM12Pne0Lo087g2MEQBS7su/jiFxxEuB/B8LcD\n" +
            "VopHisYsJTcZJZpnYuzEWueR75dl6Zl87gmmfclUVkjKlF8X9wPQKcpvpuet1AyYamkiVDSv5tYq\n" +
            "k8tMZ6+qsJX26xwfbSRowpnQ79SwSc8iZu0thTLwMrnwMYTIf/xxc1/b4nKhNBGUNVkd7XEuPwEw\n" +
            "EtmMAVt2wg2Du28OoFmaZ6IaSYkgCybrO4UUUV5ME075LLq+uj0rSZIEnq6849Op9qbsjBQ6ziTX\n" +
            "6zOaOoCtaFIovjR7QMuC1QVNSZWYITmpNgcQJK12CCndnDp+E8CFZnJO6D8Ti/gcNhomqLY72oZO\n" +
            "uJhngMxmZp3qa1YIkzIniTKmTHf/bWr428w3i6L/V9TqVQys1GrsoHDoAHM8EBo4oBCNTu1fLTPy\n" +
            "q/BX2Lnww9Jz4Un41WWPTRDWBMOgfwBB9HEJotMQREcnGA4sQYTDAwjij0sQn4YgPj7BYd+ewfDN\n" +
            "M5hw8bQ734SIjUWjPY6N3e8muQdmItn8xePVJRK3Is1nRc6kXgP7gm/LgZmZ07vy8H5ee2aVYbt7\n" +
            "zxi2vWdR1BHPh8m+0PAAb1E8mBxNFm0iVdZrRNBJiNh92yUSdnUWtZ3tlAdfJokOJVK9Y9b2cigP\n" +
            "fBIesCuPrq62aXTI2icBT0wiOAWJzucCtSJf9RTtP29Ql+fbHr+jkbDLjDarrVRsnaatZWLJZSbS\n" +
            "ugc0YyoGD0wq071G4Ob2ESDUwz0MzW8Ae+DnvRnlolgB7J17AXaD0K0bY0574IukcQRWg/MeuKeS\n" +
            "MaOAhhiuEBxA8BlcYHB1dw1KrmOgs4LGqg4Cdu1mRzhgaSuPnSUKvWG1RJnYLlE1bSJLi4RM60Zx\n" +
            "26Xajhbbi6fKeWOCdc98g2xe3UvOyrGzkCSPq5CR7TAv/wI0lyve</history:state>\n" +
            "    <history:state>eNrNl11vmzAUhu/3KyxuG8A2pE1QUu2jmlSp6yp1qqrdRI7jBKtgmG1C8u9nMEnD0qi00pJeRCjm\n" +
            "nPfY72MDZyRVzijQ65yNHcn+FExpByyYYJJoNptM12Pne0Lo087g2MEQBS7su/jiFxxEuB+h8LcD\n" +
            "VopHisYsJTcZJZpnYuzEWueR75dl6Zl87gmmfclUVkjKlF8X9wPQKcpvpuet1AyYamkiVDSv5tYq\n" +
            "k8tMZwdV2Er7dY6PNhI04UzoN2rYpGcRs/aWQhl4mVz4GELkP/64ua9tcblQmgjKmqyO9jiXnwAY\n" +
            "iWzGgC074YbB3TcH0CzNM1GNpESQBZP1nUKKKC+mCad8Fl1f3Z6VJEkCT1fe8elUe1N2RgodZ5Lr\n" +
            "9RlNHcBWNCkUX5o9oGXB6oKmpErMkJxUmwMIklY7hJRuTh2/CeBCMzkn9J+JRXwOGw0TVNsdbUMn\n" +
            "XMwzQGYzs071NSuESZmTRBlTprv/NjX8bearRdH/K2r1KgZWajV2UDh0gDkeCA0cUIhGp/avlhn5\n" +
            "VfgBdi78sPRceBJ+ddljE4Q1wTDov4Mg+rgE0WkIoqMTDAeWIMLhOwjij0sQn4YgPj7BYd+ewfDV\n" +
            "M5hw8bQ734SIjUWjPY6N3W8muQdmItn8xePVJRK3Is1nRc6kXgP7gm/LgZmZ05vy8H5ee2aVYbt7\n" +
            "zxi2vWdR1BHPh8m+0PAAb1E8mBxNFm0iVdYhIugkROy+7RIJuzqL2s52yoMvk0TvJVK9Y9b28l4e\n" +
            "+CQ8YFceXV1t07A2U5ITaiZldmwfwtdk9tE0uodkjs8qOAWrzicHtSIPmoz2n0ioyxNwj/DRTo1d\n" +
            "ZrRZbaVi6zSNLxNLLjOR1l2iGVMxeGBSmf42Aje3jwChHu5haH4D2AM/780oF8UKYO/cC7AbhG7d\n" +
            "OnPaA18kjSOwGpz3wD2VjBkFNMRwheAAgs/gAoOru2tQch0DnRU0VnUQsGs3O8IBS1t57CxR6A2r\n" +
            "JcrE9pGqaSRZWiRkWreS2z7W9rzYXjxVzhsTrHvmK2Xzcl9yVo6dhSR5XIWMbA96+RfQ/zWr</history:state>\n" +
            "    <history:state>eNrNl11vmzAUhu/3KyxuG8A2yZqgpNpHNalS11XqVFW7iRzHCVbBMNsE8u9nMEnD0qg0UpteRCjm\n" +
            "nPeY97ExZyxVxijQ64xNHMn+5kxpByyZYJJoNp/O1hPnR0zo487gxMEQBS4cuPj8NxyGeBDi4I8D\n" +
            "SsVDRSOWkOuUEs1TMXEirbPQ94ui8Ew+9wTTvmQqzSVlyq+L+wHoFOU30/NKNQemWhILFS6qubXK\n" +
            "ZDLV6UEVVmq/zvHRRoLGnAn9Sg2b9CRinr2lUAReKpc+hhD5Dz+v72pbXC6UJoKyJqujPc7FJwDG\n" +
            "Ip0zYMtOuWFw+90BNE2yVFQjCRFkyWR9J5cizPJZzCmfh1eXN2cFiePA05V3fDbT3oydkVxHqeR6\n" +
            "fUYTB7CSxrniK7MGtMxZXdCUVLEZktNqcQBBkmqFkMLNqOM3AVxoJheE/jexkC9go2GCarvDbeiU\n" +
            "i0UKyHxunlN9S3NhUhYkVsaU2e6/TQ1/m/liUfR2Ra1excBKlRMH9UcOMNsDoaEDctHo1P7VMmO/\n" +
            "Cj/AzoUflp4LT8KvLvveBGFNsB8MjiCIPi5BdBqC6N0J9oeWIML9Iwjij0sQn4Ygfn+Co4Hdg/0X\n" +
            "92DMxePufGMiNhaN9zg2dr+a5B6YqWSLZ7dXl0jcijSfFRmTeg3sAd+WA3Mzp1fl4f289swqw3bX\n" +
            "njFse8+iqCOeNpM90PAQb1HcmxxNlm0iVdYhIugkROy67RIJuzqL2s52yoPPk0THEqnOmLW9HMsD\n" +
            "n4QH7Mqjq6ttGtZmSjJCzaTMih1A+JLMPppG95DM+7MKTsGq885BrciDJqP9N5IZik3jKGjlcafX\n" +
            "4R7uAxJvzMgaEG58qFRsnaYlZmLFZSqSun80YyoC90wq0/mG4PrmASDUwz0MzW8Ie+DXnRnlIi8B\n" +
            "9j57AXaDvls31Zz2wFdJoxCUw889cEclY0YBjTAsERxC8AWcY3B5ewUKriOg05xGqg4C9tnNWnHA\n" +
            "ylaeOCvU90bVI8rYdpiqaTFZksdkVjeZ2w7XdsPYXjxVLBoTrHvm+2Vz7K84KybOUpIsqkLGtju9\n" +
            "+Acypj2R</history:state>\n" +
            "    <history:state>eNrNl11v2jAUhu/3K6zcliS2AytEUO2jmlSp6yp1qqrdIGMMsZo4me0Q+Pdz4kDJKCJFKvQCRTjn\n" +
            "vMd5HzvxGUqVMQr0KmMjR7K/OVPaAXMmmCSaTceT1cj5ERP6vDU4cjBEgQt7Lr78Dfsh7oVB8McB\n" +
            "S8VDRSOWkNuUEs1TMXIirbPQ94ui8Ew+9wTTvmQqzSVlyq+K+wFoFeXX0/OWagpMtSQWKpyVc2uU\n" +
            "yWSq070qbKn9KsdHawkacyb0GzVs0ouIefaGQhF4qZz7GELkP/28fahscblQmgjK6qyW9jhXnwAY\n" +
            "inTKgC075obB/XcH0DTJUlGOJESQOZPVnVyKMMsnMad8Gt5c310UJI4DT5fe8clEexN2QXIdpZLr\n" +
            "1QVNHMCWNM4VX5g1oGXOqoKmpIrNkByXiwMIkpQrhBRuRh2/DuBCMzkj9L+JhXwGaw0TVNkdbkLH\n" +
            "XMxSQKZT85zqW5oLkzIjsTKmTLb/rWv4m8yDRdH7FbV6JQMrtRw5qDtwgNkeCPUdkItap/Kvkhn6\n" +
            "Zfgedi78sPRceBZ+VdlTE4QVwW7QO4Ig+rgE0XkIopMT7PYtQYS7RxDEH5cgPg9BfHqCg57dg92D\n" +
            "ezDm4nl7vjERa4uGOxxru99McgfMWLLZq9urTSRuRJpjRcakXgH7gW/KgamZUzMPZMYupsdxqsxZ\n" +
            "AXoQHZLCu1LokFRp6/YKNbZu7llgVcTLlrOfPdzHG2CPJkeTeZNbmbWPGzoLN7u620TCNtysXMPs\n" +
            "Vnnwdd5HEym/RCt7OZYHPgsP2JZHW1ebNKzNlJilbyZlVmwPwkMyu2hq3X0yp2cVnINV652DGpF7\n" +
            "TUa7LykzFJv2UtDS41YvzR3ceyTemZE1IFz7UKrYOnXjzMSCy1QkVZdpxlQEHplUpj8Owe3dE0Co\n" +
            "gzsYml8fdsCvBzPKRb4E2PvsBdgNum7VenPaAV8ljUKw7H/ugAcqGTMKaIDhEsE+BF/AJQbX9zeg\n" +
            "4DoCOs1ppKogYJ/drBUHLGzlkbNAXW9QPqKMbR+q6kaUJXlMJlUruumDbc+M7cVTxaw2wbpnTjnr\n" +
            "w8GCs2LkzCXJojJkaHvYq39MSEmC</history:state>\n" +
            "    <history:state>eNrNl11v2jAUhu/3K45yW0hsAytEUO2jmlSp6yp1qqrdIGMMsRqczHYI/Ps5caBkFJFWaulFhWrO\n" +
            "eY/zPsfEZ6h0yhmYdcpHnuJ/M66NB3MuuaKGT8eT9cj7EVP2uLM48gjCnTbqtcn5b9QPSS/s9v94\n" +
            "sNIi1CziC3qdMGpEIkdeZEwaBkGe577NF77kJlBcJ5liXAdl8aADjaKCanv+Sk/BVlvEUoezYm+1\n" +
            "MqlKTHJQha9MUOYEeCPBYsGleaGGS3oSsc9eU8g7fqLmAUEIBw8/r+9KW9pCakMl41VWQ3u8i08A\n" +
            "Q5lMObiyY2EZ3H73gCWLNJHFyoJKOueq/CZTMkyzSSyYmIZXlzdnOY3jjm8K78RkYvwJP6OZiRIl\n" +
            "zPqMLTzgKxZnWixtDxiV8bKgLalju6TGRXOApIuiQ2jeTpkXVAFCGq5mlP23sVDMUKVhg0q7w23o\n" +
            "WMhZAnQ6tc+pvyWZtCkzGmtrymT3v02NYJt5tCh+u6JOr2DgpFYjD3cHHtjjgXHfg0xWOqV/pcww\n" +
            "KMIPsGujD0uvjU7Cryz73gRRSbDb6b2CIP64BPFpCOJ3J9jtO4KYdF9BkHxcguQ0BMn7Exz03Bns\n" +
            "Hj2DsZCPu/uNqdxYNNzjWNn9YpJ7YMaKz549Xk0iSS3SXitSrswa3Au+LgdTu6d6HqTWLm7GcaLt\n" +
            "XQH5CB+TIvtS+JhUYetuh1pbt985YGXE05Fzrz3SJ1tg9zbH0HmdW5F1iBs+CTfX3U0iURNuTq5m\n" +
            "tsuD2F6TJSu6et94ckwWPd8OuKnsC3kW77G1+3gtTXISmqgpzSYs0R5LR4FRa7TdlO33HkLHZPbJ\n" +
            "VbqHZN6fVecUrBqfO1yLPGgy3v+J2z0epNFP7h7uAxJvzMgZEG58KFRcnWrs5nIpVCIX5Yxq13QE\n" +
            "91xpO12HcH3zABi3SIsg+9dHLfh1Z1eFzFZA/M9+h7Q73XY5uAvWgq+KRSGs+p9bcMcU51YBDwha\n" +
            "YdRH8AXOCVzeXkEuTAQmyVikyyBwz257xYOlqzzylrjrD4pHVLGbYnU1xvJFFtNJOchup2g3cRP3\n" +
            "4et8Vpng3LN3pM3VYil4PvLmiqZRETJ0E/DFP9NHXQQ=</history:state>\n" +
            "    <history:state>eNrNmN9v2jAQx9/3V5zyWkhsAyuNoNqPalKlrqvUqar2gowxYDU4me0Q+O/nxIFCU0RaaaQPKMLc\n" +
            "fc++z51jPFA64QzMOuFDT/G/KdfGgxmXXFHDJ6Pxeuj9iCh72hkcegThThv12uT8N+qHpBf2yB8P\n" +
            "VlqEms35gt7EjBoRy6E3NyYJgyDLMt/6C19yEyiu41QxroMieNCBWlZBOT1/pSdgoy0iqcNpPre9\n" +
            "MImKTXxQha9MUPgEeCPBIsGleaOGc3oWsWvfU8g6fqxmAUEIB48/b+6LtLSF1IZKxkuvmunxLj8B\n" +
            "DGQ84eDCjoRlcPfdAxYvkljmIwsq6Yyr4pdUyTBJx5FgYhJeX92eZTSKOr7JcyfGY+OP+RlNzTxW\n" +
            "wqzP2MIDvmJRqsXS1oBRKS8C2pA6skNqlBcHSLrIK4Rm7YR5QWkgpOFqStmLiYViikoNa1SkO9ya\n" +
            "joScxkAnE7tO/S1OpXWZ0kjbpIx3v21iBFvPo0FxE0HJ/wvq9HLwTmo19HD3wgPbkxj3PUhlqVNA\n" +
            "K2QGQW5+oGDa6MOWTBs1UjRFWHxigqgg2O303kEQf1yCuBmC+OQEu33iepCgdxAkH5cgaYYgaWTr\n" +
            "LsKedvPuXvRc63ePtn4k5NPufCMqN2QGlfIpKb+5gCr1MFJ8+mpX17Eke5b2CJVwZdbgDjP7cjCx\n" +
            "c9r3g8Smi5tRFGt7LkI+wsekSFUKH5PK07rbGDat298csMLiudPd25bkHV8Ce7A+hs72ueVeh7jh\n" +
            "Rri5pqpjiepwc3J7yXZ+ENm/BJLlVV1NPDkmi14vB1xX9o0889fn2j3eS5M0QhPVpVmHJaqwdBQY\n" +
            "tYm2k7L13kPomEyVXKl7SOb0rDpNsKrdd3jP8mCScXWL220PUmvLreA+IHF6Rt3GdkdSkyapszeS\n" +
            "lwkmx8mS6sZ3sp3NLTLcrDVXcXHKyx4ul0LFclHcjNgxPYcHrrSIZQg3t4+AcYu0CLKfPmrBr3s7\n" +
            "KmS6AuJ/9juk3em2i+siwVrwVbF5CKv+5xbcM8W5VcAXBK0w6iP4AucEru6uIRNmDiZO2VwXRuDW\n" +
            "bivCg6WLPPSWuOtf5EtUkbs70eXlCV+kER0X1yfbuxt3z0Pcw9fZtEyCy549JG8OeUvBs6E3UzSZ\n" +
            "5yYDd+9y+Q817CS9</history:state>\n" +
            "    <history:state>eNrNWE2P2jAQvfdXWLkuJPYEdiGCql+qVGm7XWmrquoFGWPAanBS2yHw7+vEgUJTRBapZA8IYWbe\n" +
            "2PPeTJwZKZ1yhsw25WNP8V8Z18ZDCy65oobPJtPt2PsYU/bzYHHsASZhF/e7cPcVDyK4jfDwh4c2\n" +
            "WkSaLfmK3ieMGpHIsbc0Jo2CIM9z3/oLX3ITKK6TTDGugzJ4EKJGVkG1PX+jZ8hGW8VSR/Nib0dh\n" +
            "UpWY5CQK35ig9AnIDoLFgkvzTAzn9AfEnv0IIQ/9RC0CwJgE3z/fP5Vp6QqpDZWMV14N0+O9foXQ\n" +
            "SCYzjlzYibAcPL73EEtWaSKLlRWVdMFV+U+mZJRm01gwMYs+fXi4yWkch74pciemU+NP+Q3NzDJR\n" +
            "wmxv2MpDfMPiTIu11YBRGS8D2pA6tktqUogDSboqFELzbsq8oDIQ0nA1p+yvjUVijisMa1SmO9qb\n" +
            "ToScJ4jOZvac+l2SSesyp7G2SZke/trFCPaeZ4OSNoLC/wvq8AriHdRm7JHe0EO2JgkZeCiTFU5J\n" +
            "WgkzCgrzE4Lp4hcrmS5uRTRlWNJO2GsLB5fC6YX9C4RDXq5wSDvCIe0Ih1xdOL0BuI4D+ALhwMsV\n" +
            "DrQjHGhHOHB94Qz7ruP0znacWMifh/uNqdwxM6rJp2L52QKq6WGi+PyfzaSJJRxZ2gtjypXZInd1\n" +
            "O4ZDM7unYz+U2nRxM4kTbW+B2MfkHBTUocg5qCKth4Vh07r/zxFWWvypdHe3gKLiK8K+WR9DF8e8\n" +
            "FV6neCOt8OaKqoklbsKbgztKtvNDsX0BkqxQdT3xcA4W/1sOpCnsM/ksntpb93Upm9AKm7gpm024\n" +
            "xDUuHQuM2kTbTVm99zE+B1NnrsI9BXN9rsI2uGpcd+TI8mSSSb3FHZYHNGq5NbpPQFyfo15r3REa\n" +
            "sglNeiP8nWA4zyzUG9/FnS0cDNyT6g5fzkW/tRsGNO6C0ETuUG9MjR5FUK+1ixmB/nMZcYeNdmcu\n" +
            "cFykatzI5VqoRK7K2Zxd00v0jSstEhmh+4fviJAOdADbzwB30JcnuypktkHg3/ohdMNetxxYCtZB\n" +
            "bxVbRmgzuO2gJ6Y4twhkCHhD8ACjN+gO0IfHTygXZolMkrGlLo2QO71VhofWLvLYW5OePywagIrd\n" +
            "9E5X4zu+ymI6LQd4++mhmzSC+/J1Pq+S4PJnX1x2F++14PnYWyiaLguTkZv8vf4NIEHu3g==</history:state>\n" +
            "    <history:state>eNrNWF2P2joQfb+/wsrrQmJPYBciqPqlSpX27q20VVX1BRljwGpwUtsh8O+vE4ddaBYRqEr2AUU4\n" +
            "M2ecOWcmzoyUTjlDZpvysaf4r4xr46EFl1xRw2eT6XbsfYop+7m3OPYAk7CL+124+4oHEdxGMPzh\n" +
            "oY0WkWZLvqL3CaNGJHLsLY1JoyDI89y3/sKX3ASK6yRTjOugDB6EqJFVUG3P3+gZstFWsdTRvNjb\n" +
            "QZhUJSY5isI3Jih9ArKDYLHg0pyJ4ZyeQeyzHyDkoZ+oRQAYk+D7v/ePZVq6QmpDJeOVV8P0eG/+\n" +
            "QWgkkxlHLuxEWA6+fPAQS1ZpIouVFZV0wVV5J1MySrNpLJiYRZ8/PtzkNI5D3xS5E9Op8af8hmZm\n" +
            "mShhtjds5SG+YXGmxdpqwKiMlwFtSB3bJTUpxIEkXRUKoXk3ZV5QGQhpuJpT9tvGIjHHFYY1KtMd\n" +
            "PZlOhJwniM5m9jn1+yST1mVOY22TMt3/t4sRPHmeDEraCAp/L6jDK4h3UJuxR3pDD9maJGTgoUxW\n" +
            "OCVpJcwoKMyPCKaLX61kurgV0ZRhSTthry0cXAqnF/YvEA55vcIh7QiHtCMccnXh9AbgOg7gC4QD\n" +
            "r1c40I5woB3hwPWFM+y7jtM72XFiIX/u7zemcsfMqCafiuWzBVTTw0Tx+YvNpIklHFjaA2PKldki\n" +
            "d3Q7hEMzu6dDP5TadHEziRNtT4HYx+QUFNShyCmoIq37hWHT+nTPEVZaPFe6O1tAUfEVYd+sj6GL\n" +
            "Q94Kr2O8kVZ4c0XVxBI34c3BHSTb+aHYfgBJVqi6nng4BYtflgNpCnsmn8Vbe+sul7IJrbCJm7LZ\n" +
            "hEtc49KxwKhNtN2U1Xsf41MwdeYq3GMw1+cqbIOrxnVHDiyPJpnUW9x+eUCjlluj+wjE9TnqtdYd\n" +
            "oSGb0KQ3wu8JhtPMQr3xXdzZwsHAvanu8OVc9Fs7YUDjLghN5A71xgT7jSnERWN6roDwhUND2KSN\n" +
            "Qr04/yDQmZxD/1zOXTqjXVYLHBepGmhyuRYqkaty+mfX9BJ940qLREbo/uE7IqQDHcD2N8Ad9N+j\n" +
            "XRUy2yDwb/0QumGvW45EBeugd4otI7QZ3HbQI1OcWwQyBLwheIDRW3QH6OOXzygXZolMkrGlLo2Q\n" +
            "e3qrPQ+tXeSxtyY9f1i0GBW7+aCuBoR8lcV0Wo4In+aTbpYJ7uLrfF4lweXPfhrtjvZrwfOxt1A0\n" +
            "XRYmIzdbfPM/ee4Mjw==</history:state>\n" +
            "  </history:slice_history>\n" +
            "  <flack:slice_info view=\"graph\"/>\n" +
            "</rspec>";
    public static final String rspecG = "<rspec type=\"request\" generated_by=\"Flack\" generated=\"2013-05-24T08:41:03Z\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd  \" xmlns:flack=\"http://www.protogeni.net/resources/rspec/ext/flack/1\" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
            "  <node client_id=\"PC\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC:if0\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <interface client_id=\"PC:if1\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"74\" y=\"95\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"VM\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" exclusive=\"false\">\n" +
            "    <sliver_type name=\"emulab-openvz\"/>\n" +
            "    <interface client_id=\"VM:if0\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"503\" y=\"229\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC-0\" component_manager_id=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\" component_id=\"urn:publicid:IDN+wall3.test.ibbt.be+node+n095-20a\" component_name=\"n095-20a\" exclusive=\"true\">\n" +
            "    <location latitude=\"51.036145\" longitude=\"3.734761\" country=\"BE\"/>\n" +
            "    <sliver_type name=\"raw-pc\">\n" +
            "      <disk_image name=\"urn:publicid:IDN+wall3.test.ibbt.be+image+emulab-ops//DEB60_64-STD\"/>\n" +
            "    </sliver_type>\n" +
            "    <services>\n" +
            "      <execute command=\"/example/example.sh\" shell=\"sh\"/>\n" +
            "      <install install_path=\"/example/\" url=\"http://example.com/example.tgz\"/>\n" +
            "    </services>\n" +
            "    <interface client_id=\"PC-0:if0\">\n" +
            "      <flack:interface_info addressBound=\"false\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"265\" y=\"322\" unbound=\"false\"/>\n" +
            "  </node>\n" +
            "  <link client_id=\"lan0\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"VM:if0\"/>\n" +
            "    <interface_ref client_id=\"PC:if0\"/>\n" +
//            "    <property source_id=\"VM:if0\" dest_id=\"PC:if0\"/>\n" +
//            "    <property source_id=\"PC:if0\" dest_id=\"VM:if0\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"412\" y=\"78\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"lan1\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3.test.ibbt.be+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if0\"/>\n" +
            "    <interface_ref client_id=\"PC:if1\"/>\n" +
            "    <property source_id=\"PC-0:if0\" dest_id=\"PC:if1\" capacity=\"1000000000\" latency=\"10\" packet_loss=\"0.05\"/>\n" +
            "    <property source_id=\"PC:if1\" dest_id=\"PC-0:if0\" capacity=\"1000000000\" latency=\"10\" packet_loss=\"0.05\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <client:client_info name=\"Flack\" environment=\"Flash Version: LNX 11,2,202,280, OS: Linux 2.6.32-34-generic, Arch: x86, Screen: 1920x1080 @ 72 DPI with touchscreen type none\" version=\"v14.91\" url=\"https://www.emulab.net/protogeni/flack2/flack.swf\"/>\n" +
            "  <history:slice_history backIndex=\"8\" note=\"Established lan1\" xmlns:history=\"http://www.protogeni.net/resources/rspec/ext/history/1\">\n" +
            "    <history:state>eNqVUk1r20AQvfdXDHu1rdWHE9vCCi0NhYCbBlxK6MWs1mNrqbSr7ocl//uuVkrbHArpQUiMZt6b\n" +
            "ee9ttWmRg722WBCNPx0aS+CMEjWzeDyU14J8qhn/8VexIGmcZIv4ZpEuv8brPFvl8fI7gd6I3PAK\n" +
            "G7ZTnFmhZEEqa9uc0q7rIj8vIomWajTKaY6GBnKawZu66LRe1JsjeLamliY/Dbu9omm1suqfKNhb\n" +
            "GmZo8gLBa4HS/ifGOPQHxN/+CqHLIqXPNI3jhD5/3u2DLAshjWWS4zT1RnnI3TuArVRHhJH2ILwH\n" +
            "Tx8JcNW0Sg6Vhkl2Rh3+OC3z1pW14OKYP9w/zjpW11lkB+1EWdqoxBlztlJa2OuMNwSw57Uz4uIz\n" +
            "YLXDQOgpTe1L+jCEAyRrhoSwbtFyQqeGoGQ+bHYQ8qSgL8hqScBnZnNDwMlSOXmcMMPMlg7N4Ws8\n" +
            "JX+5aBgfOaa4obwIrWQTvPE1U8E31ManKofd4zMkyTydp7F/1vEcvux9VUjXQxrdRlm6yJaLEFjB\n" +
            "5/BB8yqHfn07hz3XiB4h2aRxn8TrGN7DKoX7pwfohK3AKscrE5pgvNvrS+AyMhfkkiyjjXfd6Xp0\n" +
            "z0z2YeNqVgYDf6dnTFo6viLTnSYRRtm8unzS7SKwK8hZs7YaWraj83e/AGKxORI=</history:state>\n" +
            "    <history:state>eNq1U9tq20AQfe9XDPtq6+6rsEJLQyHgpAGXEPpiVuuxtVTaVfdiyf36ri5pG2jT9KEPQjCaOWfO\n" +
            "0ZmN0jUyMJcaM6Lwq0VtCJxQoKIGD/v8kpEPJWVffilmJA6jxAvnXjz7FK7SZJmGi88EWs1TzQqs\n" +
            "6FYyargUGSmMqdMgaJrGd/PcF2gChVpaxVAHPXmQwKu6gnE9v9UHAEdXlUKnx265Zzy1kkb+EQZb\n" +
            "E/QzQfQEwUqOwvwjxjD0E8SJf4bQJL5UpyAOwyh4vN3uel88LrShguE49Up/yNUbgI2QB4SBds/d\n" +
            "T7h/T4DJqpaiq1RU0BOq/otVIq1tXnLGD+nN9d2koWWZ+KYzj+e58XOcUGsKqbi5TFhFAFtWWs3P\n" +
            "LgRGWewJHaUuXUntu3SAoFUXEdp4NSPB2NA7mXab7bk4SmgzspwRcKFZzwlYkUsrDiNmP7MJuubf\n" +
            "6nm4/S96jrTULwjCypY092SN4vztJV3zMOmFxfH6b8oGUemTtg5gIBsvyVFxJUXVp87VdAEPqLQ7\n" +
            "mBS2d48QRdN4GofuWYVT+LhzVS5sC7G/8JPYS2Zef4ucTeGdYkUK7WoxhR1TiA4hWsdhG4WrEN7C\n" +
            "Mobr+xtouCnASMsK3TfBYIBzmsB5YM7IOZr5a5dnq8ohl3oM5mBRH80fdzHcUDy8fN0cRxMG45zN\n" +
            "bHTuzLHJyEnRuuhaNkOmr74Dd+GBlg==</history:state>\n" +
            "    <history:state>eNrNVF1r2zAUfd+vuOi1sS3bSZOYuGy0DAppF+goZS9BVpRYzJY8fcROf/1ky91W2Lr2YbAHY7i6\n" +
            "9xydo3vvSumGUTCnhuVIsW+WaYPgwARTxLDdtjjl6GNF6NdfgjlKcJwGeBYk0894kaXzDC++IOg0\n" +
            "zzQtWU3WkhLDpchRaUyTRVHbtqGr56FgJlJMS6so09FAHqXwqqxovF7Y6R2Ao6srobN9f7lnPI2S\n" +
            "Rv4RhnUmGmqi+AmCVpwJ80YMX/QTxIl/htCmoVSHKME4jh5u1neDLwEX2hBB2Vj1Sn/QxTuAlZA7\n" +
            "Bp52y90jbC4RUFk3UvSRmghyYGo4sUpkjS0qTvkuu766PWtJVaWh6c3jRWHCgp0Ra0qpuDmd0RoB\n" +
            "62hlNT+6JjDKsoHQUerKhdS27w4QpO5bhLRBQ1E0JgxOZv3NtlzsJXQ5mk8RuKZZzhBYUUgrdiPm\n" +
            "ULOK+uTf6rm/+Sd69qTSLwhita1IEciGiePjS7pmOB2EJcnyrco2lwH+L98qxjOvaX7+N01eTvak\n" +
            "qgfwLON2cPZxJUU9TJKL6RLumdJuCWSwvn2AOJ4kkwS7b4En8OnORbmwHSTheZgmQToNhv3C6QQ+\n" +
            "KFpm0C3OJ3BHFWMOIV4muIvxAsN7mCdwtbmGlpsSjLS01EMSeOXOYQRHz5yjYzwNl25Grar8rOlx\n" +
            "2PyzD+P2Y9b9Xkj8L9TtfjTBG+f8paNzR87aHB0Uaco+ZeXn9OI7KwrHAQ==</history:state>\n" +
            "    <history:state>eNrNVF1r3DAQfO+vWPSasy3b92nOoSWhEEjSg5QQ+nLIOt1Z1JZcST47+fWVJadtoE2TQiEPxrDa\n" +
            "ndGMllkr3TAK5r5hOVLsW8u0QXBggili2G5b3OfoY0Xo11+KOUpwnAZ4FiTTz3iZpYssnn5B0Gue\n" +
            "aVqymlxKSgyXIkelMU0WRV3XhXaeh4KZSDEtW0WZjhx5lMKLuqLxemGvdwCWrq6EzvbD5Z7wNEoa\n" +
            "+UcY1pvIzUTxIwStOBPmlRh+6CeIFf8EoUtDqQ5RgnEc3V1d3jhfAi60IYKyceqF/qDTdwBrIXcM\n" +
            "PO2W20fYnCGgsm6kGCo1EeTAlDtplciatqg45bvs4vz6pCNVlYZmMI8XhQkLdkJaU0rFzf0JrRGw\n" +
            "nlat5ke7BEa1zBFaSl3ZktoO2wGC1MOKkC5oKIrGBudkNtxsy8VeQp+jxRSBXZrVDEErCtmK3Yjp\n" +
            "ZtbR0PxbPbdX/0XPnlT6GUGsbitSBLJh4vjwnK4ZTp2wJFm9VtnmLMBv8q1iPPOaFvN/0BS/SU2z\n" +
            "uZMUL6d/k+TVZI+ihnlPMgae3QiupKhdONiaLuGWKW1zLYPL6zuI40kySbD9lngCn25slYu2hySc\n" +
            "h2kSpNPARSanE/igaJlBv5xP4IYqxixCvEpwH+MlhvewSOB8cwEdNyUY2dJSuybwwq3BCI6eOUfH\n" +
            "eBqurPWtqnx86DE//Ca7BPkRXz7qEv8LdbcfTfC+WXvpaNyRsy5HB0WacmhZ++g5/Q5nCQxK</history:state>\n" +
            "    <history:state>eNrNVclu2zAQvfcrBrzG2r0KdtA2QYECSRoghRH0YtA0bRGRSJWkLLlfX4qUE2drkgJdDoas0Zs3\n" +
            "fI+DmalUJSWgdyWdIUm/V1RpBBvKqcSarhbL3Qx9yjG5OQjOUBxGiRcOvLj/NRynySiN428IGsVS\n" +
            "RTJa4DNBsGaCz1CmdZkGQV3XvslnPqc6kFSJShKqAls8SOBVqKA7nt+oFYApV+Rcpev2cPfqlFJo\n" +
            "8SwNbXRgc4JoT0FyRrl+I4dLuiMx4u8x1Ikv5CaIwzAKrs/PrqwvHuNKY05ol/VKf9DxO4ApFysK\n" +
            "ruyCmUu4PEFARFEK3kYKzPGGSvulkjwtq2XOCFuln08vjmqc54mvW/PYcqn9JT3Clc6EZHp3RAoE\n" +
            "tCF5pdjWNIGWFbUFTUmVm5BctN0BHBdti+DaKwkKOgDjmso1Jg8OlrJ12HEYkLU7vYUuGF8LwKuV\n" +
            "0ak+ioqblDXOlTFlefi2rxHcZnYBx9fa4aiaGRr1EZhOnQwQVLxjsUIsyTRowU+aOD//IyY6Bc+6\n" +
            "SIsqx0tPlJRvf/zazPn5XzdzECbWzTievNXOyxMv/Pdd+YSmKBw4TaPhb2iK/ktNg6GVFI37L0nK\n" +
            "Gb85lJRjvm+p6SNhXf03S3vUxgtJ10+08ou4bn7scWYWl1TqHbipeEgFK3Oa1+Z0kLucB+dpTTq8\n" +
            "AGPSA/ctYu9+2xQ79+jMn5sMjTf376DNsf+cwHSvs2Vxdbr1akYBk4IXdhWZmMpgTqUyWzSFs4tr\n" +
            "iKJe3ItD8xuHPfhyZaKMVw3E/tBPYi/pe3ZBM9KDD5JkKTTjYQ+uiKTUMESTOGyicBzCexjFcHr5\n" +
            "GWqmM9CiIpmyIHDaTS8g2LrKM7SN+v6klShzt6xUt63cCLP76nZZusUau4ev6nVngnPPtPh+Xm0Z\n" +
            "rWdoI3GZtZCpW3THPwExNNKq</history:state>\n" +
            "    <history:state>eNrNVl1v2jAUfd+vuMpryZcDbYig2tZqUqW2q9QJVXtBxhhiNTiZ7ZCwXz/HDpRSusKkdXtAEHPu\n" +
            "ufceHzt3IGRBCahVQYeOoD9KKpUDc8qpwIpOx5PV0PmSYfK4tTh0UBBGbtBzUfdbECdRnPTi7w7U\n" +
            "kiWSpHSBr3OCFcv50EmVKhLfr6rK0/HM41T5gsq8FIRK3yT3IzgI5bflebWcAuh0i4zLZNYU9yxP\n" +
            "IXKVv0pDa+WbGD9cU5CMUa6O5LBBTyS6+WcMVeTlYu6jIAj9h5vre6OLy7hUmBPaRh2oj3P+AWDA\n" +
            "8ykFm3bM9CbcXThA8kWR82ZlgTmeU2H+KQVPinKSMcKmydXl7UmFsyzyVCMem0yUN6EnuFRpLpha\n" +
            "nZCFA7QmWSnZUptAiZKahDqlzPSSGDfuAI4XjUVw5RbE8VsA44qKGSY7hSVsFrQcGmTkTjbQMeOz\n" +
            "HPB0qvuUn/OS65AZzqQWZbL9tM7hbyLbBcvXyGGp6qFz1nVAO7Xfc6DkLYtpxJAM/Aa8V8TRzV8R\n" +
            "0Xbwqop0UWZ44uYF5cufvxdzdPPuYvaCyKiJUP9YOe8u3ODfu3JPT+i0Z3qKEPqDnsL/9qS54fvb\n" +
            "49QoGcbdt5TMGH/cLjfDfF3q4IWebdtHK/pCoLGgsz0n6E1ce20dgGtFXyP1y6KgQq3AXtvbSWGq\n" +
            "697Hvi+mhTzF7FR+YJ4DqnuR6cCoFnRUhXuidrRobLLtfG2TnaNsEGv/dUNkDHgWb/w30iEKz5/b\n" +
            "sAkyv+zeJestbGhsonaw0ZcwEzlfmCFAr8kURlRIPb8kcH37AGHYQR0U6E8cdODrvV5lvKwBeade\n" +
            "hNyo65rRiJEOfBIkTaCOTztwTwSlmiHso6AOgziAj3CG4PLuCiqmUlB5SVJpQGCb18fBgaXNPHSW\n" +
            "Ydfr64unFJkdE2Q7J9iXh5kUNmOKHWmQ/fJkNWtFsPLpy2V9FSwZrYbOXOAibSADO2Kc/wI+g0gN</history:state>\n" +
            "    <history:state>eNrNVttu2zgQfd+vIPRq60bJN8EudtN0gQJJN0CKoNgXg5ZoiwhFaUnKVvr1HVEXy4nTOkBb7INB\n" +
            "mZyZMzw8HM5SqoLGSD8VdGVJ+l9JlbbQjgoqiabJevO0sv7mJH4cTK4s7PmB7U1sHH725lGwiDD+\n" +
            "10KVYpGKU5qRmzwmmuViZaVaF5HrHg4HB/yZI6h2JVV5KWOqXAPuBugiK7dNz6lUghDAZVyoaFsn\n" +
            "d4JTyFznr4ahlXaNj+t3IWLOqNBvjNE4HYPA5k8iHAInlzsXe57vfrm9uTe82EwoTURMW68L+bHe\n" +
            "/YHQUuQJRQ3smsEh3L23UJxnRS7qmYwIsqPSrJRSREW54SxmSfTx+tPoQDgPHF2TxzYb7WzoiJQ6\n" +
            "zSXTT6M4sxCtYl4qtgcRaFlSAwiQisOUXNfqQIJktUTIwS5iy20NmNBUbkn8LLGIbb02BhgZuqPe\n" +
            "dM3ENkckSWCf6iovBbhsCVdAymb4r8Nwe892oolX09GEqlbWLLQQKHUxsVAp2ihmIybI0q2Nz5L4\n" +
            "cPtLSGx28CqLNCs52dh5QcX+6/fJfLj97WROvMCwifHirXTevbe9n0foMc6l/nU+I+EtoDR5ZBig\n" +
            "4f248orgeVu4EIdBlwksT3zHC6Z+CNLiudi1s4EzC8LZ1K8xSqEl0HX1oWf51XvTH2PC1OOaZUBO\n" +
            "a3DJ7oz9qBePct3rD1dTbz0N7fvP18czHsB3CVG5Z1BRenxa0bjUtGYIzgjYhaJGsoLTbnRUaiGV\n" +
            "Us5XFny6vacpYZyjdlwXRKcDd1CM5H1d64IBTP+td18HqZ4kdk6NeDoxagwwHqhxoOrvy9H/3xZJ\n" +
            "2//9N3tqqPTn4Y8uNmficZguJ6JLdfmCzzdI+ITRFwStJd2eKX4/tGtfnAvsWtI7S3jnCyr1E2pe\n" +
            "3CEoSiDvc9HP+bQmR59nmV+Ic0F2L5Au9GqN3pThGa9nXNQyGSofZNKvNfozFp3+Qh8bAc7mvf4e\n" +
            "wEWT3akMayfz1Zxd1B1hHaYBantSeD+ZzEVm+jeYUyl6oFJBBY/QzacvyPfHeIw9+M29MfrnHmaZ\n" +
            "KCuEnakTYDsIbdPVsniM/pJxGqFqPh2j+1hSChH8BfYq35t76E80w+j67iM6MJ0inZdxqowRajYP\n" +
            "18FC+wZ5Ze390Fn4g0qo2havKd2myes7zKYbxc3gqMO2JaGhD4pLVwr2jB5W1k6SwpTjZdMdvvsG\n" +
            "BQjV2g==</history:state>\n" +
            "    <history:state>eNq9Vttu2zgQfe9XEHy1dfdVsIvdNC1QIOkGSBEU+2LQFG0RoSgtSVlOvr4j6mK5TVoH2N0HgzI5\n" +
            "c2Z4eGbIldIFo8g8FWyNFfunZNpgtGeSKWJYstk+rfEnQejjYHKNQz+IHH/qhJOv/iKOlnG4+Buj\n" +
            "o+axpinLyE1OieG5XOPUmCL2vKqqXPDnrmTGU0znpaJMeza4F6GLrLw2PfeoE4QgXCakjnd1cmdx\n" +
            "CpWb/FUYdjSe9fGCDoIKzqR5I0bjdAKBzZ8hVJGbq70X+n7gfbu9ube8OFxqQyRlrdeF/OD37xBa\n" +
            "yTxhqAm74XAIdx8wonlW5LKeyYgke6bsSqlkXJRbwSlP4s/XX0YVESJyTU0e326Nu2UjUpo0V9w8\n" +
            "jWiGETtSUWp+ABEYVTIbEEJqAVNqU6sDSZLVEiGVU1DstQZcGqZ2hP6QWMx3fosBRpbuuDfdcLnL\n" +
            "EUkS2Ke+yksJLjsiNJCyHf7rYni9ZzvR4NV0NFDHNZ5PMAKlLqcYlbJFsRuxICuvNn6RxIfb/4TE\n" +
            "ZgevssiyUpCtkxdMHp5/TebD7f9O5tSPLJthuHwrnXcfHP/fI/SEc6l/nc9I+ktoTT4ZAjS8n1Ze\n" +
            "EbxoGxcSMJgygeVp4PrRLJiAtEQu9+1s5M6jyXwW1DFKaRTQdfWxZ/nVuumPMeH6ccMzIKc1uGR3\n" +
            "1n7Ui0d73vXHq5m/mU2c+6/XpzMehO8SYurAoaP08dmR0dKwmiE4I2AXmhrJCsG60dUpRjplQqwx\n" +
            "fHq9p21hQqB23BTEpAN3UIwSfV/rwCBM/232z4NUzxJ7SY3hbGrVGIXhQI0DVQ/kKLh8HMpRENmV\n" +
            "zuonUb6B+DNZ/lSuG8V2L5Tsb+3aPtnZwZ1TMGWeUNP9h1AogWwu9WlNTj4/5FOTNJQmkNSvNfxb\n" +
            "i47/SRBa/ueLnv4HcDFkf94Taif71eww7jZawzSB2ncE9DyucpnZOxfmdIoemNJQdTG6+fINBcE4\n" +
            "HIc+/Bb+GP11D7NclkcUujM3Cp1o4tiXCKdj9KeiaYyOi9kY3VPFGCAEy9A/Bv7CR3+geYiu7z6j\n" +
            "ipsUmbykqbZGqNk8iAGjQxN5jQ/BxF0GA/Xq9lpuys1ezP2roHlBhM3g6mrXktDQB+XXNeYDZ9Ua\n" +
            "7xUpbAmtmhv9/Xc3ORui</history:state>\n" +
            "    <history:state>eNq9Vttu2zgQfd+vIPRqSyIlXwW72E3TBQok3QApgqIvBi3TFhGK0pKUrfTrd0RdLKdx4wCbPhiU\n" +
            "yZkzw3M4Qy6UzlmMzFPOlo5i/xZMGwftmGSKGrZZrZ+Wzt+Cxo+9yaUTYBK6eOwGo694Fo1whOff\n" +
            "HVRqHuk4YSm9yWJqeCaXTmJMHvn+4XDwwJ97khlfMZ0VKmbat8H9EF1k5TfpeaXeIAThUiF1tK2S\n" +
            "O4mTq8xkZ2FYaXzr45MWIhacSfNGjNrpCAKbP0E4hF6mdn6AMfG/3d7cW15cLrWhMmaN14X8OB/+\n" +
            "QGghsw1DddgVBxHuPjooztI8k9VMSiXdMWVXCiWjvFgLHvNN9Pn6y+BAhQg9U5HH12vjrdmAFibJ\n" +
            "FDdPgzh1ECtjUWi+h0NgVMFsQAipBUypVXU6kKRpdUTowc1jx28MuDRMbWn8LLGIb3GDAUaW7qgz\n" +
            "XXG5zRDdbGCf+iorJLhsqdBAyrr/r43hd56vBiXvF7TGqzSoocqlMx05CMpjPnZQIRsUy54FWfiV\n" +
            "8YvKPdy+i3L1Ds5Kx9JC0LWb5Uzuf/xawYfb91XwBTLHOLRsBsH8rXTefXTx/0foEedS/yqfgcRz\n" +
            "6IeY9gFq3o8rZ6pMNN0SCRhMsYHlMfFwOCEjOFoik7tmNvSm4Wg6IVWMQhoFdF196lg+W6ydjBuu\n" +
            "H1c8BXIag0t2Z+0H3eHRvn/96WqCV5ORe//1+qhxL3ybEFN7Dm2si89KFheGVQyBRsAudFKa5oK1\n" +
            "o6cTB+mECbF04NPvPG3fFAI14yqnJum5w4lRomumLRiE6b7N7kcv1ZPEzvUTF//2IggmY1sEYRD0\n" +
            "iqCH06sCweVjP2FBZZvs4qdaeIPeJ9XwU5dYKbZ9oVO8atfcCa0d3K85U+YJ1TddHwptIJtLfRqT\n" +
            "o8+zfCqS+hUBJHVrNf/WouV/RALL/3TW0f8ALobuTltR5XROBPL7RejO6mUykFcobcCeCUFeF4Kc\n" +
            "+DzL6Y1SuMQqUQ0XKVFvMmr3WqHUcZrXK1x6XGUytS89mNMJemBKQ9uN0M2Xb4iQYTAMMPxmeIj+\n" +
            "uYdZLosSBd7ECwM3HLn2/cvjIfpLxUmEytlkiO5jxRggkHmAS4JnGP2JpgG6vvuMDtwkyGRFnGhr\n" +
            "hOq9w4lw0L6OvHT2ZOTNSa996eYxWPdb+xzs3qL1uzWoB08ftg0JNXvQf9umtOfssHR2iua2hy7q\n" +
            "d+SH/wBza+Mz</history:state>\n" +
            "  </history:slice_history>\n" +
            "  <flack:slice_info view=\"graph\"/>\n" +
            "</rspec>";
    public static final String rspecH = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<rspec xmlns=\"http://www.geni.net/resources/rspec/3\"\n" +
            "       xmlns:xs=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
            "       xmlns:openflow=\"http://www.geni.net/resources/rspec/ext/openflow/3\"\n" +
            "       xs:schemaLocation=\"http://www.geni.net/resources/rspec/3\n" +
            "           http://www.geni.net/resources/rspec/3/request.xsd\n" +
            "           http://www.geni.net/resources/rspec/ext/openflow/3\n" +
            "           http://www.geni.net/resources/rspec/ext/openflow/3/of-resv.xsd\"\n" +
            "       type=\"request\">\n" +
            "\n" +
            "  <openflow:sliver description=\" InstaGENI OpenFlow\" email=\"lnevers@bbn.com\">\n" +
            "    <openflow:controller url=\"tcp:mallorea.gpolab.bbn.com:33018\" type=\"primary\" />\n" +
            "\n" +
            "    <openflow:group name=\"bbn-instageni-1750\">\n" +
            "      <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.instageni.gpolab.bbn.com+datapath+06:d6:84:34:97:c6:c9:00\" \n" +
            "\tcomponent_manager_id=\"urn:publicid:IDN+openflow:foam:foam.instageni.gpolab.bbn.com+authority+am\"  />\n" +
            "    </openflow:group>\n" +
            "\n" +
            "    <openflow:match>\n" +
            "\n" +
            "      <openflow:use-group name=\"bbn-instageni-1750\" />\n" +
            "\n" +
            "      <openflow:packet>\n" +
            "        <openflow:dl_type value=\"0x800,0x806\"/>\n" +
            "        <openflow:nw_dst value=\"10.42.18.0/24\"/>\n" +
            "        <openflow:nw_src value=\"10.42.18.0/24\"/>\n" +
            "      </openflow:packet>\n" +
            "\n" +
            "    </openflow:match>\n" +
            "\n" +
            "  </openflow:sliver>\n" +
            "\n" +
            "</rspec>\n" +
            "\n";
    public static final String rspecI = "";
    public static final String rspecJ = "";
    public static final String rspecK = "";
}
