package be.iminds.ilabt.jfed.highlevel.model.rspec_source;

import be.iminds.ilabt.jfed.rspec.model.InvalidRspecException;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;
import be.iminds.ilabt.jfed.rspec.model.StringRspec;
import junit.framework.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * StringRspecTest
 */
public class StringRspecTest {

    @Test
    public void testNormalRspecParsing() {
        StringRspec s = new StringRspec(normalRspec);
        List<String> compMan = s.getAllComponentManagerUrns();
        Assert.assertTrue("size is "+compMan.size()+". list is: "+compMan, compMan.size() == 5);
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall3+authority+cm"));
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall4+authority+cm"));
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall5+authority+cm"));
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall6+authority+cm"));
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall7+authority+cm"));
    }

    @Test
    public void testErrorRspecParsing() {
        StringRspec s = new StringRspec(errorRspec);
        List<String> compMan = s.getAllComponentManagerUrns();
        Assert.assertTrue("size is "+compMan.size()+". list is: "+compMan, compMan.size() == 5);
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall3+authority+cm"));
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall4+authority+cm"));
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall5+authority+cm"));
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall6+authority+cm"));
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall7+authority+cm"));
    }

    @Test
    public void testRspecBParsing() {
        StringRspec s = new StringRspec(brechtRspec);
        List<String> compMan = s.getAllComponentManagerUrns();
        Assert.assertTrue("size is "+compMan.size()+". list is: "+compMan, compMan.size() == 1);
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall2.ilabt.iminds.be+authority+cm"));
    }

    @Test
    public void testRspecB2Parsing() {
        RequestRspecSource s = new RequestRspecSource(brechtRspec);
        List<String> compMan = s.getAllComponentManagerUrns();
        Assert.assertTrue("size is "+compMan.size()+". list is: "+compMan, compMan.size() == 1);
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall2.ilabt.iminds.be+authority+cm"));
    }

    @Test
    public void testRspecB3Parsing() throws InvalidRspecException {
        ModelRspec s = ModelRspec.fromGeni3RequestRspecXML(brechtRspec);
        List<String> compMan = s.getAllComponentManagerUrns();
        Assert.assertTrue("size is "+compMan.size()+". list is: "+compMan, compMan.size() == 1);
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+wall2.ilabt.iminds.be+authority+cm"));
    }

    @Test
    public void testOpenflowAParsing() {
        StringRspec s = new StringRspec(openflowRspecA);
        List<String> compMan = StringRspec.parseOpenflowComponentManagers(s.getXmlString());
        Assert.assertTrue("size is "+compMan.size()+". list is: "+compMan, compMan.size() == 1);
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+openflow:foam:foam.instageni.gpolab.bbn.com+authority+am"));
    }


    @Test
    public void testOpenflowBParsing() {
        StringRspec s = new StringRspec(openflowRspecB);
        List<String> compMan = StringRspec.parseOpenflowComponentManagers(s.getXmlString());
        Assert.assertTrue("size is "+compMan.size()+". list is: "+compMan, compMan.size() == 1);
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+openflow:foam:10.1.0.61+authority+am"));
    }


    @Test
    public void testOpenflowCParsing() {
        StringRspec s = new StringRspec(openflowRspecC);
        List<String> compMan = StringRspec.parseOpenflowComponentManagers(s.getXmlString());
        Assert.assertTrue("size is "+compMan.size()+". list is: "+compMan, compMan.size() == 1);
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+authority+am"));
    }

//Xml is too badly damaged, may match or not, we don't care in this case
//    @Test
//    public void testOpenflowDParsing() {
//        StringRspec s = new StringRspec(openflowRspecD);
//        List<String> compMan = StringRspec.parseOpenflowComponentManagers(s.getXmlString());
//        Assert.assertTrue("size is "+compMan.size()+". list is: "+compMan, compMan.size() == 1);
//        Assert.assertTrue(compMan.contains("urn:publicid:IDN+openflow:foam:foam.instageni.gpolab.bbn.com+authority+am"));
//    }

    @Test
    public void testOpenflowEParsing() {
        StringRspec s = new StringRspec(openflowRspecE);
        List<String> compMan = StringRspec.parseOpenflowComponentManagers(s.getXmlString());
        Assert.assertTrue("size is "+compMan.size()+". list is: "+compMan, compMan.size() == 1);
        Assert.assertTrue(compMan.contains("urn:publicid:IDN+openflow:foam:foam.atlantis.ugent.be+authority+am"));
    }

    @Test
    public void testLoginServiceParsingA() {
        ManifestRspecSource s = new ManifestRspecSource(manifestA);
        List<ManifestRspecSource.LoginService> logins = s.getNodeLoginInfo(new RspecNode("node0")); //dummy rspec node, since only the ID is used
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "n095-08b.wall2.ilabt.iminds.be");
        Assert.assertEquals(logins.get(0).getUsername(), "wvdemeer");
        Assert.assertEquals(logins.get(0).getPort(), 22);
    }

    @Test
    public void testLoginServiceParsingA2() {
        StringRspec s = new StringRspec(manifestA);
        List<ManifestRspecSource.LoginService> logins = s.getNodeLoginInfo(new RspecNode("node0")); //dummy rspec node, since only the ID is used
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "n095-08b.wall2.ilabt.iminds.be");
        Assert.assertEquals(logins.get(0).getUsername(), "wvdemeer");
        Assert.assertEquals(logins.get(0).getPort(), 22);
    }


    @Test
    public void testLoginServiceParsingA3() throws InvalidRspecException {
        ModelRspec s = ModelRspec.fromGeni3ManifestRspecXML(manifestA);
        List<RspecNode.LoginService> logins = s.getNodeById("node0").getLoginServices();
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "n095-08b.wall2.ilabt.iminds.be");
        Assert.assertEquals(logins.get(0).getUsername(), "wvdemeer");
        Assert.assertEquals(logins.get(0).getPort(), "22");
    }



    @Test
    public void testLoginServiceParsingB() {
        ManifestRspecSource s = new ManifestRspecSource(manifestB);
        List<ManifestRspecSource.LoginService> logins = s.getNodeLoginInfo(new RspecNode("node0"));
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "dummyhost0");
        Assert.assertEquals(logins.get(0).getUsername(), "dummyuser0");
        Assert.assertEquals(logins.get(0).getPort(), 22);

        logins = s.getNodeLoginInfo(new RspecNode("node1"));
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "dummyhost1");
        Assert.assertEquals(logins.get(0).getUsername(), "dummyuser1");
        Assert.assertEquals(logins.get(0).getPort(), 22);

        logins = s.getNodeLoginInfo(new RspecNode("bridge"));
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 2);
        Assert.assertEquals(logins.get(0).getHostname(), "dummyhostbridge1");
        Assert.assertEquals(logins.get(0).getUsername(), "dummyuserbridge1");
        Assert.assertEquals(logins.get(0).getPort(), 22);
        Assert.assertEquals(logins.get(1).getHostname(), "dummyhostbridge2");
        Assert.assertEquals(logins.get(1).getUsername(), "dummyuserbridge2");
        Assert.assertEquals(logins.get(1).getPort(), 22);
    }
    @Test
    public void testLoginServiceParsingB2() {
        StringRspec s = new StringRspec(manifestB);
        List<ManifestRspecSource.LoginService> logins = s.getNodeLoginInfo(new RspecNode("node0"));
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "dummyhost0");
        Assert.assertEquals(logins.get(0).getUsername(), "dummyuser0");
        Assert.assertEquals(logins.get(0).getPort(), 22);

        logins = s.getNodeLoginInfo(new RspecNode("node1"));
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "dummyhost1");
        Assert.assertEquals(logins.get(0).getUsername(), "dummyuser1");
        Assert.assertEquals(logins.get(0).getPort(), 22);

        logins = s.getNodeLoginInfo(new RspecNode("bridge"));
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 2);
        Assert.assertEquals(logins.get(0).getHostname(), "dummyhostbridge1");
        Assert.assertEquals(logins.get(0).getUsername(), "dummyuserbridge1");
        Assert.assertEquals(logins.get(0).getPort(), 22);
        Assert.assertEquals(logins.get(1).getHostname(), "dummyhostbridge2");
        Assert.assertEquals(logins.get(1).getUsername(), "dummyuserbridge2");
        Assert.assertEquals(logins.get(1).getPort(), 22);
    }

    @Test
    public void testLoginServiceParsingB3() throws InvalidRspecException {
        ModelRspec s = ModelRspec.fromGeni3ManifestRspecXML(manifestB);
        List<RspecNode.LoginService> logins = s.getNodeById("node0").getLoginServices();
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "dummyhost0");
        Assert.assertEquals(logins.get(0).getUsername(), "dummyuser0");
        Assert.assertEquals(logins.get(0).getPort(), "22");

        logins = s.getNodeById("node1").getLoginServices();
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "dummyhost1");
        Assert.assertEquals(logins.get(0).getUsername(), "dummyuser1");
        Assert.assertEquals(logins.get(0).getPort(), "22");

        logins = s.getNodeById("bridge").getLoginServices();
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 2);
        Assert.assertEquals(logins.get(0).getHostname(), "dummyhostbridge1");
        Assert.assertEquals(logins.get(0).getUsername(), "dummyuserbridge1");
        Assert.assertEquals(logins.get(0).getPort(), "22");
        Assert.assertEquals(logins.get(1).getHostname(), "dummyhostbridge2");
        Assert.assertEquals(logins.get(1).getUsername(), "dummyuserbridge2");
        Assert.assertEquals(logins.get(1).getPort(), "22");

    }


    @Test
    public void testLoginServiceParsingPle() {
        ManifestRspecSource s = new ManifestRspecSource(manifestPle);
        RspecNode requestNode = new RspecNode("node0");
        requestNode.setComponentId("urn:publicid:IDN+ple:quantavisple+node+marie.iet.unipi.it");
        requestNode.setComponentManagerId("urn:publicid:IDN+ple+authority+cm");
        List<ManifestRspecSource.LoginService> logins = s.getNodeLoginInfo(requestNode);
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "marie.iet.unipi.it");
        Assert.assertEquals(logins.get(0).getUsername(), "wall3testibbtbe_DebugjFed");
        Assert.assertEquals(logins.get(0).getPort(), 22);
    }

    @Test
    public void testLoginServiceParsingPle2() {
        ManifestRspecSource s = new ManifestRspecSource(manifestPle);
        RspecNode requestNode = new RspecNode("node0");
        requestNode.setComponentId("urn:publicid:IDN+ple:quantavisple+node+marie.iet.unipi.it");
        requestNode.setComponentManagerId("urn:publicid:IDN+ple:ibbtple+authority+cm");
        List<ManifestRspecSource.LoginService> logins = s.getNodeLoginInfo(requestNode);
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "marie.iet.unipi.it");
        Assert.assertEquals(logins.get(0).getUsername(), "wall3testibbtbe_DebugjFed");
        Assert.assertEquals(logins.get(0).getPort(), 22);
    }

    @Test
    public void testLoginServiceParsingPle3() {
        StringRspec s = new StringRspec(manifestPle);
        RspecNode requestNode = new RspecNode("node0");
        requestNode.setComponentId("urn:publicid:IDN+ple:quantavisple+node+marie.iet.unipi.it");
        requestNode.setComponentManagerId("urn:publicid:IDN+ple+authority+cm");
        List<ManifestRspecSource.LoginService> logins = s.getNodeLoginInfo(requestNode);
        Assert.assertNotNull(logins);
        Assert.assertTrue("size is "+logins.size()+". list is: "+logins, logins.size() == 1);
        Assert.assertEquals(logins.get(0).getHostname(), "marie.iet.unipi.it");
        Assert.assertEquals(logins.get(0).getUsername(), "wall3testibbtbe_DebugjFed");
        Assert.assertEquals(logins.get(0).getPort(), 22);
    }


    //Rspecs for tests (these rspecs make no sense, they are just for testing)
    private static String normalRspec = "<rspec type=\"request\" generated_by=\"Flack\" generated=\"2013-01-11T10:30:10Z\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd \" xmlns:flack=\"http://www.protogeni.net/resources/rspec/ext/flack/1\" xmlns:client=\"http://www.protogeni.net/resources/rspec/ext/client/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.geni.net/resources/rspec/3\">\n" +
            "  <node client_id=\"PC\" component_manager_id=\"urn:publicid:IDN+wall3+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC:if0\">\n" +
            "      <flack:interface_info addressUnset=\"true\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"67\" y=\"116\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC\" component_manager_id=\"urn:publicid:IDN+wall3+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC:if0\">\n" +
            "      <flack:interface_info addressUnset=\"true\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"67\" y=\"116\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC-0\" component_manager_id=\"urn:publicid:IDN+wall4+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC-0:if0\">\n" +
            "      <flack:interface_info addressUnset=\"true\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"375\" y=\"172\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <link client_id=\"lan0\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall5+authority+cm\"/>\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall6+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC:if0\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if0\"/>\n" +
            "    <property source_id=\"PC:if0\" dest_id=\"PC-0:if0\" capacity=\"1000000\"/>\n" +
            "    <property source_id=\"PC-0:if0\" dest_id=\"PC:if0\" capacity=\"1000000\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"lan1\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall7+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC:if0\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if0\"/>\n" +
            "    <property source_id=\"PC:if0\" dest_id=\"PC-0:if0\" capacity=\"1000000\"/>\n" +
            "    <property source_id=\"PC-0:if0\" dest_id=\"PC:if0\" capacity=\"1000000\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"lan1\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall6+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC:if0\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if0\"/>\n" +
            "    <property source_id=\"PC:if0\" dest_id=\"PC-0:if0\" capacity=\"1000000\"/>\n" +
            "    <property source_id=\"PC-0:if0\" dest_id=\"PC:if0\" capacity=\"1000000\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <client:client_info name=\"Flack\" environment=\"Flash Version: LNX 11,2,202,258, OS: Linux 2.6.32-34-generic, Arch: x86, Screen: 1920x1080 @ 72 DPI with touchscreen type none\" version=\"v14.46\" url=\"https://www.emulab.net/protogeni/flack2/flack.swf?mode=public&amp;debug=0&amp;usejs=1\"/>\n" +
            "  </rspec>";
    private static String brechtRspec = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
            "<rspec generated=\"2014-02-01T16:47:22.736+01:00\" generated_by=\"Experimental jFed Rspec Editor\" type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd\" xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:jFed=\"http://jfed.iminds.be/rspec/ext/jfed/1\" xmlns:delay=\"http://www.protogeni.net/resources/rspec/ext/delay/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" >\n" +
            "<node client_id=\"node0\" component_manager_id=\"urn:publicid:IDN+wall2.ilabt.iminds.be+authority+cm\" exclusive=\"true\">\n" +
            "<sliver_type name=\"raw-pc\">\n" +
            "<disk_image name=\"urn:publicid:IDN+wall2.ilabt.iminds.be+image+emulab-ops//DEB60_64-VLAN\"/>\n" +
            "</sliver_type>\n" +
            "<services>\n" +
            "<execute shell=\"sh\" command=\"sudo apt-get install dstat\"/>\n" +
            "<install url=\"http://download.videolan.org/pub/videolan/vlc/0.5.1/vlc-0.5.1.tar.gz\" install_path=\"/local\"/>\n" +
            "</services>\n" +
            "<jFed:location x=\"73.0\" y=\"27.0\"/>\n" +
            "<interface client_id=\"node0:if0\"/>\n" +
            "</node>\n" +
            "<node client_id=\"node1\" component_manager_id=\"urn:publicid:IDN+wall2.ilabt.iminds.be+authority+cm\" exclusive=\"true\">\n" +
            "<sliver_type name=\"raw-pc\"/>\n" +
            "<jFed:location x=\"296.0\" y=\"207.0\"/>\n" +
            "<interface client_id=\"node1:if0\"/>\n" +
            "</node>\n" +
            "<node client_id=\"bridge\" component_manager_id=\"urn:publicid:IDN+wall2.ilabt.iminds.be+authority+cm\" exclusive=\"true\">\n" +
            "<sliver_type name=\"delay\">\n" +
            "<delay:sliver_type_shaping>\n" +
            "<pipe source=\"delay:left\" dest=\"delay:right\" capacity=\"1000\" latency=\"50\" />\n" +
            "<pipe source=\"delay:right\" dest=\"delay:left\" capacity=\"10000\" latency=\"25\" packet_loss=\"0.01\"/>\n" +
            "</delay:sliver_type_shaping>\n" +
            "</sliver_type>\n" +
            "<interface client_id=\"delay:left\" />\n" +
            "<interface client_id=\"delay:right\" />\n" +
            "</node>\n" +
            "<link client_id=\"link1\">\n" +
            "<interface_ref client_id=\"node0:if0\" />\n" +
            "<interface_ref client_id=\"delay:left\" />\n" +
            "<property source_id=\"delay:left\" dest_id=\"node0:if0\"/>\n" +
            "<property source_id=\"node0:if0\" dest_id=\"delay:left\"/>\n" +
            "<link_type name=\"lan\"/>\n" +
            "</link>\n" +
            "<link client_id=\"link2\">\n" +
            "<interface_ref client_id=\"node1:if0\" />\n" +
            "<interface_ref client_id=\"delay:right\" />\n" +
            "<property source_id=\"delay:right\" dest_id=\"node1:if0\"/>\n" +
            "<property source_id=\"node1:if0\" dest_id=\"delay:right\"/>\n" +
            "<link_type name=\"lan\"/>\n" +
            "</link>\n" +
            "</rspec>";
    private static String errorRspec = "<rspec>\n" +
            "  <node component_manager_id=\"urn:publicid:IDN+wall3+authority+cm\" exclusive=\"true\" test=\"test\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC:if0\">\n" +
            "      <flack:interface_info addressUnset=\"true\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC:if0\">\n" +
            "      <flack:interface_info addressUnset=\"true\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "  </node>\n" +
            "  <link client_id=\"lan0\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall5+authority+cm\"/>\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall6+authority+cm\"/>\n" +
            "    <component_manager/>\n" +
            "    <interface_ref client_id=\"PC:if0\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if0\"/>\n" +
            "    <property source_id=\"PC:if0\" dest_id=\"PC-0:if0\" capacity=\"1000000\"/>\n" +
            "    <property source_id=\"PC-0:if0\" dest_id=\"PC:if0\" capacity=\"1000000\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link client_id=\"lan100\">\n" +
            "  </link>\n" +
            "  <link client_id=\"lan0\">\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall7+authority+cm\"/>\n" +
            "    <interface_ref client_id=\"PC:if0\"/>\n" +
            "    <interface_ref client_id=\"PC-0:if0\"/>\n" +
            "    <property source_id=\"PC:if0\" dest_id=\"PC-0:if0\" capacity=\"1000000\"/>\n" +
            "    <property source_id=\"PC-0:if0\" dest_id=\"PC:if0\" capacity=\"1000000\"/>\n" +
            "    <link_type name=\"lan\"/>\n" +
            "    <flack:link_info x=\"-1\" y=\"-1\" unboundVlantag=\"true\"/>\n" +
            "  </link>\n" +
            "  <link>\n" +
            "    <component_manager name=\"urn:publicid:IDN+wall3+authority+cm\" blah=\"blah\"/>\n" +
            "  </link>\n" +
            "  <node client_id=\"PC-0\" component_manager_id=\"urn:publicid:IDN+wall4+authority+cm\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC-0:if0\">\n" +
            "      <flack:interface_info addressUnset=\"true\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"375\" y=\"172\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <node client_id=\"PC-0\" component_manager_id=\"\" exclusive=\"true\">\n" +
            "    <sliver_type name=\"raw-pc\"/>\n" +
            "    <interface client_id=\"PC-0:if0\">\n" +
            "      <flack:interface_info addressUnset=\"true\" bound=\"false\"/>\n" +
            "    </interface>\n" +
            "    <flack:node_info x=\"375\" y=\"172\" unbound=\"true\"/>\n" +
            "  </node>\n" +
            "  <client:client_info name=\"Flack\" environment=\"Flash Version: LNX 11,2,202,258, OS: Linux 2.6.32-34-generic, Arch: x86, Screen: 1920x1080 @ 72 DPI with touchscreen type none\" version=\"v14.46\" url=\"https://www.emulab.net/protogeni/flack2/flack.swf?mode=public&amp;debug=0&amp;usejs=1\"/>\n" +
            "  </rspec>";
    private static String openflowRspecA = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<rspec xmlns=\"http://www.geni.net/resources/rspec/3\"\n" +
            "       xmlns:xs=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
            "       xmlns:openflow=\"http://www.geni.net/resources/rspec/ext/openflow/3\"\n" +
            "       xs:schemaLocation=\"http://www.geni.net/resources/rspec/3\n" +
            "           http://www.geni.net/resources/rspec/3/request.xsd\n" +
            "           http://www.geni.net/resources/rspec/ext/openflow/3\n" +
            "           http://www.geni.net/resources/rspec/ext/openflow/3/of-resv.xsd\"\n" +
            "       type=\"request\">\n" +
            "\n" +
            "  <openflow:sliver description=\" InstaGENI OpenFlow\" email=\"lnevers@bbn.com\">\n" +
            "    <openflow:controller url=\"tcp:mallorea.gpolab.bbn.com:33018\" type=\"primary\" />\n" +
            "\n" +
            "    <openflow:group name=\"bbn-instageni-1750\">\n" +
            "      <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.instageni.gpolab.bbn.com+datapath+06:d6:84:34:97:c6:c9:00\" \n" +
            "\tcomponent_manager_id=\"urn:publicid:IDN+openflow:foam:foam.instageni.gpolab.bbn.com+authority+am\"  />\n" +
            "    </openflow:group>\n" +
            "\n" +
            "    <openflow:match>\n" +
            "\n" +
            "      <openflow:use-group name=\"bbn-instageni-1750\" />\n" +
            "\n" +
            "      <openflow:packet>\n" +
            "        <openflow:dl_type value=\"0x800,0x806\"/>\n" +
            "        <openflow:nw_dst value=\"10.42.18.0/24\"/>\n" +
            "        <openflow:nw_src value=\"10.42.18.0/24\"/>\n" +
            "      </openflow:packet>\n" +
            "\n" +
            "    </openflow:match>\n" +
            "\n" +
            "  </openflow:sliver>\n" +
            "\n" +
            "</rspec>\n" +
            "\n";
    private static String openflowRspecB = "<rspec type=\"advertisement\"\n" +
            "    xmlns=\"http://www.geni.net/resources/rspec/3\"\n" +
            "    xmlns:openflow=\"http://www.geni.net/resources/rspec/ext/openflow/3\"\n" +
            "    xmlns:topology=\"http://geni.bssoftworks.com/rspec/ext/topo/1\"\n" +
            "    xmlns:xs=\"http://www.w3.org/2001/XMLSchema-instance\" xs:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/ad.xsd http://www.geni.net/resources/rspec/ext/openflow/3 http://www.geni.net/resources/rspec/ext/openflow/3/of-ad.xsd http://geni.bssoftworks.com/rspec/ext/topo/1 http://geni.bssoftworks.com/rspec/ext/topo/1\">\n" +
            "    <openflow:datapath\n" +
            "        component_id=\"urn:publicid:IDN+openflow:foam:10.1.0.61+datapath+00:01:00:06:f6:73:e8:80\"\n" +
            "        component_manager_id=\"urn:publicid:IDN+openflow:foam:10.1.0.61+authority+am\" dpid=\"00:01:00:06:f6:73:e8:80\">\n" +
            "        <openflow:port name=\"Eth1/23\" num=\"23\"/>\n" +
            "        <openflow:port name=\"Eth1/25\" num=\"25\"/>\n" +
            "        <openflow:port name=\"Eth1/24\" num=\"24\"/>\n" +
            "        <openflow:port name=\"Eth1/20\" num=\"20\">\n" +
            "            <topology:geni-of desc=\"switch.10.1.0.61[Eth1/20]\"\n" +
            "                remote-component-id=\"urn:publicid:IDN+10.1.0.61+switch+00:01:00:06:f6:73:e8:80\" remote-port-name=\"Eth1/20\"/>\n" +
            "        </openflow:port>\n" +
            "        <openflow:port name=\"Eth1/21\" num=\"21\"/>\n" +
            "        <openflow:port name=\"Eth1/22\" num=\"22\"/>\n" +
            "    </openflow:datapath>\n" +
            "    <openflow:datapath\n" +
            "        component_id=\"urn:publicid:IDN+openflow:foam:10.1.0.61+datapath+00:01:e0:2f:6d:45:ba:00\"\n" +
            "        component_manager_id=\"urn:publicid:IDN+openflow:foam:10.1.0.61+authority+am\" dpid=\"00:01:e0:2f:6d:45:ba:00\">\n" +
            "        <openflow:port name=\"Eth1/23\" num=\"23\"/>\n" +
            "        <openflow:port name=\"Eth1/24\" num=\"24\"/>\n" +
            "        <openflow:port name=\"Eth1/21\" num=\"21\"/>\n" +
            "        <openflow:port name=\"Eth1/25\" num=\"25\"/>\n" +
            "        <openflow:port name=\"Eth1/20\" num=\"20\"/>\n" +
            "        <openflow:port name=\"Eth1/22\" num=\"22\"/>\n" +
            "    </openflow:datapath>\n" +
            "</rspec>\n" +
            "\n";
    private static String openflowRspecC = "<?xml version=\"1.0\" ?>\n" +
            "<!-- Resources at AM:\n" +
            "\tURN: unspecified_AM_URN\n" +
            "\tURL: https://foam.gpolab.bbn.com:3626/foam/gapi/1\n" +
            " -->\n" +
            "\n" +
            "<rspec type=\"advertisement\" xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:openflow=\"http://www.geni.net/resources/rspec/ext/openflow/3\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema-instance\" xs:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/ad.xsd http://www.geni.net/resources/rspec/ext/openflow/3 http://www.geni.net/resources/rspec/ext/openflow/3/of-ad.xsd\">\n" +
            "  <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+datapath+06:a4:00:12:e2:b8:a5:d0\" component_manager_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+authority+am\" dpid=\"06:a4:00:12:e2:b8:a5:d0\">\n" +
            "    <openflow:port name=\"GBE0/20\" num=\"20\"/>\n" +
            "    <openflow:port name=\"GBE0/21\" num=\"21\"/>\n" +
            "    <openflow:port name=\"GBE0/22\" num=\"22\"/>\n" +
            "  </openflow:datapath>\n" +
            "  <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+datapath+06:a4:00:24:a8:c4:b9:00\" component_manager_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+authority+am\" dpid=\"06:a4:00:24:a8:c4:b9:00\">\n" +
            "    <openflow:port name=\"1\" num=\"25\"/>\n" +
            "    <openflow:port name=\"2\" num=\"26\"/>\n" +
            "    <openflow:port name=\"6\" num=\"30\"/>\n" +
            "    <openflow:port name=\"8\" num=\"32\"/>\n" +
            "    <openflow:port name=\"9\" num=\"33\"/>\n" +
            "    <openflow:port name=\"11\" num=\"35\"/>\n" +
            "    <openflow:port name=\"47\" num=\"71\"/>\n" +
            "    <openflow:port name=\"local\" num=\"65534\"/>\n" +
            "    <openflow:port name=\"7\" num=\"31\"/>\n" +
            "    <openflow:port name=\"5\" num=\"29\"/>\n" +
            "  </openflow:datapath>\n" +
            "  <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+datapath+06:c6:00:24:a8:c4:b9:00\" component_manager_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+authority+am\" dpid=\"06:c6:00:24:a8:c4:b9:00\">\n" +
            "    <openflow:port name=\"31\" num=\"55\"/>\n" +
            "    <openflow:port name=\"41\" num=\"65\"/>\n" +
            "    <openflow:port name=\"local\" num=\"65534\"/>\n" +
            "  </openflow:datapath>\n" +
            "  <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+datapath+06:d6:00:12:e2:b8:a5:d0\" component_manager_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+authority+am\" dpid=\"06:d6:00:12:e2:b8:a5:d0\">\n" +
            "    <openflow:port name=\"GBE0/3\" num=\"3\"/>\n" +
            "    <openflow:port name=\"GBE0/5\" num=\"5\"/>\n" +
            "    <openflow:port name=\"GBE0/9\" num=\"9\"/>\n" +
            "    <openflow:port name=\"GBE0/11\" num=\"11\"/>\n" +
            "    <openflow:port name=\"GBE0/18\" num=\"18\"/>\n" +
            "    <openflow:port name=\"GBE0/20\" num=\"20\"/>\n" +
            "    <openflow:port name=\"GBE0/21\" num=\"21\"/>\n" +
            "    <openflow:port name=\"GBE0/22\" num=\"22\"/>\n" +
            "    <openflow:port name=\"GBE0/15\" num=\"15\"/>\n" +
            "  </openflow:datapath>\n" +
            "  <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+datapath+06:d6:00:24:a8:c4:b9:00\" component_manager_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+authority+am\" dpid=\"06:d6:00:24:a8:c4:b9:00\">\n" +
            "    <openflow:port name=\"25\" num=\"49\"/>\n" +
            "    <openflow:port name=\"26\" num=\"50\"/>\n" +
            "    <openflow:port name=\"27\" num=\"51\"/>\n" +
            "    <openflow:port name=\"28\" num=\"52\"/>\n" +
            "    <openflow:port name=\"29\" num=\"53\"/>\n" +
            "    <openflow:port name=\"31\" num=\"55\"/>\n" +
            "    <openflow:port name=\"32\" num=\"56\"/>\n" +
            "    <openflow:port name=\"47\" num=\"71\"/>\n" +
            "    <openflow:port name=\"local\" num=\"65534\"/>\n" +
            "    <openflow:port name=\"8\" num=\"32\"/>\n" +
            "    <openflow:port name=\"4\" num=\"28\"/>\n" +
            "    <openflow:port name=\"9\" num=\"33\"/>\n" +
            "    <openflow:port name=\"1\" num=\"25\"/>\n" +
            "    <openflow:port name=\"11\" num=\"35\"/>\n" +
            "    <openflow:port name=\"2\" num=\"26\"/>\n" +
            "    <openflow:port name=\"12\" num=\"36\"/>\n" +
            "    <openflow:port name=\"6\" num=\"30\"/>\n" +
            "    <openflow:port name=\"10\" num=\"34\"/>\n" +
            "    <openflow:port name=\"3\" num=\"27\"/>\n" +
            "    <openflow:port name=\"7\" num=\"31\"/>\n" +
            "    <openflow:port name=\"5\" num=\"29\"/>\n" +
            "  </openflow:datapath>\n" +
            "  <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+datapath+06:ae:00:24:a8:c4:b9:00\" component_manager_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+authority+am\" dpid=\"06:ae:00:24:a8:c4:b9:00\"/>\n" +
            "  <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+datapath+06:b3:00:24:a8:c4:b9:00\" component_manager_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+authority+am\" dpid=\"06:b3:00:24:a8:c4:b9:00\"/>\n" +
            "  <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+datapath+06:b0:00:24:a8:c4:b9:00\" component_manager_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+authority+am\" dpid=\"06:b0:00:24:a8:c4:b9:00\"/>\n" +
            "  <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+datapath+06:af:00:24:a8:c4:b9:00\" component_manager_id=\"urn:publicid:IDN+openflow:foam:foam.gpolab.bbn.com+authority+am\" dpid=\"06:af:00:24:a8:c4:b9:00\"/>\n" +
            "</rspec>\n" +
            "\n";
    private static String openflowRspecD = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<rspec xmlns=\"http://www.geni.net/resources/rspec/3\"\n" +
            "       xmlns:xs=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
            "       xs:schemaLocation=\"http://www.geni.net/resources/rspec/3\n" +
            "           http://www.geni.net/resources/rspec/3/request.xsd\n" +
            "           http://www.geni.net/resources/rspec/ext/openflow/3\n" +
            "           http://www.geni.net/resources/rspec/ext/openflow/3/of-resv.xsd\"\n" +
            "       type=\"request\">\n" +
            "\n" +
            "  <sliver description=\" InstaGENI OpenFlow\" email=\"lnevers@bbn.com\">\n" +
            "    <openflow:controller url=\"tcp:mallorea.gpolab.bbn.com:33018\" type=\"primary\" />\n" +
            "\n" +
            "    <openflow:group name=\"bbn-instageni-1750\">\n" +
            "      <openflow:datapath component_id=\"urn:publicid:IDN+openflow:foam:foam.instageni.gpolab.bbn.com+datapath+06:d6:84:34:97:c6:c9:00\" \n" +
            "\tcomponent_manager_id=\"urn:publicid:IDN+openflow:foam:foam.instageni.gpolab.bbn.com+authority+am\"  />\n" +
            "    </openflow:group>\n" +
            "\n" +
            "    <openflow:match>\n" +
            "\n" +
            "      <openflow:use-group name=\"bbn-instageni-1750\" />\n" +
            "\n" +
            "      <openflow:packet>\n" +
            "        <openflow:dl_type value=\"0x800,0x806\"/>\n" +
            "        <openflow:nw_dst value=\"10.42.18.0/24\"/>\n" +
            "        <openflow:nw_src value=\"10.42.18.0/24\"/>\n" +
            "      </openflow:packet>\n" +
            "\n" +
            "    </openflow:match>\n" +
            "\n" +
            "  </openflow:sliver>\n" +
            "\n" +
            "</rspec>\n" +
            "\n";
    private static String openflowRspecE = "<?xml version=\"1.1\" encoding=\"UTF-8\"?>\n" +
            "<rspec  xmlns=\"http://www.geni.net/resources/rspec/3\"\n" +
            "        xmlns:xs=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
            "        xmlns:openflow=\"http://www.geni.net/resources/rspec/ext/openflow/3\"\n" +
            "        xs:schemaLocation=\"http://www.geni.net/resources/rspec/3\n" +
            "              http://www.geni.net/resources/rspec/3/request.xsd\n" +
            "              http://www.geni.net/resources/rspec/ext/openflow/3\n" +
            "              http://www.geni.net/resources/rspec/ext/openflow/3/of-resv.xsd\"\n" +
            "    type=\"request\">\n" +
            " \n" +
            "    <openflow:sliver description=\"My awesome experiment that you should opt-in because I'm awesome.\"\n" +
            "                     email=\"john.doe@example.net\"\n" +
            "                     ref=\"http://wiki.example.net/myproject\">\n" +
            " \n" +
            "        <openflow:controller url=\"tcp:10.2.33.65:6633\" type=\"primary\" />\n" +
            "        \n" +
            "        <openflow:group name=\"johngrp\">\n" +
            "            <openflow:datapath\n" +
            "                component_id=\"urn:publicid:IDN+openflow:foam:foam.atlantis.ugent.be+datapath+00:00:86:5e:a1:df:d1:a3\"\n" +
            "                component_manager_id=\"urn:publicid:IDN+openflow:foam:foam.atlantis.ugent.be+authority+am\">\n" +
            "                <openflow:port num=\"1\" name=\"br0\" />\n" +
            "                \n" +
            "             </openflow:datapath>\n" +
            " \n" +
            "             \n" +
            "        </openflow:group>\n" +
            " \n" +
            "        \n" +
            " \n" +
            "        <openflow:match>\n" +
            "            <openflow:datapath\n" +
            "                component_id=\"urn:publicid:IDN+openflow:foam:foam.atlantis.ugent.be+datapath+00:00:86:5e:a1:df:d1:a3\"\n" +
            "                component_manager_id=\"urn:publicid:IDN+openflow:foam:foam.atlantis.ugent.be+authority+am\"\n" +
            "                dpid=\"00:00:86:5e:a1:df:d1:a3\">\n" +
            "              <openflow:port num=\"1\" />\n" +
            "              \n" +
            "            </openflow:datapath>\n" +
            " \n" +
            "            <openflow:packet>\n" +
            "                <openflow:dl_src value=\"22:33:44:55:66:77\" />\n" +
            "                <openflow:dl_dst value=\"00:33:44:55:66:99\" />\n" +
            "                <openflow:dl_type value=\"0x800\" />\n" +
            "                <openflow:dl_vlan value=\"15\" />\n" +
            "                <openflow:nw_src value=\"192.168.3.0/24\" />\n" +
            "                <openflow:nw_dst value=\"192.168.3.0/24\" />\n" +
            "                <openflow:nw_proto value=\"17\" />\n" +
            "                <openflow:tp_src value=\"100\" />\n" +
            "                <openflow:tp_dst value=\"1024-1026\" />\n" +
            "            </openflow:packet>\n" +
            "        </openflow:match>\n" +
            "    </openflow:sliver>\n" +
            "</rspec>";
    private static final String manifestA = "<rspec xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:jFed=\"http://jfed.iminds.be/rspec/ext/jfed/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" generated=\"2014-02-05T13:38:12.981+01:00\" generated_by=\"Experimental jFed Rspec Editor\" type=\"manifest\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/manifest.xsd\">\n" +
            "    <node xmlns:jFed=\"http://jfed.iminds.be/rspec/ext/jfed/1\" client_id=\"node0\" component_manager_id=\"urn:publicid:IDN+wall2.ilabt.iminds.be+authority+cm\" exclusive=\"true\" component_id=\"urn:publicid:IDN+wall2.ilabt.iminds.be+node+n095-08b\" sliver_id=\"urn:publicid:IDN+wall2.ilabt.iminds.be+sliver+2345\">\n" +
            "        <sliver_type name=\"raw-pc\"/>\n" +
            "        <jFed:location x=\"38.0\" y=\"25.0\"/>\n" +
            "        <jFed:nodeDescription>simple-node</jFed:nodeDescription>\n" +
            "    <rs:vnode xmlns:rs=\"http://www.protogeni.net/resources/rspec/ext/emulab/1\" name=\"n095-08b\"/>"+
            "<host name=\"node0.tstManifest1.wall2-ilabt-iminds-be.wall2.ilabt.iminds.be\"/>"+
            "<services><login authentication=\"ssh-keys\" hostname=\"n095-08b.wall2.ilabt.iminds.be\" port=\"22\" username=\"wvdemeer\"/></services></node>\n" +
            "</rspec>";
    private static final String manifestB = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
            "<rspec generated=\"2014-02-01T16:47:22.736+01:00\" generated_by=\"Experimental jFed Rspec Editor\" type=\"request\" xsi:schemaLocation=\"http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd\" xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:jFed=\"http://jfed.iminds.be/rspec/ext/jfed/1\" xmlns:delay=\"http://www.protogeni.net/resources/rspec/ext/delay/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" > \n" +
            "    <node client_id=\"node0\" component_manager_id=\"urn:publicid:IDN+wall2.ilabt.iminds.be+authority+cm\" exclusive=\"true\">\n" +
            "        <sliver_type name=\"raw-pc\">\n" +
            "            <disk_image name=\"urn:publicid:IDN+wall2.ilabt.iminds.be+image+emulab-ops//DEB60_64-VLAN\"/>\n" +
            "        </sliver_type>\n" +
            "        <services>\n" +
            "            <execute shell=\"sh\" command=\"sudo apt-get install dstat\"/>\n" +
            "            <install url=\"http://download.videolan.org/pub/videolan/vlc/0.5.1/vlc-0.5.1.tar.gz\" install_path=\"/local\"/>\n" +
            "            <login authentication=\"ssh-keys\" hostname=\"dummyhost0\" port=\"22\" username=\"dummyuser0\"/>\n"+
            "        </services>\n" +
            "        <jFed:location x=\"73.0\" y=\"27.0\"/>\n" +
            "        <interface client_id=\"node0:if0\"/>\n" +
            "    </node>\n" +
            "    <node client_id=\"node1\" component_manager_id=\"urn:publicid:IDN+wall2.ilabt.iminds.be+authority+cm\" exclusive=\"true\">\n" +
            "        <sliver_type name=\"raw-pc\"/>\n" +
            "        <jFed:location x=\"296.0\" y=\"207.0\"/>\n" +
            "        <interface client_id=\"node1:if0\"/>\n" +
            "        <services><login authentication=\"ssh-keys\" hostname=\"dummyhost1\" port=\"22\" username=\"dummyuser1\"/></services>\n" +
            "    </node>\n" +
            "  <node client_id=\"bridge\" component_manager_id=\"urn:publicid:IDN+wall2.ilabt.iminds.be+authority+cm\" exclusive=\"true\">\n" +
            "   <sliver_type name=\"delay\">\n" +
            "     <delay:sliver_type_shaping>\n" +
            "       <pipe source=\"delay:left\" dest=\"delay:right\" capacity=\"1000\" latency=\"50\" />\n" +
            "       <pipe source=\"delay:right\" dest=\"delay:left\" capacity=\"10000\" latency=\"25\" packet_loss=\"0.01\"/>\n" +
            "     </delay:sliver_type_shaping>\n" +
            "   </sliver_type>\n" +
            "   <interface client_id=\"delay:left\" />\n" +
            "   <interface client_id=\"delay:right\" />\n" +
            "        <services>" +
            "             <login authentication=\"ssh-keys\" hostname=\"dummyhostbridge1\" port=\"22\" username=\"dummyuserbridge1\"/>" +
            "             <login authentication=\"ssh-keys\" hostname=\"dummyhostbridge2\" port=\"22\" username=\"dummyuserbridge2\"/>" +
            "        </services>" +
            " </node>\n" +
            " <link client_id=\"link1\">\n" +
            "    <interface_ref client_id=\"node0:if0\" />\n" +
            "    <interface_ref client_id=\"delay:left\" />\n" +
            "     <property source_id=\"delay:left\" dest_id=\"node0:if0\"/>\n" +
            "\t    <property source_id=\"node0:if0\" dest_id=\"delay:left\"/>\n" +
            "\t    <link_type name=\"lan\"/>\n" +
            " </link>\n" +
            " <link client_id=\"link2\">\n" +
            "   <interface_ref client_id=\"node1:if0\" />\n" +
            "   <interface_ref client_id=\"delay:right\" />\n" +
            "   <property source_id=\"delay:right\" dest_id=\"node1:if0\"/>\n" +
            "\t<property source_id=\"node1:if0\" dest_id=\"delay:right\"/>\n" +
            "\t<link_type name=\"lan\"/>\n" +
            " </link>\n" +
            "</rspec>";
    private static final String manifestPle = "<?xml version=\"1.0\"?>\n" +
            "<RSpec type=\"SFA\" expires=\"2013-07-18T12:37:03Z\" generated=\"2013-07-04T10:45:38Z\">\n" +
            "  <network name=\"ple\">\n" +
            "    <node component_manager_id=\"urn:publicid:IDN+ple+authority+cm\" component_id=\"urn:publicid:IDN+ple:quantavisple+node+marie.iet.unipi.it\" component_name=\"marie.iet.unipi.it\" site_id=\"urn:publicid:IDN+ple:quantavisple+authority+sa\">\n" +
            "      <hostname>marie.iet.unipi.it</hostname>\n" +
            "      <location country=\"unknown\" longitude=\"10.3252\" latitude=\"43.5052\"/>\n" +
            "      <exclusive>FALSE</exclusive>\n" +
            "      <interface component_id=\"urn:publicid:IDN+ple+interface+node14271:eth0\" client_id=\"14271:165\" ipv4=\"131.114.53.188\"/>\n" +
            "      <services>\n" +
            "        <login authentication=\"ssh-keys\" hostname=\"marie.iet.unipi.it\" port=\"22\" username=\"wall3testibbtbe_DebugjFed\"/>\n" +
            "      </services>\n" +
            "      <hrn>ple.quantavisple.marie\\.iet\\.unipi\\.it</hrn>\n" +
            "      <responsew>n/a</responsew>\n" +
            "      <memw>n/a</memw>\n" +
            "      <reliabilityy>0</reliabilityy>\n" +
            "      <responsem>n/a</responsem>\n" +
            "      <sliver name=\"wall3testibbtbe_DebugjFed\"/>\n" +
            "    </node>\n" +
            "    <sliver_defaults>\n" +
            "      <vsys>vif_up</vsys>\n" +
            "      <vsys>vif_down</vsys>\n" +
            "      <vsys>fd_tuntap</vsys>\n" +
            "      <vsys>promisc</vsys>\n" +
            "      <vsys>vroute</vsys>\n" +
            "    </sliver_defaults>\n" +
            "  </network>\n" +
            "</RSpec>\n";
}
