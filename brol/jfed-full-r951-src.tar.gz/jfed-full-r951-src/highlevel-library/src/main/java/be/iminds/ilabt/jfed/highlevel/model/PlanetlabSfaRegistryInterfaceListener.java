package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.history.UserInfo;
import be.iminds.ilabt.jfed.log.ApiCallDetails;
import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.Gid;
import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.api.PlanetlabSfaRegistryInterface;
import be.iminds.ilabt.jfed.lowlevel.api.ProtogeniSliceAuthority;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.resourceid.ResourceId;
import be.iminds.ilabt.jfed.util.RFC3339Util;
import javafx.application.Platform;
import org.apache.logging.log4j.LogManager;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

/**
 * EasyModelSliceAuthorityListener: this watches for SliceAuthority calls and fills in EasyModel using the info in them
 */
public class PlanetlabSfaRegistryInterfaceListener extends EasyModelAbstractListener {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    public PlanetlabSfaRegistryInterfaceListener(EasyModel model) {
        super(model);
    }


    private void onGetCredentialResult(ApiCallDetails result) {
        logger.trace("PlanetlabSfaRegistryInterfaceListener.onGetCredentialResult called.");
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            //store credential
            AnyCredential anyCredential = (AnyCredential)result.getReply().getValue();
            String type = result.getMethodParameters().containsKey("type") ? null : (String) result.getMethodParameters().get("type");
            boolean knownType = false;
            if (type != null && (type.equals("user") || type.equals("authority"))) {
                model.getParameterHistoryModel().addUserCredential(new CredentialInfo(anyCredential));
                knownType = true;
            }
            if (type != null && (type.equals("slice"))) {
                model.getParameterHistoryModel().addSliceCredential(new CredentialInfo(anyCredential));
                knownType = true;
            }
            if (!knownType) {
                logger.warn("Unknown credential type passed to PlanetlabSfaRegistryInterfaceListener.onGetCredentialResult: \""+type+"\". Adding as both slice and user credential.");
                model.getParameterHistoryModel().addUserCredential(new CredentialInfo(anyCredential));
                model.getParameterHistoryModel().addSliceCredential(new CredentialInfo(anyCredential));
            }
        }
    }

    private void onGetSelfCredentialResult(ApiCallDetails result) {
        logger.trace("PlanetlabSfaRegistryInterfaceListener.onGetSelfCredentialResult called.");
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            //store user credential
            AnyCredential userCredential = (AnyCredential)result.getReply().getValue();
            logger.trace("PlanetlabSfaRegistryInterfaceListener.onGetSelfCredentialResult sets user credential.");
            model.setUserCredential(userCredential);
        }
    }

    @Override
    public void onResult(final ApiCallDetails details) {
        assert Platform.isFxApplicationThread();
        onResultInJavaFXThread(details);
    }
    public void onResultInJavaFXThread(ApiCallDetails result) {
        logger.trace("PlanetlabSfaRegistryInterfaceListener.onResultInJavaFXThread called. api="+result.getApiName());
        //ignore errors here
        if (result.getReply() == null || result.getJavaMethodName() == null)
            return;

        if (!result.getApiName().equals(PlanetlabSfaRegistryInterface.getApiName()))
            return;

        try {
//            if (result.getJavaMethodName().equals("getVersion"))
//                onGetVersionResult(result);
            logger.trace("PlanetlabSfaRegistryInterfaceListener.onResultInJavaFXThread called for "+result.getJavaMethodName());

            if (result.getJavaMethodName().equals("getCredential")) //GetCredential call
                onGetCredentialResult(result);

            if (result.getJavaMethodName().equals("getSelfCredential")) //GetSelfCredential call
                onGetSelfCredentialResult(result);

            if (result.getJavaMethodName().equals("getSelfCredential_AutomaticArguments")) //GetSelfCredential call
                onGetSelfCredentialResult(result);

//            if (result.getJavaMethodName().equals("getCredential")) //GetCredential
//                onGetCredentialResult(result);

//            if (result.getJavaMethodName().equals("resolve"))
//                onResolveResult(result);

//            if (result.getJavaMethodName().equals("list"))
//                onListResult(result);
        } catch (Exception e) {
            logger.warn("WARNING: Exception when processing PlanetlabSfaRegistryInterface reply for EasyModel. " +
                    "This will be ignored, but it is most likely a bug. message: " + e.getMessage(), e);
        }
    }
}
