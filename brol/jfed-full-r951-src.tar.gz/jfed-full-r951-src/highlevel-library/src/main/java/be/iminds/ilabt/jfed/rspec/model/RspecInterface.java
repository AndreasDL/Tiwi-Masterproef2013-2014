package be.iminds.ilabt.jfed.rspec.model;

import be.iminds.ilabt.jfed.rspec.request.geni_rspec_3.InterfaceContents;
import be.iminds.ilabt.jfed.rspec.request.geni_rspec_3.InterfaceRefContents;
import be.iminds.ilabt.jfed.rspec.request.geni_rspec_3.IpContents;
import be.iminds.ilabt.jfed.rspec.request.geni_rspec_3.LinkContents;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.util.ArrayList;
import java.util.List;

public class RspecInterface {
    public RspecInterface(RspecNode node, RspecLink link, String id) {
        assert link != null;
        assert node != null;

        this.node = node;
        this.link = link;
        this.id.setValue(id);

        //check if not already added
        for (RspecInterface existingIface : node.getInterfaces())
            if (existingIface == this || this.getId().equals(existingIface.getId()))
                throw new RuntimeException("Duplicate interfaces in XML Rspec: id=\""+existingIface.getId()+"\"");
        for (RspecInterface existingIface : link.getInterfaces())
            if (existingIface == this || this.getId().equals(existingIface.getId()))
                throw new RuntimeException("Duplicate interfaces in XML Rspec: id=\""+existingIface.getId()+"\"");

        node.getInterfaces().add(this);
        link.getInterfaces().add(this);
    }
//    /** Special copy method*/
//    public static RspecInterface createCopy(RspecInterface o, Rspec rspec, RspecLink rspecLink) {
//        RspecNode node = rspec.getNodeById(o.getNode().getId());
//        assert node != null;
//        RspecInterface res = new RspecInterface(node, rspecLink, o.getId());
//        res.macAddress.set(o.macAddress.get());
//        return res;
//    }

    private final List<Object> others = new ArrayList<>();
    private final List<Object> othersForRef = new ArrayList<>();
    private final StringProperty id = new SimpleStringProperty();

    public String getId() {
        return id.get();
    }

    public void setId(String value) {
        id.set(value);
    }

    public StringProperty idProperty() {
        return id;
    }


    private final StringProperty macAddress = new SimpleStringProperty();

    public String getMacAddress() {
        return macAddress.get();
    }

    public void setMacAddress(String value) {
        macAddress.set(value);
    }

    public StringProperty macAddressProperty() {
        return macAddress;
    }

    private final StringProperty ipAddress = new SimpleStringProperty();

    public String getIpAddress() {
        return ipAddress.get();
    }

    public void setIpAddress(String value) {
        ipAddress.set(value);
    }

    public StringProperty ipAddressProperty() {
        return ipAddress;
    }


    private final StringProperty netmask = new SimpleStringProperty();
    public String getNetmask() {
        return netmask.get();
    }

    public void setNetmask(String value) {
        netmask.set(value);
    }

    public StringProperty netmaskProperty() {
        return netmask;
    }



    private RspecNode node;
    public RspecNode getNode() {
        return node;
    }

    private RspecLink link;
    public RspecLink getLink() {
        return link;
    }

    public void delete() {
//        System.out.println("RSpecInterface(\""+getId()+"\").delete() node="+node+" link="+link+" link interfaces:");
//        if (link != null) {
//            for (RspecInterface iface : link.getInterfaces()) {
//                System.out.println("  iface="+iface.getId());
//            }
//        }

        assert link != null;
        assert node != null;
        if (node != null) {
            Object removed = node.getInterfaces().remove(this);
            assert removed != null;
        }
        if (link != null) {
            Object removed = link.getInterfaces().remove(this);
            assert removed != null;
        }
        node = null;
        link = null;
    }

    /** delete, even if in incorrect state. */
    void deleteAlways() {
        if (node != null) {
            Object removed = node.getInterfaces().remove(this);
            assert removed != null;
        }
        if (link != null) {
            Object removed = link.getInterfaces().remove(this);
            assert removed != null;
        }
        node = null;
        link = null;
    }

    @Override
    public String toString() {
        return "RspecInterface{id=" + id.get() + '}';
    }

    public void setPropertiesFromGeni3RequestRspec(InterfaceRefContents interfaceContents) {
        othersForRef.addAll(interfaceContents.getAny());
    }

    public void setPropertiesFromGeni3RequestRspec(InterfaceContents interfaceContents) {
        others.addAll(interfaceContents.getAnyOrIp());
    }

    public void setPropertiesFromGeni3AdvertisementRspec(be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.InterfaceRefContents interfaceContents) {
        othersForRef.addAll(interfaceContents.getAny());
    }

    public void setPropertiesFromGeni3AdvertisementRspec(be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.InterfaceContents interfaceContents) {
        others.addAll(interfaceContents.getAnyOrIpOrMonitoring());
    }

    public void setPropertiesFromGeni3ManifestRspec(be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.InterfaceRefContents interfaceContents) {
        othersForRef.addAll(interfaceContents.getAny());
    }

    public void setPropertiesFromGeni3ManifestRspec(be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.InterfaceContents interfaceContents) {
        others.addAll(interfaceContents.getAnyOrIpOrHost());
    }

    public void writePropertiesToGeni3RequestRspec(InterfaceContents interfaceContents) {
        interfaceContents.setClientId(getId());
        //add IP address info if any
        if (getIpAddress() != null || getNetmask() != null) {
            IpContents ip = new IpContents();
            if (getIpAddress() != null)
                ip.setAddress(getIpAddress());
            if (getNetmask() != null)
                ip.setNetmask(getNetmask());
            interfaceContents.getAnyOrIp().add(ip);
        }
        interfaceContents.getAnyOrIp().addAll(others);
    }

    public void writePropertiesToGeni3RequestRspec(InterfaceRefContents interfaceContents) {
        interfaceContents.setClientId(getId());
        interfaceContents.getAny().addAll(othersForRef);
    }
}
