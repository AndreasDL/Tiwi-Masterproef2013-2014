package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.log.ApiCallDetails;
import be.iminds.ilabt.jfed.log.ResultListener;
import be.iminds.ilabt.jfed.lowlevel.GeniAMResponseCode;
import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.GeniResponseCode;
import be.iminds.ilabt.jfed.lowlevel.SfaCredential;
import be.iminds.ilabt.jfed.lowlevel.resourceid.ResourceId;
import be.iminds.ilabt.jfed.lowlevel.resourceid.ResourceUrn;

import java.util.Date;
import java.util.List;

/**
 * EasyModelAbstractListener
 */
public abstract class EasyModelAbstractListener implements ResultListener {
    protected EasyModel model;

    public EasyModelAbstractListener(EasyModel model) {
        this.model = model;
    }

    /**
     * helper: GENIRESPONSE_SEARCHFAILED means not exist, success means exist. anything else is ignored.
     * */
    private void deriveSliceExistence(ResourceId sliceId, GeniResponseCode geniResponseCode) {
        if (sliceId == null)
            return;

        if (geniResponseCode.equals(GeniAMResponseCode.GENIRESPONSE_SEARCHFAILED))
            if (sliceId.getType().equals("urn"))
                model.logNotExistSlice(sliceId.getValue());

        if (geniResponseCode.isSuccess())
            if (sliceId.getType().equals("urn"))
                model.logExistSlice(sliceId.getValue());
    }

    /**
     * helper that derives that a user credential is valid for the user: if it is used as argument and the call is
     * successful it is valid */
    protected void noteUserCredentialInParameters(ApiCallDetails result) {
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            AnyCredential userCredential = null;
            if (result.getMethodParameters().containsKey("userCredential"))
                userCredential = (AnyCredential) result.getMethodParameters().get("userCredential");
            if (result.getMethodParameters().containsKey("credentialList")) {
                @SuppressWarnings("unchecked")
                List<AnyCredential> userCredentials = (List<AnyCredential>) result.getMethodParameters().get("credentialList");
                if (userCredentials != null && userCredentials.size() > 0)
                    userCredential = userCredentials.get(0);
            }
            model.setUserCredential(userCredential);
        }
    }

    /** helper that derives that a slice credential is valid for the user: if it is used as argument and the call is
     * successful it is valid */
    protected ResourceId noteSliceCredentialInParameters(ApiCallDetails result) {
        AnyCredential sliceCredential = (AnyCredential) result.getMethodParameters().get("sliceCredential");
        if (sliceCredential instanceof SfaCredential) {
            String sliceUrn = ((SfaCredential)sliceCredential).getTargetUrn();
            ResourceUrn sliceId = new ResourceUrn(sliceUrn);
            deriveSliceExistence(sliceId, result.getReply().getGeniResponseCode());

            if (result.getReply().getGeniResponseCode().isSuccess()) {
                Slice slice = model.getSlice(sliceUrn);
                assert slice != null;
                if (slice.getCredential() == null) {
                    slice.setCredential(sliceCredential);

                    noteSliceExpirationInSliceCredential(slice, sliceCredential);
                    //                model.fireSliceChanged(slice);
                }
            }

            return sliceId;
        }

        return null;
    }

    protected void noteSliceExpirationInSliceCredential(Slice slice, AnyCredential sliceCredential) {
        //increase slice expiration time if slice expires later than before
        if (sliceCredential instanceof SfaCredential) {
            SfaCredential sfaSliceCredential = (SfaCredential) sliceCredential;
            Date expiresDate = sfaSliceCredential.getExpiresDate();
            if (expiresDate != null &&
                    (slice.getExpirationDate() == null || expiresDate.after(slice.getExpirationDate())))
                slice.setExpirationDate(expiresDate);
        }
    }

    /** helper  */
    protected ResourceId noteSliceUrnInParameters(ApiCallDetails result) {
        ResourceId id = null;
        if (result.getMethodParameters().containsKey("slice"))
            id = (ResourceId) result.getMethodParameters().get("slice");
        if (result.getMethodParameters().containsKey("sliceUrn"))
            id = (ResourceId) result.getMethodParameters().get("sliceUrn");
        deriveSliceExistence(id, result.getReply().getGeniResponseCode());
        return id;
    }
}
