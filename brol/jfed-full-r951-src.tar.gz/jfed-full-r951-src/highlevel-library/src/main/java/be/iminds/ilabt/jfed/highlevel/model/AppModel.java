package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.highlevel.controller.HighLevelController;
import be.iminds.ilabt.jfed.lowlevel.GeniUserProvider;
import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnectionPool;
import be.iminds.ilabt.jfed.lowlevel.userloginmodel.UserLoginModelManager;
import be.iminds.ilabt.jfed.util.JavaFXLogger;

/**
 * AppModel
 */
public interface AppModel {
    public JavaFXLogger getLogger();

    public AuthorityListModel getAuthorityListModel();
    public AuthorityList getAuthorityList();

    public GeniUserProvider getGeniUserProvider();

    public EasyModel getEasyModel();

    public GeniConnectionProvider getConnectionProvider();
}
