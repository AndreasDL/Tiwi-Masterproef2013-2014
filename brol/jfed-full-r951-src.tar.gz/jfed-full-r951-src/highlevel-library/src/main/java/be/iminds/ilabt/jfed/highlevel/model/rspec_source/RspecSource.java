package be.iminds.ilabt.jfed.highlevel.model.rspec_source;

import be.iminds.ilabt.jfed.rspec.model.InvalidRspecException;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.StringRspec;
import org.apache.logging.log4j.LogManager;

import java.util.List;

/**
 * RspecSource
 * <p/>
 * Note: this is an immutable class
 */
public abstract class RspecSource {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    protected StringRspec stringRspec;
    protected ModelRspec modelRspec;
    protected boolean isXmlBased;

    protected RspecSource(StringRspec stringRspec) {
        assert stringRspec != null;
        this.stringRspec = stringRspec;
        this.modelRspec = null;
        isXmlBased = true;
    }

    protected RspecSource(ModelRspec modelRspec) {
        assert modelRspec != null;
        this.modelRspec = modelRspec; //TODO make a copy of modelRspec
        this.stringRspec = null;
        isXmlBased = false;
    }

    /**
     * Determines automatically to use raw XML, or ModelRspec
     */
    public RspecSource(String xmlRspecString) {
        this.stringRspec = new StringRspec(xmlRspecString);
        try {
            this.modelRspec = stringToModel(stringRspec);
            //TODO check if dataloss when converting back to stringRspec. If so, prefer stringRspec instead!
            isXmlBased = false;
        } catch (Throwable t) {
            LOG.warn("RSpec String parse failed. Will not return ModelRspec", t);
            this.modelRspec = null;
            parseFailed = true;
            isXmlBased = true;
        }
    }

    public boolean isXmlBased() {
        return isXmlBased;
    }

    public String getRspecXmlString() {
        return getRspecXmlString(ModelRspec.RequestRspecSpecialCases.NONE);
    }

    public String getRspecXmlString(ModelRspec.RequestRspecSpecialCases rspecSpecialCase) {
        return getStringRspec(rspecSpecialCase).getXmlString();
    }

    protected boolean parseFailed = false;

    protected abstract ModelRspec stringToModel(StringRspec s) throws InvalidRspecException;

    public ModelRspec getModelRspec() {
        if (modelRspec != null) return modelRspec;
        if (parseFailed) return null;
        assert stringRspec != null;
        try {
            modelRspec = stringToModel(stringRspec);
            return modelRspec;
        } catch (Throwable t) {
            LOG.warn("RSpec String parse failed. Will not return ModelRspec", t);
            modelRspec = null;
            parseFailed = true;
            return null;
        }
    }

    public StringRspec getStringRspec() {
        return getStringRspec(ModelRspec.RequestRspecSpecialCases.NONE);
    }


    protected abstract String modelToString(ModelRspec s, ModelRspec.RequestRspecSpecialCases rspecSpecialCase);
    public StringRspec getStringRspec(ModelRspec.RequestRspecSpecialCases rspecSpecialCase) {
        if (stringRspec != null) return stringRspec;
        assert modelRspec != null;

        //TODO: choose manifest or request Rspec
        String rspecXml = modelToString(modelRspec, rspecSpecialCase);
        stringRspec = new StringRspec(rspecXml);
        return stringRspec;
    }


    public List<String> getAllComponentManagerUrns() {
        ModelRspec model = getModelRspec();
        if (model != null) {
            List<String> res = model.getAllComponentManagerUrns();

            assert getStringRspec().isWellFormed();

            //parse generated rspec for openflow component URNs.
            //   Note: This could be done more efficiently, by parsing "others", but it's not worth the trouble

            res.addAll(StringRspec.parseOpenflowComponentManagers(getStringRspec().getXmlString()));

            return res;
        } else {
            if (getStringRspec().isWellFormed())
                return getStringRspec().getAllComponentManagerUrns();
            else
                return null;
        }
    }
}
