package be.iminds.ilabt.jfed.highlevel.model.rspec_source;

import be.iminds.ilabt.jfed.rspec.model.InvalidRspecException;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.StringRspec;
import org.apache.logging.log4j.LogManager;

/**
 * AdvertisementRspecSource
 */
public class AdvertisementRspecSource extends RspecSource {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    public AdvertisementRspecSource(StringRspec stringRspec) {
        super(stringRspec);
    }

    //cannot convert from model to string! So we don't want this constructor.
//    public AdvertisementRspecSource(ModelRspec modelRspec) {
//        super(modelRspec);
//    }

    /** Determines automatically to use raw XML, or ModelRspec */
    public AdvertisementRspecSource(String xmlRspecString) {
        super(xmlRspecString);
    }

    @Override
    protected ModelRspec stringToModel(StringRspec s) throws InvalidRspecException {
        return ModelRspec.fromGeni3AdvertisementRspecXML(s.getXmlString());
    }

    @Override
    protected String modelToString(ModelRspec s, ModelRspec.RequestRspecSpecialCases rspecSpecialCase) {
        throw new RuntimeException("Cannot convert from afvertisement model to manifest XML");
    }
}
