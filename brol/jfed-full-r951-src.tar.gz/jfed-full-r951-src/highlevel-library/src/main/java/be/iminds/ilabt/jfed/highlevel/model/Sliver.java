package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import org.apache.logging.log4j.LogManager;

import java.util.Date;

/**
 * Sliver
 */
public class Sliver {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    private Slice slice;
    private SfaAuthority authority;
    private ObjectProperty<RSpecInfo> requestRspec = new SimpleObjectProperty<RSpecInfo>();
    private ObjectProperty<RSpecInfo> manifestRspec = new SimpleObjectProperty<RSpecInfo>();

    //    private AggregateManager2.SliverStatus status;
    private final StringProperty statusString = new SimpleStringProperty("<no status known>");
    private final ObjectProperty<SliverStatus> status = new SimpleObjectProperty<SliverStatus>();
    private String urn;

    private String allocationStatus;
    private String operationalStatus;
    private Date expires;

    public Sliver(String urn, Slice slice, RSpecInfo requestRspec, RSpecInfo manifestRspec, SfaAuthority authority) {
        this.slice = slice;
        this.urn = urn;
        this.requestRspec.set(requestRspec);
        this.manifestRspec.set(manifestRspec);
        this.authority = authority;
//        status = null;
        status.set(SliverStatus.UNINITIALISED);
    }

    public Slice getSlice() {
        return slice;
    }

    public RSpecInfo getManifestRspec() {
        return manifestRspec.get();
    }

    public RSpecInfo getRequestRspec() {
        return requestRspec.get();
    }

    public void setManifestRspec(RSpecInfo manifestRspec) {
        LOG.debug("highlevel.model.Sliver#setManifestRspec(" + manifestRspec + ")");
//        System.out.println("sliver "+this+" setManifestRspec called");
        this.manifestRspec.set(manifestRspec);
    }

    public void setRequestRspec(RSpecInfo requestRspec) {
        this.requestRspec.set(requestRspec);
    }

    public ObjectProperty<RSpecInfo> manifestRspecProperty() {
        return manifestRspec;
    }

    public SfaAuthority getAuthority() {
        return authority;
    }

//    public AggregateManager2.SliverStatus getStatus() {
//        return status;
//    }
//
//    public void setStatus(AggregateManager2.SliverStatus status) {
//        this.status = status;
//    }


    public String getStatusString() {
        return statusString.get();
    }

    public void setStatusString(String statusString) {
        this.statusString.set(statusString);
    }

    public StringProperty statusStringProperty() {
        return statusString;
    }


    public SliverStatus getStatus() {
        return status.get();
    }

    public void setStatus(SliverStatus status) {
        this.status.set(status);
    }

    public ObjectProperty<SliverStatus> statusProperty() {
        return status;
    }


    public String getUrn() {
        return urn;
    }

    public void setUrn(String urn) {
        slice.getEasyModel().getParameterHistoryModel().addSliverUrn(urn);
        this.urn = urn;
    }

    //better to set them both at once, since they typically are known both at once
//    public void setAllocationStatus(String allocationStatus) {
//        this.allocationStatus = allocationStatus;
//
//        updateStatusFromAm3();
//    }
//
//    public void setOperationalStatus(String operationalStatus) {
//        this.operationalStatus = operationalStatus;
//
//        updateStatusFromAm3();
//    }

    public void setAllocationAndOperationalStatus(String allocationStatus, String operationalStatus) {
        this.allocationStatus = allocationStatus;
        this.operationalStatus = operationalStatus;

        updateStatusFromAm3();
    }

    private void updateStatusFromAm3() {
        if (allocationStatus != null && allocationStatus.equalsIgnoreCase("geni_unallocated")) {
            statusString.set(allocationStatus);
            status.set(SliverStatus.UNALLOCATED);
            return;
        }
        if (allocationStatus != null && allocationStatus.equalsIgnoreCase("geni_allocated")) {
            statusString.set(allocationStatus);
            status.set(SliverStatus.CHANGING);
            return;
        }
//        if (allocationStatus.equalsIgnoreCase("geni_provisioned")) check operationalstatus instead

        if (operationalStatus != null && operationalStatus.equalsIgnoreCase("geni_pending_allocation")) {
            statusString.set(operationalStatus);
            status.set(SliverStatus.CHANGING);
            return;
        }
        if (operationalStatus != null && operationalStatus.equalsIgnoreCase("geni_notready")) {
            statusString.set(operationalStatus);
            status.set(SliverStatus.UNINITIALISED);
            return;
        }
        if (operationalStatus != null && operationalStatus.equalsIgnoreCase("geni_configuring")) {
            statusString.set(operationalStatus);
            status.set(SliverStatus.CHANGING);
            return;
        }
        if (operationalStatus != null && operationalStatus.equalsIgnoreCase("geni_stopping")) {
            statusString.set(operationalStatus);
            status.set(SliverStatus.CHANGING);
            return;
        }
        if (operationalStatus != null && operationalStatus.equalsIgnoreCase("geni_ready")) {
            statusString.set(operationalStatus);
            status.set(SliverStatus.READY);
            return;
        }
        if (operationalStatus != null && operationalStatus.equalsIgnoreCase("geni_ready_busy")) {
            statusString.set(operationalStatus);
            status.set(SliverStatus.CHANGING);
            return;
        }
        if (operationalStatus != null && operationalStatus.equalsIgnoreCase("geni_failed")) {
            statusString.set(operationalStatus);
            status.set(SliverStatus.FAIL);
            return;
        }

        LOG.warn("Unknown operationalStatus \"" + operationalStatus + "\" or allocationStatus \"" + allocationStatus + "\"");
        statusString.set(operationalStatus);
        status.set(SliverStatus.UNKNOWN);
    }

    public void setExpires(Date expires) {
        this.expires = expires;
    }

    @Override
    public String toString() {
        return "Sliver{" +
                "slice=" + slice +
                ", urn='" + urn + '\'' +
                ", expires=" + expires +
                '}';
    }
}
