package be.iminds.ilabt.jfed.rspec.model;

import be.iminds.ilabt.jfed.highlevel.model.rspec_source.ManifestRspecSource;
import be.iminds.ilabt.jfed.util.GeniUrn;
import org.apache.logging.log4j.LogManager;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * StringRspec
 */
public class StringRspec {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    private final String xmlString;
    private boolean wellFormed;

    public StringRspec(String xmlString) {
        this.xmlString = xmlString;
        try {
            wellFormed = true;
            parse();
        } catch (Exception e) {
            LOG.warn("XML is not well-formed and cannot be parsed: "+e.getMessage(), e);
            wellFormed = false;
        }
    }

    public String getXmlString() {
        return xmlString;
    }
    public boolean isWellFormed() { return wellFormed; }

    private static class MyXmlErrorHandler implements ErrorHandler {
        public void error(SAXParseException e) {
            LOG.warn("XML parse error: "+message(e), e);
        }
        public void fatalError(SAXParseException e) {
            LOG.warn("XML parse fatal error: " + message(e), e);
        }
        public void warning(SAXParseException e) {
            LOG.warn("XML parse warning: " + message(e), e);
        }
        private String message(SAXParseException e) {
            int line = e.getLineNumber();
            int col = e.getColumnNumber();
            String publicId = e.getPublicId();
            String systemId = e.getSystemId();
            return e.getMessage() + ": line=" + line + ", col=" + col + ", PUBLIC="
                    + publicId + ", SYSTEM=" + systemId;
        }
    }

    private static Document getDocumentIgnoringAsMuchAsPossible(String xmlString, boolean namespaceAware) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        dbFactory.setValidating(false);
        dbFactory.setNamespaceAware(namespaceAware);
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        dBuilder.setErrorHandler(new MyXmlErrorHandler()); //tries to ignore fatal errors. No guarantee that exceptions won't be thrown
        dBuilder.setEntityResolver(new EntityResolver() {
            @Override
                public InputSource resolveEntity(String publicId, String systemId) {
                        //instead of resolving anything, just return an empty document.
                        return new InputSource(new StringReader("")); // Returns a valid dummy source
                }
            });
        return dBuilder.parse(new InputSource(new StringReader(xmlString)));
    }


    protected List<String> allComponentManagers;
    /** Very fault tolerant parsing. */
    protected void parse() {
        Set<String> allComponentManagersSet = new HashSet<>();

        Document doc = null;
        try {
            //first parse rspec
            doc = getDocumentIgnoringAsMuchAsPossible(xmlString, false);
        } catch (Throwable e) {
            LOG.fatal("Error parsing rspec. Will be ignored: "+e.getMessage(), e);
            wellFormed = false;
            return;
        }
        if (doc != null)
        try {
            doc.getDocumentElement().normalize();

            NodeList rspecListNoNS = doc.getElementsByTagName("rspec");
            assert rspecListNoNS.getLength() == 1 : "not a single rspec element, but "+rspecListNoNS.getLength()+" in "+xmlString;
            Node rspecNode = rspecListNoNS.item(0);
            assert rspecNode != null;
            assert rspecNode.getNodeType() == Node.ELEMENT_NODE;
            Element rspecElement = (Element) rspecNode;

            NodeList nodeList = rspecElement.getElementsByTagName("node");
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                try {
                    assert node != null;
                    assert node.getNodeType() == Node.ELEMENT_NODE;
                    Element nodeEl = (Element) node;

                    String att = nodeEl.getAttribute("component_manager_id");
                    if (att != null && !att.trim().isEmpty())
                        allComponentManagersSet.add(att);
                } catch (Throwable e) {
                    LOG.fatal("Error parsing rspec node. Will be ignored: "+e.getMessage(), e);
                }
            }

            NodeList linkList = rspecElement.getElementsByTagName("link");
            for (int i = 0; i < linkList.getLength(); i++) {
                Node link = linkList.item(i);
                try {
                    assert link != null;
                    assert link.getNodeType() == Node.ELEMENT_NODE;
                    Element linkEl = (Element) link;

                    NodeList compManList = linkEl.getElementsByTagName("component_manager");
                    for (int j = 0; j < compManList.getLength(); j++) {
                        Node compMan = compManList.item(j);
                        try {
                            assert compMan != null;
                            assert compMan.getNodeType() == Node.ELEMENT_NODE;
                            Element compManEl = (Element) compMan;
                            String att = compManEl.getAttribute("name");
                            if (att != null && !att.trim().isEmpty())
                                allComponentManagersSet.add(att);
                        } catch (Throwable e) {
                            LOG.fatal("Error parsing rspec link component_manager. Will be ignored: "+e.getMessage(), e);
                        }
                    }
                } catch (Throwable e) {
                    LOG.fatal("Error parsing rspec link. Will be ignored: "+e.getMessage(), e);
                }
            }

        } catch (Throwable e) {
            LOG.fatal("Error parsing rspec. Will be ignored: "+e.getMessage(), e);
        }

        allComponentManagersSet.addAll(parseOpenflowComponentManagers(xmlString));

        allComponentManagers = new ArrayList<>(allComponentManagersSet);
    }


    private static void extractComponentIdAttributesFromNodeList(NodeList nl, Set<String> allComponentManagersSet) {
        try {
            for (int i = 0; i < nl.getLength(); i++) {
                Node openflowNode = nl.item(i);
                if (openflowNode.getNodeType() == Node.ELEMENT_NODE) {
                    try {
                        Element openflowEl = (Element) openflowNode;
                        String att = openflowEl.getAttribute("component_manager_id");
                        if (att != null && !att.trim().isEmpty())
                            allComponentManagersSet.add(att);
                    } catch (Throwable e) {
                        LOG.fatal("Error parsing. Will be ignored: "+e.getMessage(), e);
                    }
                }
            }
        } catch (Throwable e) {
            LOG.fatal("Error parsing. Will be ignored: "+e.getMessage(), e);
        }
    }
    /**
     * Very fault tolerant parsing.
     *
     * Parses ONLY openflow component managers
     * */
    public static  List<String> parseOpenflowComponentManagers(String xmlString) {
        System.out.println("parseOpenflowComponentManagers starts");
        Set<String> allComponentManagersSet = new HashSet<>();

        try {
            Document doc = getDocumentIgnoringAsMuchAsPossible(xmlString, true);

            doc.getDocumentElement().normalize();

            //namespace: "http://www.geni.net/resources/rspec/ext/openflow/3"

            //found 2 componentManagerUrns:
            // <rspec><openflow:sliver><openflow:group><openflow:datapath component_manager_id="urn:publicid:IDN+openflow:foam:foam.instageni.gpolab.bbn.com+authority+am"...
            // <rspec><openflow:datapath component_manager_id="

            //but we'll keep it simple:: look for any openflow node, and find component_manager_id in it.
            //                           then look for any datapath node, and find component_manager_id in it.

            try {
                NodeList allOpenflowNodes = doc.getDocumentElement().getElementsByTagNameNS("http://www.geni.net/resources/rspec/ext/openflow/3", "*");
                System.out.println("allOpenflowNodes.getLength()="+allOpenflowNodes.getLength());
                extractComponentIdAttributesFromNodeList(allOpenflowNodes, allComponentManagersSet);
            } catch (Throwable e) {
                LOG.fatal("Error parsing openflow nodes. Will be ignored: "+e.getMessage(), e);
            }

        } catch (Throwable e) {
            LOG.fatal("Error parsing RSpex XML. Will be ignored: "+e.getMessage(), e);
        }

        //try without namespaces. But this is pretty pointless
//        try{
//             Document doc = getDocumentIgnoringAsMuchAsPossible(xmlString);
//
//            doc.getDocumentElement().normalize();
//            try {
//                NodeList allDataPaths0 = doc.getDocumentElement().getElementsByTagNameNS("*", "openflow:datapath");
//                System.out.println("allDataPaths0.getLength()="+allDataPaths0.getLength());
//                extractComponentIdAttributesFromNodeList(allDataPaths0, allComponentManagersSet);
//            } catch (Throwable e) {
//                LOG.fatal("Error parsing datapath nodes. Will be ignored: "+e.getMessage(), e);
//            }
//            try {
//                NodeList allDataPaths1 = doc.getDocumentElement().getElementsByTagName("openflow:datapath");
//                System.out.println("allDataPaths1.getLength()="+allDataPaths1.getLength());
//                extractComponentIdAttributesFromNodeList(allDataPaths1, allComponentManagersSet);
//            } catch (Throwable e) {
//                LOG.fatal("Error parsing datapath nodes. Will be ignored: "+e.getMessage(), e);
//            }
//            try {
//                NodeList allDataPaths2 = doc.getDocumentElement().getElementsByTagNameNS("*", "datapath");
//                System.out.println("allDataPaths2.getLength()="+allDataPaths2.getLength());
//                extractComponentIdAttributesFromNodeList(allDataPaths2, allComponentManagersSet);
//            } catch (Throwable e) {
//                LOG.fatal("Error parsing datapath nodes. Will be ignored: "+e.getMessage(), e);
//            }
//            try {
//                NodeList allDataPaths3 = doc.getDocumentElement().getElementsByTagName("datapath");
//                System.out.println("allDataPaths3.getLength()="+allDataPaths3.getLength());
//                extractComponentIdAttributesFromNodeList(allDataPaths3, allComponentManagersSet);
//            } catch (Throwable e) {
//                LOG.fatal("Error parsing datapath nodes. Will be ignored: "+e.getMessage(), e);
//            }
//        } catch (Throwable e) {
//            LOG.fatal("Error parsing RSpex XML. Will be ignored: "+e.getMessage(), e);
//        }

        return new ArrayList<>(allComponentManagersSet);
    }

    public List<String> getAllComponentManagerUrns() {
        if (allComponentManagers != null) return allComponentManagers;
        if (!isWellFormed()) return null;
        parse();
        return allComponentManagers;
    }



    public List<ManifestRspecSource.LoginService> getNodeLoginInfo(RspecNode requestNode) {
        if (!isWellFormed()) return null;

        String nodeId = requestNode.getId().trim();

        List<ManifestRspecSource.LoginService> res = new ArrayList<>();
        try {
            Document doc = getDocumentIgnoringAsMuchAsPossible(xmlString, true);

            doc.getDocumentElement().normalize();

            boolean isPle = false; //HACK to make PLE manifest work
            if (requestNode.getComponentId() != null && !requestNode.getComponentId().trim().isEmpty()) {
                GeniUrn comManUrn = GeniUrn.parse(requestNode.getComponentId().trim());
                if (comManUrn != null &&
                        (comManUrn.getTopLevelAuthority().equals("ple") ||
                                comManUrn.getTopLevelAuthority().startsWith("ple:"))) {
                    isPle = true;
                }
            }

            List<Element> matchingNodes = new ArrayList<>();
            try {
                NodeList nodes = doc.getDocumentElement().getElementsByTagNameNS("http://www.geni.net/resources/rspec/3", "node");
                for (int i = 0; i < nodes.getLength(); i++) {
                    Node nodeNode = nodes.item(i);
                    if (nodeNode.getNodeType() == Node.ELEMENT_NODE) {
                        try {
                            Element nodeEl = (Element) nodeNode;

                            String clientId = nodeEl.getAttribute("client_id");
                            if (clientId != null && !clientId.trim().isEmpty() && clientId.trim().equals(nodeId)) {
                                matchingNodes.add(nodeEl);
                            }
                        } catch (Throwable e) {
                            LOG.fatal("Error parsing. Will be ignored: "+e.getMessage(), e);
                        }
                    }
                }
            } catch (Throwable e) {
                LOG.fatal("Error parsing openflow nodes. Will be ignored: "+e.getMessage(), e);
            }

            //HACK to make PLE manifest work
            //ple changes node id in manifest (which is a major bug on their part)
            //if ple and if can find node for same component manager (same component id), use that one instead!
            if (matchingNodes.isEmpty() && isPle && requestNode.getComponentId() != null) {
                try {
                    //PLE manifest might b ein very invalid RSpec format, without even namespace correct. So we don't check for it.
                    NodeList nodes = doc.getDocumentElement().getElementsByTagName("node");
                    for (int i = 0; i < nodes.getLength(); i++) {
                        Node nodeNode = nodes.item(i);
                        if (nodeNode.getNodeType() == Node.ELEMENT_NODE) {
                            try {
                                Element nodeEl = (Element) nodeNode;
                                String comId = nodeEl.getAttribute("component_id");

                                if (comId != null && !comId.trim().isEmpty() && comId.trim().equals(requestNode.getComponentId().trim())) {
                                    matchingNodes.add(nodeEl);
                                }
                            } catch (Throwable e) {
                                LOG.fatal("Error parsing. Will be ignored: "+e.getMessage(), e);
                            }
                        }
                    }
                } catch (Throwable e) {
                    LOG.fatal("Error parsing RSpec nodes. Will be ignored: "+e.getMessage(), e);
                }
            }

            for (Element matchingNodeEl : matchingNodes) {
                try {
                    NodeList services =  matchingNodeEl.getElementsByTagName("services");
                    if (services.getLength() > 1)
                        LOG.warn("RSpec XML node contained multiple <services>. This is not allowed. Will try to check all anyway.");
                    for (int i = 0; i < services.getLength(); i++) {
                        Node serviceNode = services.item(i);

                        if (serviceNode.getNodeType() == Node.ELEMENT_NODE)
                            try {
                                Element serviceEl = (Element) serviceNode;
                                NodeList loginServices =  serviceEl.getElementsByTagName("login");

                                for (int j = 0; j < loginServices.getLength(); j++) {
                                    Node loginNode = loginServices.item(j);

                                    if (loginNode.getNodeType() == Node.ELEMENT_NODE)
                                        try {
                                            Element loginEl = (Element) loginNode;

                                            ManifestRspecSource.LoginService ls = new ManifestRspecSource.LoginService(
                                                    loginEl.getAttribute("authentication"),
                                                    loginEl.getAttribute("hostname"),
                                                    Integer.parseInt(loginEl.getAttribute("port")),
                                                    loginEl.getAttribute("username"));
                                            res.add(ls);
                                        } catch (Throwable e) {
                                            LOG.fatal("Error parsing RSpec node service. Will be ignored: "+e.getMessage(), e);
                                        }
                                }
                            } catch (Throwable e) {
                                LOG.fatal("Error parsing RSpec node service. Will be ignored: "+e.getMessage(), e);
                            }
                    }
                } catch (Throwable e) {
                    LOG.fatal("Error parsing RSpec node. Will be ignored: "+e.getMessage(), e);
                }
            }

        } catch (Throwable e) {
            LOG.fatal("Error parsing RSpex XML. Will be ignored: "+e.getMessage(), e);
        }
        return res;
    }
}
