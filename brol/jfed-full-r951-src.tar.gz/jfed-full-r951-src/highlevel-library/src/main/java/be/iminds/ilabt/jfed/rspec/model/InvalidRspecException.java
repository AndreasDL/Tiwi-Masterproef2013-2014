package be.iminds.ilabt.jfed.rspec.model;

/**
* User: twalcari
* Date: 12/18/13
* Time: 10:16 AM
*/
public class InvalidRspecException extends Exception{
    public InvalidRspecException() {
    }

    public InvalidRspecException(String message) {
        super(message);
    }

    public InvalidRspecException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidRspecException(Throwable cause) {
        super(cause);
    }

    public InvalidRspecException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
