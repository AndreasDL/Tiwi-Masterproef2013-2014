package be.iminds.ilabt.jfed.highlevel.controller;

import be.iminds.ilabt.jfed.highlevel.model.AuthorityInfo;
import be.iminds.ilabt.jfed.highlevel.model.EasyModel;
import be.iminds.ilabt.jfed.highlevel.model.Slice;
import be.iminds.ilabt.jfed.highlevel.model.Sliver;
import be.iminds.ilabt.jfed.lowlevel.GeniUserProvider;
import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.SfaCredential;
import be.iminds.ilabt.jfed.lowlevel.api.UserSpec;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.AggregateManagerWrapper;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.UserAndSliceApiWrapper;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl.AutomaticAggregateManagerWrapper;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl.AutomaticUserAndSliceApiWrapper;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnectionPool;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.RspecLink;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.JavaFXLogger;
import javafx.application.Platform;
import javafx.util.Pair;
import org.apache.logging.log4j.LogManager;

import java.util.*;

/**
 * HighLevelController
 * <p/>
 * The highlevelController provides access to various typical gui tasks with simple calls.
 * It will select API's as needed.
 * Dependant calls will be performed if needed, and post completion, timeout or failure operations will be run.
 * <p/>
 * It also stores the connectionpool.
 * <p/>
 * <p/>
 * TODO This is a VERY temporary implementation with a lot of issues. The interface will probably mostly be kept,
 * TODO   but the implementation will need to be updated
 */
public class HighLevelController {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();
    private final EasyModel easyModel;
    private final SfaConnectionPool connectionPool;
    private final GeniUserProvider geniUserProvider;
    private final Map<Slice, Task> sliceCredentialCalls = new HashMap<>();
    private final Map<Slice, Task> sliceManifestCalls = new HashMap<>();
    private final Map<Sliver, Task> sliverManifestCalls = new HashMap<>();
    private final Map<Sliver, Task> sliverStatusCalls = new HashMap<>();
    //global call                 name
    //call per slice              name + slice
    //call per slice + auth pair  name + slice + auth
    //===> unique name?
    private final Map<Pair<Slice, SfaAuthority>, Task> sliceStatusOnAuthCalls =
            new HashMap<>();
    private final Map<Pair<Slice, SfaAuthority>, Task> sliceManifestOnAuthCalls =
            new HashMap<>();
    private final Map<Sliver, Task> deleteSliverCalls = new HashMap<>();
    private final Map<Slice, Task> resolveSliceCalls = new HashMap<>();
    private final Map<SfaAuthority, Task> getversionCalls = new HashMap<>();
    private final Map<SfaAuthority, Task> advertisementCalls = new HashMap<>();
    private final Map<Slice, Task> sliceStatusCalls = new HashMap<>();
    private Task userSSHKeyCall = null;
    private Task userCredentialCall = null;
    private Task resolveUserCall = null;
    private Task resolveUserCallAndSlices = null;

    public HighLevelController(EasyModel easyModel, SfaConnectionPool connectionPool, GeniUserProvider geniUserProvider) {
        this.easyModel = easyModel;
        this.connectionPool = connectionPool;
        this.geniUserProvider = geniUserProvider;
    }

    /*
    * Checks if there are links that require stitching.
    *
    * Rules:
    *   - the link has more than one componentManager
    *   - the link is not a GRE tunnel
    * */
    public static boolean needsStitching(ModelRspec rspec) {
        for (RspecLink link : rspec.getLinks())
            if (link.getComponentManagerUrns().size() >= 2) {
                if (!link.getLinkTypes().contains("gre"))
                    return true;
            }

        return false;
    }

    public EasyModel getEasyModel() {
        return easyModel;
    }

    public SfaConnectionPool getConnectionPool() {
        return connectionPool;
    }

    private UserAndSliceApiWrapper getUserAndSliceApiWrapper(SingleTask singleTask) {
        return new AutomaticUserAndSliceApiWrapper(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), geniUserProvider, connectionPool);
    }

    private AggregateManagerWrapper getAggregateManagerWrapper(SingleTask singleTask, SfaAuthority amAuth) {
        return new AutomaticAggregateManagerWrapper(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), geniUserProvider, connectionPool, amAuth);
    }

    public Task getSliceCredential(final Slice slice) {
        assert slice != null;

        Task call = sliceCredentialCalls.get(slice);
        if (call != null) return call;

        call = new Task("Get Slice Credential " + slice.getUrnString()) {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                UserAndSliceApiWrapper w = getUserAndSliceApiWrapper(singleTask);
                w.getSliceCredentials(easyModel.getUserCredential(), GeniUrn.parse(slice.getUrnString()));
//                EasySliceAuthority easySliceAuthority = new EasySliceAuthority(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                easySliceAuthority.getCredential(slice);
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getUserCredential());
                return res;
            }

            @Override
            public boolean needed() {
                //TODO check whether slice credential hasn't expired
                return slice.getCredential() == null;
            }
        };
        sliceCredentialCalls.put(slice, call);
        return call;
    }

    public Task getManifest(final Slice slice) {
        Task call = sliceManifestCalls.get(slice);
        if (call != null) return call;

        call = new Task("Get Slice Manifest") {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                LOG.debug("getManifest cm count: " + slice.manifestComponentManagersProperty().size());
                for (String cm : slice.manifestComponentManagersProperty().get()) {
                    AuthorityInfo ai = easyModel.getAuthorityList().getByUrn(cm);
                    if (ai == null) {
                        LOG.warn("Resolve Slice returned unknown component manager -> ignoring");
                        continue;
                    }
                    SfaAuthority auth = ai.getSfaAuthority();
                    if (auth == null) {
                        LOG.warn("Resolve Slice returned unknown component manager -> ignoring");
                        continue;
                    }

                    //TODO: see getStatus, here as well we need to block ourself and add these as deps instead of just adding them
                    Task subCall = getSliceManifest(slice, auth);
                    TaskThread.getInstance().addTask(subCall);
                }
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getSliceCredential(slice));
                return res;
            }

            @Override
            public List<Task> initAlwaysDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(resolveSlice(slice));
                return res;
            }
        };
        sliceManifestCalls.put(slice, call);
        return call;
    }

    public Task getManifest(final Sliver sliver) {
        Task call = sliverManifestCalls.get(sliver);
        if (call != null) return call;

        call = new Task("Get Sliver Manifest") {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                SfaAuthority auth = sliver.getAuthority();
                assert auth != null;

//                if (auth.getUrl(ServerType.GeniServerRole.AM, 2) != null) {
                AggregateManagerWrapper amWrapper = getAggregateManagerWrapper(singleTask, auth);
                amWrapper.describe(sliver.getSlice().getUrn(), sliver.getSlice().getCredential());
//                    EasyAggregateManager2 am2 =
//                            new EasyAggregateManager2(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                    am2.listSliceResources(sliver.getSlice());
//                }
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getSliceCredential(sliver.getSlice()));
                return res;
            }
        };
        sliverManifestCalls.put(sliver, call);
        return call;
    }

    public Task getSliverStatus(final Sliver sliver) {
        Task call = sliverStatusCalls.get(sliver);
        if (call != null) return call;

        call = new Task("Get Sliver Status @ " + sliver.getAuthority().getUrnString()) {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                SfaAuthority auth = sliver.getAuthority();
                assert auth != null;

//                if (auth.getUrl(ServerType.GeniServerRole.AM, 2) != null) {
                AggregateManagerWrapper amWrapper = getAggregateManagerWrapper(singleTask, auth);
                amWrapper.status(sliver.getSlice().getUrn(), sliver.getSlice().getCredential());

//                    EasyAggregateManager2 am2 =
//                            new EasyAggregateManager2(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                    am2.sliverStatus(sliver.getSlice());
//                }
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getSliceCredential(sliver.getSlice()));
                return res;
            }
        };
        sliverStatusCalls.put(sliver, call);
        return call;
    }

    /**
     * get a Status for a specific AM. We don't assume there is a sliver, as getSliverManifest does
     */
    public Task getSliceStatus(final Slice slice, final SfaAuthority auth) {
        assert auth != null;
        Pair<Slice, SfaAuthority> pair = new Pair<Slice, SfaAuthority>(slice, auth);
        Task call = sliceStatusOnAuthCalls.get(pair);
        if (call != null) return call;

        Task newCall = new Task("Status of Slice @ " + auth.getName()) {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException, JFedHighLevelException {
//                if (auth.getUrl(ServerType.GeniServerRole.AM, 2) != null) {
                AggregateManagerWrapper amWrapper = getAggregateManagerWrapper(singleTask, auth);
                SliverStatus status = amWrapper.status(slice.getUrn(), slice.getCredential());
//                    EasyAggregateManager2 am2 =
//                            new EasyAggregateManager2(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                    AggregateManager2.SliverStatus status = am2.sliverStatus(slice);

                if (status == null)
                    throw new JFedHighLevelException("AMv2 sliver status update failed");
//                } else
//                    LOG.warn("Slice has authority (" + auth.getUrnString() + ") without AMv2 support. It will be ignored!");
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getSliceCredential(slice));
                return res;
            }
        };
        sliceStatusOnAuthCalls.put(pair, newCall);
        return newCall;
    }

    /**
     * get a manifest for a specific AM. We don't assume there is a sliver, as getSliverManifest does
     */
    public Task getSliceManifest(final Slice slice, final SfaAuthority auth) {
        assert auth != null;
        Pair<Slice, SfaAuthority> pair = new Pair<Slice, SfaAuthority>(slice, auth);
        Task call = sliceManifestOnAuthCalls.get(pair);
        if (call != null) return call;


        Task newCall = new Task("get Manifest of Slice @ " + auth.getName()) {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
//                if (auth.getUrl(ServerType.GeniServerRole.AM, 2) != null) {
                AggregateManagerWrapper amWrapper = getAggregateManagerWrapper(singleTask, auth);
                amWrapper.describe(slice.getUrn(), slice.getCredential());

//                    EasyAggregateManager2 am2 =
//                            new EasyAggregateManager2(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                    am2.listSliceResources(slice);
//                } else
//                    LOG.warn("Slice has authority (" + auth.getUrnString() + ") without AMv2 support. It will be ignored!");
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getSliceCredential(slice));
                return res;
            }
        };
        sliceManifestOnAuthCalls.put(pair, newCall);
        return newCall;
    }

    public Task deleteSliver(final Sliver sliver) {
        Task call = deleteSliverCalls.get(sliver);
        if (call != null) return call;

        call = new Task("Delete Sliver " + sliver.getUrn()) {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                SfaAuthority auth = sliver.getAuthority();
                assert auth != null;

                Slice slice = sliver.getSlice();
                AggregateManagerWrapper amWrapper = getAggregateManagerWrapper(singleTask, auth);
                amWrapper.deleteSliver(slice.getUrn(), slice.getCredential());

//                if (auth.getUrl(ServerType.GeniServerRole.AM, 2) != null) {
//                    EasyAggregateManager2 am2 =
//                            new EasyAggregateManager2(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                    am2.deleteSliver(sliver.getSlice());
//                }
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getSliceCredential(sliver.getSlice()));
                return res;
            }
        };
        deleteSliverCalls.put(sliver, call);
        return call;
    }

    public Task resolveSlice(final Slice slice) {
        Task call = resolveSliceCalls.get(slice);
        if (call != null) return call;

        call = new Task("Resolve Slice") {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                UserAndSliceApiWrapper w = getUserAndSliceApiWrapper(singleTask);
                w.getAggregatesForSlice(easyModel.getUserCredential(), slice.getCredential(), GeniUrn.parse(slice.getUrnString()));
//                EasySliceAuthority easySliceAuthority = new EasySliceAuthority(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                easySliceAuthority.resolveSlice(slice);
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getUserCredential());
                res.add(getSliceCredential(slice));
                return res;
            }

            @Override
            public boolean needed() {
                //resolve if no component managers
                return slice.getManifestComponentManagers().isEmpty();
            }
        };
        resolveSliceCalls.put(slice, call);
        return call;
    }

    public Task getUserSSHKey() {
        if (userSSHKeyCall != null) return userSSHKeyCall;

        userSSHKeyCall = new Task("Get User SSH Keys") {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                UserAndSliceApiWrapper w = getUserAndSliceApiWrapper(singleTask);
                w.getSshKeysForUser(easyModel.getUserCredential(), GeniUrn.parse(geniUserProvider.getLoggedInGeniUser().getUserUrnString()));
//                EasySliceAuthority easySliceAuthority = new EasySliceAuthority(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                easySliceAuthority.getSshKeys();

            }
            // @Override public boolean needed() { return easyModel.getUserKeys() == null || easyModel.getUserKeys().isEmpty(); };

            //no dependencies
        };
        return userSSHKeyCall;
    }

    public Task getUserCredential() {
        if (userCredentialCall != null) return userCredentialCall;

        userCredentialCall = new Task("Get User Credential") {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                UserAndSliceApiWrapper w = getUserAndSliceApiWrapper(singleTask);
                w.getUserCredentials(GeniUrn.parse(geniUserProvider.getLoggedInGeniUser().getUserUrnString()));
//                EasySliceAuthority easySliceAuthority = new EasySliceAuthority(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                easySliceAuthority.getCredential();
            }

            @Override
            public boolean needed() {
                if (easyModel.getUserCredential() == null) {
                    LOG.info("Get User Credential Task: no stored user credential -> task needed");
                    return true;
                }

                if (easyModel.getUserCredential().getExpiresDate() == null) {
                    LOG.info("Get User Credential Task: no date in credential -> task needed");
                    return false; //TODO because this is false, old credentials might be used. Just implement getExpiresData to make it work!
                }
                Date now = new Date();
                if (easyModel.getUserCredential().getExpiresDate().before(now)) {
                    LOG.info("Get User Credential Task: stored credential expires at "+easyModel.getUserCredential().getExpiresDate()+" while now is "+now+" -> task needed");
                    return true;
                }
                else {
                    LOG.info("Get User Credential Task: stored credential expires at "+easyModel.getUserCredential().getExpiresDate()+" while now is "+now+" -> task not needed");
                    return false;
                }
            }

            //no dependencies
        };
        return userCredentialCall;
    }

    public Task resolveUser() {
        if (resolveUserCall != null) return resolveUserCall;

        resolveUserCall = new Task("Resolve User") {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                UserAndSliceApiWrapper w = getUserAndSliceApiWrapper(singleTask);
                w.getSlicesForUser(easyModel.getUserCredential(), GeniUrn.parse(geniUserProvider.getLoggedInGeniUser().getUserUrnString()));

//                EasySliceAuthority easySliceAuthority = new EasySliceAuthority(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                easySliceAuthority.resolveUser(geniUserProvider.getLoggedInGeniUser().getUserUrn());
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getUserCredential());
                return res;
            }
        };
        return resolveUserCall;
    }

    public Task resolveUserAndSlices() {
        if (resolveUserCallAndSlices != null) return resolveUserCallAndSlices;

        resolveUserCallAndSlices = new Task("Resolve User & Slices") {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                UserAndSliceApiWrapper w = getUserAndSliceApiWrapper(singleTask);
                List<GeniUrn> sliceUrns =
                        w.getSlicesForUser(easyModel.getUserCredential(), GeniUrn.parse(geniUserProvider.getLoggedInGeniUser().getUserUrnString()));
//                EasySliceAuthority easySliceAuthority = new EasySliceAuthority(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                UserInfo res = easySliceAuthority.resolveUser(geniUserProvider.getLoggedInGeniUser().getUserUrn());

                //note: resolveUser call result might not have triggered listener yet, so easymodel might not yet know of it!

                for (final GeniUrn sliceUrn : sliceUrns) {
                    //TODO very dirty, fix! (see TODOs below for info)
                    //TODO how to wait for result to be processed so we can request slice resolve? One way is to run this in JavaFX thread,
                    //TODO     it is a dirty method, as it relies on much implementation info.
                    //TODO     a better method would be to have a method that waits for all pending updates in EasyModel or the EasyModelListeners.
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            Slice slice = easyModel.getSlice(sliceUrn.toString());
                            assert slice != null;
                            Task resolveSliceCall = resolveSlice(slice);

                            //TODO reblock self and add these as dependencies instead
                            //Note: this to do requires that the other is done first
                            TaskThread.getInstance().addTask(resolveSliceCall);
                        }
                    });
                }
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getUserCredential());
                return res;
            }
        };
        return resolveUserCallAndSlices;
    }

    public Task getVersion(final SfaAuthority auth) {
        Task call = getversionCalls.get(auth);
        if (call != null) return call;

        call = new Task("GetVersion on " + auth.getName()) {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                AggregateManagerWrapper amWrapper = getAggregateManagerWrapper(singleTask, auth);
                amWrapper.getVersion();
//                EasyAggregateManager2 am2 =
//                        new EasyAggregateManager2(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                am2.getVersion();
            }

            @Override
            public boolean needed() {
                //TODO: Store cached GetVersion result?
//                AuthorityInfo ai = easyModel.getAuthorityList().get(auth);
//                if (ai.hetCachehedGetVersionResult() != null) return false;
                return super.needed();
            }

            ;
        };
        getversionCalls.put(auth, call);
        return call;
    }

    public Task getAdvertisement(final SfaAuthority auth) {
        Task call = advertisementCalls.get(auth);
        if (call != null) return call;

        call = new Task("Fetch Advertisement RSpec on " + auth.getName()) {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                AggregateManagerWrapper amWrapper = getAggregateManagerWrapper(singleTask, auth);
                amWrapper.listResources(easyModel.getUserCredential(), true /*available*/);

//                EasyAggregateManager2 am2 =
//                        new EasyAggregateManager2(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                am2.listResources(true /*available*/);
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getUserCredential());
                return res;
            }
        };
        advertisementCalls.put(auth, call);
        return call;
    }

    public CreateSliceTask createSlice(String sliceName) {
        return new CreateSliceTask(sliceName);
    }

    public CreateSliceTask createSlice(String sliceName, Date expirationDate) {
        return new CreateSliceTask(sliceName, expirationDate);
    }

    public List<Task> refreshSlices() {
        //resolve user AND get credential for each slice and resolve it
        //possibly also get all manifest/statuses

        //TODO add more?
        List<Task> res = new ArrayList<Task>();
        res.add(resolveUserAndSlices());

        //remove this hack  (was used for demo)
//        for (AuthorityInfo ai : easyModel.getAuthorityList().authorityInfosProperty()) {
//            //for ple, we need to be able to assign nodes, so we will get the advertisement manifest
//            if (ai.getGeniAuthority().getType().equals("planetlab"))
//                res.add(getAdvertisement(ai.getGeniAuthority()));
//        }
        return res;
    }

    //see SliceTabController.createSlivers() for code below
//    /**
//     * This assumes the request is stored in the slice, and it will create the slivers on all component managers
//     * that are mentioned in the Rspec */
//    public List<TaskThread.Task> createSliversWithStitching(final Slice slice) {
//        Rspec rspec = slice.requestRspecProperty().get();
//        if (needsStitching(rspec)) {
//            ParallelStitcher parallelStitcher = new ParallelStitcher(easyModel, rspec.toGeni3RequestRspec());
////            CreateSliverStatusPanel.showStitchingOverview(easyModel, parallelStitcher);
////            parallelStitcher.setSlice(stitchSlice);
////            parallelStitcher.start();
//        } else {
//            return createSliversNoStitching(slice);
//        }
//    }

    public List<CreateSliverTask> createSliversNoStitching(final Slice slice) {
        return createSliversNoStitching(slice, slice.getExpirationDate());
    }

    /**
     * This assumes the request is stored in the slice, and it will create the slivers on all component managers
     * that are mentioned in the Rspec
     */
    public List<CreateSliverTask> createSliversNoStitching(final Slice slice, final Date expirationDate) {
        List<CreateSliverTask> calls = new ArrayList<>();

        List<String> componentManagerUrns = slice.getRequestRspec().getAllComponentManagerUrns();
        LOG.debug("  createSlivers start  componentManagerUrns=" + componentManagerUrns);
        for (final String componentManagerUrn : componentManagerUrns) {
            final AuthorityInfo ai = easyModel.getAuthorityList().getByUrn(componentManagerUrn);
            if (ai == null) {
                //TODO handle better
                LOG.warn("INPUT ERROR: Component Manager Urn in Request RSpec unknown: \"" + componentManagerUrn + "\". Will ignore!");
                continue;
            }
            final SfaAuthority auth = ai.getSfaAuthority();
            assert auth != null;

//            //report that we are creating sliver
//            Runnable startStatus = new Runnable() {
//                @Override
//                public void run() {
//                    Sliver newSliver = easyModel.logExistSliverGeniSingle(slice.getUrnString(), auth);
//                    newSliver.setStatus(SliverStatus.CHANGING);
//                    newSliver.setStatusString("will call CreateSliver");
//                }
//            };
//            if (Platform.isFxApplicationThread()) startStatus.run();
//            else Platform.runLater(startStatus);

            CreateSliverTask call = new CreateSliverTask(slice, expirationDate, ai);

            calls.add(call);
        }

        return calls;
    }

    public List<Task> getSliceStatusAndManifest(final Slice slice) {
        List<Task> res = new ArrayList<Task>();
        res.add(getSliceStatus(slice));
        res.add(getManifest(slice));
        return res;
    }

    /**
     * call Status on all slivers in the slice. Needs to be sure resolve has been done first, so that all AM involved are known.
     */
    public Task getSliceStatus(final Slice slice) {
        Task call = sliceStatusCalls.get(slice);
        if (call != null) return call;

        call = new Task("Status of Slice") {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                for (String cmUrn : slice.getManifestComponentManagers()) {
                    final AuthorityInfo ai = easyModel.getAuthorityList().getByUrn(cmUrn);
                    if (ai == null) {
                        LOG.warn("Resolve call returned component_manager for unknown authority (" + cmUrn + "). Will be ignored.");
                        return;
                    }
                    final SfaAuthority auth = ai.getSfaAuthority();
                    assert auth != null;

                    //TODO would it be better if we put ourself in blocked again and added these to our deps? (because whatever might depend on us will think we are done now)
                    Task subCall = getSliceStatus(slice, auth);
                    TaskThread.getInstance().addTask(subCall);
                }
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getSliceCredential(slice));
                return res;
            }

            @Override
            public List<Task> initAlwaysDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(resolveSlice(slice));
                return res;
            }
        };
        sliceStatusCalls.put(slice, call);
        return call;
    }

    /**
     * call Status on al slivers in the slice. Needs to be sure resolve has been done first, so that all AM involved are known.
     */
    public Task deleteSlice(final Slice slice) {
        List<Task> calls = new ArrayList<Task>();

        Task call = new Task("Delete All Slivers on slice " + slice.getUrnString()) {
            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException, InterruptedException {
                for (String cmUrn : slice.getManifestComponentManagers()) {
                    AuthorityInfo ai = easyModel.getAuthorityList().getByUrn(cmUrn);
                    if (ai == null) {
                        LOG.warn(" Resolve call returned component_manager for unknown authority (" + cmUrn + "). Will be ignored.");
                        return;
                    }
                    SfaAuthority auth = ai.getSfaAuthority();
                    assert auth != null;
//                    if (auth.getUrl(ServerType.GeniServerRole.AM, 2) != null) {
                    AggregateManagerWrapper amWrapper = getAggregateManagerWrapper(singleTask, auth);
                    amWrapper.deleteSliver(slice.getUrn(), slice.getCredential());
//                        EasyAggregateManager2 am2 =
//                                new EasyAggregateManager2(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                        am2.deleteSliver(slice);
//                    } else
//                        LOG.warn(" Slice has authority (" + cmUrn + ") without AMv2 support. It will be ignored!");
                }
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(getSliceCredential(slice));
                return res;
            }

            @Override
            public List<Task> initAlwaysDependsOn() {
                List<Task> res = new ArrayList<Task>();
                res.add(resolveSlice(slice));
                return res;
            }
        };

        return call;
    }

    public Task renewSlice(Slice slice, Date newExpirationDate) {
        return new RenewSliceTask(slice, newExpirationDate);
    }

    public final class CreateSliceTask extends Task {

        private final String sliceName;
        private final Date expirationDate;
        private Slice slice;

        public CreateSliceTask(String sliceName) {
            super("Create Slice");
            this.sliceName = sliceName;
            this.expirationDate = null;
        }

        public CreateSliceTask(String sliceName, Date expirationDate) {
            super("Create Slice");
            this.sliceName = sliceName;
            this.expirationDate = expirationDate;
        }

        @Override
        public void doTask(SingleTask singleTask) throws JFedException, InterruptedException, JFedHighLevelException {
            UserAndSliceApiWrapper w = getUserAndSliceApiWrapper(singleTask);
            LOG.debug("Requesting slice with expiration time " + expirationDate.getTime());
            UserAndSliceApiWrapper.SliceInfo sliceInfo =
                    w.createSlice(easyModel.getUserCredential(), sliceName, expirationDate);

            if (sliceInfo.getCredential() != null) {
                GeniUrn sliceUrn = sliceInfo.getUrn();

                slice = easyModel.getSlice(sliceUrn.toString());
            } else {
                LOG.error("Create Slice task failed: sliceCredential == null");
                throw new JFedHighLevelException("Creation of slice failed");
            }
        }

        @Override
        public List<Task> initDependsOn() {
            List<Task> res = new ArrayList<>();
            res.add(getUserCredential());
            return res;
        }

        public String getSliceName() {
            return sliceName;
        }

        public Slice getSlice() {
            return slice;
        }
    }

    public final class RenewSliceTask extends Task {

        private final Slice slice;
        private final Date newExpirationDate;

        public RenewSliceTask(Slice slice, Date newExpirationDate) {
            super("Renew Slice");
            this.slice = slice;
            this.newExpirationDate = newExpirationDate;
        }

        @Override
        protected void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
            UserAndSliceApiWrapper w = getUserAndSliceApiWrapper(singleTask);
            w.renewSlice(slice.getCredential(), newExpirationDate);
        }
    }

    public final class CreateSliverTask extends Task {
        private final Slice slice;
        private final Date expirationDate;
        private final AuthorityInfo ai;
        private final SfaAuthority auth;
        private Sliver sliver;

        public CreateSliverTask(Slice slice, Date expirationDate, AuthorityInfo ai) {
            super("Create Sliver @ " + ai.getSfaAuthority().getUrnString());
            this.slice = slice;
            this.expirationDate = expirationDate;
            this.ai = ai;
            this.auth = ai.getSfaAuthority();
        }

        @Override
        public void doTask(SingleTask singleTask) throws JFedException, InterruptedException, InterruptedException, JFedHighLevelException {


//            //report that we are creating sliver
//            Runnable callingStatus = new Runnable() {
//                @Override
//                public void run() {
//                    sliver = easyModel.logExistSliverGeniSingle(slice.getUrnString(), auth);
//                    sliver.setStatus(SliverStatus.CHANGING);
//                    sliver.setStatusString("now calling CreateSliver");
//                }
//            };
//            if (Platform.isFxApplicationThread()) callingStatus.run();
//            else Platform.runLater(callingStatus);

            ModelRspec.RequestRspecSpecialCases rspecSpecialCase = ModelRspec.RequestRspecSpecialCases.NONE;
            if (auth.getType().equals("planetlab")) {
                rspecSpecialCase = ModelRspec.RequestRspecSpecialCases.PLE;
            }

            AggregateManagerWrapper amWrapper = getAggregateManagerWrapper(singleTask, auth);
            List<UserSpec> userSpecs = new ArrayList<>();
            userSpecs.add(new UserSpec(geniUserProvider.getLoggedInGeniUser().getUserUrnString(), easyModel.getUserKeys()));
            LOG.debug("  createSlivers AMv2 @ " + auth.getUrnString());
            String manifestRspec = amWrapper.createSliver(
                    slice.getUrn(),
                    slice.getCredential(),
                    slice.getRequestRspec().getRspecXmlString(rspecSpecialCase),
                    userSpecs,
                    expirationDate);

            //Note: listener that handles createSliver should update the list of component managers, as it will have changed

            sliver = slice.findSliverFromAuthorityUrn(auth.getUrn());

            //either something failed, or the sliver is now being prepared. Either way, we will check the status
            if (manifestRspec != null) {
                //try in 10 seconds
                TaskThread.getInstance().scheduleTask(new GetStatusUntilReadyOrFailTask(), 10000);
            } else {
                throw new JFedHighLevelException("Creation of the sliver failed.");
            }
        }

        @Override
        public List<Task> initDependsOn() {
            List<Task> res = new ArrayList<Task>();
            res.add(getSliceCredential(slice));
            res.add(getUserSSHKey());
            return res;
        }

        public Slice getSlice() {
            return slice;
        }

        public AuthorityInfo getAuthorityInfo() {
            return ai;
        }

        public SfaAuthority getSfaAuthority() {
            return auth;
        }

        public Sliver getSliver() {
            return sliver;
        }

        private final class GetStatusUntilReadyOrFailTask extends Task {

            public GetStatusUntilReadyOrFailTask() {
                super("Status of Sliver @ " + auth.getUrnString());

            }

            @Override
            public void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
//                if (auth.getUrl(ServerType.GeniServerRole.AM, 2) == null)
//
//                    throw new RuntimeException("Error: only AMv2 support is implemented currently");

                AggregateManagerWrapper amWrapper = getAggregateManagerWrapper(singleTask, auth);
                SliverStatus status = amWrapper.status(slice.getUrn(), slice.getCredential());
//                EasyAggregateManager2 am2 =
//                        new EasyAggregateManager2(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                AggregateManager2.SliverStatus am2sliverStatus = am2.sliverStatus(slice);

//                if (am2sliverStatus == null) {
                if (status == null) {
                    LOG.warn(" Something went wrong while waiting for slice \"" + slice.getUrnString() + "\" to become ready. Will stop checking status...");
                    return;
                }

//                //if not fail or ready, schedule again!
//                List<String> scheduleAgainStatuses = new ArrayList<String>();
//                scheduleAgainStatuses.add("configuring");
//                scheduleAgainStatuses.add("unknown");
//                scheduleAgainStatuses.add("changing");
//                scheduleAgainStatuses.add("notready");
//                if (scheduleAgainStatuses.contains(am2sliverStatus.getStatus())) {
//                    LOG.info("Status of Slice " + slice.getUrnString() + " is \"" + am2sliverStatus.getStatus() + "\": will check again in 10 seconds.");
                if (status.equals(SliverStatus.UNKNOWN) || status.equals(SliverStatus.CHANGING)) {
                    LOG.info("Status of Slice " + slice.getUrnString() + " is \"" + status + "\": will check again in 10 seconds.");
                    TaskThread.getInstance().scheduleTask(this, 10000);
                } else {
                    TaskThread.getInstance().addTask(new ListSliceResourcesTask());
                }
            }

            @Override
            public List<Task> initDependsOn() {
                List<Task> res = new ArrayList<>();
                res.add(getSliceCredential(slice));
                return res;
            }
        }

        private final class ListSliceResourcesTask extends Task {

            public ListSliceResourcesTask() {
                super("ListResources of Slice @ " + auth.getUrnString());
            }

            @Override
            protected void doTask(SingleTask singleTask) throws JFedException, InterruptedException {
                AggregateManagerWrapper amWrapper = getAggregateManagerWrapper(singleTask, auth);
                String rspec = amWrapper.describe(slice.getUrn(), slice.getCredential());

//                EasyAggregateManager2 am2 =
//                        new EasyAggregateManager2(JavaFXLogger.wrap(easyModel.getLogger(), singleTask), easyModel, auth);
//                RSpecInfo rspecInfo = am2.listSliceResources(slice);
            }
        }
    }

}

