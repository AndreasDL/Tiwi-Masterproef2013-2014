package be.iminds.ilabt.jfed.highlevel.model.rspec_source;

import be.iminds.ilabt.jfed.rspec.model.InvalidRspecException;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.StringRspec;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import org.apache.logging.log4j.LogManager;

import java.util.List;

/**
 * RequestRspecSource
 */
public class RequestRspecSource extends RspecSource {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    public RequestRspecSource(StringRspec stringRspec) {
        super(stringRspec);
    }

    public RequestRspecSource(ModelRspec modelRspec) {
        super(modelRspec);
    }

    /** Determines automatically to use raw XML, or ModelRspec */
    public RequestRspecSource(String xmlRspecString) {
        super(xmlRspecString);
    }

    @Override
    protected ModelRspec stringToModel(StringRspec s) throws InvalidRspecException {
        return ModelRspec.fromGeni3RequestRspecXML(s.getXmlString());
    }

    @Override
    protected String modelToString(ModelRspec s, ModelRspec.RequestRspecSpecialCases rspecSpecialCase) {
        return  modelRspec.toGeni3RequestRspec(rspecSpecialCase);
    }
}
