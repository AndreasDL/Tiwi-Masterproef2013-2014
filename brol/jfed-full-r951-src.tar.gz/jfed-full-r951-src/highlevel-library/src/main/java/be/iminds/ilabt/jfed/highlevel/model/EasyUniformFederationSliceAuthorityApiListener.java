package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.log.ApiCallDetails;
import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.JFedException;
import be.iminds.ilabt.jfed.lowlevel.api.AbstractFederationApi1;
import be.iminds.ilabt.jfed.lowlevel.api.FederationSliceAuthorityApi1;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.resourceid.ResourceId;
import be.iminds.ilabt.jfed.util.GeniUrn;
import javafx.application.Platform;
import org.apache.logging.log4j.LogManager;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

/**
 * EasyModelSliceAuthorityListener: this watches for SliceAuthority calls and fills in EasyModel using the info in them
 */
public class EasyUniformFederationSliceAuthorityApiListener extends EasyModelAbstractListener {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    public EasyUniformFederationSliceAuthorityApiListener(EasyModel model) {
        super(model);
    }

    private void onGetSliceCredentials(ApiCallDetails result) {
        LOG.debug("EasyUniformFederationSliceAuthorityApiListener#onGetSliceCredentials() parameters.size(): "+result.getMethodParameters().size());
        ResourceId sliceId = noteSliceUrnInParameters(result);
        assert sliceId != null;
        noteUserCredentialInParameters(result);

        if (result.getReply().getGeniResponseCode().isSuccess()) {
            String sliceUrn = sliceId.getValue();
            Slice slice = model.getSlice(sliceUrn);
            assert slice != null;
            List<AnyCredential> credentialList = (List<AnyCredential>) result.getReply().getValue();
            if (credentialList != null && credentialList.size() > 0)
                slice.setCredential(credentialList.get(0));
        }
    }


    private void onGetAggregates(ApiCallDetails result) throws JFedException {
        ResourceId sliceId = noteSliceUrnInParameters(result);
        noteUserCredentialInParameters(result);

        if (result.getReply().getGeniResponseCode().isSuccess()) {
            List<String> amUrls = (List<String>) result.getReply().getValue();

            String sliceUrn = sliceId.getValue();
            Slice slice = model.getSlice(sliceUrn);
            assert slice != null;


            //log existence and non existence of slivers
            List<GeniUrn> amUrns = new ArrayList<GeniUrn>();
            for (String amUrl : amUrls) {
                AuthorityInfo ai  = model.getAuthorityList().getByUrl(amUrl);
                if (ai == null) continue;
                SfaAuthority auth = ai.getSfaAuthority();
                assert auth != null;
                GeniUrn amUrn = auth.getUrn();
                amUrns.add(amUrn);

                //log existence of sliver
                //note that can we know anything for sure? we don't know if sliver is on AM with geni_single true...
                model.logExistSliver(sliceUrn, auth);

            }
            List<Sliver> slivers = slice.getSlivers();
            for (Sliver sliver : slivers) {
                if (!amUrns.contains(sliver.getAuthority().getUrnString()))
                    model.logNotExistSliverGeniSingle(slice.getUrnString(), sliver.getAuthority());
            }
        }
    }
    private void onGetSlicesForMember(ApiCallDetails result) throws JFedException {
        noteUserCredentialInParameters(result);

        if (result.getReply().getGeniResponseCode().isSuccess()) {
            AbstractFederationApi1.FederationApiReply<List<FederationSliceAuthorityApi1.UrnRoleTuple>> reply =
                    (AbstractFederationApi1.FederationApiReply<List<FederationSliceAuthorityApi1.UrnRoleTuple>>) result.getReply();

            if (reply == null || reply.getGeniResponseCode() == null || !reply.getGeniResponseCode().isSuccess() || reply.getValue() == null)
                return;

            List<FederationSliceAuthorityApi1.UrnRoleTuple> urnRoleTuples = reply.getValue();
            for (FederationSliceAuthorityApi1.UrnRoleTuple urnRoleTuple : urnRoleTuples) {
                String sliceUrnString = urnRoleTuple.getUrn().getValue();
                Slice slice = model.logExistSlice(sliceUrnString);
            }
        }
    }

    /** create_slice probably won't return a credential (not in default return, but could be in extension)! a call to get_credentials is needed */
    private void onCreateSlice(ApiCallDetails result) {
        noteUserCredentialInParameters(result);
//        ResourceId sliceId = noteSliceUrnInParameters(result); //only on success we can assume slice exists
        //we could also check other failures, for example, when calling register when a slice already exists.
        //but it's not really needed

        if (result.getReply().getGeniResponseCode().isSuccess()) {

            Hashtable<String, String> sliceInfo = (Hashtable<String, String>) result.getReply().getValue();
            if (sliceInfo.containsKey("SLICE_URN")) {
                model.logExistSlice(sliceInfo.get("SLICE_URN"));
            }
//            //not in standard!
//            if (sliceInfo.contains("SLICE_CREDENTIAL")) {
//                ResourceId sliceId = noteSliceUrnInParameters(result);
//                String sliceUrn = sliceId.getValue();
//                Slice slice = model.getSlice(sliceUrn);
//                assert slice != null;
//                slice.setCredential(AnyCredential.create("create_slice "+sliceUrn, sliceInfo.get("SLICE_CREDENTIAL"), "geni_sfa", "3")); //what type??
//            }
        }
    }



    @Override
    public void onResult(final ApiCallDetails details) {
        assert Platform.isFxApplicationThread();
        onResultInJavaFXThread(details);
    }
    public void onResultInJavaFXThread(ApiCallDetails result) {
        //ignore errors here
        if (result.getReply() == null || result.getJavaMethodName() == null)
            return;

        if (!result.getApiName().equals(FederationSliceAuthorityApi1.getApiName()))
            return;

        try {
            LOG.debug("EasyUniformFederationSliceAuthorityApiListener#onResult() methodName="+result.getJavaMethodName()+" parameters.size(): "+result.getMethodParameters().size());

            if (result.getJavaMethodName().equals("getSliceCredentials"))
                onGetSliceCredentials(result);

            if (result.getJavaMethodName().equals("createSlice"))
                onCreateSlice(result);

            if (result.getJavaMethodName().equals("getAggregates"))
                onGetAggregates(result);

            if (result.getJavaMethodName().equals("lookupSlicesForMember"))
                onGetSlicesForMember(result);

        } catch (Exception e) {
            System.err.println("WARNING: Exception when processing SliceAuthority reply for EasyModel. This will be ignored, but it is most likely a bug. " + e.getMessage());
            e.printStackTrace();
        }
    }
}
