package be.iminds.ilabt.jfed.util;

import be.iminds.ilabt.jfed.highlevel.controller.TaskThread;
import be.iminds.ilabt.jfed.log.ApiCallDetails;
import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.log.ResultListener;
import javafx.application.Platform;
import org.apache.logging.log4j.LogManager;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * JavaFXLogger exactly the same as Logger, but always handles events in JavaFX thread
 */
public class JavaFXLogger extends Logger {
    private static org.apache.logging.log4j.Logger logger = LogManager.getLogger();

    private boolean synchronous;
    /**
     * @param synchronous should fireResult be synchronous, or should it return after all results have been processed
     * */
    public JavaFXLogger(boolean synchronous) {
        this.synchronous = synchronous;
    }


    @Override
    public synchronized void fireResult(final ApiCallDetails reply) {
        if (!synchronous) {
            //asynchronous event processing
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    for (ResultListener l : resultListeners)
                        l.onResult(reply);
                }
            });
            return;
        }

        if (Platform.isFxApplicationThread())
            for (ResultListener l : resultListeners)
                l.onResult(reply);
        else {
            //synchronous event processing
//            final Lock lock = new ReentrantLock();
//            final Condition waiter = lock.newCondition();
//
//            lock.lock();
//
//            Platform.runLater(new Runnable() { @Override public void run() {
//
////                    JavaFXLogger.super.fireResult(reply);
//                for (ResultListener l : resultListeners)
//                    try {
//                        l.onResult(reply);
//                    } catch (Throwable e) {
//                        //ignore, because we want unlocking below to happen!
//                        logger.error("Error while processing Logger ApiCallDetails reply on JavaFX thread. (will be ignored)", e);
//                    }
//
//                lock.lock();
//                waiter.signalAll();
//                lock.unlock();
//            } });
//
//            try {
//                waiter.await();
//            } catch (InterruptedException e) {
//                //TODO: handle?
//                e.printStackTrace();
//            }
//            lock.unlock();
//
            final CyclicBarrier barrier = new CyclicBarrier(2);

            Platform.runLater(new Runnable() { @Override public void run() {
//                    JavaFXLogger.super.fireResult(reply);
                for (ResultListener l : resultListeners)
                    try {
                        l.onResult(reply);
                    } catch (Throwable e) {
                        //ignore, because we want unlocking below to happen!
                        logger.error("Error while processing Logger ApiCallDetails reply on JavaFX thread. (will be ignored)", e);
                    }

                try {
                    barrier.await();
                } catch (InterruptedException ex) {
                    return;
                } catch (BrokenBarrierException ex) {
                    return;
                }
            } });

            try {
                barrier.await();
            } catch (InterruptedException ex) {
                return;
            } catch (BrokenBarrierException ex) {
                return;
            }
        }
    }

    private static class MyWrappingJavaFXLogger extends JavaFXLogger {
        private final JavaFXLogger parentLogger;
        public MyWrappingJavaFXLogger(boolean synchronous, JavaFXLogger parentLogger) { super(synchronous); this.parentLogger = parentLogger; }
        @Override
        public synchronized void fireResult(ApiCallDetails reply) {
            //fire for all parentLogger listeners, even if they changed
            parentLogger.fireResult(reply);

            //fire for any listener added to this new wrapping logger
            super.fireResult(reply);
        }
    }

    @Override
    public JavaFXLogger getWrappingLogger() {
        return new MyWrappingJavaFXLogger(synchronous, this);
    }

    public static Logger wrap(final JavaFXLogger logger) {
        return wrap(logger, null);
    }
    public static JavaFXLogger wrap(final JavaFXLogger logger, final ResultListener resultListener) {
        JavaFXLogger res = new MyWrappingJavaFXLogger(logger.synchronous, logger);
        if (resultListener != null)
            res.addResultListener(resultListener);
        return res;
    }
}
