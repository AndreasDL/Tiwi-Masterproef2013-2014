package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.highlevel.model.rspec_source.ManifestRspecSource;
import be.iminds.ilabt.jfed.highlevel.model.rspec_source.RequestRspecSource;
import be.iminds.ilabt.jfed.highlevel.model.rspec_source.RspecSource;
import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.Gid;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.rspec.model.InvalidRspecException;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.RspecLink;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;
import be.iminds.ilabt.jfed.util.GeniUrn;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import org.apache.logging.log4j.LogManager;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Slice
 * <p/>
 * Example slice Urn:  "urn:publicid:IDN+"+authority.getNameForUrn()+"+slice+"+sliceName;
 */
public class Slice {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();
    final ChangeListener<SliverStatus> statusChangeListener = new ChangeListener<SliverStatus>() {
        @Override
        public void changed(ObservableValue<? extends SliverStatus> observableValue, SliverStatus oldStatus, SliverStatus newStatus) {
//            System.out.println("DEBUG: Slice "+Slice.this+" -> "+getUrn()+" sliver status changed");
            updateStatus();
        }
    };
    final ChangeListener<RSpecInfo> manifestRspecChangeListener = new ChangeListener<RSpecInfo>() {
        @Override
        public void changed(ObservableValue<? extends RSpecInfo> observableValue, RSpecInfo oldRSpecInfo, RSpecInfo newRSpecInfo) {
//            System.out.println("DEBUG: Slice "+Slice.this+" -> "+getUrn()+" sliver manifest Rspec changed");

            LOG.debug("Change in sliver manifest rspec: joining manifests");
            joinManifestRspecs();
        }
    };
    final ListChangeListener<Sliver> sliverListChangeListener = new ListChangeListener<Sliver>() {
        @Override
        public void onChanged(Change<? extends Sliver> change) {
//            System.out.println("DEBUG: slice "+Slice.this+" -> "+getUrn()+" detected that sliver list changed. list has now "+slivers.size()+" entries");
            while (change.next()) {
                for (Sliver sliver : change.getRemoved()) {
//                    System.out.println("DEBUG:    removing slice listeners to sliver "+sliver+" -> "+sliver.getUrn()+" @ "+sliver.getAuthority().getUrn());
                    sliver.statusProperty().removeListener(statusChangeListener);
                    sliver.manifestRspecProperty().removeListener(manifestRspecChangeListener);

                    manifestComponentManagers.remove(sliver.getAuthority().getUrnString());
                }
                for (Sliver sliver : change.getAddedSubList()) {
//                    System.out.println("DEBUG:    adding slice listeners to sliver "+sliver+" -> "+sliver.getUrn()+" @ "+sliver.getAuthority().getUrn());
                    sliver.statusProperty().addListener(statusChangeListener);
                    sliver.manifestRspecProperty().addListener(manifestRspecChangeListener);

                    manifestComponentManagers.add(sliver.getAuthority().getUrnString());
                }
            }
            updateStatus();
            LOG.debug("Sliver added or removed: joining manifests");
            joinManifestRspecs();
        }
    };
    private final StringProperty urn = new SimpleStringProperty();
    private final StringProperty auth = new SimpleStringProperty();
    private final StringProperty name = new SimpleStringProperty();
    private final StringProperty uuid = new SimpleStringProperty();
    private final StringProperty creator_uuid = new SimpleStringProperty();
    private final StringProperty creator_urn = new SimpleStringProperty();
    private final ObjectProperty<SliverStatus> status = new SimpleObjectProperty<SliverStatus>();
    /**
     * Component managers in manifests. This data is retreived by the Resolve slice call on the Slice Authority
     */
    private final ListProperty<String> manifestComponentManagers =
            new SimpleListProperty(FXCollections.observableArrayList());
    /**
     * Component managers that can be added to the request RSpec. This list is user controller: entries may be added and removed by the user.
     * It is a good practice to keep at least the ComponentManagers in requestComponentManagers and manifestComponentManagers in this list.
     */
    private final ListProperty<String> editorComponentManagers =
            new SimpleListProperty(FXCollections.observableArrayList());
    /**
     * Component managers used in the actual Rspec request.
     * The list should  be automatically updated if the user manually specifies component URN's in the RSpec details of a component.
     * The list should be updated if the user adds a node that is assigned to a component manager already
     */
    private final ListProperty<String> requestComponentManagers =
            new SimpleListProperty(FXCollections.observableArrayList());


    //stored in both String as RSpec format. Take great care! Sometimes, only 1 will be available, sometimes, both will be available.
    //Use the getters, they will create one if needed
    private final ObjectProperty<RequestRspecSource> requestRspec = new SimpleObjectProperty<>();

    //manifest Rspec is actually a join af manifest Rspec from multiple authorities/slivers!
    private final ObjectProperty<ManifestRspecSource> manifestRspec = new SimpleObjectProperty<>();
    private final ObjectProperty<Gid> gid = new SimpleObjectProperty<Gid>();
    private final ObjectProperty<Date> expirationDate = new SimpleObjectProperty<Date>();
    private final ObjectProperty<AnyCredential> credential = new SimpleObjectProperty<AnyCredential>();
    private ListProperty<Sliver> slivers = new SimpleListProperty(FXCollections.observableArrayList());
    private EasyModel easyModel;
    private List<String> allReceivedRspecString = new ArrayList<String>();

    /**
     * constructor is limited to package, use EasyModel to get Slices
     */
    Slice(String urn, EasyModel easyModel) {
        this.easyModel = easyModel;
        this.urn.setValue(urn);
        GeniUrn geniUrn = GeniUrn.parse(urn);
        if (geniUrn != null) {
            this.auth.setValue(geniUrn.getTopLevelAuthority());
            this.name.setValue(geniUrn.getResourceName());
        } else {
            LOG.error("Urn is not valid: \"" + urn + "\"");
        }

        //automatically listen to sliver all status
        slivers.addListener(sliverListChangeListener);

        this.credential.addListener(new ChangeListener<AnyCredential>() {
            @Override
            public void changed(ObservableValue<? extends AnyCredential> observableValue, AnyCredential oldGeniCredential, AnyCredential newGeniCredential1) {
                Slice.this.easyModel.getParameterHistoryModel().addSliceCredential(new CredentialInfo(newGeniCredential1));
            }
        });
    }


    /**
     * constructor is limited to package, use EasyModel to get Slices
     */
    Slice(String urn, AnyCredential credential, EasyModel easyModel) {
        this(urn, easyModel);
        this.credential.set(credential);
    }

    //helpers
    private static boolean updateStatusHelper_takesPriorityOver(SliverStatus status1, SliverStatus status2) {
        return updateStatusHelper_priority(status1) > updateStatusHelper_priority(status2);
    }

    private static int updateStatusHelper_priority(SliverStatus status) {
//                    order of priority of states when aggregating them
//                  0  UNINITIALISED, /* nothing known about status*/
//                  1      READY,
//                  2      UNALLOCATED,   /* known not to exist */
//                  3      UNKNOWN,       /* known to exist, but no status known. probably it is changing. */
//                  4      CHANGING,
//                  5      FAIL;

        //returns priority of a status
        switch (status) {
            case UNINITIALISED:
                return 0;
            case READY:
                return 1;
            case UNALLOCATED:
                return 2;
            case UNKNOWN:
                return 3;
            case CHANGING:
                return 4;
            case FAIL:
                return 5;
            default:
                throw new RuntimeException("BUG: updateStatusHelper_priority Unhandled status: " + status);
        }
    }

    private void updateStatus() {
        //do not use list of slivers if a manifest is present: use list of auth's in manifest in that case, and fail if any is unallocated

//        System.out.println("DEBUG: slice.updateStatus() called");
        //create aggregated status
        SliverStatus newStatus = SliverStatus.UNINITIALISED;
        if (slivers.isEmpty()) {
            newStatus = SliverStatus.UNALLOCATED;
            status.set(newStatus);
            return;
        }

        //use any rspec found as base. Prefer request rspec, then joined manifest, and finally any individual manifest
        //note that some AM's return only their nodes in the manfiest
        RspecSource anyRspec = null;
        if (anyRspec == null)
            for (Sliver sliver : slivers)
                if (sliver.getRequestRspec() != null) {
                    anyRspec = new RequestRspecSource(sliver.getRequestRspec().getStringContent());
                }
        if (anyRspec == null && manifestRspec.get() != null)
            anyRspec = manifestRspec.get();
        if (anyRspec == null)
            for (Sliver sliver : slivers)
                if (sliver.getManifestRspec() != null) {
                    anyRspec = new RequestRspecSource(sliver.getManifestRspec().getStringContent());
                }

        boolean statusUpToDate = false;
        if (anyRspec == null) {
            statusUpToDate = false;
        } else {
            statusUpToDate = true;


            //special case: consider UNALLOCATED as FAIL, unless all slivers are unallocated or uninitialised
            boolean allUnallocated = true;
            for (String cmUrn : anyRspec.getAllComponentManagerUrns()) {
                SfaAuthority rspecAuth = easyModel.getAuthorityList().getAuthorityListModel().getByUrn(cmUrn);
                if (rspecAuth == null)
                    continue;
                assert rspecAuth != null;
                List<Sliver> sliversForAuth = findSlivers(rspecAuth);
                for (Sliver sliver : sliversForAuth) {
                    SliverStatus sliverStatus = sliver.getStatus();
                    if (sliverStatus != SliverStatus.UNALLOCATED && sliverStatus != SliverStatus.UNINITIALISED)
                        allUnallocated = false;
                }

            }

            for (String cmUrn : anyRspec.getAllComponentManagerUrns()) {
                SfaAuthority rspecAuth = easyModel.getAuthorityList().getAuthorityListModel().getByUrn(cmUrn);
                if (rspecAuth == null) {
                    System.err.println("rspec manifest contained cm urn \"" + cmUrn + "\". But that urn is unknown!");
                    statusUpToDate = false; //will cause other slivers to be taken into account AS WELL
                } else {
                    assert rspecAuth != null;
                    List<Sliver> sliversForAuth = findSlivers(rspecAuth);

                    if (sliversForAuth.isEmpty()) {
                        //this is equal to state "UNALLOCATED"  (note: it will probably never occur)
                        SliverStatus sliverStatus;
                        if (allUnallocated)
                            sliverStatus = SliverStatus.UNALLOCATED;
                        else
                            sliverStatus = SliverStatus.FAIL;

                        if (updateStatusHelper_takesPriorityOver(sliverStatus, newStatus))
                            newStatus = sliverStatus;
                    }

                    for (Sliver sliver : sliversForAuth) {
                        SliverStatus sliverStatus = sliver.getStatus();
                        if (sliverStatus == SliverStatus.UNALLOCATED && !allUnallocated)
                            sliverStatus = SliverStatus.FAIL;

                        if (updateStatusHelper_takesPriorityOver(sliverStatus, newStatus))
                            newStatus = sliverStatus;
                    }
                }
            }
        }

        if (!statusUpToDate)
            for (Sliver sliver : slivers) {
                //UNALLOCATED is not FAIL here, as slivers that have nothing to do with manifest may be included
                SliverStatus sliverStatus = sliver.getStatus();
                if (updateStatusHelper_takesPriorityOver(sliverStatus, newStatus))
                    newStatus = sliverStatus;
            }

//        System.out.println("DEBUG: slice.updateStatus()   aggregated status = "+newStatus);
        status.set(newStatus);
    }

    public EasyModel getEasyModel() {
        return easyModel;
    }

    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public String getAuthorityName() {
        return auth.get();
    }

    public StringProperty authorityProperty() {
        return auth;
    }

    public GeniUrn getUrn() {
        return GeniUrn.parse(urn.get());
    }

    public String getUrnString() {
        return urn.get();
    }

    public StringProperty urnProperty() {
        return urn;
    }

    public boolean hasCredential() {
        return credential != null;
    }

    public AnyCredential getCredential() {
        return credential.get();
    }

    public void setCredential(AnyCredential credential) {
//        AnyCredential orig = this.credential;
        this.credential.set(credential);
//        if (!orig.equals(this.credential))
//            fireSliceChanged();
    }

    public ObjectProperty<AnyCredential> credentialProperty() {
        return credential;
    }

    public String getUuid() {
        return uuid.get();
    }

    public StringProperty uuidProperty() {
        return uuid;
    }

    public String getCreator_uuid() {
        return creator_uuid.get();
    }

    public StringProperty creator_uuidProperty() {
        return creator_uuid;
    }

    public String getCreator_urn() {
        return creator_urn.get();
    }

    public StringProperty creator_urnProperty() {
        return creator_urn;
    }

    public Gid getGid() {
        return gid.get();
    }

    public void setGid(Gid gid) {
        this.gid.set(gid);
    }

    public ObjectProperty<Gid> gidProperty() {
        return gid;
    }

    public ObservableList<String> getRequestComponentManagers() {
        return requestComponentManagers.get();
    }

    public ListProperty<String> requestComponentManagersProperty() {
        return requestComponentManagers;
    }

    public ObservableList<String> getEditorComponentManagers() {
        return editorComponentManagers.get();
    }

    public ListProperty<String> editorComponentManagersProperty() {
        return editorComponentManagers;
    }

    public ObservableList<String> getManifestComponentManagers() {
        return manifestComponentManagers.get();
    }

    public ListProperty<String> manifestComponentManagersProperty() {
        return manifestComponentManagers;
    }

    public SliverStatus getStatus() {
        return status.get();
    }

    public void setStatus(SliverStatus status) {
        this.status.set(status);
    }

    public ObjectProperty<SliverStatus> statusProperty() {
        return status;
    }

//    public ObjectProperty<ModelRspec> manifestRspecProperty() {
//        return manifestRspec;
//    }

    public List<String> getAllLastReceivedRspecString() {
        return allReceivedRspecString;
    }

    private void joinManifestRspecs() {
        LOG.debug("joinManifestRspecs()");
        //always need to recreate the joined RSpec, as parts may have changed, or been deleted
        ManifestRspecSource joined = null;

        for (Sliver sliver : slivers) {
            //use request as base manifest for merging (since real manifests might not contain nodes from all cm's)
            if (joined == null && sliver.getRequestRspec() != null) {
                joined = new ManifestRspecSource(sliver.getRequestRspec().getStringContent());
                LOG.debug("starting from request");
            }
        }

        allReceivedRspecString.clear();
        for (Sliver sliver : slivers) {
            SfaAuthority auth = sliver.getAuthority();
            RSpecInfo sliverManifestRspec = sliver.getManifestRspec();
            if (sliverManifestRspec != null) {
                LOG.debug("joining with sliver from " + auth.getName());
                allReceivedRspecString.add(sliverManifestRspec.getStringContent());
                if (joined == null) {
                    assert sliverManifestRspec.getStringContent() != null;
                    joined = new ManifestRspecSource(sliverManifestRspec.getStringContent());
                    LOG.debug("started with single manifest Rspec");
                } else {
                    joinManifestRspecs(joined, auth, sliverManifestRspec);
                    LOG.debug("joining with another manifest Rspec");
                }
            } else
                LOG.debug("No sliver manifest from " + auth.getName());
        }

        LOG.debug("updating manifestRequest property");
        if (LOG.isDebugEnabled()) {
            if (joined != null && joined.getModelRspec() != null && joined.getModelRspec().getNodes() != null) {
                LOG.debug("   nodes in joined rspec: ");
                for (RspecNode node : joined.getModelRspec().getNodes()) {
                    LOG.debug("       - node id=\"" + node.getId() + "\" comp_id=\"" + node.getComponentId() + "\" manager=\"" + node.getComponentManagerId() + "\"" +
                            " loginservices=" + node.getLoginServices().size());
                }
            } else {
                if (joined != null && joined.getModelRspec() != null)
                    LOG.debug("   no nodes in joined rspec: " + (joined == null ? "null"
                        : (joined.getModelRspec().getNodes() == null ? "ptr->null" : joined.getModelRspec().getNodes().size() + "")));
                else
                    LOG.debug("   no nodes in joined rspec");
            }
        }
        manifestRspec.set(joined);
    }

    private void joinManifestRspecs(ManifestRspecSource mergedRspec, SfaAuthority auth, RSpecInfo manifestRspec) {
//        System.out.println("DEBUG       joinManifestRspecs() from "+auth.getName());
        ModelRspec manifestModelRspec;
        try {
            manifestModelRspec = manifestRspec.getRSpec().getModelRspec();
        } catch (InvalidRspecException ex) {
            LOG.error("Could not parse request rSpec - aborting join", ex);
            return;
        }
        if (manifestModelRspec == null) {
            //TODO: we should join without using ModelRspec, by just using StringRspec s
            LOG.error("Could not parse request rSpec - aborting join");
            return;
        }
        ModelRspec mergedModelRspec;
        mergedModelRspec = mergedRspec.getModelRspec();
        if (mergedModelRspec == null) {
            //TODO: we should join without using ModelRspec, by just using StringRspec s
            LOG.error("Could not parse request mergedRspec - aborting join");
            return;
        }
        for (RspecNode node : manifestModelRspec.getNodes())
            if (node.getComponentManagerId().equals(auth.getUrnString())) {
                RspecNode existingNode = mergedModelRspec.getNodeById(node.getId());
                if (existingNode == null) {
                    LOG.debug("joinManifestRspecs: adding node " + node.getId() + " at " + node.getComponentManagerId());
                    existingNode = new RspecNode(node.getId());
                    mergedModelRspec.getNodes().add(existingNode);
                } else
                    LOG.debug("joinManifestRspecs: joining node " + node.getId() + " at " + node.getComponentManagerId());
                assert node.getXmlManifestNodeContents() != null;
                existingNode.setPropertiesFromGeni3ManifestRspec(node.getXmlManifestNodeContents());
            } else
                LOG.debug("joinManifestRspecs: NOT joining node " + node.getId() + " at " + node.getComponentManagerId());
        for (RspecLink link : manifestModelRspec.getLinks())
            if (link.getComponentManagerUrns().contains(auth.getUrnString())) { //Note: this overwrites, because 2 component managers will have the link if they share 1!
                RspecLink existingLink = mergedModelRspec.getLinkById(link.getId());
                if (existingLink == null) {
                    existingLink = new RspecLink(mergedModelRspec, link.getId());
                    mergedModelRspec.getLinks().add(existingLink);
                }
                assert link.getXmlManifestLinkContents() != null;
                existingLink.setPropertiesFromGeni3ManifestRspec(link.getXmlManifestLinkContents());
            }
    }

    public void addSliver(Sliver sliver) {
        slivers.add(sliver);
//        fireSliceChanged();
    }

    public void removeSliver(Sliver sliver) {
        //clear the status of a removed sliver
        sliver.setStatusString("sliver removed");
        sliver.setStatus(SliverStatus.UNALLOCATED);
        sliver.setManifestRspec(null);
        slivers.remove(sliver);
//        fireSliceChanged();
    }

    public ReadOnlyListProperty<Sliver> getSlivers() {
        return slivers;
    }

    public List<Sliver> findSlivers(SfaAuthority auth) {
        List<Sliver> res = new ArrayList<Sliver>();
        for (Sliver sliver : slivers)
            if (sliver.getAuthority() != null && sliver.getAuthority().equals(auth))
                res.add(sliver);
        return res;
    }

    public Sliver findSliver(String sliverUrn) {
        for (Sliver sliver : slivers)
            if (sliver.getUrn() != null) {
                if (sliver.getUrn().equals(sliverUrn))
                    return sliver;
            } else {
                //TODO this is a hack that works for AMv2.
                //    Problem is that the sliver URN is not known after the createSliver command in AMv2.
                //    For AMv3, this should not be needed as the sliver urn is known quickly I think
                //         it will cause bugs for AMv3 if multiple slivers for the same slice are on an AM (which is not supported in AMv2)
                String urnStart = "urn:publicid:IDN+" + sliver.getAuthority().getNameForUrn() + "+sliver+";
                if (sliverUrn.startsWith(urnStart)) {
                    sliver.setUrn(sliverUrn);
                    return sliver;
                }

            }
        return null;
    }

    public Sliver findSliverFromAuthorityUrn(GeniUrn authorityUrn) {
        for (Sliver sliver : slivers)
            if (sliver.getAuthority() != null && sliver.getAuthority().getUrn() != null) {
                if (sliver.getAuthority().getUrn().equals(authorityUrn))
                    return sliver;
            }
//            else {
//                //TODO this is a hack that works for AMv2.
//                //    Problem is that the sliver URN is not known after the createSliver command in AMv2.
//                //    For AMv3, this should not be needed as the sliver urn is known quickly I think
//                //         it will cause bugs for AMv3 if multiple slivers for the same slice are on an AM (which is not supported in AMv2)
//                String urnStart = "urn:publicid:IDN+"+sliver.getAuthority().getNameForUrn()+"+sliver+";
//                if (sliverUrn.startsWith(urnStart)) {
//                    sliver.setUrn(sliverUrn);
//                    return sliver;
//                }
//
//            }
        return null;
    }

    public Date getExpirationDate() {
        return expirationDate.get();
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate.set(expirationDate);
    }

    public ObjectProperty<Date> expirationDateProperty() {
        return expirationDate;
    }


    public RequestRspecSource getRequestRspec() {
        return requestRspec.get();
    }
    public void setRequestRspec(RequestRspecSource rspec) {
        requestRspec.set(rspec);
    }


    public ManifestRspecSource getManifestRspec() {
        return manifestRspec.get();
    }
}
