package be.iminds.ilabt.jfed.highlevel.model;

/**
 * SliverListener
 */
public interface SliverListener {
    public void onSliverChanged(Sliver sliver);
}
