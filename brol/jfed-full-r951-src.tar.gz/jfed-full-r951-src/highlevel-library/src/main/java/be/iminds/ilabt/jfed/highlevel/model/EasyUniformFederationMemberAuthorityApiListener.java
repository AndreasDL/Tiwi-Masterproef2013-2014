package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.log.ApiCallDetails;
import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.GeniUserProvider;
import be.iminds.ilabt.jfed.lowlevel.api.FederationMemberAuthorityApi1;
import be.iminds.ilabt.jfed.util.GeniUrn;
import javafx.application.Platform;

import java.util.List;
import java.util.Map;

/**
 * EasyModelSliceAuthorityListener: this watches for SliceAuthority calls and fills in EasyModel using the info in them
 */
public class EasyUniformFederationMemberAuthorityApiListener extends EasyModelAbstractListener {
    private GeniUserProvider geniUserProvider;

    public EasyUniformFederationMemberAuthorityApiListener(EasyModel model, GeniUserProvider geniUserProvider) {
        super(model);
        this.geniUserProvider = geniUserProvider;
    }

    private void onGetCredentials(ApiCallDetails result) {
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            //store first user credential
            List<AnyCredential> userCredentials = (List<AnyCredential>) result.getReply().getValue();
            if (userCredentials != null && userCredentials.size() > 0)
                model.setUserCredential(userCredentials.get(0));
        }
    }

    private void onLookupKeys(ApiCallDetails result) {
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            Map<GeniUrn, List<Map<String, Object>>> lookupResult = (Map<GeniUrn, List<Map<String, Object>>>) result.getReply().getValue();

            for (GeniUrn userUrn : lookupResult.keySet()) {
                List<Map<String, Object>> userKeys = lookupResult.get(userUrn);
                for (Map<String, Object> keyInfo : userKeys) {
                    if (keyInfo.containsKey("KEY_PUBLIC")) {

                        //TODO check which member key is for     (probably possible after API has changed)
                        //  currently assumes it's the logged in users key

                        String pubKey = (String) keyInfo.get("KEY_PUBLIC");

                        //if key is for logged in user, store it
                        if (geniUserProvider != null &&
                                geniUserProvider.isUserLoggedIn() &&
                                userUrn.equals(geniUserProvider.getLoggedInGeniUser().getUserUrn()))
                            model.addUserKey((String)pubKey);
                    }
                }
            }
        }
    }



    @Override
    public void onResult(final ApiCallDetails details) {
        assert Platform.isFxApplicationThread();
        onResultInJavaFXThread(details);
    }
    public void onResultInJavaFXThread(ApiCallDetails result) {
        //ignore errors here
        if (result.getReply() == null || result.getJavaMethodName() == null)
            return;

        if (!result.getApiName().equals(FederationMemberAuthorityApi1.getApiName()))
            return;

        try {
            if (result.getJavaMethodName().equals("lookupKeys"))
                onLookupKeys(result);

            if (result.getJavaMethodName().equals("getCredentials"))
                onGetCredentials(result);

        } catch (Exception e) {
            System.err.println("WARNING: Exception when processing SliceAuthority reply for EasyModel. This will be ignored, but it is most likely a bug. " + e.getMessage());
            e.printStackTrace();
        }
    }
}
