package be.iminds.ilabt.jfed.highlevel.controller;

import be.iminds.ilabt.jfed.log.ApiCallDetails;
import be.iminds.ilabt.jfed.log.ResultListener;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * */
public class SingleTask implements ResultListener {
    private static final AtomicInteger taskUniqueIdHelper = new AtomicInteger();

    protected final Task task;
    protected final String name;
    protected final String id;
    protected TaskState state;

    protected Throwable exception = null;
    protected final List<ApiCallDetails> apiCallHistory = new ArrayList<>();
    protected JavaFXTaskThread.SingleTask javafx;
    private boolean canceledByUser = false;
    private Date runStart;
    private Date runStop;
    private Thread thread;
    /*
    * These are resolved dependencies, with only the actually needed onces added.
    *
    * The task can be queued and run once all these dependencies are SUCCESS.
    * The task fails if any one of these FAILED.
    *
    * The difference between initDependsOn() and initAlwaysDependsOn() has been processed into this once list:
    *    - initDependsOn() deps will depend on the original SingleTask associated with this task
    *    - initAlwaysDependsOn() deps will depend on the original one only if it is not yet succesful. It it is done already, they will make a new one.
    * */
    private final List<SingleTask> dependsOn = new ArrayList<SingleTask>();
    private final List<SingleTask> dependingOnThis = new ArrayList<SingleTask>();

    public SingleTask(Task task) {
        this.task = task;
        this.name = task.getName();
        this.id = "" + taskUniqueIdHelper.getAndIncrement();
        state = TaskState.UNSUBMITTED;
    }

    Thread getThread() {
        return thread;
    }

    public List<SingleTask> getDependsOn() {
        return dependsOn;
    }

    public List<SingleTask> getDependingOnThis() {
        return dependingOnThis;
    }

    @Override
    public void onResult(ApiCallDetails result) {
        apiCallHistory.add(result);
    }

    public List<ApiCallDetails> getApiCallHistory() {
        return apiCallHistory;
    }

    public boolean canRun() {
        for (SingleTask dep : dependsOn) {
            if (dep.state != TaskState.SUCCESS) return false;
        }
        return true;
    }

    public boolean mustFail() {
        for (SingleTask dep : dependsOn) {
            if (dep.state == TaskState.FAILED || dep.state == TaskState.CANCELLED) return true;
        }
        return false;
    }

    public boolean isCanceledByUser() {
        return canceledByUser;
    }

    void setCanceledByUser(boolean canceledByUser) {
        this.canceledByUser = canceledByUser;
    }

    public Date getRunStart() {
        return runStart;
    }

    public Date getRunStop() {
        return runStop;
    }

    public TaskState getState() {
        return state;
    }

    public void setState(TaskState newState) {
        state = newState;
    }

    public boolean isCompleted() {
        return state.equals(TaskState.FAILED) || state.equals(TaskState.SUCCESS) || state.equals(TaskState.CANCELLED);
    }

    //These are used to set the actual start and stop time. It cannot be done directly, because this is not called on a JavaFX thread!
    void registerRunStart() {
        assert runStart == null;
        final Date now = new Date();
        runStart = now;
    }

    void registerRunStop() {
        assert runStop == null;
        final Date now = new Date();
        runStop = now;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public Throwable getException() {
        return exception;
    }

    public String toString() {
        String deps = "";
        for (SingleTask dep : dependsOn) {
            if (!deps.isEmpty()) deps += ", ";
            deps += "\"" + dep.name + "\" " + dep.state;
        }
        return "SingleTask(" + id + " \"" + getName() + "\" " + state + ", deps={" + deps + "})";
    }

    void setThread(Thread thread) {
        this.thread = thread;
    }

    public static enum TaskState {UNSUBMITTED, BLOCKED, QUEUED, RUNNING, FAILED, FUTURE, SUCCESS, CANCELLED}
}
