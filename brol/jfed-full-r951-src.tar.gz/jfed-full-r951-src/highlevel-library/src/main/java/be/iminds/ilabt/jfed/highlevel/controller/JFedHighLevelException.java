package be.iminds.ilabt.jfed.highlevel.controller;

/**
* User: twalcari
* Date: 12/11/13
* Time: 10:43 AM
*/
public class JFedHighLevelException extends Exception{
    public JFedHighLevelException(String message) {
        super(message);
    }

    public JFedHighLevelException() {
    }
}
