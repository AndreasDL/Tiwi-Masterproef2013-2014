package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.log.ApiCallDetails;
import be.iminds.ilabt.jfed.lowlevel.GeniAMResponseCode;
import be.iminds.ilabt.jfed.lowlevel.api.AggregateManager2;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.rspec.model.InvalidRspecException;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.util.GeniUrn;
import javafx.application.Platform;
import org.apache.logging.log4j.LogManager;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * EasyModelSliceAuthorityListener: this watches for SliceAuthority calls and fills in EasyModel using the info in them
 */
public class EasyModelAggregateManager2Listener extends EasyModelAbstractListener {
    private final static org.apache.logging.log4j.Logger LOG = LogManager.getLogger();
    private static boolean debug = false;

    public EasyModelAggregateManager2Listener(EasyModel model) {
        super(model);
    }

    private List<String> getSliceUrns(List<String> urns) {
        List<String> res = new ArrayList<String>();
        for (String u : urns) {
            GeniUrn geniUrn = GeniUrn.parse(u);
            if (geniUrn != null && geniUrn.getResourceType().equals("slice"))
                res.add(u);
        }
        return res;
    }

    private List<String> getSliverUrns(List<String> urn) {
        List<String> res = new ArrayList<String>();
        for (String u : urn) {
            GeniUrn geniUrn = GeniUrn.parse(u);
            if (geniUrn != null && geniUrn.getResourceType().equals("sliver"))
                res.add(u);
        }
        return res;
    }

    private void onGetVersionResult(ApiCallDetails result) {
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            //TODO
        }
    }

    public void onStatusResult(String sliceUrn, AggregateManager2.SliverStatus statusInfo, SfaAuthority auth) {
        Slice slice = model.logExistSlice(sliceUrn);
        assert slice != null;

//        Sliver sliver = model.logExistSliver(sliceUrn, statusInfo.getUrn(), true/*geni_single is true for AMv2*/); //since success is returned, the sliver must exist  //note: the urn in the status info is not (always) a sliver urn
        Sliver sliver =
                model.logExistSliverGeniSingle(sliceUrn, auth); //since success is returned, the sliver must exist
        assert sliver != null;

        assert sliver.getAuthority() == auth :
                "sliver.getAuthority()=" + sliver.getAuthority().getUrnString() + " != auth=" + auth.getUrnString();

        if (debug)
            System.out.println("DEBUG: EasyModelAggregateManager2Listener.onStatusResult is changing slice " + slice.getName() + " sliver @ " + auth.getName() + " status from " + sliver.getStatusString() + " to " + statusInfo.getStatus());

        assert statusInfo.getStatus() != null;
        sliver.setStatusString(statusInfo.getStatus());
        boolean knownStatus = false;
        if (statusInfo.getStatus().equals("configuring")) {
            sliver.setStatus(SliverStatus.CHANGING);
            knownStatus = true;
        }
        if (statusInfo.getStatus().equals("unknown")) {
            sliver.setStatus(SliverStatus.UNKNOWN);
            knownStatus = true;
        }
        if (statusInfo.getStatus().equals("changing")) {
            sliver.setStatus(SliverStatus.CHANGING);
            knownStatus = true;
        }
        if (statusInfo.getStatus().equals("notready")) {
            sliver.setStatus(SliverStatus.CHANGING);
            knownStatus = true;
        }
        if (statusInfo.getStatus().equals("ready")) {
            sliver.setStatus(SliverStatus.READY);
            knownStatus = true;
        }
        if (statusInfo.getStatus().equals("failed")) {
            sliver.setStatus(SliverStatus.FAIL);
            knownStatus = true;
        }
        if (!knownStatus) {
            System.err.println("WARNING: unknown status received from AM: " + statusInfo.getStatus());
            sliver.setStatus(SliverStatus.UNKNOWN);
        }
    }

    public void seeAdvertisementRspec(SfaAuthority auth, boolean available, String rspec) {
        LOG.trace("EasyModelAggregateManager2Listener.seeAdvertisementRspec(" + auth.getName() + ", " + available + ", rspec.length=" + rspec.length() + ")");
        AuthorityInfo ai = model.getAuthorityList().get(auth);
        ai.setAdvertisementRspec(available, rspec);
    }

//    public void seeRequestRspec(SfaAuthority auth, String sliceUrn, List<String> sliverUrns, String rspec) {
//        model.getRSpecList().seeRequestRspec(auth, sliceUrn, sliverUrns, rspec);
//    }
//
//    public void seeEchoRequestRspec(SfaAuthority auth, String sliceUrn, List<String> sliverUrns, String rspec) {
//        model.getRSpecList().seeEchoRequestRspec(auth, sliceUrn, sliverUrns, rspec);
//    }

    /**
     * seeing a manifest rspec also means that the sliver exists.
     */
    public void seeManifestRspec(SfaAuthority auth, String sliceUrn, String manifestRspecString) {
        Slice slice = model.getSlice(sliceUrn);
        if (slice == null) return;
        Sliver sliver =
                model.logExistSliverGeniSingle(sliceUrn, auth); //since success is returned, the sliver must exist
        List<Sliver> sliverList = new ArrayList<Sliver>();
        sliverList.add(sliver);

        //////// HACK for PLE ////////
        if (manifestRspecString.contains("component_manager_id=\"urn:publicid:IDN+ple+authority+cm\"")) {
            manifestRspecString = manifestRspecString.replaceAll(
                    Pattern.quote("urn:publicid:IDN+ple+authority+cm"),
                    Matcher.quoteReplacement("urn:publicid:IDN+ple:ibbtple+authority+cm"));
            LOG.warn("Using PLE hack in EasyModelAggregateManager2Listener#seeManifestRspec. succesfully applied: " +
                    (!manifestRspecString.contains("component_manager_id=\"urn:publicid:IDN+ple+authority+cm\"")));
            assert !manifestRspecString.contains("component_manager_id=\"urn:publicid:IDN+ple+authority+cm\"") :
                    "HACK applied unsuccessfully to:\n" + manifestRspecString;
        }
        //////// HACK for PLE ////////


        RSpecInfo rSpecInfo =
                new RSpecInfo(manifestRspecString, RSpecInfo.RspecType.MANIFEST, slice, sliverList, model.getAuthorityList().get(auth));
        LOG.debug("EasyModelAggregateManager2Listener seeManifestRspec is setting manifest for " + slice + " -> " + sliceUrn + "  " + sliver + " -> " + sliver.getUrn());
        sliver.setManifestRspec(rSpecInfo);

        //sliver exists on all cm's mentioned in manifest. (even if unallocated on others)
        try {
            for (String cmUrn : rSpecInfo.getRSpec().getAllComponentManagerUrns()) {
                SfaAuthority rspecAuth = model.getAuthorityList().getAuthorityListModel().getByUrn(cmUrn);
                if (rspecAuth == null) {
                    LOG.error("Error in manifest: contained an unknown authority urn: \"" + cmUrn + "\"");
                    continue;
                }
                model.logExistSliverGeniSingle(sliceUrn, rspecAuth); //it is in manifest, so the sliver must exist (even if it is unallocated)
            }
        } catch (InvalidRspecException ex) {
            LOG.error("Error while processing Rspec XML", ex);
        }
    }

    /**
     * process the result, in the JavaFX thread. And wait for it in this thread.
     */
    @Override
    public void onResult(final ApiCallDetails details) {
//        final Lock lock = new ReentrantLock();
//        final Condition waiter = lock.newCondition();
//
//        Platform.runLater(new Runnable() { @Override public void run() {
//            onResultInJavaFXThread(details);
//            lock.lock();
//            waiter.signalAll();
//            lock.unlock();
//        } });
//
//        lock.lock();
//        try {
//            waiter.await();
//        } catch (InterruptedException e) {
//            //TODO: handle?
//            e.printStackTrace();
//        }
//        lock.unlock();

        assert Platform.isFxApplicationThread();
        onResultInJavaFXThread(details);
    }

    public void onResultInJavaFXThread(ApiCallDetails details) {
        if (debug)
            System.out.println("EasyModelAggregateManager2Listener onResultInJavaFXThread SfaCommand=\"" + details.getGeniMethodName() + "\" javaCommand=\"" + details.getJavaMethodName() + "\"");

        //ignore errors here
        if (details.getReply() == null || details.getJavaMethodName() == null)
            return;

        if (!details.getApiName().equals(AggregateManager2.getApiName()))
            return;

        try {
            if (details.getJavaMethodName().equals("getVersion")) //returns VersionInfo
                onGetVersionResult(details);

            if (details.getJavaMethodName().equals("listResources") && !details.getMethodParameters().containsKey("sliceUrn")) { //returns String (rspec)
                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    String rspec = (String) details.getReply().getValue();
                    boolean available = false;
                    if (details.getMethodParameters().get("available") != null)
                        available = (Boolean) details.getMethodParameters().get("available");
                    seeAdvertisementRspec(details.getAuthority(), available, rspec);
                }
            }

            if (details.getJavaMethodName().equals("listResources") && details.getMethodParameters().containsKey("sliceUrn")) { //returns String (rspec)
                String sliceUrn = (String) details.getMethodParameters().get("sliceUrn");
                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    LOG.debug("EasyModelAggregateManager2Listener sees successful ListResources call with sliceUrn");
                    String rspec = (String) details.getReply().getValue();
                    boolean available = false;
                    if (details.getMethodParameters().get("available") != null)
                        available = (Boolean) details.getMethodParameters().get("available");
                    model.logExistSlice(sliceUrn); //since success is returned, the slice must exist
                    model.logExistSliverGeniSingle(sliceUrn, details.getAuthority()); //since success is returned, the sliver must exist
                    seeManifestRspec(details.getAuthority(), sliceUrn, rspec);
                } else {
                    LOG.debug("EasyModelAggregateManager2Listener sees failed ListResources call with sliceUrn");
                    if (details.getReply().getGeniResponseCode().equals(GeniAMResponseCode.GENIRESPONSE_SEARCHFAILED)) {
                        //since searchfailed is returned, the sliver must not exist
                        model.logNotExistSliverGeniSingle(sliceUrn, details.getAuthority());
                    }
                }
            }

            if (details.getJavaMethodName().equals("createSliver")) { //returns AllocateAndProvisionInfo
                if (debug)
                    System.out.println("EasyModelAggregateManager2Listener onResultInJavaFXThread CreateSliver success=" + details.getReply().getGeniResponseCode().isSuccess());
                String sliceUrn = (String) details.getMethodParameters().get("sliceUrn");
                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    Slice slice = model.logExistSlice(sliceUrn);
                    Sliver sliver =
                            model.logExistSliverGeniSingle(sliceUrn, details.getAuthority()); //since success is returned, the sliver must exist

                    //also process request Rspec. Just create the slivers that exist in it.
                    if (details.getMethodParameters().get("rspec") != null) {
                        String rspecRequestString = details.getMethodParameters().get("rspec").toString();
                        ModelRspec rspecRequest = ModelRspec.fromGeni3RequestRspecXML(rspecRequestString);

                        List<Sliver> slivers = new ArrayList<Sliver>();
                        for (String cmUrn : rspecRequest.getAllComponentManagerUrns()) {
//                            SfaAuthority rspecAuth = model.getAuthorityList().getByUrn(cmUrn).getSfaAuthority(); //might not be up to date!
                            SfaAuthority rspecAuth = model.getAuthorityList().getAuthorityListModel().getByUrn(cmUrn);
                            Sliver requestSliver =
                                    model.logExistSliverGeniSingle(sliceUrn, rspecAuth); //it is in request, so the sliver must exist (even if it is unallocated)
                            slivers.add(requestSliver);
                        }
                        RSpecInfo rspecRequestInfo = new RSpecInfo(
                                rspecRequestString,
                                RSpecInfo.RspecType.REQUEST,
                                slice, slivers,
                                null /*authority */,
                                rspecRequest);
                        for (Sliver requestSliver : slivers)
                            requestSliver.setRequestRspec(rspecRequestInfo);
                    }

                    String manifestRspec = (String) details.getReply().getValue();
                    LOG.trace("EasyModelAggregateManager2Listener sets manifest Rspec on CreateSliver");
                    seeManifestRspec(details.getAuthority(), sliceUrn, manifestRspec);

                    sliver.setStatus(SliverStatus.UNKNOWN); //no specific status known. May be changing, failed or ready
                    sliver.setStatusString("CreateSliver successful");
                } else {
                    //allocate failed!
//                    Slice slice = model.logExistSlice(sliceUrn);
//                    assert slice != null;
//                    List<Sliver> slivers = slice.findSlivers(details.getAuthority());
//
//                    if (slivers.isEmpty()) {
                    //sliver creation failed
                    Sliver sliver =
                            model.logExistSliverGeniSingle(sliceUrn, details.getAuthority()); //since success is returned, the sliver must exist

                    sliver.setStatus(SliverStatus.FAIL);
                    sliver.setStatusString("CreateSliver failed");
//                    } else {
//                       //sliver creation failed because sliver already existed?
//                    }
                }
            }

            if (details.getJavaMethodName().equals("sliverStatus")) // returns SliverStatus
            {
                String sliceUrn = (String) details.getMethodParameters().get("sliceUrn");
                if (debug)
                    System.out.println("EasyModelAggregateManager2Listener onResultInJavaFXThread sliverStatus slice=" + sliceUrn +
                            " at " + details.getAuthority().getName() +
                            " success=" + details.getReply().getGeniResponseCode().isSuccess());

                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    assert sliceUrn != null;

                    onStatusResult(sliceUrn, (AggregateManager2.SliverStatus) details.getReply().getValue(), details.getAuthority());
                } else {
                    if (details.getReply().getGeniResponseCode().equals(GeniAMResponseCode.GENIRESPONSE_SEARCHFAILED)) {
                        //since searchfailed is returned, the sliver must not exist
                        model.logNotExistSliverGeniSingle(sliceUrn, details.getAuthority());
                    }
                }
            }

            if (details.getGeniMethodName().equals("DeleteSliver") || details.getGeniMethodName().equals("Shutdown")) { //both return Boolean
                String sliceUrn = (String) details.getMethodParameters().get("sliceUrn");
                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    Boolean isDeleted = null;
                    if (details.getReply().getValue() instanceof Boolean)
                        isDeleted = (Boolean) details.getReply().getValue();
                    if (details.getReply().getValue() instanceof Integer)
                        isDeleted = ((Integer) details.getReply().getValue()) != 0;
                    if (details.getReply().getValue() instanceof String) {
                        String isDeletedString = (String) details.getReply().getValue();
                        if (isDeletedString.trim().equalsIgnoreCase("true") || isDeletedString.trim().equalsIgnoreCase("yes") || isDeletedString.trim().equalsIgnoreCase("1"))
                            isDeleted = true;
                        if (isDeletedString.trim().equalsIgnoreCase("false") || isDeletedString.trim().equalsIgnoreCase("no") || isDeletedString.trim().equalsIgnoreCase("0"))
                            isDeleted = false;
                    }
                    if (isDeleted == null)
                        LOG.error("call \"" + details.getGeniMethodName() + "\" returned unrecognized value. class=" +
                                details.getReply().getValue().getClass().getName() + " value=\"" + details.getReply().getValue().toString() + "\"");
                    if (isDeleted != null && isDeleted)
                        model.logNotExistSliverGeniSingle(sliceUrn, details.getAuthority());
                }
                if (details.getReply().getGeniResponseCode().equals(GeniAMResponseCode.GENIRESPONSE_SEARCHFAILED))
                    model.logNotExistSliverGeniSingle(sliceUrn, details.getAuthority());
            }

            if (details.getJavaMethodName().equals("renew")) { //returns List<SliverInfo>
                String sliceUrn = (String) details.getMethodParameters().get("sliceUrn");
                if (details.getReply().getGeniResponseCode().isSuccess()) {
//                    List<AggregateManager2.SliverInfo> si = (List<AggregateManager2.SliverInfo>) details.getReply().getValue();
//                    List<String> urns = (List<String>) details.getMethodParameters().get("urns");
//                    List<String> sliceUrns = getSliceUrns(urns);
//                    String sliceUrn = sliceUrns.size() != 1 ? null : sliceUrns.get(0);
//                    onListOfSliverInfoResult(sliceUrn, si);
                }
                if (details.getReply().getGeniResponseCode().equals(GeniAMResponseCode.GENIRESPONSE_SEARCHFAILED))
                    model.logNotExistSliverGeniSingle(sliceUrn, details.getAuthority());
            }
        } catch (Exception e) {
            System.err.println("WARNING: Exception when processing AggregateManager2 reply for EasyModel. This will be ignored, but it is most likely a bug. " + e.getMessage());
            e.printStackTrace();
        }
    }
}
