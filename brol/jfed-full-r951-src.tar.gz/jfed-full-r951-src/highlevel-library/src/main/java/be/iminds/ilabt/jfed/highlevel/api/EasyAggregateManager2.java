package be.iminds.ilabt.jfed.highlevel.api;

import be.iminds.ilabt.jfed.highlevel.model.AppModel;
import be.iminds.ilabt.jfed.highlevel.model.RSpecInfo;
import be.iminds.ilabt.jfed.highlevel.model.Slice;
import be.iminds.ilabt.jfed.highlevel.model.Sliver;
import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.lowlevel.api.AggregateManager2;
import be.iminds.ilabt.jfed.lowlevel.api.UserSpec;
import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityProvider;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnection;
import org.apache.logging.log4j.LogManager;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

/**
 * EasyAggregateManager2
 * <p/>
 * Important note: the model is being built by listening to logger data in another thread,
 * so model updates are not guaranteed to have completed when these calls return. These calls can also not return
 * any model object reliably for that reason.
 */
public class EasyAggregateManager2 {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    private GeniUserProvider geniUserProvider;
    private GeniConnectionProvider connectionProvider;
    private AuthorityProvider authorityProvider;
    private AggregateManager2 am;

    private final AppModel appModel;

    public EasyAggregateManager2(Logger logger, AppModel appModel, AuthorityProvider authorityProvider) {
        this.appModel = appModel;

        this.geniUserProvider = appModel.getGeniUserProvider();
        this.connectionProvider = appModel.getConnectionProvider();
        this.authorityProvider = authorityProvider;
        this.am = new AggregateManager2(logger);
    }

    public EasyAggregateManager2(Logger logger, AppModel appModel, GeniUserProvider geniUserProvider, final SfaAuthority auth) {
        this(logger, appModel, new AuthorityProvider() {
            @Override
            public SfaAuthority getAuthority() {
                return auth;
            }
        });
    }

    public XMLRPCCallDetails getLastLoggedResult() {
        return am.getLastXmlRpcResult();
    }

    private GeniUser getContext() {
        return geniUserProvider.getLoggedInGeniUser();
    }

    private SfaConnection getConnection() throws JFedException {
        return (SfaConnection) connectionProvider.getConnectionByAuthority(geniUserProvider.getLoggedInGeniUser(), authorityProvider.getAuthority(), new ServerType(ServerType.GeniServerRole.AM, 2));
    }

    public int getVersion() throws JFedException {
        AggregateManager2.AggregateManagerReply<AggregateManager2.VersionInfo> version = am.getVersion(getConnection());

        if (!version.getGeniResponseCode().isSuccess())
            throw new JFedException("Error in GetVersion: " + version.getGeniResponseCode() + " (" + version.getOutput() + ")", getLastLoggedResult(), version.getGeniResponseCode());

        return version.getValue().getApi();
    }

    public RSpecInfo listResources(boolean available) throws JFedException {
        List<AnyCredential> creds = new ArrayList<AnyCredential>();
        assert appModel.getEasyModel().getUserCredential() != null;
        creds.add(appModel.getEasyModel().getUserCredential());

        String rspecType = "geni";
        String rspecVersion = "3";

        AggregateManager2.AggregateManagerReply<String> res =
                am.listResources(getConnection(), creds,
                        rspecType, rspecVersion, available, true, null, null);

        if (!res.getGeniResponseCode().isSuccess())
            throw new JFedException("Error in ListResources: " + res.getGeniResponseCode() + " (" + res.getOutput() + ")", getLastLoggedResult(), res.getGeniResponseCode());

        return new RSpecInfo(res.getValue(), RSpecInfo.RspecType.ADVERTISEMENT, null /*slice*/, null /*slivers*/,
                appModel.getAuthorityList().get(getConnection().getGeniAuthority()));
    }

    public RSpecInfo listSliceResources(Slice slice) throws JFedException {
        if (slice.getCredential() == null)
            throw new RuntimeException("Slice credential not known");

        List<AnyCredential> creds = new ArrayList<AnyCredential>();
        creds.add(slice.getCredential());

        String rspecType = "geni";
        String rspecVersion = "3";

        AggregateManager2.AggregateManagerReply<String> res =
                am.listResources(getConnection(), creds,
                        rspecType, rspecVersion, false/*available*/, true/*compressed*/, slice.getUrnString(), null);


        if (!res.getGeniResponseCode().isSuccess())
            throw new JFedException("Error in ListResources: " + res.getGeniResponseCode() + " (" + res.getOutput() + ")", getLastLoggedResult(), res.getGeniResponseCode());

        RSpecInfo r = new RSpecInfo(res.getValue(), RSpecInfo.RspecType.MANIFEST, slice, null /*slivers*/,
                appModel.getAuthorityList().get(getConnection().getGeniAuthority()));

        return r;
    }

    /*returns success*/
    public boolean createSliver(Slice slice, RSpecInfo rspec, List<String> userUrns/*, boolean useContextKey*/) throws JFedException {
        List<AnyCredential> creds = new ArrayList<AnyCredential>();
        creds.add(slice.getCredential());

        List<UserSpec> users = new ArrayList<UserSpec>();
        for (String userUrn : userUrns) {
            LOG.debug("DEBUG EasyAggregateManager2 createSliver -> userUrn=" + userUrn + "  getContext().getUserUrn()=" + getContext().getUserUrnString());
            if (userUrn.equals(getContext().getUserUrnString())) {
                LOG.debug("DEBUG EasyAggregateManager2 createSliver -> easyModel.getUserKeys()=" + appModel.getEasyModel().getUserKeys());
                if (appModel.getEasyModel().getUserKeys() != null && appModel.getEasyModel().getUserKeys().size() > 0) {
                    users.add(new UserSpec(userUrn, new Vector<String>(appModel.getEasyModel().getUserKeys())));
                } else
                    users.add(new UserSpec(userUrn));
            } else
                users.add(new UserSpec(userUrn));
        }

        AggregateManager2.AggregateManagerReply<String> res =
                am.createSliver(getConnection(), creds, slice.getUrnString(), rspec.getStringContent(), users, null);

        return res.getGeniResponseCode().isSuccess();
        //if (!res.getGeniResponseCode().isSuccess())
        //throw new GeniException("Error in CreateSliver: "+res.getGeniResponseCode()+" ("+res.getOutput()+")", getLastLoggedResult(), res.getGeniResponseCode());
    }

    public boolean deleteSliver(Sliver sliver) throws JFedException {
        //because AMv2 is always geni_single
        return deleteSliver(sliver.getSlice());
    }

    public boolean deleteSliver(Slice slice) throws JFedException {
        String sliceUrn = slice.getUrnString();
        List<AnyCredential> creds = new ArrayList<AnyCredential>();
        creds.add(slice.getCredential());

        AggregateManager2.AggregateManagerReply<Boolean> res =
                am.deleteSliver(getConnection(), creds, sliceUrn, null);

        //if sliver doesn't exist, also just return success
        if (res.getGeniResponseCode().equals(GeniAMResponseCode.GENIRESPONSE_SEARCHFAILED))
            return true;

        if (!res.getGeniResponseCode().isSuccess())
            throw new JFedException("Error in DeleteSliver: " + res.getGeniResponseCode() + " (" + res.getOutput() + ")", getLastLoggedResult(), res.getGeniResponseCode());

        return res.getValue();
    }

    public AggregateManager2.SliverStatus sliverStatus(Sliver sliver) throws JFedException {
        return sliverStatus(sliver.getSlice());
    }

    public AggregateManager2.SliverStatus sliverStatus(Slice slice) throws JFedException {
        List<AnyCredential> creds = new ArrayList<AnyCredential>();
        //creds.add(context.getUserCredential());
        creds.add(slice.getCredential());

        AggregateManager2.AggregateManagerReply<AggregateManager2.SliverStatus> res =
                am.sliverStatus(getConnection(), creds, slice.getUrnString(), null);

        if (!res.getGeniResponseCode().isSuccess())
            return null;

        AggregateManager2.SliverStatus am2SliverStatus = res.getValue();

        return am2SliverStatus;
    }

    public boolean renewSliver(Slice slice, Date expirationTime) throws JFedException {
        List<AnyCredential> creds = new ArrayList<AnyCredential>();
        //creds.add(context.getUserCredential());
        creds.add(slice.getCredential());

        AggregateManager2.AggregateManagerReply<Boolean> res =
                am.renewSliver(getConnection(), creds, slice.getUrnString(), expirationTime, null);

        if (!res.getGeniResponseCode().isSuccess())
            throw new JFedException("Error in RenewSliver: " + res.getGeniResponseCode() + " (" + res.getOutput() + ")", getLastLoggedResult(), res.getGeniResponseCode());

        return res.getValue();
    }

    public boolean shutdown(Slice slice) throws JFedException {
        List<AnyCredential> creds = new ArrayList<AnyCredential>();
        //creds.add(context.getUserCredential());
        creds.add(slice.getCredential());

        AggregateManager2.AggregateManagerReply<Boolean> res =
                am.shutdown(getConnection(), creds, slice.getUrnString(), null);

        if (!res.getGeniResponseCode().isSuccess())
            throw new JFedException("Error in Shutdown: " + res.getGeniResponseCode() + " (" + res.getOutput() + ")", getLastLoggedResult(), res.getGeniResponseCode());

        return res.getValue();
    }
}
