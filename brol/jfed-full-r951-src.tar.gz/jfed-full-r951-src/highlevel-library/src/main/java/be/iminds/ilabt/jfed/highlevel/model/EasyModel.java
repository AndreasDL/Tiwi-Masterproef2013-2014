package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.highlevel.history.ApiCallHistory;
import be.iminds.ilabt.jfed.history.UserInfo;
import be.iminds.ilabt.jfed.lowlevel.AnyCredential;
import be.iminds.ilabt.jfed.lowlevel.GeniUserProvider;
import be.iminds.ilabt.jfed.lowlevel.SfaCredential;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniUrn;
import be.iminds.ilabt.jfed.util.JavaFXLogger;
import javafx.beans.property.ListProperty;
import javafx.beans.property.ReadOnlyListProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.collections.FXCollections;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

/**
 * EXPERIMENTAL
 * <p/>
 * EasyModel is passive, it just listens to replies from the SA and AM servers, and offers access to data from them.
 * It caches and informs listeners
 * <p/>
 * It also offers access to the connection pool, and the logged in user
 * It also has methods that will schedule and execute requests. Note that all updates caused by this execution is still
 * received by the passive monitoring of easymodel.
 */
public class EasyModel /*implements SliceListener*/ {
    private static final Logger LOG = LogManager.getLogger();

    private final ListProperty<Slice> slices = new SimpleListProperty(FXCollections.observableArrayList());
    private final ReadOnlyListProperty<Slice> slicesReadOnly = slices;

    private final JavaFXLogger logger;
    private final AuthorityList authorityList;
    private Map<String, Slice> slicesByUrn;
    private AnyCredential userCredential;
    private UserInfo userInfo;
    private List<String> userKeys;
    private final ParameterHistoryModel parameterHistoryModel = new ParameterHistoryModel();
    private final ApiCallHistory apiCallHistory;

    public EasyModel(JavaFXLogger logger,
                     AuthorityListModel authorityListModel,
                     GeniUserProvider geniUserProvider /*may be null*/) {

        this.logger = logger;
        this.authorityList = new AuthorityList(this, authorityListModel);
        this.apiCallHistory = new ApiCallHistory(logger);

        EasyModelAbstractListener planetlabSfaRegistryInterfaceListener =
                new PlanetlabSfaRegistryInterfaceListener(this);
        logger.addResultListener(planetlabSfaRegistryInterfaceListener);
        EasyModelAbstractListener sliceAuthorityListener = new EasyModelSliceAuthorityListener(this);
        logger.addResultListener(sliceAuthorityListener);
        EasyModelAggregateManager3Listener am3Listener = new EasyModelAggregateManager3Listener(this);
        logger.addResultListener(am3Listener);
        EasyModelAggregateManager2Listener am2Listener = new EasyModelAggregateManager2Listener(this);
        logger.addResultListener(am2Listener);
        EasyModelOCCIListener occiListener = new EasyModelOCCIListener(this);
        logger.addResultListener(occiListener);
        EasyUniformFederationSliceAuthorityApiListener ufSaListener =
                new EasyUniformFederationSliceAuthorityApiListener(this);
        logger.addResultListener(ufSaListener);
        EasyUniformFederationMemberAuthorityApiListener ufMaListener =
                new EasyUniformFederationMemberAuthorityApiListener(this, geniUserProvider);
        logger.addResultListener(ufMaListener);

        this.slicesByUrn = new HashMap<String, Slice>();
        this.userCredential = null;
        this.userInfo = null;
        this.userKeys = null;
    }

//    /**
//     * forget all state. (state will come back by listening to Results)
//     */
//    public void reset() {
//        slices.clear();
//        slicesByUrn.clear();
//        userCredential = null;
//        userInfo = null;
//        userKeys = null;
////        fireAllChanged();
//    }

    public JavaFXLogger getLogger() {
        return logger;
    }

    public AuthorityList getAuthorityList() {
        return authorityList;
    }

    public ReadOnlyListProperty<Slice> slicesProperty() {
        return slicesReadOnly;
    }

    void logNotExistSlice(String sliceUrn) {
        Slice existingSlice = slicesByUrn.get(sliceUrn);
        if (existingSlice != null) {
            //TODO: remove all slivers
            slices.remove(existingSlice);
            slicesByUrn.remove(existingSlice.getUrnString());
//            LOG.debug("logNotExistSlice removed Slice "+existingSlice+" with urn "+existingSlice.getUrn());
//            fireSliceRemoved(existingSlice);
        }
    }

    Slice logExistSlice(GeniUrn sliceUrn) {
        return this.logExistSlice(sliceUrn.getValue());
    }

    Slice logExistSlice(String sliceUrn) {
        assert sliceUrn.startsWith("urn:publicid:IDN");
        Slice existingSlice = slicesByUrn.get(sliceUrn);
        if (existingSlice == null) {
            Slice newSlice = new Slice(sliceUrn, this);
            parameterHistoryModel.addSliceUrn(sliceUrn);
            slices.add(newSlice);
            slicesByUrn.put(sliceUrn, newSlice);
//            LOG.debug("logExistSlice created Slice "+newSlice+" for urn "+sliceUrn);
//            fireSliceAdded(newSlice);
            return newSlice;
        }
        return existingSlice;
    }

    Slice logExistSliceName(SfaAuthority auth, String sliceName) {
        assert !sliceName.startsWith("urn:publicid:IDN") : "sliceName is urn \"" + sliceName + "\"";
        String sliceUrn = "urn:publicid:IDN+" + auth.getNameForUrn() + "+slice+" + sliceName;
        return logExistSlice(sliceUrn);
    }

    public Slice logExistSliceUrn(SfaAuthority auth, String sliceUrn) {
        assert auth != null;
        assert sliceUrn.startsWith("urn:publicid:IDN") : "sliceUrn is not urn \"" + sliceUrn + "\"";
        assert sliceUrn.startsWith("urn:publicid:IDN+" + auth.getNameForUrn() + "+slice+") :
                "sliceUrn is not for the correct authority: urn \"" + sliceUrn + "\" auth: \"" + auth.getUrnString() + "\"";
        return logExistSlice(sliceUrn);
    }

    /**
     * @param sliceUrn  urn of the slice the sliver belongs to, may be null if unknown
     * @param sliverUrn urn of the silver
     */
    public void logNotExistSliver(String sliceUrn, String sliverUrn) {
        //////// HACK for PLE ////////
        if (sliverUrn != null && sliverUrn.contains("+ple+")) {
            LOG.warn("HACK: correcting sliver-urn from +ple+ to +ple:ibbtple+");
            sliverUrn = sliverUrn.replace("+ple+", "+ple:ibbtple+");
        }
        //////// HACK for PLE ////////

        Slice slice = logExistSlice(sliceUrn);
        assert slice != null;
        Sliver sliver = slice.findSliver(sliverUrn);
        if (sliver == null) return;

        sliver.setStatus(SliverStatus.UNALLOCATED);
        sliver.setStatusString("non existing");
        sliver.setManifestRspec(null);

        //Do not remove! Keep list of slivers, but mark as unallocated
//        slice.removeSliver(sliver);
    }

    /**
     * @param sliceUrn   urn of the slice the sliver belongs to, may be null if unknown
     * @param sliverUrn  urn of the silver
     * @param geniSingle if true, then an existing sliver for the same authority will be considered the same if its urn is null
     * @return the sliver or null if not stored
     */
    public Sliver logExistSliver(String sliceUrn, String sliverUrn, boolean geniSingle) {
        assert sliverUrn.contains("+sliver+") :
                "sliverUrn=\"" + sliverUrn + "\" is not a sliver urn (sliceUrn=" + sliceUrn + ")";
        assert sliceUrn.contains("+slice+") :
                "sliceUrn=\"" + sliceUrn + "\" is not a slice urn (sliverUrn=" + sliverUrn + ")";
        //////// HACK for PLE ////////
        if (sliverUrn != null && sliverUrn.contains("+ple+")) {
            LOG.warn("HACK: correcting sliver-urn from +ple+ to +ple:ibbtple+");
            sliverUrn = sliverUrn.replace("+ple+", "+ple:ibbtple+");
        }
        //////// HACK for PLE ////////

        if (geniSingle)
            return logExistSliverGeniSingle(sliceUrn, sliverUrn, authorityList.getFromAnyUrn(sliverUrn).getSfaAuthority());

        Slice slice = logExistSlice(sliceUrn);
        assert slice != null;
        Sliver sliver = slice.findSliver(sliverUrn);
        if (sliver == null) {
//            LOG.debug("logExistSliver did not find sliver by urn "+sliverUrn);


            AuthorityInfo auth = authorityList.getFromAnyUrn(sliverUrn);
            assert auth != null : "Error, got sliver info for sliver of unknown authority: " + sliverUrn;
            LOG.debug("sliver with urn \"" + sliverUrn + "\" is from authority " + auth.getSfaAuthority().getUrnString());

            assert !geniSingle;
            //check if sliver for that urn already exists
            LOG.debug("logExistSliver without geniSingle did not find sliver by urn " + sliverUrn + " so it will create a sliver");
            sliver = new Sliver(sliverUrn, slice, null, null, auth.getSfaAuthority());
            parameterHistoryModel.addSliverUrn(sliverUrn);
            slice.addSliver(sliver);

        } else {
            LOG.debug("logExistSliver found sliver " + sliver + " by urn " + sliverUrn);
        }
        return sliver;
    }

    /**
     * @param sliceUrn urn of the slice the sliver belongs to, may be null if unknown
     * @param auth     the authority of the sliver
     *                 <p/>
     *                 There exists a sliver for the slice, on the AM which has geni_allocate value of geni_single. See specs:
     *                 geni_allocate: A case insensitive string, one of fixed set of possible values. Default is geni_single.
     *                 This option defines whether this AM allows adding slivers to slices at an AM (i.e. calling
     *                 Allocate() multiple times, without first deleting the allocated slivers). Possible values:
     *                 geni_single: Performing multiple Allocates without a delete is an error condition because
     *                 the aggregate only supports a single sliver per slice or does not allow incrementally adding
     *                 new slivers. This is the AM API v2 behavior.
     * @return the sliver or null if not stored
     */
    public Sliver logExistSliverGeniSingle(GeniUrn sliceUrn, GeniUrn sliverUrn, SfaAuthority auth) {
        return logExistSliverGeniSingle(sliceUrn.getValue(), sliverUrn.getValue(), auth);
    }

    public Sliver logExistSliverGeniSingle(String sliceUrn, SfaAuthority auth) {
        return logExistSliverGeniSingle(sliceUrn, null, auth);
    }

    public Sliver logExistSliverGeniSingle(String sliceUrn, String sliverUrn, SfaAuthority auth) {
        assert sliceUrn != null;
        assert auth != null;
        assert sliverUrn == null || sliverUrn.contains("+sliver+") :
                "sliverUrn=\"" + sliverUrn + "\" is not a sliver urn (sliceUrn=" + sliceUrn + ")";
        assert sliceUrn.contains("+slice+") :
                "sliceUrn=\"" + sliceUrn + "\" is not a slice urn (sliverUrn=" + sliverUrn + ")";

        //////// HACK for PLE ////////
        if (sliverUrn != null && sliverUrn.contains("+ple+")) {
            LOG.warn("HACK: correcting sliver-urn from +ple+ to +ple:ibbtple+");
            sliverUrn = sliverUrn.replace("+ple+", "+ple:ibbtple+");
        }
        //////// HACK for PLE ////////

        Slice slice = logExistSlice(sliceUrn);
        assert slice != null;
        List<Sliver> slivers = slice.findSlivers(auth);
        if (slivers.isEmpty()) {
            Sliver sliver = new Sliver(sliverUrn, slice, null, null, auth);
            slice.addSliver(sliver);
            parameterHistoryModel.addSliverUrn(sliverUrn);
            LOG.debug("logExistSliverGeniSingle (sliceurn=" + sliceUrn + ") did not find sliver by authority (" + auth.getUrn() + ") so it created one: " + sliver + " sliverurn=" + sliver.getUrn());
            return sliver;
        } else {
            LOG.debug("logExistSliverGeniSingle (sliceurn=" + sliceUrn + ") found sliver " + slivers.get(0) + " by authority (" + auth.getUrn() + ") sliverurn=" + slivers.get(0).getUrn());
        }
        assert slivers.size() == 1 :
                "only geni_single supported, but multiple slivers found, this is a bug. slivers: " + slivers;
        Sliver res = slivers.get(0);
        if (res.getUrn() == null && sliverUrn != null)
            res.setUrn(sliverUrn);
        assert res.getUrn() == null || sliverUrn == null || res.getUrn().equals(sliverUrn) :
                "res.getUrn() != sliverUrn -> " + res.getUrn() + " != " + sliceUrn;
        return res;
    }

    public Sliver logExistSliver(String sliceUrn, SfaAuthority auth) {
        LOG.warn("WARNING: assuming AMv2 or geni_single! logExistSliver(" + sliceUrn + ", " + auth.getName() + ")");
        return logExistSliverGeniSingle(sliceUrn, auth);
    }

    /**
     * @param sliceUrn urn of the slice the sliver belongs to, may be null if unknown
     * @param auth     the authority of the sliver
     *                 <p/>
     *                 See logExistSliverGeniSingle for detqails about "geni_single"
     * @return the sliver or null if not stored
     */
    public void logNotExistSliverGeniSingle(String sliceUrn, SfaAuthority auth) {
        Slice slice = logExistSlice(sliceUrn);
        assert slice != null;
        List<Sliver> slivers = slice.findSlivers(auth);
        if (slivers.isEmpty()) return;
        assert slivers.size() == 1;
        Sliver sliver = slivers.get(0);

        sliver.setStatus(SliverStatus.UNALLOCATED);
        sliver.setStatusString("non existing");
        sliver.setManifestRspec(null);

        //Do not remove! Keep list of slivers, but mark as unallocated
        //slice.removeSliver(sliver);
    }

    public Slice getSlice(String sliceUrn) {
        return slicesByUrn.get(sliceUrn);
    }

    public List<Slice> getSlices() {
        return Collections.unmodifiableList(slices);
    }

    public Sliver getSliver(String sliverUrn) {
        //////// HACK for PLE ////////
        if (sliverUrn != null && sliverUrn.contains("+ple+")) {
            LOG.warn("HACK: correcting sliver-urn from +ple+ to +ple:ibbtple+");
            sliverUrn = sliverUrn.replace("+ple+", "+ple:ibbtple+");
        }
        //////// HACK for PLE ////////

        for (Slice slice : slicesByUrn.values()) {
            Sliver res = slice.findSliver(sliverUrn);
            if (res != null) return res;
        }
        return null;
    }

    public void addUserKey(String key) {
        if (this.userKeys == null)
            this.userKeys = new ArrayList<String>();

        if (!userKeys.contains(key)) {
            LOG.trace("adding key " + key);
            this.userKeys.add(key);
        } else {
            LOG.trace("ignoring duplicate key " + key);
        }
    }

    private UserInfo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    public List<String> getUserKeys() {
        return userKeys;
    }


    //////////////////////////////////////////////////////////////////
    /////////////////////// ParameterHistoryModel ////////////////////
    //////////////////////////////////////////////////////////////////

    public AnyCredential getUserCredential() {
        return userCredential;
    }

    public void setUserCredential(AnyCredential userCredential) {
        if (userCredential != null)
            parameterHistoryModel.addUserCredential(new CredentialInfo(userCredential));

        if (userCredential != null && this.userCredential != null &&
                userCredential.getExpiresDate() != null && this.userCredential.getExpiresDate() != null) {
            //only replace if more recent
            if (userCredential.getExpiresDate().before(this.userCredential.getExpiresDate()))
                return;
        }

        this.userCredential = userCredential;
    }

    //////////////////////////////////////////////////////////////////
    ////////////////////////// ApiCallHistory ////////////////////////
    //////////////////////////////////////////////////////////////////

    public ParameterHistoryModel getParameterHistoryModel() {
        return parameterHistoryModel;
    }

    public ApiCallHistory getApiCallHistory() {
        return apiCallHistory;
    }
}
