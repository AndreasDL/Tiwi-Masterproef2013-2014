package be.iminds.ilabt.jfed.highlevel.controller;

import org.apache.logging.log4j.LogManager;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

import static java.util.concurrent.TimeUnit.MILLISECONDS;

/**
 * TaskThread: manages the thread on which Tasks (typically Sfa commands) are called
 * <p/>
 * Uses ScheduledExecutorService and adds names and dependencies to Callable
 */
public class TaskThread {
    private static org.apache.logging.log4j.Logger LOG = LogManager.getLogger();
    private static TaskThread instance = null;
    private final List<Thread> taskThreads = new ArrayList<Thread>();
    /**
     * This boolean is used to check whether the taskthread should stop
     */
    private final AtomicBoolean stopRequested = new AtomicBoolean(false);
    private final ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(1);
    //1 simultaneous assign future task possible
    //calls ready to be executed
    BlockingDeque<SingleTask> queuedTasks = new LinkedBlockingDeque<SingleTask>();
    //calls waiting for dependencies
    BlockingDeque<SingleTask> blockedTasks = new LinkedBlockingDeque<SingleTask>();
    //all active, future, and historic Tasks. only gets added to, never removed from
    //can be added to from multiple threads. Can be read from multiple threads.
    BlockingQueue<SingleTask> allTasks = new LinkedBlockingQueue<SingleTask>();


    //only uses BlockingDeque when that queue is added to from some thread and waited on in other thread.
    //example: a running queue is never waited for anywhere, the thread that runs would add AND remove from that queue

    private TaskThread() {
        for (int i = 0; i < 3; i++) {
            final int threadNum = i;
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        while (!stopRequested.get())
                            TaskThread.this.runTask();
                    } catch (Throwable t) {
                        LOG.fatal("Fatal error in jFed Experimenter Task Thread nr"+threadNum+": "+ t.getMessage(), t);
                        throw t;
                    } finally {
                        LOG.info("jFed Experimenter Task Thread nr"+threadNum+" is shutting down.");
                    }
                }
            });
            t.setDaemon(true);
            t.setName("TaskThread-" + i);
            taskThreads.add(t);
            t.start();
        }
    }

    public static TaskThread getInstance() {
        if (instance == null) {
            synchronized (TaskThread.class) {
                if (instance == null)
                    instance = new TaskThread();
            }
        }
        assert instance != null;

        return instance;
    }

    public void requestStop() {
        stopRequested.set(true);
        scheduledExecutorService.shutdownNow();
    }

    public boolean isStopRequested() {
        return stopRequested.get();
    }

    public void checkStateCorrectness(SingleTask task) {
        if (task == null)
            throw new NullPointerException("task cannot be null");
        synchronized (task) {
            try {
                SingleTask.TaskState state = task.getState();
                if (state == null)
                    throw new NullPointerException("Task state cannot be null");

                if (state == SingleTask.TaskState.BLOCKED)
                    assert blockedTasks.contains(task);
                else
                    assert !blockedTasks.contains(task);

                if (state == SingleTask.TaskState.QUEUED)
                    assert queuedTasks.contains(task);
                else
                    assert !queuedTasks.contains(task);
            } catch (Throwable e) {
                LOG.error("checkStateCorrectness failed for task " + task, e);
                LOG.error("      queuedTasks=" + queuedTasks);
                LOG.error("     blockedTasks=" + blockedTasks);
                LOG.error("  THIS POTENTIALLY FATAL ERROR WILL BE IGNORED!");
            }
        }
    }

    public void cancel(List<Task> tasks) {
        for (Task t : tasks)
            cancel(t);
    }

    public void cancel(Task task) {
        for (SingleTask st : task.getCurrentActiveSingleTasksCopy())
            cancel(st);
        for (FutureTask ft : task.getFuturesCopy())
            ft.tryCancel();
    }

    /**
     * Try to deque or stop execution of a task. Note that this task may have started or completed during this method,
     * so success cannot be guaranteed. (Except that when this method returns, the task is not running and will
     * never start running)
     */
    public void cancel(SingleTask task) {
        synchronized (task) {
            if (task.state == SingleTask.TaskState.RUNNING) {
                task.setCanceledByUser(true);
                if (task.getThread() != null) {
                    //Note: interrupt will not force stop. It might be too late to cancel.
                    task.getThread().interrupt();
                }
                return;
            }

            if (task.state == SingleTask.TaskState.BLOCKED)
                blockedTasks.remove(task);

            if (task.state == SingleTask.TaskState.QUEUED)
                queuedTasks.remove(task);

            task.setCanceledByUser(true);
            task.state = SingleTask.TaskState.CANCELLED;
            task.task.removeActiveSingleTask(task);
        }
        checkStateCorrectness(task);
        updateBlocking();
    }

    /**
     * Execute a single call. (or execute no call in some cases) This blocks.
     */
    void runTask() {
        SingleTask firstTask;
        try {
            firstTask = queuedTasks.takeFirst();
        } catch (InterruptedException e) {
            //someone is trying to cancel this thread?
            LOG.warn("runTask() for InterruptedException: stopping");
            return;
        }

        synchronized (firstTask) {
            //last check of cancel flag (doesn't have to be thread safe. If it is too late, it is too late)
            if (firstTask.isCanceledByUser()) {
                firstTask.setState(SingleTask.TaskState.CANCELLED);
                return; //ignore task
            }
        }

        synchronized (firstTask) {
            firstTask.setState(SingleTask.TaskState.RUNNING);
            firstTask.setThread(Thread.currentThread());
        }

        SingleTask.TaskState completedState = SingleTask.TaskState.FAILED;
        try {
            LOG.debug("Starting: " + firstTask);
            firstTask.registerRunStart();
            firstTask.task.doTask(firstTask);
            firstTask.registerRunStop();
            LOG.debug("Run Successfully: " + firstTask);
            completedState = SingleTask.TaskState.SUCCESS;
        } catch (InterruptedException e) {
            completedState = SingleTask.TaskState.CANCELLED;
            firstTask.exception = e;
            LOG.warn("Run cancelled: " + firstTask + "  -> Exception=\"" + e + "\"", e);
        } catch (Throwable t) {
            completedState = SingleTask.TaskState.FAILED;
            firstTask.exception = t;
            LOG.error("Run failed: " + firstTask + "  -> Exception=\"" + t + "\"", t);
        } finally {
            List<TaskFinishedCallback> callbacks;
            synchronized (firstTask) {
                callbacks = new ArrayList<TaskFinishedCallback>(firstTask.task.getCallbacks());
                firstTask.setState(completedState);
                firstTask.setThread(null);
                firstTask.task.setLastCompletedSingleTask(firstTask);
                firstTask.task.removeActiveSingleTask(firstTask);
            }

            for (TaskFinishedCallback callback : callbacks) {
                try {
                    callback.onTaskFinished(firstTask.task, firstTask, completedState);
                } catch (Throwable t) {
                    LOG.error("Run Task Callback failed: " + t.getMessage(), t);
                }
            }
        }

        updateBlocking();
    }

    /**
     * check if all blocked tasks are still blocked
     */
    public void updateBlocking() {
        List<SingleTask> toCheck = new ArrayList<>();
        blockedTasks.drainTo(toCheck);
        //blockedTasks is now empty!

        if (!toCheck.isEmpty()) {
            LOG.debug("Assigning blocked tasks");
            for (SingleTask blockedCall : toCheck) {
                assignSingleTask(blockedCall);
            }
        }

        LOG.debug("runTask() updateAfterTaskrun done, will unlock"
                + "\n\t" + queuedTasks.size() + " queuedTasks= " + queuedTasks
                + "\n\t" + blockedTasks.size() + " blockedTasks=" + blockedTasks);
    }

    /**
     * put calls either in the queued calls (can run now) or in the blocked calls (waiting for at least 1 dependency)
     */
    private void processNewSingleTask(SingleTask origSingleTask) {
        if (origSingleTask == null) return;

        //if deps are not added, add them now
        List<SingleTask> singleTasksToAssign = new ArrayList<SingleTask>();
        Queue<SingleTask> newSingleTasksToProcess = new LinkedList<SingleTask>();
        newSingleTasksToProcess.offer(origSingleTask);
        singleTasksToAssign.add(origSingleTask);

        LOG.debug("processNewSingleTask ->  origSingleTask=" + origSingleTask + " (id=" + origSingleTask.id + ")");

        while (!newSingleTasksToProcess.isEmpty()) {
            LOG.trace("assigning calls: " + newSingleTasksToProcess);

            SingleTask singleTask = newSingleTasksToProcess.poll();

            Task task = singleTask.task;

            LOG.debug("processNewSingleTask -> PROCESS task=" + task + " (id=" + task.getId() + ")  singleTask=" + singleTask + " (id=" + singleTask.id + ")");

            /*
             * DependsOn-tasks only have to be executed once.
             * If it was executed in the past, we can use that result of that call.
             */
            for (Task dep : task.getDependsOn()) {
                LOG.debug("processNewSingleTask ->      DEP=" + dep + " (id=" + dep.getId() + ")");
//                    checkStateCorrectness(dep);

                SingleTask depSingleTask = null;
                //Use any running task that is the same Task
                for (SingleTask activeSingleTask : dep.getCurrentActiveSingleTasksCopy()) {
                    LOG.debug("processNewSingleTask ->         found in currentActiveSingleTasks activeSingleTask=" + activeSingleTask + "");
                    if (activeSingleTask.getState() != SingleTask.TaskState.FUTURE)
                        depSingleTask = activeSingleTask;
                }

                //Use any newly created unsubmitted task that is the same Task
                for (SingleTask newlyCreatedTask : singleTasksToAssign)
                    if (newlyCreatedTask.task == dep) {
                        LOG.debug("processNewSingleTask ->         found in singleTasksToAssign newlyCreatedTask=" + newlyCreatedTask + "");
                        depSingleTask = newlyCreatedTask;
                    }

                //Use any finished task that is the same Task
                //TODO FEDIBBTDEV-278 only when not needed? When needed, need to make a new one?
                if (dep.getLastCompletedSingleTask() != null) {
                    LOG.debug("processNewSingleTask ->         found in dep.lastCompletedSingleTask=" + dep.getLastCompletedSingleTask() + "");
                    depSingleTask = dep.getLastCompletedSingleTask();
                }

                //Create a new SingleTask if no singleTask to use found
                if (depSingleTask == null) {
                    depSingleTask = new SingleTask(dep);
                    newSingleTasksToProcess.offer(depSingleTask);
                    singleTasksToAssign.add(depSingleTask);
                    depSingleTask.task.addActiveSingleTask(depSingleTask);
                    LOG.debug("processNewSingleTask ->         creating new: " + depSingleTask + "");
                }

                assert depSingleTask != null;

                //always register as dep
                singleTask.getDependsOn().add(depSingleTask);
                depSingleTask.getDependingOnThis().add(singleTask);
            }

            /*
             * AlwaysDependsOn-tasks should always be (re-)executed before doing this task.
              * This is necessary to detect changing statusses, etc
             */
            for (Task dep : task.getAlwaysDependsOn()) {
                LOG.debug("processNewSingleTask ->      ALWAYSDEP=" + dep + " (id=" + dep.getId() + ")");
//                    checkStateCorrectness(dep);

                SingleTask depSingleTask = null;
                //Use any running task that is the same Task
                LOG.debug("processNewSingleTask ->            dep.currentActiveSingleTasks=" + dep.getCurrentActiveSingleTasks() + "");
                for (SingleTask activeSingleTask : dep.getCurrentActiveSingleTasksCopy()) {
                    LOG.debug("processNewSingleTask ->         found in currentActiveSingleTasks activeSingleTask=" + activeSingleTask + "");
                    if (activeSingleTask.getState() != SingleTask.TaskState.FUTURE)
                        depSingleTask = activeSingleTask;
                }

                //Use any newly created unsubmitted task that is the same Task
                for (SingleTask newlyCreatedTask : singleTasksToAssign)
                    if (newlyCreatedTask.task == dep) {
                        LOG.debug("processNewSingleTask ->         found in singleTasksToAssign newlyCreatedTask=" + newlyCreatedTask + "");
                        depSingleTask = newlyCreatedTask;
                    }

                //Create a new SingleTask if no singleTask to use found
                if (depSingleTask == null) {
                    depSingleTask = new SingleTask(dep);
                    newSingleTasksToProcess.offer(depSingleTask);
                    singleTasksToAssign.add(depSingleTask);
                    depSingleTask.task.addActiveSingleTask(depSingleTask);
                    LOG.debug("processNewSingleTask ->         creating new: " + depSingleTask + "");
                }

                assert depSingleTask != null;

                //always register as dep
                singleTask.getDependsOn().add(depSingleTask);
                depSingleTask.getDependingOnThis().add(singleTask);
            }

            assert !allTasks.contains(singleTask) : "task was already added: " + singleTask.getName();
            allTasks.add(singleTask);

        }

        while (!singleTasksToAssign.isEmpty()) {
            List<SingleTask> assignedTasks = new ArrayList<SingleTask>();
            for (SingleTask newSingleTask : singleTasksToAssign) {
                boolean assigned = assignSingleTask(newSingleTask);
                if (assigned) assignedTasks.add(newSingleTask);
            }
            singleTasksToAssign.removeAll(assignedTasks);
            if (assignedTasks.isEmpty())
                throw new RuntimeException("Infinite loop while assigning: " + singleTasksToAssign); //was an assert, but it's best to always check
        }
    }

    /**
     * receives a singlerun with all dependencies filled in correctly. (and recursively filled in correctly for deps of deps etc...)
     * <p/>
     * Will submit unsubmitted singleRuns.
     * Will queue blocked singleRuns if they are not blocked anymore
     * will fail (and move them to history) calls if their deps have failed.
     * <p/>
     * Also checks correctness of call status VS lists they are in
     * <p/>
     * Tasks sent here will not be in queuedTasks or blockedTasks, so checkStateCorrectness is incorrect at first!
     * <p/>
     * returns true if assign is successful (call is no longer unsubmitted)
     * in case any dependency is unsubmitted, this returns false and does not assign.
     */
    public boolean assignSingleTask(SingleTask singleTask) {
        synchronized (singleTask) {
//            checkStateCorrectness(singleTask); //not guaranteed

            //this is only supposed to be used in the following cases:
            assert singleTask.getState() == SingleTask.TaskState.BLOCKED ||
                    singleTask.getState() == SingleTask.TaskState.QUEUED ||
                    singleTask.getState() == SingleTask.TaskState.UNSUBMITTED :
                    "did not expect task given as argument to assignSingleTask to be in state: " + singleTask.getState();

            LOG.debug("DEBUG   assignSingleTask(" + singleTask + ")");

            //nothing to do for calls that have failed or are successful
            switch (singleTask.getState()) {
                case SUCCESS:
                case CANCELLED: //fall-through
                case FAILED: {
                    return true;
                }
                default: {
                }
            }

            boolean allDepsOk = true;
            for (SingleTask singleTaskDep : singleTask.getDependsOn()) {
                synchronized (singleTaskDep) {
//                    checkStateCorrectness(singleTaskDep); //not guaranteed (deps might not yet have been assigned)

                    if (singleTaskDep.getState() == SingleTask.TaskState.FAILED || singleTask.getState() == SingleTask.TaskState.CANCELLED) {
                        singleTask.setState(singleTaskDep.getState());
                        checkStateCorrectness(singleTask);
                        return true;
                    }
                    if (singleTask.isCanceledByUser()) {
                        singleTask.setState(SingleTask.TaskState.CANCELLED);
                        checkStateCorrectness(singleTask);
                        return true;
                    }

                    if (singleTaskDep.getState() == SingleTask.TaskState.UNSUBMITTED)
                        return false; //cannot continue until it is submitted

                    //new plan: if the task is successful, OR it is not needed, the dep is OK.
                    if (singleTaskDep.getState() != SingleTask.TaskState.SUCCESS && singleTaskDep.task.needed()) {
                   //TODO FEDIBBTDEV-278  use this? ->  if (singleTaskDep.task.needed()) {
                        LOG.debug("DEBUG         singleTaskDep(" + singleTaskDep + ").task.needed=" + singleTaskDep.task.needed() + " state=" + singleTaskDep.getState() + ", so allDepsOk = false");
                        allDepsOk = false;
                    }
                }
            }

            LOG.debug("DEBUG         allDepsOk=" + allDepsOk);

            try {
                if (allDepsOk) {
                    synchronized (singleTask) {
                        singleTask.setState(SingleTask.TaskState.QUEUED);
                        queuedTasks.putFirst(singleTask);
                    }
                } else {
                    synchronized (singleTask) {
                        singleTask.setState(SingleTask.TaskState.BLOCKED);
                        blockedTasks.putFirst(singleTask);
                    }
                }
            } catch (InterruptedException e) {
                LOG.error("Did not expect InterruptedException could occur in assignSingleTask. This is possibly a problem. It will be ignored.", e);
            }

            checkStateCorrectness(singleTask);

            return true;
        }
    }

    public void addTask(final Task task) {
        LOG.debug("                  adding task: \"" + task + "\"");

        if (task.isActive()) {
            LOG.error("trying to add active task: " + task.getCurrentActiveSingleTasksCopy() + " -> task will not be added.");
            return;
        }

        LOG.debug("                        " + queuedTasks.size() + " queuedTasks= " + queuedTasks);
        LOG.debug("                        " + blockedTasks.size() + " blockedTasks=" + blockedTasks);

        SingleTask singleTask = new SingleTask(task);
        task.addActiveSingleTask(singleTask);
        processNewSingleTask(singleTask);

        LOG.debug("                  added task: \"" + task + "\"");
        LOG.debug("                        " + queuedTasks.size() + " queuedTasks= " + queuedTasks);
        LOG.debug("                        " + blockedTasks.size() + " blockedTasks=" + blockedTasks);
    }

    public void addTasks(List<? extends Task> tasks) {
        for (Task task : tasks) {
            addTask(task);
        }
    }

    public void scheduleTask(final Task task, final long delayMs) {
        LOG.debug("DEBUG TaskThread ==> DEBUG schedule task in " + delayMs + " ms: \"" + task.getName() + "\".");
        SingleTask singleTask = new SingleTask(task);
        singleTask.setState(SingleTask.TaskState.FUTURE);
        task.addActiveSingleTask(singleTask);

        FutureTask futureTask = new FutureTask(singleTask);
        ScheduledFuture scheduledFuture = scheduledExecutorService.schedule(futureTask, delayMs, MILLISECONDS);
        futureTask.setScheduledFuture(scheduledFuture);
        task.addFuture(futureTask);
    }

    public class FutureTask implements Runnable {

        private final SingleTask task;
        JavaFXTaskThread.FutureTask javafx;
        private ScheduledFuture scheduledFuture;
        private boolean cancel = false;

        FutureTask(SingleTask task) {
            this.task = task;
        }

        public SingleTask getTask() {
            return task;
        }

        public ScheduledFuture getScheduledFuture() {
            return scheduledFuture;
        }

        void setScheduledFuture(ScheduledFuture scheduledFuture) {
            this.scheduledFuture = scheduledFuture;
        }

        public void tryCancel() {
            cancel = true;
            if (scheduledFuture != null) {
                boolean wasCancelled = scheduledFuture.cancel(false);
                if (wasCancelled)
                    task.setState(SingleTask.TaskState.CANCELLED);
            }
        }

        public long getTimeLeftMs() {
            if (scheduledFuture != null)
                return scheduledFuture.getDelay(MILLISECONDS);
            else
                return -1;
        }

        @Override
        public void run() {
            if (cancel) {
                task.setState(SingleTask.TaskState.CANCELLED);
                return;
            }
            try {
                LOG.debug("                  adding future task: \"" + task + "\"");

                boolean wasRemoved = task.task.removeFuture(this);
                assert wasRemoved;

                task.setState(SingleTask.TaskState.UNSUBMITTED);

                processNewSingleTask(task);
                LOG.debug("                  added future task: \"" + task + "\"");
                LOG.debug("                        queuedTasks= " + queuedTasks);
                LOG.debug("                        blockedTasks=" + blockedTasks);
            } catch (Throwable e) {
                LOG.error("Exception while running addCall on future task. This is a bug. " + e.getMessage(), e);
            }
        }
    }

}
