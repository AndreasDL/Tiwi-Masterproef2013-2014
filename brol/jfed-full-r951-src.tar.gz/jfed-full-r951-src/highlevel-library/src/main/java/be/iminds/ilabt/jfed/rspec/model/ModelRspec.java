package be.iminds.ilabt.jfed.rspec.model;

import be.iminds.ilabt.jfed.rspec.ext.binding.Location;
import be.iminds.ilabt.jfed.rspec.ext.binding.NodeDescriptionType;
import be.iminds.ilabt.jfed.rspec.request.geni_rspec_3.*;
import com.sun.xml.bind.marshaller.NamespacePrefixMapper;
import javafx.beans.property.ReadOnlyListProperty;
import javafx.beans.property.ReadOnlyListWrapper;
import javafx.collections.FXCollections;
import org.apache.logging.log4j.LogManager;
import org.apache.xerces.dom.ElementNSImpl;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.bind.*;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.*;

public class ModelRspec {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    private ReadOnlyListWrapper<be.iminds.ilabt.jfed.rspec.model.RspecNode> nodes =
            new ReadOnlyListWrapper<>(FXCollections.<be.iminds.ilabt.jfed.rspec.model.RspecNode>observableArrayList());
    private ReadOnlyListWrapper<RspecLink> links =
            new ReadOnlyListWrapper<>(FXCollections.<RspecLink>observableArrayList());
    private final List<Object> others = new ArrayList<>();

    private boolean origIsParsed = false;
    private String origDefaultNamespace = null;
    private String origSchemaLocation = null;
    private final Map<String, String> origNameSpaceInfo = new HashMap<>();

    private void processNamespaceInfo(String xml) {
        origIsParsed = true;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        DocumentBuilder builder = null;
        try {
            builder = dbf.newDocumentBuilder();
            assert builder.isNamespaceAware();
            InputSource is = new InputSource(new StringReader(xml));
            Document d = builder.parse(is);
            NamedNodeMap attributes = d.getDocumentElement().getAttributes();
            if (attributes != null) {
                for (int i = 0; i < attributes.getLength(); i++) {
                    Node node = attributes.item(i);
                    if (node.getNodeType() == Node.ATTRIBUTE_NODE) {
                        String name = node.getNodeName();
                        String val = node.getNodeValue();
                        if (name.equals("xmlns")) {
                            origDefaultNamespace = val;
                        }
                        if (name.equals("xsi:schemaLocation")) {
                            origSchemaLocation = val;
                        }
                        if (name.startsWith("xmlns:")) {
                            String nsName = name.substring(6);
                            origNameSpaceInfo.put(nsName, val);
                        }
                    }
                }
            }
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e); //TODO: handle exceptions
        } catch (SAXException e) {
            throw new RuntimeException(e); //TODO: handle exceptions
        } catch (IOException e) {
            throw new RuntimeException(e); //TODO: handle exceptions
        }
    }

//    /** Copy constructor */
//    public Rspec(Rspec rspec) {
//        //copy of nodes will not include interfaces yet
//        for (RspecNode node : nodes)
//            nodes.add(new RspecNode(node));
//        //copy of link will create interfaces and link them to nodes
//        for (RspecLink link : links)
//            links.add(new RspecLink(this, link));
//    }

    public ReadOnlyListProperty<be.iminds.ilabt.jfed.rspec.model.RspecNode> getNodes() {
        return nodes.getReadOnlyProperty();
    }

    public ReadOnlyListProperty<RspecLink> getLinks() {
        return links.getReadOnlyProperty();
    }

    public RspecNode getNodeById(String id) {
        for (RspecNode node : nodes)
            if (node.getId().equals(id))
                return node;
        return null;
    }

    public RspecLink getLinkById(String id) {
        for (RspecLink link : links)
            if (link.getId().equals(id))
                return link;
        return null;
    }

    /**
     * Create an empty Rspec
     */
    public ModelRspec() {
    }

    /**
     * Deletes a node and all interfaces attached to it. If a link becomes surplus, it is removed also.
     *
     * @param node
     */
    public void deleteNode(RspecNode node) {
        List<RspecLink> linksToDelete = new ArrayList<>();
        List<RspecInterface> ifacesToDelete = new ArrayList<>();
        for (RspecInterface iface : node.getInterfaces()) {
            RspecLink link = iface.getLink();
            if (link != null && link.getInterfaces().size() <= 2)
                linksToDelete.add(link);
            ifacesToDelete.add(iface);
        }
        for (RspecInterface iface : ifacesToDelete)
            iface.delete();
        nodes.remove(node);
        for (RspecLink link : linksToDelete)
            deleteLink(link);
    }

    /**
     * Removes the link from the Rspec
     *
     * @param link
     */
    public void deleteLink(RspecLink link) {
        AbstractList<RspecInterface> ifacesToDelete = new ArrayList<>(link.getInterfaces());
        for (RspecInterface iface : ifacesToDelete)
            iface.delete();
        links.remove(link);
    }

    public static ModelRspec dummy() {
        ModelRspec res = new ModelRspec();
        //dummy
        RspecNode n1 = new RspecNode(res.nextNodeName());
        res.nodes.add(n1);
        RspecNode n2 = new RspecNode(res.nextNodeName());
        res.nodes.add(n2);
        RspecNode n3 = new RspecNode(res.nextNodeName());
        res.nodes.add(n3);
        RspecNode n4 = new RspecNode(res.nextNodeName());
        res.nodes.add(n4);
        n1.setOsImage("DUMMY");
        n2.setOsImage("DUMMY");
        n3.setOsImage("DUMMY");
        n4.setOsImage("DUMMY");


        n1.setEditorX(10);
        n1.setEditorY(10);


        n2.setEditorX(300);
        n2.setEditorY(10);


        n3.setEditorX(10);
        n3.setEditorY(300);


        n4.setEditorX(300);
        n4.setEditorY(300);

        RspecLink l1 = new RspecLink(res, res.nextLinkName());
        RspecInterface i1 = new RspecInterface(n1, l1, res.nextIfaceName(n1));
        RspecInterface i2 = new RspecInterface(n2, l1, res.nextIfaceName(n2));
        RspecInterface i3 = new RspecInterface(n3, l1, res.nextIfaceName(n3));
        i1.setId("if1");
        i2.setId("if2");
        i3.setId("if3");
        res.links.add(l1);

        RspecLink l2 = new RspecLink(res, res.nextLinkName());
        RspecInterface i4 = new RspecInterface(n1, l2, res.nextIfaceName(n1));
        RspecInterface i5 = new RspecInterface(n4, l2, res.nextIfaceName(n4));
        l2.setId("gigalink2");
        res.links.add(l2);

        return res;
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///// WARNING: very dirty cut and paste code reuse between fromGeni3RequestRspecXML and fromGeni3ManifestRspecXML and fromGeni3AdvertisementRspecXML! /////
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public static ModelRspec fromGeni3RequestRspecXML(String inputRspec) throws InvalidRspecException {

        try {
            ModelRspec res = new ModelRspec();
            res.processNamespaceInfo(inputRspec);

            //handle empty String
            if (inputRspec == null || inputRspec.equals(""))
                throw new InvalidRspecException("Received an empty input.");

            JAXBContext jc = JAXBContext.newInstance(RSpecContents.class, Location.class, NodeDescriptionType.class);
            Unmarshaller u = jc.createUnmarshaller();
            @SuppressWarnings("unchecked")
            JAXBElement<RSpecContents> doc = (JAXBElement<RSpecContents>) u.unmarshal(new StringReader(inputRspec));
            RSpecContents c = doc.getValue();

            assert c != null;

            //Note: getType() will return null if the type is specified but not "request".
            //      This is because the xsd specifies type as a choice from a list containing only "request".
            if (c != null &&
                    c.getType() != null &&
                    c.getType().value() != null) {
                if (!c.getType().value().equals("request"))
                    LOG.warn("Parsing an RSpec " + c.getType().value() + " as an RSpec request!");
            } else {
                LOG.warn("Parsed RSpec has no type (note: this also occurs if the type is not \"request\"): " + inputRspec);
            }

            Map<String, RspecInterface> nameToIface = new HashMap<>();
            Map<String, RspecNode> ifaceNameToRspecNode = new HashMap<>();
            Map<String, InterfaceContents> ifaceNameToIfaceContents = new HashMap<>();

            //first nodes
            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    if (el.getValue() instanceof NodeContents) {
                        NodeContents node = (NodeContents) el.getValue();

                        String id = node.getClientId();
                        //in an advertisement, client ID is typically empty, but component name and ID are set
                        if (id == null) id = node.getComponentName();
                        if (id == null) id = node.getComponentId();
                        //if all else fails, we assign a name ourselves
                        if (id == null) id = res.nextNodeName();

                        assert id != null : "Rspec has a node without any ID: " + el;
                        RspecNode resNode = new RspecNode(id);
                        assert resNode.getId() != null;
                        resNode.setPropertiesFromGeni3RequestRspec(node);

                        //check if node with same name is not already added
                        for (RspecNode existingNode : res.getNodes()) {
                            assert resNode != null;
                            assert existingNode != null;
                            assert resNode.getId() != null;
                            assert existingNode.getId() != null;
                            if (existingNode == resNode || resNode.getId().equals(existingNode.getId()))
                                throw new InvalidRspecException("Duplicate nodes in XML Rspec: id=\"" + node.getClientId() + "\"");
                        }
                        res.getNodes().add(resNode);

                        for (Object nodeElO : node.getAnyOrRelationOrLocation()) {
                            if (nodeElO instanceof JAXBElement) {
                                JAXBElement nodeEl = (JAXBElement) nodeElO;
                                if (nodeEl.getValue() instanceof InterfaceContents) {
                                    InterfaceContents ic = (InterfaceContents) nodeEl.getValue();
                                    assert ic != null;

                                    //for a request, this is mandatory, but we use the same code to parse the advertisement
                                    //assert ic.getClientId() != null : "InterfaceContents has no clientId: "+ic;
                                    if (ic.getClientId() != null) {
                                        //check if iface with same name is not already added
                                        for (String existingIfaceName : ifaceNameToRspecNode.keySet())
                                            if (ic.getClientId().equals(existingIfaceName))
                                                throw new InvalidRspecException("Duplicate interfaces in XML Rspec: id=\"" + existingIfaceName + "\"");

                                        ifaceNameToRspecNode.put(ic.getClientId(), resNode);
                                        ifaceNameToIfaceContents.put(ic.getClientId(), ic);
                                    } else {
                                        LOG.warn("ignoring that InterfaceContents has no clientId");
                                    }
                                }
                            }
                        }
                    }
                }
            }

            //then the rest
            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    boolean handled = false;
                    if (el.getValue() instanceof NodeContents)
                        handled = true;
                    if (el.getValue() instanceof LinkContents) {
                        RspecLink resLink = null;
                        try {
                            handled = true;
                            LinkContents link = (LinkContents) el.getValue();

                            String id = link.getClientId();
                            //in an advertisement, client ID is typically empty, but component name and ID are set
                            if (id == null) id = link.getOtherAttributes().get(new QName("component_name"));
                            if (id == null) id = link.getOtherAttributes().get(new QName("component_id"));
                            //if all else fails, we assign a name ourselves
                            if (id == null) id = res.nextLinkName();

                            assert id != null : "Rspec has a link without any ID: " + el;

                            //check if all interfaces of link are known. We will ignore the link if they are not.
                            boolean hasUnknownInterfaces = false;
                            for (Object linkElO : link.getAnyOrPropertyOrLinkType()) {
                                if (linkElO instanceof JAXBElement) {
                                    JAXBElement linkEl = (JAXBElement) linkElO;
                                    if (linkEl.getValue() instanceof InterfaceRefContents) {
                                        InterfaceRefContents ic = (InterfaceRefContents) linkEl.getValue();

                                        RspecInterface iface = nameToIface.get(ic.getClientId());
                                        if (iface == null) {
                                            RspecNode rspecNode = ifaceNameToRspecNode.get(ic.getClientId());

                                            if (rspecNode == null) {
                                                hasUnknownInterfaces = true;
                                                LOG.warn("Interface has not been defined in a <node>, but is referred to in a <link>: " + ic.getClientId());
                                            }
                                        }
                                    }
                                }
                            }

                            if (hasUnknownInterfaces) {
                                LOG.warn("because link has one or more unknown interfaces, it will be ignored!");
                            } else {
                                resLink = new RspecLink(res, id);
                                //check if iface with same name is not already added
                                for (RspecLink existingLink : res.getLinks()) {
                                    assert resLink != null;
                                    assert existingLink != null;
                                    assert resLink.getId() != null;
                                    assert existingLink.getId() != null;
                                    if (existingLink == resLink || resLink.getId().equals(existingLink.getId()))
                                        throw new InvalidRspecException("Duplicate link in XML Rspec: id=\"" + resLink.getId() + "\"");
                                }
                                res.getLinks().add(resLink);

                                for (Object linkElO : link.getAnyOrPropertyOrLinkType()) {
                                    if (linkElO instanceof JAXBElement) {
                                        JAXBElement linkEl = (JAXBElement) linkElO;
                                        if (linkEl.getValue() instanceof InterfaceRefContents) {
                                            InterfaceRefContents ic = (InterfaceRefContents) linkEl.getValue();

                                            RspecInterface iface = nameToIface.get(ic.getClientId());
                                            if (iface == null) {
                                                RspecNode rspecNode = ifaceNameToRspecNode.get(ic.getClientId());

                                                if (rspecNode != null) {
                                                    iface = new RspecInterface(rspecNode, resLink, ic.getClientId());
                                                    iface.setPropertiesFromGeni3RequestRspec(ic);
                                                    iface.setPropertiesFromGeni3RequestRspec(ifaceNameToIfaceContents.get(ic.getClientId()));
                                                    nameToIface.put(iface.getId(), iface);
                                                }
                                            }

                                            if (iface == null) {
                                                //should not happen here anymore, since we handle it above!
                                                throw new InvalidRspecException("Interface has not been defined in a <node>, but is referred to in a <link>: " + ic.getClientId());
                                            }

                                            //adding interface here would be a bug, because interface should not be added here! RspecInterface constructor already adds to link
//                                    //check if iface with same name is not already added
//                                    for (RspecInterface existingIface : resLink.getInterfaces())
//                                        if (existingIface == iface || iface.getId().equals(existingIface.getId()))
//                                            throw new RuntimeException("Duplicate interfaces in XML Rspec: id=\""+existingIface.getId()+"\"");
//                                    resLink.getInterfaces().add(iface);

                                            //fill in iface details
                                        }
                                    }
                                }

                                //set properties AFTER interfaces have been added and LinkSetting have been updated
                                //      (LinkSetting is automatically updated, but can be safely called manually)
                                resLink.updateLinkSettings();
                                resLink.setPropertiesFromGeni3RequestRspec(link);
                            }
                        } catch (Throwable e) {
                            LOG.error("Error parsing link. Will remove link from RSpec: " + e.getMessage(), e);
                            //break down link
                            if (resLink != null) {
                                res.getLinks().remove(resLink);
                                List<RspecInterface> ifaces = new ArrayList<>(resLink.getInterfaces());
                                for (RspecInterface iface : ifaces) {
                                    iface.delete();
                                }
                            }
                        }
                    }
                    if (!handled) {
//                        LOG.warn("Unhandled rspec JAXBElement value class: " + el.getValue().getClass().getName());
                        res.others.add(el);
                    }
                } else {
                    if (o instanceof ElementNSImpl) {
//                        ElementNSImpl elementNS = (ElementNSImpl) o;
//                        LOG.debug("elementNS " + elementNS.toString() + " ");
                    } else {
//                        LOG.debug("Unhandled rspec element class: " + o.getClass().getName());
                    }
                    res.others.add(o);
                }
            }


//            System.out.println("rspec type "+c.getType().value()+" ");

            return res;
        } catch (Throwable e) {
            throw new InvalidRspecException("Error reading Request Rspec XML", e);
        }
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///// WARNING: very dirty cut and paste code reuse between fromGeni3RequestRspecXML and fromGeni3ManifestRspecXML and fromGeni3AdvertisementRspecXML! /////
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public static ModelRspec fromGeni3ManifestRspecXML(String inputRspec) throws InvalidRspecException {
        LOG.trace("Rspec.fromGeni3ManifestRspecXML() called  inputRspec=" + (inputRspec.length() > 30
                ? inputRspec.substring(0, 20) + "..." : inputRspec));
        ModelRspec res = new ModelRspec();
        res.processNamespaceInfo(inputRspec);

        //handle empty String
        if (inputRspec == null || inputRspec.equals(""))
            throw new InvalidRspecException("Received an empty input.");

        //quick HACK to allow the planetlab Europe rspec manifest
        if (inputRspec.contains("<RSpec")) {
            LOG.debug("HACK: rewriting received planetlab manifest XML to make it parsable xml");
            inputRspec =
                    inputRspec.replace("<RSpec type=\"SFA\"", "<rspec xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" type=\"manifest\"");
            inputRspec =
                    inputRspec.replace("<RSpec ", "<rspec xmlns=\"http://www.geni.net/resources/rspec/3\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" type=\"manifest\"");
            inputRspec = inputRspec.replace("</RSpec>", "</rspec>");
            inputRspec = inputRspec.replace("<network name=\"ple\">", "");
            inputRspec = inputRspec.replace("</network>", "");
            LOG.debug("HACK: rewriten xml: " + inputRspec);
        }

        try {
            JAXBContext jc =
                    JAXBContext.newInstance(be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents.class, Location.class, NodeDescriptionType.class);
            Unmarshaller u = jc.createUnmarshaller();
            @SuppressWarnings("unchecked")
            JAXBElement<be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents> doc =
                    (JAXBElement<be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents>) u.unmarshal(new StringReader(inputRspec));
            be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.RSpecContents c = doc.getValue();


            assert c != null;

            if (c != null &&
                    c.getType() != null &&
                    c.getType().value() != null) {
                if (!c.getType().value().equals("manifest"))
                    LOG.warn("Parsing an RSpec " + c.getType().value() + " as an RSpec manifest!");
            } else {
                LOG.warn("Parsed RSpec has no type: " + inputRspec);
            }

            Map<String, RspecInterface> nameToIface = new HashMap<>();
            Map<String, RspecNode> ifaceNameToRspecNode = new HashMap<>();
            Map<String, be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.InterfaceContents> ifaceNameToIfaceContents =
                    new HashMap<>();

            //first nodes
            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    if (el.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents) {
                        be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents node =
                                (be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents) el.getValue();

                        String id = node.getClientId();

                        LOG.trace("Found node with ID=" + id);

                        //in an advertisement, client ID is typically empty, but component name and ID are set
                        if (id == null) id = node.getComponentName();
                        if (id == null) id = node.getComponentId();
                        //if all else fails, we assign a name ourselves
                        if (id == null) id = res.nextNodeName();

                        assert id != null : "Rspec has a node without any ID: " + el;
                        RspecNode resNode = new RspecNode(id);
                        assert resNode.getId() != null;
                        resNode.setPropertiesFromGeni3ManifestRspec(node);

                        //check if node with same name is not already added
                        for (RspecNode existingNode : res.getNodes()) {
                            assert resNode != null;
                            assert existingNode != null;
                            assert resNode.getId() != null;
                            assert existingNode.getId() != null;
                            if (existingNode == resNode || resNode.getId().equals(existingNode.getId()))
                                throw new InvalidRspecException("Duplicate nodes in XML Rspec: id=\"" + node.getClientId() + "\"");
                        }
                        res.getNodes().add(resNode);

                        for (Object nodeElO : node.getAnyOrRelationOrLocation()) {
                            if (nodeElO instanceof JAXBElement) {
                                JAXBElement nodeEl = (JAXBElement) nodeElO;
                                if (nodeEl.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.InterfaceContents) {
                                    be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.InterfaceContents ic =
                                            (be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.InterfaceContents) nodeEl.getValue();

                                    //check if iface with same name is not already added
                                    for (String existingIfaceName : ifaceNameToRspecNode.keySet())
                                        if (ic.getClientId().equals(existingIfaceName))
                                            throw new InvalidRspecException("Duplicate interfaces in XML Rspec: id=\"" + existingIfaceName + "\"");

                                    ifaceNameToRspecNode.put(ic.getClientId(), resNode);
                                    ifaceNameToIfaceContents.put(ic.getClientId(), ic);

                                    //fill in iface details
                                }
                            }
                        }
                    }
                }
            }

            //then the rest
            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    boolean handled = false;
                    if (el.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.NodeContents)
                        handled = true;
                    if (el.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.LinkContents) {
                        handled = true;
                        RspecLink resLink = null;
                        try {
                            be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.LinkContents link =
                                    (be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.LinkContents) el.getValue();

                            String id = link.getClientId();
                            //in an advertisement, client ID is typically empty, but component name and ID are set
                            if (id == null) id = link.getOtherAttributes().get("component_name");
                            if (id == null) id = link.getOtherAttributes().get("component_id");
                            //if all else fails, we assign a name ourselves
                            if (id == null) id = res.nextLinkName();

                            assert id != null : "Rspec has a link without any ID: " + el;

                            resLink = new RspecLink(res, id);
                            //check if iface with same name is not already added
                            for (RspecLink existingLink : res.getLinks()) {
                                assert resLink != null;
                                assert existingLink != null;
                                assert resLink.getId() != null;
                                assert existingLink.getId() != null;
                                if (existingLink == resLink || resLink.getId().equals(existingLink.getId()))
                                    throw new InvalidRspecException("Duplicate link in XML Rspec: id=\"" + resLink.getId() + "\"");
                            }
                            res.getLinks().add(resLink);

                            for (Object linkElO : link.getAnyOrPropertyOrLinkType()) {
                                if (linkElO instanceof JAXBElement) {
                                    JAXBElement linkEl = (JAXBElement) linkElO;
                                    if (linkEl.getValue() instanceof be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.InterfaceRefContents) {
                                        be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.InterfaceRefContents ic =
                                                (be.iminds.ilabt.jfed.rspec.manifest.geni_rspec_3.InterfaceRefContents) linkEl.getValue();

                                        RspecInterface iface = nameToIface.get(ic.getClientId());
                                        if (iface == null) {
                                            RspecNode rspecNode = ifaceNameToRspecNode.get(ic.getClientId());

                                            if (rspecNode != null) {
                                                iface = new RspecInterface(rspecNode, resLink, ic.getClientId());
                                                iface.setPropertiesFromGeni3ManifestRspec(ifaceNameToIfaceContents.get(ic.getClientId()));
                                                iface.setPropertiesFromGeni3ManifestRspec(ic);
                                                nameToIface.put(iface.getId(), iface);
                                            }
                                        }

                                        if (iface == null) {
                                            throw new InvalidRspecException("Interface has not been defined in a <node>, but is referred to in a <link>: " + ic.getClientId());
                                        }

                                        //adding interface here would be a bug, because interface should not be added here! RspecInterface constructor already adds to link
//                                    //check if iface with same name is not already added
//                                    for (RspecInterface existingIface : resLink.getInterfaces())
//                                        if (existingIface == iface || iface.getId().equals(existingIface.getId()))
//                                            throw new RuntimeException("Duplicate interfaces in XML Rspec: id=\""+existingIface.getId()+"\"");
//                                    resLink.getInterfaces().add(iface);

                                        //fill in iface details
                                    }
                                }
                            }

                            //set properties AFTER interfaces have been added
                            resLink.setPropertiesFromGeni3ManifestRspec(link);
                        } catch (Throwable e) {
                            LOG.error("Error parsing link. Will remove link from RSpec: " + e.getMessage(), e);
                            //break down link
                            if (resLink != null) {
                                res.getLinks().remove(resLink);
                                List<RspecInterface> ifaces = new ArrayList<>(resLink.getInterfaces());
                                for (RspecInterface iface : ifaces) {
                                    iface.delete();
                                }
                            }
                        }

                    }
                    if (!handled) {
//                        LOG.debug("Unhandled rspec JAXBElement value class: " + el.getValue().getClass().getName());
                        res.others.add(el);
                    }
                } else {
                    if (o instanceof ElementNSImpl) {
//                        ElementNSImpl elementNS = (ElementNSImpl) o;
//                        LOG.debug("elementNS " + elementNS.toString() + " ");
                    } else {
//                        LOG.debug("Unhandled rspec element class: " + o.getClass().getName());
                    }
                    res.others.add(o);
                }
            }

            LOG.trace("Finished processing nodes and links. nodes.size=" + res.nodes.size() + " links.size=" + res.links.size());

//            System.out.println("rspec type "+c.getType().value()+" ");

            return res;
        } catch (Exception e) {

            throw new InvalidRspecException("Error reading Manifest Rspec XML", e);
        }
    }  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///// WARNING: very dirty cut and paste code reuse between fromGeni3RequestRspecXML and fromGeni3ManifestRspecXML and fromGeni3AdvertisementRspecXML! /////
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    public static Rspec fromGeni3AdvertisementRspecXML(String inputRspec) {
//        //TODO: add specific advertisement parsing?
//        LOG.warn("Using manifest parsing for advertisement RSpec. This will generate a warning.");
//        return fromGeni3ManifestRspecXML(inputRspec);
//    }
    public static ModelRspec fromGeni3AdvertisementRspecXML(String inputRspec) throws InvalidRspecException {
        ModelRspec res = new ModelRspec();
        res.processNamespaceInfo(inputRspec);

        //handle empty String
        if (inputRspec == null || inputRspec.equals(""))
            throw new InvalidRspecException("Received an empty input.");

        try {
            JAXBContext jc =
                    JAXBContext.newInstance(be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents.class, Location.class, NodeDescriptionType.class);
            Unmarshaller u = jc.createUnmarshaller();
            @SuppressWarnings("unchecked")
            JAXBElement<be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents> doc =
                    (JAXBElement<be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents>) u.unmarshal(new StringReader(inputRspec));
            be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.RSpecContents c = doc.getValue();


            assert c != null;

            if (c != null && c.getType() != null) {
                if (!c.getType().equals("advertisement"))
                    LOG.warn("Parsing an RSpec " + c.getType() + " as an RSpec advertisement!");
            } else {
                LOG.warn("Parsed RSpec has no type: " + inputRspec);
            }

            Map<String, RspecInterface> nameToIface = new HashMap<>();
            Map<String, RspecNode> ifaceNameToRspecNode = new HashMap<>();
            Map<String, be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.InterfaceContents>
                    ifaceNameToIfaceContents = new HashMap<>();

            //first nodes
            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    if (el.getValue() instanceof be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.NodeContents) {
                        be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.NodeContents node =
                                (be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.NodeContents) el.getValue();

                        String id = node.getComponentName();
                        //in an advertisement, client ID does not exist empty, but component name and ID are always set
                        if (id == null) id = node.getComponentId();
                        //if all else fails, we assign a name ourselves
                        if (id == null) id = res.nextNodeName();

                        assert id != null : "Rspec has a node without any ID: " + el;
                        RspecNode resNode = new RspecNode(id);
                        assert resNode.getId() != null;
                        resNode.setPropertiesFromGeni3AdvertisementRspec(node);

                        //check if node with same name is not already added
                        for (RspecNode existingNode : res.getNodes()) {
                            assert resNode != null;
                            assert existingNode != null;
                            assert resNode.getId() != null;
                            assert existingNode.getId() != null;
                            if (existingNode == resNode || resNode.getId().equals(existingNode.getId()))
                                throw new InvalidRspecException("Duplicate nodes in XML Rspec: id=\"" + node.getComponentName() + "\"");
                        }
                        res.getNodes().add(resNode);

                        for (Object nodeElO : node.getAnyOrRelationOrLocation()) {
                            if (nodeElO instanceof JAXBElement) {
                                JAXBElement nodeEl = (JAXBElement) nodeElO;
                                if (nodeEl.getValue() instanceof be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.InterfaceContents) {
                                    be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.InterfaceContents ic =
                                            (be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.InterfaceContents) nodeEl.getValue();

                                    //check if iface with same name is not already added
                                    for (String existingIfaceName : ifaceNameToRspecNode.keySet())
                                        if (ic.getComponentId().equals(existingIfaceName))
                                            throw new InvalidRspecException("Duplicate interfaces in XML Rspec: id=\"" + existingIfaceName + "\"");

                                    ifaceNameToRspecNode.put(ic.getComponentId(), resNode);
                                    ifaceNameToIfaceContents.put(ic.getComponentId(), ic);

                                    //fill in iface details
                                }
                            }
                        }
                    }
                }
            }

            //then the rest
            for (Object o : c.getAnyOrNodeOrLink()) {
                if (o instanceof JAXBElement) {
                    JAXBElement el = (JAXBElement) o;
                    boolean handled = false;
                    if (el.getValue() instanceof be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.NodeContents)
                        handled = true;
                    if (el.getValue() instanceof be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.LinkContents) {
                        RspecLink resLink = null;
                        try {

                            handled = true;
                            be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.LinkContents link =
                                    (be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.LinkContents) el.getValue();

                            String id = link.getComponentName();
                            //in an advertisement, client ID does not exist empty, but component name and ID are always set
                            if (id == null) id = link.getComponentId();
                            //if all else fails, we assign a name ourselves
                            if (id == null) id = res.nextLinkName();

                            assert id != null : "Rspec has a link without any ID: " + el;

                            resLink = new RspecLink(res, id);
                            //check if iface with same name is not already added
                            for (RspecLink existingLink : res.getLinks()) {
                                assert resLink != null;
                                assert existingLink != null;
                                assert resLink.getId() != null;
                                assert existingLink.getId() != null;
                                if (existingLink == resLink || resLink.getId().equals(existingLink.getId()))
                                    throw new InvalidRspecException("Duplicate link in XML Rspec: id=\"" + resLink.getId() + "\"");
                            }
                            res.getLinks().add(resLink);

                            for (Object linkElO : link.getAnyOrPropertyOrLinkType()) {
                                if (linkElO instanceof JAXBElement) {
                                    JAXBElement linkEl = (JAXBElement) linkElO;
                                    if (linkEl.getValue() instanceof be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.InterfaceRefContents) {
                                        be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.InterfaceRefContents ic =
                                                (be.iminds.ilabt.jfed.rspec.advertisement.geni_rspec_3.InterfaceRefContents) linkEl.getValue();

                                        RspecInterface iface = nameToIface.get(ic.getComponentId());
                                        if (iface == null) {
                                            RspecNode rspecNode = ifaceNameToRspecNode.get(ic.getComponentId());

                                            if (rspecNode != null) {
                                                iface = new RspecInterface(rspecNode, resLink, ic.getComponentId());
                                                iface.setPropertiesFromGeni3AdvertisementRspec(ic);
                                                iface.setPropertiesFromGeni3AdvertisementRspec(ifaceNameToIfaceContents.get(ic.getComponentId()));
                                                nameToIface.put(iface.getId(), iface);
                                            }
                                        }

                                        if (iface == null) {
                                            throw new InvalidRspecException("Interface has not been defined in a <node>, but is referred to in a <link>: " + ic.getComponentId());
                                        }

                                        //adding interface to link here would be a bug, because interface should not be added here! RspecInterface constructor already adds to link
//                                    //check if iface with same name is not already added
//                                    for (RspecInterface existingIface : resLink.getInterfaces())
//                                        if (existingIface == iface || iface.getId().equals(existingIface.getId()))
//                                            throw new RuntimeException("Duplicate interfaces in XML Rspec: id=\""+existingIface.getId()+"\"");
//                                    resLink.getInterfaces().add(iface);

                                        //fill in iface details
                                    }
                                }
                            }

                            //set properties AFTER interfaces have been added
                            resLink.setPropertiesFromGeni3AdvertisementRspec(link);

                        } catch (Throwable e) {
                            LOG.error("Error parsing link. Will remove link from RSpec: " + e.getMessage(), e);
                            //break down link
                            if (resLink != null) {
                                res.getLinks().remove(resLink);
                                List<RspecInterface> ifaces = new ArrayList<>(resLink.getInterfaces());
                                for (RspecInterface iface : ifaces) {
                                    iface.delete();
                                }
                            }
                        }
                    }
                    if (!handled) {
//                        LOG.debug("Unhandled rspec JAXBElement value class: " + el.getValue().getClass().getName());
                        res.others.add(el);
                    }
                } else {
                    if (o instanceof ElementNSImpl) {
//                        ElementNSImpl elementNS = (ElementNSImpl) o;
//                        LOG.debug("elementNS " + elementNS.toString() + " ");
                    } else {
//                        LOG.debug("Unhandled rspec element class: " + o.getClass().getName());
                    }
                }
            }


//            LOG.trace("rspec type "+c.getType().value()+" ");

            return res;
        } catch (Exception e) {

            throw new InvalidRspecException("Error reading Advertisement Rspec XML", e);
        }
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///// WARNING: very dirty cut and paste code reuse between fromGeni3RequestRspecXML and fromGeni3ManifestRspecXML and fromGeni3AdvertisementRspecXML! /////
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public enum RequestRspecSpecialCases {NONE, PLE, NITOS}

    ;

    /**
     * For the moment, this does nothing more than call toGeni3RequestRspec_internal and write Xml To string.
     * Later, this can be edited to handle special cases in the geni request rspec v3 generation.
     * <p/>
     * only the PLE case is handled now, but it works automatically, without a need to specify it.
     */
    public String toGeni3RequestRspec(RequestRspecSpecialCases specialCase) {
        boolean addSchemaLocation = true;
        RSpecContents res;
        switch (specialCase) {
            case NONE: {
                res = toGeni3RequestRspec_internal(null);
                break;
            }
            case PLE: {
                //already using quick hack to get ple to work in: RspecNode.writePropertiesToGeni3RequestRspec()
                List<String> allowedComponentManagers = new ArrayList<>();
                allowedComponentManagers.add("urn:publicid:IDN+ple:ibbtple+authority+cm");
                res = toGeni3RequestRspec_internal(allowedComponentManagers);
                addSchemaLocation = false; //ple also doesn't like schemaLocation
                break;
            }
            case NITOS: {
                /* example:

                <?xml version="1.0"?>
                <rspec type="request"
                       xmlns="http://www.geni.net/resources/rspec/3"
                       xmlns:ol="http://nitlab.inf.uth.gr/schema/sfa/rspec/1"
                       xmlns:omf="http://schema.mytestbed.net/sfa/rspec/1"
                       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                       xsi:schemaLocation="http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd http://nitlab.inf.uth.gr/schema/sfa/rspec/1 http://nitlab.inf.uth.gr/schema/sfa/rspec/1/request-reservation.xsd"
                       >
                  <ol:lease client_id="l1" valid_from="2013-01-08T19:00:00Z" valid_until="2013-01-08T20:00:00Z"/>
                  <node component_id="urn:publicid:IDN+omf:nitos+node+omf.nitos.node001"
                        component_manager_id="urn:publicid:IDN+omf:nitos+authority+am"
                        component_name="node1"
                        exclusive="true"
                        client_id="my_node">
                    <interface component_id="urn:publicid:IDN+omf:nitos+interface+control"
                               component_name="control">
                      <ip address="10.0.0.1"/>
                    </interface>
                    <ol:lease_ref id_ref="l1"/>
                  </node>
                </rspec>

                */

                res = toGeni3RequestRspec_internal(null);

//                //need to add lease
//                try {
//                    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//                    DocumentBuilder db = dbf.newDocumentBuilder();
//                    Document document = db.newDocument();
//
//                    org.w3c.dom.Element lease = document.createElementNS("http://nitlab.inf.uth.gr/schema/sfa/rspec/1", "lease");
//                    lease.setAttribute("client_id", "l1");
//                    lease.setAttribute("valid_from", javax.xml.bind.DatatypeConverter.printDateTime(Calendar.getInstance()));
//                    Calendar until = Calendar.getInstance();
//                    until.setTime(new Date(System.currentTimeMillis() + 5*60*60*1000));
//                    lease.setAttribute("valid_until", javax.xml.bind.DatatypeConverter.printDateTime(until));
//
//                    res.getAnyOrNodeOrLink().add(lease);
//
//                    LOG.debug("HACK: forcing \"lease\" element to Nitos request RSpec --> success!");
//
//                } catch (ParserConfigurationException e) {
//                    LOG.error("Error while forcing \"lease\" element to Nitos request RSpec", e);
//                }

                break;
            }
            default:
                throw new RuntimeException("Special case " + specialCase + " not supported");
        }

        StringWriter sw = new StringWriter();
        try {
            JAXBContext context =
                    JAXBContext.newInstance(RSpecContents.class, Location.class, NodeDescriptionType.class);
            Marshaller m = context.createMarshaller();

            /*
            * see http://stackoverflow.com/questions/2326107/what-happened-to-jaxbs-namespaceprefixmapper-in-jdk6u18
            *
            * This is not guaranteed to always work. But it is the only thing that does what is needed...
            * */
            if (origIsParsed)
//                m.setProperty("com.sun.xml.internal.bind.namespacePrefixMapper", new NamespacePrefixMapper() {
                m.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapper() {
                    @Override
                    public String[] getPreDeclaredNamespaceUris() {
                        Collection<String> res = origNameSpaceInfo.values();
                        String[] resArr = new String[res.size()];
                        int i = 0;
                        for (String s : res)
                            resArr[i++] = s;
                        return resArr;
//                                return new String[] { origSchemaLocation };
                    }

                    @Override
                    public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
                        for (Map.Entry<String, String> e : origNameSpaceInfo.entrySet())
                            if (namespaceUri.equals(e.getValue()))
                                return e.getKey();
                        return suggestion;

                    }
                });

                   /*
                   * Note: annotation in Location package-info.java is:
                   *
                       @javax.xml.bind.annotation.XmlSchema(
                       namespace = "http://jfed.iminds.be/rspec/ext/jfed/1"
                       , xmlns = {
                           @javax.xml.bind.annotation.XmlNs(prefix = "jFed", namespaceURI = "http://jfed.iminds.be/rspec/ext/jfed/1") }
                       , elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)


                       annotation in RspecConet's pacakge-info is:
       @javax.xml.bind.annotation.XmlSchema(namespace = "http://www.geni.net/resources/rspec/3"
               , xmlns = {
                           @javax.xml.bind.annotation.XmlNs(prefix = "", namespaceURI = "http://www.geni.net/resources/rspec/3") }
               , elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)


                           the prefix is set to "" there, so that it becomes the default namespace. (it is silly one cannot do this in code when creating the context...)
                   * */

            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);


            if (addSchemaLocation) {
                if (!origIsParsed)
                    m.setProperty(Marshaller.JAXB_SCHEMA_LOCATION, "http://www.geni.net/resources/rspec/3 http://www.geni.net/resources/rspec/3/request.xsd");
                else {
                    if (origSchemaLocation != null)
                        m.setProperty(Marshaller.JAXB_SCHEMA_LOCATION, origSchemaLocation); //TODO add our own locations to this
                }
            }

            LOG.debug("Marshalling Rpsec XML");
            m.marshal(res, sw);
            return sw.getBuffer().toString();
        } catch (JAXBException e) {
            LOG.error("Error converting to Rspec", e);
            throw new RuntimeException("Error converting to Rspec" + e, e);
        }
    }

    public String toGeni3RequestRspec() {
        return toGeni3RequestRspec(RequestRspecSpecialCases.NONE);
    }

    public RSpecContents toGeni3RequestRspec_internal(List<String> allowedComponentManagers) {
        RSpecContents res = new RSpecContents();
        res.setType(RspecTypeContents.REQUEST);
        res.setGeneratedBy("Experimental jFed Rspec Editor");
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        DatatypeFactory datatypeFactory = null;
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            throw new RuntimeException("Could not create DataFactory needed to get current time as XMLGregorianCalendar: " + e.getMessage(), e);
        }
        XMLGregorianCalendar now = datatypeFactory.newXMLGregorianCalendar(gregorianCalendar);
        res.setGenerated(now);

        for (RspecNode node : nodes) {
            assert !node.getId().isEmpty();

            if (allowedComponentManagers != null && !allowedComponentManagers.contains(node.getComponentManagerId()))
                continue;

            NodeContents nodeContents = new NodeContents();
            node.writePropertiesToGeni3RequestRspec(nodeContents);
            assert nodeContents.getClientId() != null;

            List<RspecInterface> ifaces = node.getInterfaces();
            for (RspecInterface iface : ifaces) {
                assert !iface.getId().isEmpty() : "iface.getId() is empty for node " + node.getId();

                InterfaceContents interfaceContents = new InterfaceContents();
                iface.writePropertiesToGeni3RequestRspec(interfaceContents);
                nodeContents.getAnyOrRelationOrLocation().add(interfaceContents);
            }
            res.getAnyOrNodeOrLink().add(nodeContents);
        }
        for (RspecLink link : links) {
            LinkContents linkContents = new LinkContents();
            link.writePropertiesToGeni3RequestRspec(linkContents);
            assert linkContents.getClientId() != null;

            if (allowedComponentManagers != null) {
                boolean skipLink = true;
                for (String cm : link.getComponentManagerUrns())
                    if (allowedComponentManagers.contains(cm))
                        skipLink = false;
                if (skipLink)
                    continue;
            }

            List<RspecInterface> ifaces = link.getInterfaces();
            for (RspecInterface iface : ifaces) {
                assert !iface.getId().isEmpty();
                InterfaceRefContents interfaceContents = new InterfaceRefContents();
                iface.writePropertiesToGeni3RequestRspec(interfaceContents);
                linkContents.getAnyOrPropertyOrLinkType().add(interfaceContents);
            }

            assert !link.getId().isEmpty();

            res.getAnyOrNodeOrLink().add(linkContents);
        }
        res.getAnyOrNodeOrLink().addAll(others);

        return res;
    }

    public List<String> getAllComponentManagerUrns() {
        Set<String> urns = new HashSet<>();
        for (RspecNode node : nodes)
            if (node.getComponentManagerId() != null)
                urns.add(node.getComponentManagerId());
        for (RspecLink link : links)
            for (String cmUrn : link.getComponentManagerUrns())
                urns.add(cmUrn);

        return new ArrayList<>(urns);
    }


    public String nextLinkName() {
        List<String> names = new ArrayList<>();
        for (RspecLink n : links)
            names.add(n.getId());

        int c = nodes.size();
        String res = "link" + c;
        while (names.contains(res))
            res = "link" + (++c);

        return res;
    }

    public String nextNodeName() {
        List<String> names = new ArrayList<>();
        for (RspecNode n : nodes)
            names.add(n.getId());

        int c = nodes.size();
        String res = "node" + c;
        while (names.contains(res))
            res = "node" + (++c);

        return res;
    }

    public String nextIfaceName(RspecNode node) {
        List<String> names = new ArrayList<>();
        for (RspecNode n : nodes)
            for (RspecInterface i : n.getInterfaces())
                names.add(i.getId());

//        int c = nodes.size();
        int c = node.getInterfaces().size();
        String res = node.getId() + ":if" + c;
        while (names.contains(res))
            res = node.getId() + ":if" + (++c);

        return res;
    }

}
