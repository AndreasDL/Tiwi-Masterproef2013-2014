package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.lowlevel.GeniUserProvider;
import be.iminds.ilabt.jfed.lowlevel.authority.AuthorityListModel;
import be.iminds.ilabt.jfed.lowlevel.authority.JFedAuthorityList;
import be.iminds.ilabt.jfed.lowlevel.connection.GeniConnectionProvider;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaConnectionPool;
import be.iminds.ilabt.jfed.lowlevel.userloginmodel.UserLoginModelManager;
import be.iminds.ilabt.jfed.util.JavaFXLogger;

/**
 * BasicGuiModel
 */
public class BasicAppModel implements AppModel {
    protected final JavaFXLogger logger;
    protected final AuthorityListModel authorityListModel;
    protected final UserLoginModelManager userLoginModelManager;
    protected final EasyModel easyModel;
    protected final SfaConnectionPool sfaConnectionPool;

    public BasicAppModel() {
        this.logger = new JavaFXLogger(true /*synchronous processing*/);
        //initialize UserLoginModelManager
        this.authorityListModel = JFedAuthorityList.getAuthorityListModel();
        this.userLoginModelManager = new UserLoginModelManager(authorityListModel, logger);
        this.userLoginModelManager.load();

        this.easyModel = new EasyModel(logger, authorityListModel, userLoginModelManager);
        this.sfaConnectionPool = new SfaConnectionPool();
    }

    @Override public JavaFXLogger getLogger() { return logger; }

    @Override public AuthorityListModel getAuthorityListModel() { return authorityListModel; }
    @Override public AuthorityList getAuthorityList() { return easyModel.getAuthorityList(); }

    @Override public GeniUserProvider getGeniUserProvider() { return userLoginModelManager; }

    @Override public EasyModel getEasyModel() { return easyModel; }

    @Override public GeniConnectionProvider getConnectionProvider() { return sfaConnectionPool; }
}
