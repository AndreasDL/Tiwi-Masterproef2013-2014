package be.iminds.ilabt.jfed.highlevel.controller;

/**
 * TaskFinishedCallback
 */
public interface TaskFinishedCallback {
    public void onTaskFinished(Task task, SingleTask singleTask, SingleTask.TaskState state);
}
