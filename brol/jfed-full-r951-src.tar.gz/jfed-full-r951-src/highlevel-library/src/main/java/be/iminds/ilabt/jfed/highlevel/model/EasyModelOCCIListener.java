package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.log.ApiCallDetails;
import be.iminds.ilabt.jfed.lowlevel.api.OCCI;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.SliverStatus;
import be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl.OcciToAggregateManagerWrapper;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniUrn;
import javafx.application.Platform;
import javafx.util.Pair;
import org.apache.logging.log4j.LogManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * EasyModelSliceAuthorityListener: this watches for OCCI calls and fills in EasyModel using the info in them
 *
 * WARNING: this assumes a special mapping between OCCI concepts and SFA concepts, see also OcciToAggregateManagerWrapper
 * @see be.iminds.ilabt.jfed.lowlevel.api_wrapper.impl.OcciToAggregateManagerWrapper
 */
public class EasyModelOCCIListener extends EasyModelAbstractListener {
    public static final String bonfireUrnPart = OcciToAggregateManagerWrapper.bonfireUrnPart;
    public static final GeniUrn bonfireUrn = new GeniUrn(bonfireUrnPart, "authority", "cm");

    private final static org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    private static boolean debug = false;

    public EasyModelOCCIListener(EasyModel model) {
        super(model);
    }

    public void seeAdvertisementRspec(SfaAuthority auth, boolean available, String rspec) {
        LOG.trace("EasyModelOCCIListener.seeAdvertisementRspec("+auth.getName()+", "+available+", rspec.length="+rspec.length()+")");
        AuthorityInfo ai = model.getAuthorityList().get(auth);
        ai.setAdvertisementRspec(available, rspec);
    }

//    public void seeRequestRspec(SfaAuthority auth, String sliceUrn, List<String> sliverUrns, String rspec) {
//        model.getRSpecList().seeRequestRspec(auth, sliceUrn, sliverUrns, rspec);
//    }


    private void onLocationsResult(ApiCallDetails result) {
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            List<String> sites = OcciToAggregateManagerWrapper.parseLocationsXml(result.getHttpReply());
            LOG.debug("EasyModelOCCIListener.onLocationsResult: Received "+sites.size()+" locations from server: "+sites);
            final String adRspec = OcciToAggregateManagerWrapper.fakeAdvertisementRspec(sites);
            LOG.debug("EasyModelOCCIListener.onLocationsResult: Created fake advertisement Rspec: "+adRspec);

            boolean available = true; /* experiment GUI looks only at available */
            seeAdvertisementRspec(result.getAuthority(), available, adRspec);
        }
    }

    /*
    *  NOTE: onExperimentComputes and onLocationCompute are needed to process status information
    *
    *  A big hack is used here to process this date.
    *  It relies some assumptions:
    *   - one single EasyModelOCCIListener exists and sees all calls.
    *   - first onExperimentComputes is called, and then onLocationCompute for each compute in it.
    * */

    //these 2 mappings are kept in sync by receiving calls
    private Map<String, List<OcciToAggregateManagerWrapper.ComputeInfo>> experimentIdToComputeInfoList = new HashMap<>();
    private Map<Pair<String, String>, OcciToAggregateManagerWrapper.ComputeInfo> locationAndComputeIdToComputeInfo = new HashMap<>();

    private void onExperimentComputes(ApiCallDetails result) {
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            String experimentId = (String) result.getMethodParameters().get("experimentId");
            assert experimentId != null; //must be in parameters of getExperimentComputes
            GeniUrn sliceUrn = OcciToAggregateManagerWrapper.mapExperimentIdToSliceUrn(experimentId);
            assert sliceUrn != null;
            List<OcciToAggregateManagerWrapper.ComputeInfo> infoRecv = OcciToAggregateManagerWrapper.parseExperimentComputes(experimentId, result.getHttpReply());
            //infoRecv contains only locationName, computeId and experimentId, no other fields.
            for (OcciToAggregateManagerWrapper.ComputeInfo computeInfoRecv : infoRecv)
                if (computeInfoRecv.experimentId != null && computeInfoRecv.locationName != null && computeInfoRecv.computeId != null) {
                    computeInfoToSliceUrn.put(new Pair<String, String>(computeInfoRecv.locationName, computeInfoRecv.computeId), sliceUrn);

                    List<OcciToAggregateManagerWrapper.ComputeInfo> storedExpInfoList = experimentIdToComputeInfoList.get(computeInfoRecv.experimentId);
                    if (storedExpInfoList == null) {
                        storedExpInfoList = new ArrayList<OcciToAggregateManagerWrapper.ComputeInfo>();
                        experimentIdToComputeInfoList.put(computeInfoRecv.experimentId, storedExpInfoList);
                    }
                    //warning, this is an inefficient and slow algorithm! But this list should not get long, so we ignore it for now
                    //TODO: make this more efficient! (now quadratic complexity!)
                    boolean hasThisCompute = false;
                    for (OcciToAggregateManagerWrapper.ComputeInfo storeExpInf : storedExpInfoList) {
                        if (storeExpInf.computeId.equals(computeInfoRecv.computeId) && storeExpInf.locationName.equals(computeInfoRecv.locationName)) {
                            hasThisCompute = true;
                            computeInfoRecv = storeExpInf; //use stored version from now. (used if not yet stored in locationAndComputeIdToComputeInfo below)
                            break;
                        }
                    }
                    if (!hasThisCompute)
                        storedExpInfoList.add(computeInfoRecv);

                    Pair<String, String> key = new Pair<>(computeInfoRecv.locationName, computeInfoRecv.computeId);
                    OcciToAggregateManagerWrapper.ComputeInfo storedComputeInfo2 =
                            locationAndComputeIdToComputeInfo.get(key);
                    if (storedComputeInfo2 == null) {
                        locationAndComputeIdToComputeInfo.put(key, computeInfoRecv);
                        assert !hasThisCompute : "should always be added to both lists at once: was in experimentIdToComputeInfoList but not in locationAndComputeIdToComputeInfo";
                    } else {
                        assert hasThisCompute : "should always be added to both lists at once: was not in experimentIdToComputeInfoList but was in locationAndComputeIdToComputeInfo";
                    }
                } else {
                    LOG.warn("Parsed info received from /experiments/<ID>/computes missed some field!"+
                            " experimentId="+computeInfoRecv.experimentId+
                            " locationName="+computeInfoRecv.locationName+
                            " computeId="+computeInfoRecv.computeId);
                }
            refreshStatus(sliceUrn, result.getAuthority());
        }
    }

    private void onPostExperiment(ApiCallDetails result) {
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            OcciToAggregateManagerWrapper.ExperimentInfo expInf = OcciToAggregateManagerWrapper.parseExperiment(result.getAuthority(), null/*sliceUrn*/, result.getHttpReply());
            assert expInf.experimentId != null;
            assert expInf.experimentName != null;
            assert expInf.sliverUrn != null;

            assert expInf.sliceUrn == null;
            expInf.sliceUrn = OcciToAggregateManagerWrapper.mapExperimentIdToSliceUrn(expInf.experimentId);
            assert expInf.sliceUrn != null;
            assert expInf.sliverUrn.equals(OcciToAggregateManagerWrapper.mapSliceUrnToSliverUrn(expInf.sliceUrn));

            //logExistSliverGeniSingle also logs slice existence
            model.logExistSliverGeniSingle(expInf.sliceUrn, expInf.sliverUrn, result.getAuthority());
        }
    }

    private void onPostExperimentCompute(ApiCallDetails result) {
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            OcciToAggregateManagerWrapper.ComputeInfo expInf = OcciToAggregateManagerWrapper.parseCompute(result.getHttpReply());
            //TODO: do something with this?
        }
    }

    private Map<Pair<String, String>, GeniUrn> computeInfoToSliceUrn = new HashMap<>();
    private void onLocationCompute(ApiCallDetails result) {
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            OcciToAggregateManagerWrapper.ComputeInfo infoRecv = OcciToAggregateManagerWrapper.parseCompute(result.getHttpReply());
            assert infoRecv.locationName != null;
            assert infoRecv.computeId != null;
            OcciToAggregateManagerWrapper.ComputeInfo infoToUpdate =
                    locationAndComputeIdToComputeInfo.get(new Pair<String, String>(infoRecv.locationName, infoRecv.computeId));
            infoToUpdate.state = infoRecv.state;

            refreshStatus(
                    computeInfoToSliceUrn.get(new Pair<String, String>(infoRecv.locationName, infoRecv.computeId)),
                    result.getAuthority());
        }
    }

    private void refreshStatus(GeniUrn sliceUrn, SfaAuthority auth) {
        boolean allReady = true;


        for (String experimentId : experimentIdToComputeInfoList.keySet()) {
            GeniUrn sliverUrn = OcciToAggregateManagerWrapper.mapSliceUrnToSliverUrn(sliceUrn);

            for (OcciToAggregateManagerWrapper.ComputeInfo computeInfo : experimentIdToComputeInfoList.get(experimentId)) {
                LOG.debug("EasyModelOCCIListener.refreshStatus computeId="+computeInfo.computeId+" state="+computeInfo.state);
                if (computeInfo.state != null) {
                    LOG.debug("                                    ready="+computeInfo.ready());
                    if (!computeInfo.ready()) allReady = false;
                } else
                    allReady = false;

            }
            if (experimentIdToComputeInfoList.isEmpty()) return;

            LOG.debug("EasyModelOCCIListener.refreshStatus allReady="+allReady);

            //TODO register state in already
            Slice slice = model.logExistSlice(sliceUrn);
            assert slice != null;

            Sliver sliver = model.logExistSliverGeniSingle(sliceUrn, sliverUrn, auth);
            assert sliver != null;

            sliver.setStatusString(allReady ? "ready" : "changing");
            sliver.setStatus(allReady ? SliverStatus.READY : SliverStatus.CHANGING);

            LOG.debug("EasyModelOCCIListener.refreshStatus sliver=" + sliver.getUrn() + " status=" + sliver.getStatus());

            //to log it doesn't exist: model.logNotExistSliverGeniSingle(sliceUrn, details.getAuthority());
        }
    }



    /** process the result, in the JavaFX thread. And wait for it in this thread. */
    @Override
    public void onResult(final ApiCallDetails details) {
        assert Platform.isFxApplicationThread();
        onResultInJavaFXThread(details);
    }
    public void onResultInJavaFXThread(ApiCallDetails details) {
        if (debug) System.out.println("EasyModelOCCIListener onResultInJavaFXThread SfaCommand=\""+details.getGeniMethodName()+"\" javaCommand=\""+details.getJavaMethodName()+"\"");

        if (!details.getApiName().equals(OCCI.getApiName()))
            return;

        if (details.getJavaMethodName().equals("fakeManifest")){
            //HACK
            SfaAuthority auth = details.getAuthority();
            GeniUrn sliceUrn = (GeniUrn) details.getMethodParameters().get("sliceUrn");
            GeniUrn sliverUrn = (GeniUrn) details.getMethodParameters().get("sliverUrn");
            String manifest = (String) details.getMethodParameters().get("fakeManifest");
            Slice slice = model.logExistSlice(sliceUrn);
            Sliver sliver = model.logExistSliverGeniSingle(sliceUrn, sliverUrn, auth);
            List<Sliver> slivers = new ArrayList<>();
            slivers.add(sliver);
            AuthorityInfo authInf = model.getAuthorityList().get(auth);
            LOG.debug("EasyModelOCCIListener fakeManifest HACK sets rspec manifest on "+auth.getUrn()+" sliceUrn="+sliceUrn+" sliverUrn="+sliverUrn+" manifest.size()="+manifest.length());
            sliver.setManifestRspec(new RSpecInfo(manifest, RSpecInfo.RspecType.MANIFEST, slice, slivers, authInf));
            return;
        }

        //ignore errors here
        if (details.getReply() == null || details.getJavaMethodName() == null)
            return;

        try {
            if (details.getJavaMethodName().equals("postExperimentWizard"))
                onPostExperiment(details);
            if (details.getJavaMethodName().equals("postExperiment"))
                onPostExperiment(details);
            if (details.getJavaMethodName().equals("postExperimentCompute"))
                onPostExperimentCompute(details);
            if (details.getJavaMethodName().equals("getLocations"))
                onLocationsResult(details);
            if (details.getJavaMethodName().equals("getExperimentComputes"))
                onExperimentComputes(details);
            if (details.getJavaMethodName().equals("getLocationCompute"))
                onLocationCompute(details);
        } catch (Exception e) {
            System.err.println("WARNING: Exception when processing AggregateManager2 reply for EasyModel. This will be ignored, but it is most likely a bug. " + e.getMessage());
            e.printStackTrace();
        }
    }
}
