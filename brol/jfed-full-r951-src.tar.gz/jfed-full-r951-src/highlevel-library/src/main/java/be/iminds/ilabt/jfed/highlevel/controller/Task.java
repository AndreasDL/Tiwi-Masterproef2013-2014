package be.iminds.ilabt.jfed.highlevel.controller;

import be.iminds.ilabt.jfed.lowlevel.JFedException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Task: a Runnable with lots of extra info
 */
public abstract class Task {
    private static final AtomicLong nextId = new AtomicLong();
    public final List<TaskThread.FutureTask> futureTasks = new ArrayList<>();
    protected final String name;
    private final List<SingleTask> currentActiveSingleTasks = new ArrayList<>();
    private final List<TaskFinishedCallback> callbacks = new ArrayList<>();
    //private helper that makes sure all dependencies STAY the same objects
    protected List<Task> depCache = null;
    //private helper that makes sure all dependencies STAY the same objects
    protected List<Task> alwaysDepCache = null;
    JavaFXTaskThread.Task javafx;
    private long id = nextId.getAndIncrement();
    private SingleTask lastCompletedSingleTask = null;

    public Task(String name) {
        this.name = name;
    }

    /**
     * execute the call and throw a GeniException when needed.
     * The SingleTask this is running is is provided.
     */
    protected abstract void doTask(SingleTask singleTask) throws JFedException, JFedHighLevelException, InterruptedException;

    /**
     * override to specify dependencies
     * this is called only once
     */
    public List<Task> initDependsOn() {
        return new ArrayList<>();
    }

    /**
     * override to specify dependencies that should ALWAYS run
     * this is called only once
     */
    public List<Task> initAlwaysDependsOn() {
        return new ArrayList<>();
    }

    /**
     * Is the call still needed?
     * This checks if the data that the call retrieves is already available, or the action is already done.
     * <p/>
     * default: needed as long as this task has never completed successfully
     */
    public boolean needed() {
        return lastCompletedSingleTask == null ||
                lastCompletedSingleTask.getState() == SingleTask.TaskState.FAILED ||
                lastCompletedSingleTask.getState() == SingleTask.TaskState.CANCELLED;

        //TODO FEDIBBTDEV-278 use this instead?
//        return lastCompletedSingleTask == null || lastCompletedSingleTask.getState() != SingleTask.TaskState.SUCCESS;
    }

    public String getName() {
        return name;
    }

    public String toString() {
        String res = "Task(\"" + getName() + "";
        synchronized (currentActiveSingleTasks) {
            if (currentActiveSingleTasks.size() > 0)
                res += " active={";
            boolean first = true;
            for (SingleTask st : currentActiveSingleTasks) {
                if (!first)
                    res += ", ";
                res += st.getState();
                first = false;
            }
            if (currentActiveSingleTasks.size() > 0)
                res += "}";
        }
        if (lastCompletedSingleTask != null)
            res += " last=" + lastCompletedSingleTask.state;
        res += ")";
        return res;
    }

    protected List<Task> getDependsOn() {
        if (depCache == null)
            depCache = new ArrayList<Task>(initDependsOn());
        return depCache;
    }

    protected List<Task> getAlwaysDependsOn() {
        if (alwaysDepCache == null)
            alwaysDepCache = new ArrayList<Task>(initAlwaysDependsOn());
        return alwaysDepCache;
    }

    public synchronized boolean isActive() {
        return !currentActiveSingleTasks.isEmpty();
    }

    public synchronized int getActiveTaskCount() {
        return currentActiveSingleTasks.size();
    }

    synchronized void addActiveSingleTask(SingleTask singleTask) {
        currentActiveSingleTasks.add(singleTask);
    }

    synchronized boolean removeActiveSingleTask(SingleTask singleTask) {
        return currentActiveSingleTasks.remove(singleTask);
    }

    public synchronized List<SingleTask> getCurrentActiveSingleTasksCopy() {
        return new ArrayList<SingleTask>(currentActiveSingleTasks);
    }

    synchronized void addFuture(TaskThread.FutureTask futureTask) {
        futureTasks.add(futureTask);
    }

    synchronized boolean removeFuture(TaskThread.FutureTask futureTask) {
        return futureTasks.remove(futureTask);
    }

    synchronized List<TaskThread.FutureTask> getFuturesCopy() {
        return new ArrayList<TaskThread.FutureTask>(futureTasks);
    }

    /*
   * WARNING: No guarantee on what thread this callback will be called!
   * In particular: it most likely is not the JavaFX thread
   *
   * Note: All Call logging callbacks are already done when this callback is called.
   * */
    public void addCallback(TaskFinishedCallback callback) {
        callbacks.add(callback);
    }

    public void removeCallback(TaskFinishedCallback callback) {
        callbacks.remove(callback);
    }

    /**
     * returns a CountDownLatch, that when waited for will unlock once the task is finished.
     */
    public CountDownLatch getCompletionCountDownLatch() {
        final CountDownLatch latch = new CountDownLatch(1);

        addCallback(new TaskFinishedCallback() {
            @Override
            public void onTaskFinished(Task task, SingleTask singleTask, SingleTask.TaskState state) {
                latch.countDown();
            }
        });

        return latch;
    }

    List<TaskFinishedCallback> getCallbacks() {
        return callbacks;
    }

    public long getId() {
        return id;
    }

    SingleTask getLastCompletedSingleTask() {
        return lastCompletedSingleTask;
    }

    void setLastCompletedSingleTask(SingleTask lastCompletedSingleTask) {
        this.lastCompletedSingleTask = lastCompletedSingleTask;
    }

    List<SingleTask> getCurrentActiveSingleTasks() {
        return currentActiveSingleTasks;
    }

    //not very safe?
//        public void waitForCompleted() {
//            //TODO: check if task is ready!
//
//            final CyclicBarrier barrier = new CyclicBarrier(2);
//
//            addCallback(new TaskFinishedCallback() {
//                @Override
//                public void onTaskFinished(Task task, SingleTask singleTask, SingleTask.TaskState state) {
//                    try {
//                        barrier.await();
//                    } catch (InterruptedException ex) {
//                        return;
//                    } catch (BrokenBarrierException ex) {
//                        return;
//                    }
//                }
//            });
//
//            try {
//                barrier.await();
//            } catch (InterruptedException ex) {
//                return;
//            } catch (BrokenBarrierException ex) {
//                return;
//            }
//        }
}
