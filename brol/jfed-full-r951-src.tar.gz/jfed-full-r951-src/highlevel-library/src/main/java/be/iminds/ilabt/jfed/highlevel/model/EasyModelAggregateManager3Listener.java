package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.log.ApiCallDetails;
import be.iminds.ilabt.jfed.lowlevel.api.AggregateManager3;
import be.iminds.ilabt.jfed.lowlevel.authority.SfaAuthority;
import be.iminds.ilabt.jfed.util.GeniUrn;
import javafx.application.Platform;
import org.apache.logging.log4j.LogManager;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * EasyModelSliceAuthorityListener: this watches for SliceAuthority calls and fills in EasyModel using the info in them
 */
public class EasyModelAggregateManager3Listener extends EasyModelAbstractListener {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    public EasyModelAggregateManager3Listener(EasyModel model) {
        super(model);
    }

    private List<String> getSliceUrns(List<String> urns) {
        List<String> res = new ArrayList<String>();
        for (String u : urns) {
            GeniUrn geniUrn = GeniUrn.parse(u);
            if (geniUrn != null && geniUrn.getResourceType().equals("slice"))
                res.add(u);
        }
        return res;
    }

    private List<String> getSliverUrns(List<String> urn) {
        List<String> res = new ArrayList<String>();
        for (String u : urn) {
            GeniUrn geniUrn = GeniUrn.parse(u);
            if (geniUrn != null && geniUrn.getResourceType().equals("sliver"))
                res.add(u);
        }
        return res;
    }

    private List<String> getSliverUrnsFromSliverInfo(List<AggregateManager3.SliverInfo> sliverinfos) {
        List<String> res = new ArrayList<String>();
        for (AggregateManager3.SliverInfo si : sliverinfos)
            res.add(si.getSliverUrn());
        return res;
    }


    private void onGetVersionResult(ApiCallDetails result) {
        if (result.getReply().getGeniResponseCode().isSuccess()) {
            //TODO
        }
    }

    public void onStatusResult(AggregateManager3.StatusInfo statusInfo) {
        model.logExistSlice(statusInfo.getSliceUrn());

        onListOfSliverInfoResult(statusInfo.getSliceUrn(), statusInfo.getSliverInfo());
    }

    /**
     * @param sliceUrn urn of the slice the sliver belongs to, may be null if unknown
     */
    public void onListOfSliverInfoResult(String sliceUrn, List<AggregateManager3.SliverInfo> sliverinfos) {
        assert sliceUrn != null;
        if (sliverinfos == null) return;

        for (AggregateManager3.SliverInfo si : sliverinfos) {

            if (si.getAllocationStatus().equals("geni_unallocated")) {
                //sliver is deleted
                model.logNotExistSliver(sliceUrn, si.getSliverUrn());
            } else {
                Sliver sliver =
                        model.logExistSliver(sliceUrn, si.getSliverUrn(), true/*geni_single  todo amv3, so we need to check getversion for this*/);
                sliver.setAllocationAndOperationalStatus(si.getAllocationStatus(), si.getOperationalStatus());
                try {
                    sliver.setExpires(si.getExpiresDate());
                } catch (ParseException e) {
                    System.err.println("in EasyModelAggregateManager3Listener in onListOfSliverInfoResult(): Invalid RFC3339 date in sliver expires: " + si.getExpires());
                }
            }
        }
    }

    public void onAllocateAndProvisionInfoResult(String sliceUrn, AggregateManager3.AllocateAndProvisionInfo info) {
        onListOfSliverInfoResult(sliceUrn, info.getSliverInfo());
    }

    public void onManifestInfo(SfaAuthority auth, AggregateManager3.ManifestInfo manifestInfo) {
        assert manifestInfo != null;
        assert manifestInfo.getSliceUrn() != null;
        assert manifestInfo.getSliverInfos() != null;
        assert manifestInfo.getManifestRspec() != null;
        assert !manifestInfo.getSliverInfos().isEmpty();

        List<String> sliverUrns = getSliverUrnsFromSliverInfo(manifestInfo.getSliverInfos());
        seeManifestRspec(auth, manifestInfo.getSliceUrn(), sliverUrns, manifestInfo.getManifestRspec());

        onListOfSliverInfoResult(manifestInfo.getSliceUrn(), manifestInfo.getSliverInfos());
    }

    public void seeAdvertisementRspec(SfaAuthority auth, boolean available, String rspec) {
        AuthorityInfo ai = model.getAuthorityList().get(auth);
        ai.setAdvertisementRspec(available, rspec);
    }

//    public void seeRequestRspec(SfaAuthority auth, String sliceUrn, List<String> sliverUrns, String rspec) {
//        assert sliverUrns != null;
//        assert model.getRSpecList() != null;
//        model.getRSpecList().seeRequestRspec(auth, sliceUrn, sliverUrns, rspec);
//    }
//
//    public void seeEchoRequestRspec(SfaAuthority auth, String sliceUrn, List<String> sliverUrns, String rspec) {
//        assert sliverUrns != null;
//        assert model.getRSpecList() != null;
//        model.getRSpecList().seeEchoRequestRspec(auth, sliceUrn, sliverUrns, rspec);
//    }

    public void seeManifestRspec(SfaAuthority auth, String sliceUrn, List<String> sliverUrns, String manifestRspecString) {
        assert auth != null;
        assert sliceUrn != null;
        assert sliverUrns != null;
        assert manifestRspecString != null;
        assert !sliverUrns.isEmpty();

        Slice slice = model.getSlice(sliceUrn);
        if (slice == null) return;
        List<Sliver> sliverList = new ArrayList<Sliver>();
        for (String sliverUrn : sliverUrns) {
            Sliver sliver =
                    model.logExistSliverGeniSingle(sliceUrn, sliverUrn, auth); //since success is returned, the sliver(s) must exist
            sliverList.add(sliver);
        }

        //////// HACK for PLE ////////
        if (manifestRspecString.contains("component_manager_id=\"urn:publicid:IDN+ple+authority+cm\"")) {
            manifestRspecString = manifestRspecString.replaceAll(
                    Pattern.quote("urn:publicid:IDN+ple+authority+cm"),
                    Matcher.quoteReplacement("urn:publicid:IDN+ple:ibbtple+authority+cm"));
            LOG.warn("Using PLE hack in EasyModelAggregateManager2Listener#seeManifestRspec. succesfully applied: " +
                    (!manifestRspecString.contains("component_manager_id=\"urn:publicid:IDN+ple+authority+cm\"")));
            assert !manifestRspecString.contains("component_manager_id=\"urn:publicid:IDN+ple+authority+cm\"") :
                    "HACK applied unsuccessfully to:\n" + manifestRspecString;
        }
        //////// HACK for PLE ////////


        RSpecInfo rSpecInfo =
                new RSpecInfo(manifestRspecString, RSpecInfo.RspecType.MANIFEST, slice, sliverList, model.getAuthorityList().get(auth));

        for (Sliver sliver : sliverList) {
            LOG.debug("EasyModelAggregateManager2Listener seeManifestRspec is setting manifest for " + slice + " -> " + sliceUrn + "  " + sliver + " -> " + sliver.getUrn());
            sliver.setManifestRspec(rSpecInfo);
        }

//        //sliver exists on all cm's mentioned in manifest. (even if unallocated on others)
//        try {
//            for (String cmUrn : rSpecInfo.getRSpec().getAllComponentManagerUrns()) {
//                SfaAuthority rspecAuth = model.getAuthorityList().getAuthorityListModel().getByUrn(cmUrn);
//                if (rspecAuth == null) {
//                    LOG.error("Error in manifest: contained an unknown authority urn: \"" + cmUrn + "\"");
//                    continue;
//                }
//                model.logExistSliverGeniSingle(sliceUrn, rspecAuth); //it is in manifest, so the sliver must exist (even if it is unallocated)
//            }
//        } catch (InvalidRspecException ex) {
//            LOG.error("Error while processing Rspec XML", ex);
//        }

    }

    @Override
    public void onResult(final ApiCallDetails details) {
//        //Since this triggers updates to the GUI (because it changes Properties) this has to be executed on the JavaFX thread.
//
//        final Lock lock = new ReentrantLock();
//        final Condition waiter = lock.newCondition();
//
//        Platform.runLater(new Runnable() { @Override public void run() {
//            onResultInJavaFXThread(details);
//            lock.lock();
//            waiter.signalAll();
//            lock.unlock();
//        } });
//
//        lock.lock();
//        try {
//            waiter.await();
//        } catch (InterruptedException e) {
//            //TODO: handle?
//            e.printStackTrace();
//        }
//        lock.unlock();
        assert Platform.isFxApplicationThread();
        onResultInJavaFXThread(details);
    }

    public void onResultInJavaFXThread(ApiCallDetails details) {
        //ignore errors here
        if (details.getReply() == null || details.getJavaMethodName() == null)
            return;

        if (!details.getApiName().equals(AggregateManager3.getApiName()))
            return;

        try {
            if (details.getJavaMethodName().equals("getVersion")) //returns VersionInfo
                onGetVersionResult(details);

            if (details.getJavaMethodName().equals("listResources")) { //returns String (rspec)
                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    String rspec = (String) details.getReply().getValue();
                    boolean available = false;
                    if (details.getMethodParameters().get("available") != null)
                        available = (Boolean) details.getMethodParameters().get("available");
                    seeAdvertisementRspec(details.getAuthority(), available, rspec);
                }
            }

            if (details.getJavaMethodName().equals("describe")) { //returns ManifestInfo
                onManifestInfo(details.getAuthority(), (AggregateManager3.ManifestInfo) details.getReply().getValue());
            }

            if (details.getJavaMethodName().equals("allocate")) { //returns AllocateAndProvisionInfo
                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    AggregateManager3.AllocateAndProvisionInfo info =
                            (AggregateManager3.AllocateAndProvisionInfo) details.getReply().getValue();
                    String sliceUrn = (String) details.getMethodParameters().get("sliceUrn");
                    model.logExistSlice(sliceUrn);
                    List<String> sliverUrns = getSliverUrnsFromSliverInfo(info.getSliverInfo());
//                    seeRequestRspec(details.getAuthority(), sliceUrn, sliverUrns, (String) details.getMethodParameters().get("rspec"));
//                    seeEchoRequestRspec(details.getAuthority(), sliceUrn, sliverUrns, info.getRspec());
                    onAllocateAndProvisionInfoResult(sliceUrn, info);
                }
            }

            if (details.getJavaMethodName().equals("provision")) { //returns AllocateAndProvisionInfo
                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    AggregateManager3.AllocateAndProvisionInfo info =
                            (AggregateManager3.AllocateAndProvisionInfo) details.getReply().getValue();
                    List<String> urns = (List<String>) details.getMethodParameters().get("urns");
                    List<String> sliceUrns = getSliceUrns(urns);
                    String sliceUrn = sliceUrns.size() != 1 ? null : sliceUrns.get(0);
                    if (sliceUrn != null)
                        model.logExistSlice(sliceUrn);

                    //  alternative, get from result instead of arguments:
                    List<String> sliverUrns = getSliverUrnsFromSliverInfo(info.getSliverInfo());
                    //  alternative: get from arguments instead of result:
                    //List<String> sliverUrns = getSliverUrns(urns);

                    seeManifestRspec(details.getAuthority(), sliceUrn, sliverUrns, info.getRspec());
                    onAllocateAndProvisionInfoResult(sliceUrn, info);
                }
            }

            if (details.getJavaMethodName().equals("status")) // returns StatusInfo
            {
                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    //not much to know from urn argument?   List urns = (List) details.getMethodParameters().get("urns");
                    //TODO if single slice URN, and success and at least one sliverinfo, that slice exists...
                    onStatusResult((AggregateManager3.StatusInfo) details.getReply().getValue());
                }
            }

            if (details.getJavaMethodName().equals("performOperationalAction")) { //returns List<SliverInfo>
                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    List<AggregateManager3.SliverInfo> si =
                            (List<AggregateManager3.SliverInfo>) details.getReply().getValue();
                    List<String> urns = (List<String>) details.getMethodParameters().get("urns");
                    List<String> sliceUrns = getSliceUrns(urns);
                    String sliceUrn = sliceUrns.size() != 1 ? null : sliceUrns.get(0);
                    onListOfSliverInfoResult(sliceUrn, si);
                }
            }

            if (details.getJavaMethodName().equals("delete")) { //returns List<SliverInfo>
                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    List<AggregateManager3.SliverInfo> si =
                            (List<AggregateManager3.SliverInfo>) details.getReply().getValue();
                    List<String> urns = (List<String>) details.getMethodParameters().get("urns");
                    List<String> sliceUrns = getSliceUrns(urns);
                    String sliceUrn = sliceUrns.size() != 1 ? null : sliceUrns.get(0);
                    onListOfSliverInfoResult(sliceUrn, si);
                }
            }

            if (details.getJavaMethodName().equals("renew")) { //returns List<SliverInfo>
                if (details.getReply().getGeniResponseCode().isSuccess()) {
                    List<AggregateManager3.SliverInfo> si =
                            (List<AggregateManager3.SliverInfo>) details.getReply().getValue();
                    List<String> urns = (List<String>) details.getMethodParameters().get("urns");
                    List<String> sliceUrns = getSliceUrns(urns);
                    String sliceUrn = sliceUrns.size() != 1 ? null : sliceUrns.get(0);
                    onListOfSliverInfoResult(sliceUrn, si);
                }
            }

            if (details.getJavaMethodName().equals("shutdown")) { //returns Boolean
                //ignored
            }
        } catch (Exception e) {
            System.err.println("WARNING: Exception when processing AggregateManager3 reply for EasyModel. This will be ignored, but it is most likely a bug. " + e.getMessage());
            e.printStackTrace();
        }
    }
}
