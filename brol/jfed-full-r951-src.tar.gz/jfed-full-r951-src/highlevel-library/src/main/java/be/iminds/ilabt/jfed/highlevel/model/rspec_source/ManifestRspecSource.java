package be.iminds.ilabt.jfed.highlevel.model.rspec_source;

import be.iminds.ilabt.jfed.rspec.model.InvalidRspecException;
import be.iminds.ilabt.jfed.rspec.model.ModelRspec;
import be.iminds.ilabt.jfed.rspec.model.RspecNode;
import be.iminds.ilabt.jfed.rspec.model.StringRspec;
import be.iminds.ilabt.jfed.util.GeniUrn;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.stage.Stage;
import org.apache.logging.log4j.LogManager;

import java.util.ArrayList;
import java.util.List;

/**
 * RequestRspecSource
 */
public class ManifestRspecSource extends RspecSource {
    private static final org.apache.logging.log4j.Logger LOG = LogManager.getLogger();

    public ManifestRspecSource(StringRspec stringRspec) {
        super(stringRspec);
    }

    //cannot convert from model to string! So we don't want this constructor.
//    public ManifestRspecSource(ModelRspec modelRspec) {
//        super(modelRspec);
//    }

    /** Determines automatically to use raw XML, or ModelRspec */
    public ManifestRspecSource(String xmlRspecString) {
        super(xmlRspecString);
    }

    @Override
    protected ModelRspec stringToModel(StringRspec s) throws InvalidRspecException {
        return ModelRspec.fromGeni3ManifestRspecXML(s.getXmlString());
    }

    @Override
    protected String modelToString(ModelRspec s, ModelRspec.RequestRspecSpecialCases rspecSpecialCase) {
        throw new RuntimeException("Cannot convert from manifest model to manifest XML");
    }

    public static class LoginService {
        private final String authentication;
        private final String hostname;
        private final int port;
        private final String username;

        public LoginService(String authentication, String hostname, int port, String username) {
            this.authentication = authentication;
            this.hostname = hostname;
            this.port = port;
            this.username = username;
        }

        public String getAuthentication() { return authentication; }
        public String getHostname() { return hostname; }
        public int getPort() { return port; }
        public String getUsername() { return username; }
    }

    //TODO: fall back to parsing string itself, instead of using ModelRspec
    public List<LoginService> getNodeLoginInfo(RspecNode requestNode) {
        String nodeId = requestNode.getId();
        ModelRspec mRSpec = getModelRspec();
        if (mRSpec == null) return getStringRspec().getNodeLoginInfo(requestNode);
        RspecNode manifestRspecNode = mRSpec.getNodeById(nodeId);

        if (manifestRspecNode == null || manifestRspecNode.getLoginServices().size() == 0) {
            boolean fail = true;
            ///////////// HACK to make PLE work /////////////
            //ple changes node id in manifest (which is a major bug on their part)
            //if ple and if can find node for same component manager, use that one instead!
            GeniUrn comManIdUrn = GeniUrn.parse(requestNode.getComponentManagerId());
            if (comManIdUrn != null && (comManIdUrn.getTopLevelAuthority().equals("ple") || comManIdUrn.getTopLevelAuthority().startsWith("ple:"))) {
                LOG.warn("No node with login info found: Using hack for PLE to find a node that might match");
                String searchedComponentId = requestNode.getComponentId();
                for (RspecNode node : mRSpec.getNodes()) {
                    LOG.warn("  PLE hack: checking if node for \"" + node.getComponentId() + "\" matches searched component id \"" + searchedComponentId + "\"");
                    if (node.getComponentId() != null && node.getComponentId().equals(searchedComponentId))
                        manifestRspecNode = node;
                }

                if (manifestRspecNode != null && manifestRspecNode.getLoginServices().size() > 0) {
                    LOG.warn("===> PLE HACK successfully found a node to login to. Not guaranteed to be the correct node if multiple for the same component_id exist.");
                    fail = false;
                } else {
                    LOG.warn("===> PLE HACK failed to find login node");
                }
            }
            ///////////// HACK to make PLE work /////////////

            if (fail)
                return null;
        }

        List<LoginService> res = new ArrayList<>();
        for (RspecNode.LoginService rspecLoginService : manifestRspecNode.getLoginServices()) {
            LoginService ls = new LoginService(
                    rspecLoginService.getAuthentication(),
                    rspecLoginService.getHostname(),
                            Integer.parseInt(rspecLoginService.getPort()),
                    rspecLoginService.getUsername());
            res.add(ls);
        }

        return res;
    }
}
