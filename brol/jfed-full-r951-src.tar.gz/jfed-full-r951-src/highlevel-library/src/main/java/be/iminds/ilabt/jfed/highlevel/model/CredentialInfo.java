package be.iminds.ilabt.jfed.highlevel.model;

import be.iminds.ilabt.jfed.lowlevel.AnyCredential;

/**
 * CredentialInfo wraps AnyCredential
 *
 * fields of credential: name, xml, type and version
 *
 * TODO: do I need this wrapper?
 */
public class CredentialInfo {
    private AnyCredential credential;

    public CredentialInfo(AnyCredential credential) {
        this.credential = credential;
    }

    public AnyCredential getCredential() {
        return credential;
    }


    public String toString() {
        return credential.getName();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CredentialInfo that = (CredentialInfo) o;

        if (credential != null ? !credential.equals(that.credential) : that.credential != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return credential != null ? credential.hashCode() : 0;
    }
}
