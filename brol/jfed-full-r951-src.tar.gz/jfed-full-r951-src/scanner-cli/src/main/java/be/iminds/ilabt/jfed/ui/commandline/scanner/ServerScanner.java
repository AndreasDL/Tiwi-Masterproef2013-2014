package be.iminds.ilabt.jfed.ui.commandline.scanner;

import be.iminds.ilabt.jfed.lowlevel.api.ProtogeniSliceAuthority;
import be.iminds.ilabt.jfed.lowlevel.authority.*;
import be.iminds.ilabt.jfed.lowlevel.*;
import be.iminds.ilabt.jfed.log.Logger;
import be.iminds.ilabt.jfed.lowlevel.api.AggregateManager2;
import be.iminds.ilabt.jfed.lowlevel.api.AggregateManager3;
import be.iminds.ilabt.jfed.lowlevel.connection.SfaSslConnection;
import be.iminds.ilabt.jfed.util.*;
import org.apache.commons.cli.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * CommandLineClient
 */
public class ServerScanner {

    public static void help(Options options) {
        HelpFormatter formatter = new HelpFormatter();
        formatter.printHelp(200, "jfed-scanner-cli [options ... ] <server url or urn> [<server url or urn> ...]", "Possible options:", options, "");
    }

    public static void main(String[] args) throws JFedException, IOException {
        CommandLineParser parser = new BasicParser();

        // create the Options
        Options options = new Options();
        options.addOption( "k", "key-file", true, "file containing user certificate and key in PEM format" );
        options.addOption( OptionBuilder.withLongOpt( "context-file" )
                .withDescription( "get user authentication info from the provided context properties file (same format as used by automated tester. Test authority is ignored.)" )
                .hasArg()
                .withArgName("CONTEXT_FILE")
                .create() );
        options.addOption( OptionBuilder.withLongOpt("output-file")
                .withDescription( "The xml file to write the xml description of the scanned servers to. Default: write to stdout" )
                .hasArg()
                .withArgName("OUTPUT XML FILE")
                .create() );
        options.addOption( "q", "quiet", false, "less output" );
        options.addOption( "d", "debug", false, "extra debugging output" );
        options.addOption( "U", "accept-getversion-without-urn", false, "Accept info from GetVersion call replies that return no URN." );

        CommandLine line = null;
        try {
            // parse the command line arguments
            line = parser.parse( options, args );
        }
        catch( ParseException exp ) {
            System.err.println( "Command line argument Syntax error: " + exp.getMessage() );
            help(options);
            System.exit(1);
        }

        boolean debug = line.hasOption("debug");
        boolean acceptGetversionWithoutUrn = line.hasOption("accept-getversion-without-urn");
        String outputfile = line.getOptionValue("output-file");
        boolean silent = line.hasOption("quiet");
        String pemKeyCertFilename = line.getOptionValue("key-file");
        String contextProperties = line.getOptionValue("context-file");

        //first check if mandatory options are given (we don;t do this using the library, because it's either context-file or it is a number of other options  )
        boolean contextExists = line.hasOption("context-file");

        if (contextExists && line.hasOption("k")) {
            System.err.println("--context-file cannot be combined with -k (--key-file)");
            help(options);
            System.exit(1);
        }
        if (!contextExists && !line.hasOption("k")) {
            File defaultPemKeyCertFile = new File(System.getProperty("user.home")+ File.separator+".ssl"+File.separator+"geni_cert.pem");
            if (defaultPemKeyCertFile.exists())
                pemKeyCertFilename = defaultPemKeyCertFile.getPath();
            else {
                System.err.println("Either --context-file or -k (--key-file) has to be specified unless the default file exists ("+defaultPemKeyCertFile.getPath()+")");
                help(options);
                System.exit(1);
            }
        }

        List<String> arguments = line.getArgList();
        if (arguments.size() < 1) {
            System.err.println("No URN or urls specified.");
            String inputs = IOUtils.askCommandLineInput("Give a list of space seperated inputs");
            String[] in = inputs.split(" ");
            for (String i : in)
                arguments.add(i);
            if (arguments.size() < 1) {
                System.err.println("Error: No URN or urls specified.");
                help(options);
                System.exit(1);
            }
        }


        SfaAuthority.debug = false; //ugly hack to suppress output
        Logger logger = new Logger();

        AggregateManager2 am2 = new AggregateManager2(logger);
        AggregateManager3 am3 = new AggregateManager3(logger);
        ProtogeniSliceAuthority sa = new ProtogeniSliceAuthority(logger);

        GeniUser user = null;
        if (contextProperties == null) {
            String pemKeyCertContent = IOUtils.fileToString(pemKeyCertFilename);
            if (pemKeyCertContent == null) {
                System.err.println("Error reading file '"+pemKeyCertFilename+"'");
                System.exit(1);
            }

            char[] pass = null;
            if (KeyUtil.hasEncryptedRsaPrivateKey(pemKeyCertContent)) {
                pass = IOUtils.askCommandLinePassword("Key password");
            }

            user = new SimpleGeniUser(null, null, pemKeyCertContent, pass, new File(pemKeyCertFilename), new File(pemKeyCertFilename)); //hack: userAuth not known, but not needed for SfaSslConnection either
        } else {
            File testContextFile = new File(contextProperties);
            if (!testContextFile.exists()) throw new FileNotFoundException("Cannot find Context properties file: "+contextProperties);

            CommandExecutionContext context = CommandExecutionContext.loadFromFile(testContextFile, true/*requireUser*/, false/*requireTestAuthority*/);
            user = context.getGeniUser();
        }

        List<String> failedScans = new ArrayList<String>();
        List<SfaAuthority> resultAuthorities = new ArrayList<SfaAuthority>();
        for (String argument : arguments) {
            List<String> serverBases = new ArrayList<String>();
            List<URL> urlsToStart = new ArrayList<URL>();
            if (GeniUrn.valid(argument)) {
                String tla = GeniUrn.parse(argument).getTopLevelAuthority();
                serverBases.add(tla);
                serverBases.add(tla+":12369"); //protogeni default
                serverBases.add(tla+":11443"); //exogeni port
            }
            try {
                URL argUrl = new URL(argument);
                urlsToStart.add(argUrl);
                String host = argUrl.getHost();
                if (argUrl.getPort() == -1)
                    serverBases.add(host);
                else
                    serverBases.add(host+":"+argUrl.getPort());
            } catch (MalformedURLException e) { /*ignore*/ }

            //if not url of urn, use it as serverbase if it doesn't contain special chars
            if (serverBases.isEmpty() && argument.matches("[-a-zA-Z_.:0-9]*")) {
                serverBases.add(argument);
            }

            for (String serverBase : serverBases) {
                //remove boss. or www. from serverbase
                if (serverBase.startsWith("boss."))
                    serverBase = serverBase.substring(5);
                if (serverBase.startsWith("www."))
                    serverBase = serverBase.substring(4);

                String wwwServerBase = "www."+serverBase;
                String bossServerBase = "boss."+serverBase;

                //no www.boss or boss.www
                if (serverBase.startsWith("www.") || serverBase.startsWith("boss."))
                    wwwServerBase = serverBase;
                if (serverBase.startsWith("boss.") || serverBase.startsWith("www."))
                    bossServerBase = serverBase;

                try {
                    urlsToStart.add(new URL("https://"+wwwServerBase+ "/protogeni/xmlrpc/am/2.0"));
                    urlsToStart.add(new URL("https://"+serverBase+    "/RPC2"));
                    urlsToStart.add(new URL("https://"+serverBase+    "/orca/xmlrpc"));
                    urlsToStart.add(new URL("https://"+wwwServerBase+ "/protogeni/xmlrpc/am/3.0"));
                    urlsToStart.add(new URL("https://"+wwwServerBase+ "/protogeni/xmlrpc/am"));
                    urlsToStart.add(new URL("https://"+serverBase+    "/protogeni/xmlrpc/am/2.0"));
                    urlsToStart.add(new URL("https://"+serverBase+    "/protogeni/xmlrpc/am/3.0"));
                    urlsToStart.add(new URL("https://"+serverBase+    "/protogeni/xmlrpc/am"));
                    urlsToStart.add(new URL("https://"+bossServerBase+"/protogeni/xmlrpc/am/2.0"));
                    urlsToStart.add(new URL("https://"+bossServerBase+"/protogeni/xmlrpc/am/3.0"));
                    urlsToStart.add(new URL("https://"+bossServerBase+"/protogeni/xmlrpc/am"));
                } catch (MalformedURLException e) { /*ignore*/ }
            }

            if (debug) {
                System.out.println("List of URL guesses for '"+argument+"': ");
                for (URL url : urlsToStart)
                    System.out.println("    "+url);
            }

            if (urlsToStart.isEmpty())
                System.err.println("No URL's can be guessed for '"+argument+"'");

            for (URL urlToTry : urlsToStart) {
                if (debug)
                    System.out.println("Trying url: "+urlToTry.toExternalForm());

                //first see if IP resolves
                try {
                    InetAddress[] ips = InetAddress.getAllByName(urlToTry.getHost());
                    if (ips == null || ips.length == 0) {
                        if (debug)
                            System.out.println("   Skipping: URL hostname does not resolve: \""+urlToTry.getHost()+"\"   -> ips="+ips);
                        continue;
                    }
                } catch (UnknownHostException e) {
                    if (debug)
                        System.out.println("   Skipping: URL hostname does not resolve: \""+urlToTry.getHost()+"\"   -> "+e.getMessage());
                    continue;
                }

                //TODO: do not run getCertificateInfo again for same server hostname+port combination
                if (debug)
                    System.out.println("   calling SSLCertificateDownloader.getCertificateInfo");
                SSLCertificateDownloader.SSLCertificateJFedInfo info = SSLCertificateDownloader.getCertificateInfo(urlToTry);

                if (debug) {
                    System.out.println("   SSLCertificateDownloader.getCertificateInfo returns");
                    System.out.println("      urn="+info.getUrn());
                    System.out.println("      subject="+info.getSubject());
                    System.out.println("      selfSigned="+info.isSelfSigned());
                    System.out.println("      subjectMatchesHostname="+info.getSubjectMatchesHostname());
                    System.out.println("      urnAuthPart="+info.getUrnAuthPart());
                }

                String urn = info.getUrn();
                if (info.getUrn() == null) {
                    urn = "urn:publicid:IDN+"+urlToTry.getHost()+"+authority+cm";
                    System.err.println("The URN of the server could not be determined from the certificate. Using placeholder URN for now: "+urn);
                }
                Map<ServerType, URL> urlMap = new HashMap<ServerType, URL>();
                urlMap.put(new ServerType(ServerType.GeniServerRole.AM, 2), urlToTry);
                SfaAuthority scannedGeniAuthority = new SfaAuthority(urn, info.getSubject(), urlMap, null/*proxies*/, null, null);

                if (info.getCert() != null) {
                    scannedGeniAuthority.setPemSslTrustCert(info.getCert());

                    if (!info.getSubjectMatchesHostname()) {
                        if (debug)
                            System.out.println("Note: Server certificate subject name is not for \""+urlToTry.getHost()+"\" but for \""+info.getSubject()+". Trusting anyway!");
                        scannedGeniAuthority.addAllowedCertificateHostnameAlias(info.getSubject());
                    }
                }

                SfaSslConnection con = new SfaSslConnection(scannedGeniAuthority,
                        urlToTry.toExternalForm(),
                        user.getClientCertificateChain(),
                        user.getPrivateKey(),
                        null /*proxyInfo*/,
                        false, null/*handleUntrustedCallback*/);


                if (debug)
                    System.out.println("   calling AMv2 GetVersion");
                AggregateManager2.AggregateManagerReply<AggregateManager2.VersionInfo> versionInfoReply = null;
                try {
                    //call getversion. If this fails, an exception is thrown, and we will call next url
                    versionInfoReply = am2.getVersion(con);

//                    if (debug)
//                        System.out.println("  Processing GetVersion result : \n"+ XmlRpcPrintUtil.printXmlRpcResultObject(versionInfoReply.getRawResult()));

                    if (!versionInfoReply.getGeniResponseCode().isSuccess()) continue; //try next url

                    AggregateManager2.VersionInfo versionInfo = versionInfoReply.getValue();

                    if (versionInfo == null) continue; //try next url

                    if (debug)
                        System.out.println("   AMv2 GetVersion returned a usable result");

                    String newHrn = versionInfo.getExtra("hrn");
                    if (newHrn != null)
                        scannedGeniAuthority.updateHrn(newHrn);

                    String newUrn = versionInfo.getExtra("urn");
                    if (newUrn != null) {
                        scannedGeniAuthority.updateUrn(newUrn);
                    } else {
                        if (acceptGetversionWithoutUrn)
                            System.out.println("     AMv2 GetVersion returned a usable result, without urn: using result. "); //TODO warn that URN is guessed in this case!
                        else {
                            System.out.println(" ************************ AMv2 GetVersion returned a usable result, without urn: not using result. ************************ ");
                            continue;
                        }
                    }

                    urlMap = new HashMap<ServerType, URL>();
                    for (AggregateManager2.VersionInfo.VersionPair apiVersion: versionInfo.getApiVersions()) {
                        try {
                            URL versionUrl =  new URL(apiVersion.getUrl());
                            if (versionUrl.getHost().equals("localhost")) {
                                System.err.println("WARNING: Aggregate Manager returned URL containing \"localhost\" in GetVersion result: " + apiVersion.getUrl() + "   (automatically fixing url using the URL you supplied)");
                                versionUrl =  new URL(apiVersion.getUrl().replace("localhost", urlToTry.getHost()));
                            }
                            if (versionUrl.getProtocol().equals("http")) {
                                System.err.println("Note: Server gave URL with http instead of https: \"" + apiVersion.getUrl() + "\". Will change it to https!");

                                //change http to https
                                versionUrl =  new URL(versionUrl.toString().replace("http://", "https://"));
                            }
                            urlMap.put(new ServerType(ServerType.GeniServerRole.AM, apiVersion.getVersionNr()), versionUrl);
                        } catch (MalformedURLException e) {
                            if (!silent)
                                System.err.println("Error: Aggregate Manager returned malformed URL in GetVersion result: \""+apiVersion.getUrl()+"\"");
                        }
                    }

                    //TODO perhaps check if advertised URL for this version is same as known/scanned.
                    if (urlMap.isEmpty()) {


                        //fall back to version at this URL only (should be known when GetVersion successful)
                        int versionNr = versionInfo.getApi();
                        ServerType st = new ServerType(ServerType.GeniServerRole.AM, versionNr);
                        urlMap.put(st, urlToTry);
                        scannedGeniAuthority.replaceUrls(urlMap);

                        //TODO might want to keep trying, to see if there are better URL's for GetVersion
                    } else
                        scannedGeniAuthority.replaceUrls(urlMap);

                    //success, so stop trying urls
                    resultAuthorities.add(scannedGeniAuthority);

                    if (debug)
                        System.out.println("   url successfully scanned. Saving result and not trying next url. urn="+scannedGeniAuthority.getUrnString()+"\n\n\n");
                    break;
                } catch (JFedException e) {
                    if (debug) {
                        System.out.println("   error, will skip url. "+e.getClass().getName()+"  "+e.getMessage());
                        e.printStackTrace();
                    }
                    //try next URL
                    continue;
                }
            }

            //failed to scan
            failedScans.add(argument);
        }

        if (debug) System.out.println("Printing results:");
        if (!failedScans.isEmpty()) {
            System.err.println("Scan failed for the following arguments:");
            for (String failedScan : failedScans)
                System.err.println("    "+failedScan);
        }
        AuthorityListModel model = new AuthorityListModel();
        for (SfaAuthority resAuth :resultAuthorities) {
            model.addAuthority(resAuth);
        }
        System.out.println(StoredAuthorityList.toXml(model));
//        for (SfaAuthority resAuth :resultAuthorities) {
//            System.out.println(resAuth.toXmlString(true/*omitDeclaration*/)+"\n");
//        }

        System.exit(0);
    }
}
